var ChangeCloth;
!function () {
    ChangeCloth = function () {
        ChangeCloth.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChangeCloth")
        })
    }, Laya.class(ChangeCloth, "ChangeCloth", ChangeClothUI), ChangeCloth.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChangeClothUI.uiView, e)
    };
    var e = ChangeCloth.prototype;
    e.OnShow = function (e) {
        this.mouseEnabled = !1, Laya.timer.once(2e3, this, function () {
            this.mouseEnabled = !0
        }), this._713989164 = e;
        var a = e.KingId;
        this.OnTweenBg();
        var t = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerSex,
            n = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerHeroHeadId,
            i = global.$Cfg.Common.HeadIconName[t][n];
        Laya.loader.load(i, Laya.Handler.create(this, function () {
            this.img_PlayerHead.skin = i
        }));
        var o = global.$Sys.GetTableService().GetTableRecord("throne", a), l = o.ClothPath;
        Laya.loader.load(l, Laya.Handler.create(this, function () {
            this.img_PlayerCloth.skin = l
        }));
        var h = o.FontPath;
        Laya.loader.load(h, Laya.Handler.create(this, function () {
            this.img_KingName.skin = h
        }));
        var r = o.NameFontPath;
        Laya.loader.load(r, Laya.Handler.create(this, function () {
            this.img_KingFontName.skin = r, this.hBox_ChangeText.changeItems(), this.hBox_ChangeText.centerX = 8
        })), this.hBox_ChangeText.changeItems(), GetPalaceInterface().DoGetKingById(a, function (e) {
            var a = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
            this._3781520182 = e.PlayerInfo[a].Time, this.OnTimeHandle(), Laya.timer.loop(1e3, this, this.OnTimeHandle)
        }.bind(this))
    }, e.OnClose = function () {
        Laya.timer.clear(this, this.OnTimeHandle), Laya.Tween.clearAll(this.img_PlayerBg)
    }, e.OnTimeHandle = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("throne", this._713989164.KingId).ContinuedTime;
        e = parseInt(e);
        var a = this._3781520182 + e, t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), n = a - t,
            i = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(n);
        this.lab_KingTime.text = i
    }, e.OnTweenBg = function () {
        Laya.Tween.clearAll(this.img_PlayerBg), Laya.Tween.to(this.img_PlayerBg, {rotation: this.img_PlayerBg.rotation + 360}, 3e4, null, Laya.Handler.create(this, this.OnTweenBg))
    }
}();
var ChangeHeroView;
!function () {
    ChangeHeroView = function () {
        ChangeHeroView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            return this._4122736007 && this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.panel_Hero.vScrollBarSkin = null
    }, GameCommon._s06bc1af507ebc0f5390d44bd8481b9(ChangeHeroUI, ["box_Hero", "box_Book"]), Laya.class(ChangeHeroView, "ChangeHeroView", ChangeHeroUI), ChangeHeroView.GetPreLoadResList = function (e, a) {
        var o = a.ChangeType;
        for (var t in global.$Cfg.Common.ChangeHero[o]) e.push(global.$Cfg.Common.ChangeHero[o][t]);
        var i = global.$Sys.GetTableService().GetTableRecord("specialhero", o);
        for (var t in i) {
            e.push(i[t].BgPath);
            var n = global.$Sys.GetTableService().GetTableRecord("hero", t);
            e.push(n.BodyPath), e.push(n.NameIcon)
        }
        GameCommon._s06cdfd3fa57289d2a621c2a5c34f27(ChangeHeroUI, e)
    };
    var e = ChangeHeroView.prototype;
    e.OnCreateHeroBox = function (e, a) {
        var o = e.getChildByName("img_HeroBg");
        o.skin = this._478396318[a].BgPath;
        var t = e.getChildByName("img_Hero");
        GameCommon._s8a21ef794823199e0f5d44c20a9476(t, a);
        var i = global.$Sys.GetTableService().GetTableRecord("hero", a), n = e.getChildByName("img_NameBg"),
            r = n.getChildByName("img_Name");
        r.skin = i.NameIcon;
        var l = [];
        l = l.concat(i.ForceBook, i.BrainsBook, i.PoliticalBook, i.PrestigeBook), l.sort(function (e, a) {
            var o = global.$Sys.GetTableService().GetTableRecord("book", e),
                t = global.$Sys.GetTableService().GetTableRecord("book", a);
            return o.Attribute == t.Attribute ? t.Star - o.Star : o.Attribute - t.Attribute
        });
        for (var h = e.getChildByName("vBox_Book"), m = 0, C = 315, s = 3, g = 0, d = Math.ceil(l.length / s), u = ChangeHeroView._prefabs.box_Book, b = 0; b < d && !(g >= l.length); b++) {
            for (var v = new Laya.HBox, c = 0; c < s && l[g]; c++) {
                var y = Laya.View.createComp(u);
                m = this.OnCreateBookBox(y, l[g], m), y.x = null, y.y = null, v.addChild(y), v.changeItems(), g++
            }
            v.space = 5, h.addChild(v), h.changeItems()
        }
        e.height = h.height + C;
        var B = e.getChildByName("img_Aptitude"), _ = B.getChildByName("lab_Aptitude");
        _.text = m;
        var p = e.getChildByName("img_Halo");
        p.skin = global.$Cfg.Common.ChangeHero[this._4122736007.ChangeType].HaloPath;
        var G = e.getChildByName("btn_Change"), H = e.getChildByName("img_HasChange"),
            S = G.getChildByName("img_ItemIcon"),
            f = global.$Sys.GetTableService().GetTableRecord("consume", this._478396318[a].Consume).Consume[0],
            T = GameCommon._se35db439c4ad2364b987453544666d(f, !0);
        T.name = "itemIcon";
        var x = S.getChildByName("itemIcon");
        x && (x.removeSelf(), x.destroy()), S.addChild(T);
        var k = GameCommon._sc2670617ff77eb1396f5b63c0edc88(f[0], f[1]), I = e.getChildByName("lab_Count");
        I.text = k + "/" + f[2];
        var N = global.$Api.QueryDataSource("DataRecord").GetValue(["ChangeHero", a]);
        N ? G.visible = !1 : G.visible = !0, H.visible = !G.visible, I.visible = G.visible, G.on(Laya.Event.CLICK, this, this.OnClickChange, [a, function (e) {
            return e.Result ? (G.visible = !1, I.visible = G.visible, H.visible = !0, Laya.Tween.from(H, {
                scaleX: 2,
                scaleY: 2
            }, 200, null, Laya.Handler.create(this, this.OnUpdateCount)), void GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item)) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(e)
        }.bind(this)])
    }, e.OnCreateBookBox = function (e, a, o) {
        var t = global.$Sys.GetTableService().GetTableRecord("book", a), i = e.getChildByName("lab_BookName");
        i.text = t.BookName;
        var n = e.getChildByName("lab_BookStar");
        return n.text = "x" + t.Star, o += t.Star
    }, e.OnShow = function (e) {
        this._4122736007 = e, this._478396318 = global.$Sys.GetTableService().GetTableRecord("specialhero", this._4122736007.ChangeType);
        var a = global.$Cfg.Common.ChangeHero[this._4122736007.ChangeType];
        this.img_Title.skin = a.TitlePath, this._sc9209ae0dd3fdb06533b36ec4474b1()
    }, e.OnClose = function () {
        this.vBox_Hero.destroyChildren()
    }, e._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        this.vBox_Hero.destroyChildren();
        var e = ChangeHeroView._prefabs.box_Hero;
        for (var a in this._478396318) {
            var o = Laya.View.createComp(e);
            this.OnCreateHeroBox(o, a), o.name = "box" + a, o.x = null, o.y = null, this.vBox_Hero.addChild(o)
        }
    }, e.OnUpdateCount = function () {
        for (var e in this._478396318) {
            var a = global.$Sys.GetTableService().GetTableRecord("consume", this._478396318[e].Consume).Consume[0],
                o = this.vBox_Hero.getChildByName("box" + e),
                t = GameCommon._sc2670617ff77eb1396f5b63c0edc88(a[0], a[1]), i = o.getChildByName("lab_Count");
            i.text = t + "/" + a[2]
        }
    }, e.OnClickChange = function (e, a) {
        var o = this._478396318[e].Consume, t = GetAssetManager()._s3fe93204207ebad2b8c617add33b0a(o);
        if (!t.Result) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.ChangeHeroItemNoEnough[this._4122736007.ChangeType]]});
        var i = {
            ConsumeId: o, Purpose: "进行招募", OnConfirmUse: function (o) {
                var t = {HeroId: e, ChangeType: this._4122736007.ChangeType},
                    i = ChangeHeroCmd._s6a4dba9453762113ae0d1467dd81b3(t);
                return i.Result ? void GetCmdProxy().DoCmd("ChangeHeroCmd", t, function (e) {
                    a && a(e)
                }.bind(this)) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(i)
            }.bind(this)
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", i)
    }
}();
var ChatPlayerInfo;
!function () {
    ChatPlayerInfo = function () {
        ChatPlayerInfo.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_king.renderHandler = Laya.Handler.create(this, this.OnCreateKingIcon, null, !1)
    }, Laya.class(ChatPlayerInfo, "ChatPlayerInfo", ChatPlayerInfoUI);
    var a = ChatPlayerInfo.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this.lab_power.text = gLanguage.TotalAptitude + "：" + this._4122736007.Sum, this.lab_force.text = this._4122736007.Force, this.lab_brains.text = this._4122736007.Brains, this.lab_politics.text = this._4122736007.Politics, this.lab_prestige.text = this._4122736007.Prestige, this.lab_exp.text = this._4122736007.Exp, this.lab_loveValue.text = this._4122736007.LoveValueSum, this.lab_name.text = this._4122736007.PlayerName, this.lab_loveValue.visible = !GetInspection();
        var a = global.$Sys.GetTableService().GetTableRecord("office", this._4122736007.OfficeId), e = a.OfficeIcon;
        this.img_office.skin = e;
        var t = global.$Sys.GetTableService().GetTableRecord("level", this._4122736007.Level).Name;
        this.lab_lvProgress.text = this._4122736007.Level + "." + t + "(" + this._4122736007.Stage + "-" + this._4122736007.Progress + ")", this.lab_guild.text = this._4122736007.GuildName ? this._4122736007.GuildName : "无";
        var i = global.$Cfg.Common.HeadIconName[this._4122736007.PlayerSex][this._4122736007.PlayerHeroHeadId];
        this.img_head.skin = i, this.img_hand.skin = "";
        var s, l = [];
        _.each(this._4122736007.KingsInfo, function (a) {
            var e = global.$Sys.GetTableService().GetTableRecord("throne", a.KingId), t = e.NameFontPath;
            l.push(t), a.NowChoose && (s = e.ClothPath)
        }), this.list_king.array = l, this.lab_noTitle.visible = jasmin._s2dedbd0e220887101c856bf900fc57(l), s || (this.img_hand.skin = 1 == this._4122736007.PlayerSex ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, s = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, a.Clothing)), this.img_cloth.skin = s, this.img_vip.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, this._4122736007.VipLv), this.lab_id.text = gLanguage.IdName + "：" + this._4122736007.Id
    }, a.OnCreateKingIcon = function (a, e) {
        var t = a.getChildByName("img_king");
        t.skin = this.list_king.array[e]
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChatPlayerInfo")
    }, a.OnClose = function () {
    }, ChatPlayerInfo.GetPreLoadResList = function (a, e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChatPlayerInfo.uiView, a);
        var t = global.$Cfg.Common.HeadIconName[e.PlayerSex][e.PlayerHeroHeadId];
        a.push(t)
    }
}();
var ChildAdultListView;
!function () {
    ChildAdultListView = function () {
        ChildAdultListView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.radio_type.selectHandler = new Laya.Handler(this, this.OnSelectType), this.list_NoMarried.renderHandler = new Laya.Handler(this, this.OnCreateNoMarriedItem), this.list_NoMarried.hScrollBarSkin = null, this.list_Married.hScrollBarSkin = null, this.list_Married.renderHandler = new Laya.Handler(this, this.OnCreateMarriedItem), this.list_Attr.renderHandler = new Laya.Handler(this, this.OnCreateChildAttrItem), this.btn_Marry.on(Laya.Event.CLICK, this, this.OnClickMarry), this.btn_StopMarry.on(Laya.Event.CLICK, this, this.OnStopMarry), this.btn_Request.on(Laya.Event.CLICK, this, this.OnClickRequest), this.btn_Help.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Marry"})
        }), this._4167957872 = Leo.ListExtend._sce82baeb3517cd19efefd5bad41c01(this.list_Married, {
            Type: "Radio",
            OnCreateItem: this.OnCreateMarriedItem.bind(this),
            OnStopSelectAnimation: function (e) {
                e.visible = !1
            },
            OnCanSelect: function (e, i) {
                return !!e
            }.bind(this),
            OnSelectAnimation: function (e) {
                e.visible = !0
            },
            OnGetSelectBorder: function (e) {
                return e.getChildByName("img_Select")
            },
            OnSelectItem: this.OnSelectMarriedChild.bind(this)
        }), this._3513657938 = Leo.ListExtend._sce82baeb3517cd19efefd5bad41c01(this.list_NoMarried, {
            Type: "Radio",
            OnCreateItem: this.OnCreateNoMarriedItem.bind(this),
            OnStopSelectAnimation: function (e) {
                e.visible = !1
            },
            OnCanSelect: function (e, i) {
                return !!e
            }.bind(this),
            OnSelectAnimation: function (e) {
                e.visible = !0
            },
            OnGetSelectBorder: function (e) {
                return e.getChildByName("img_Select")
            },
            OnSelectItem: this.OnSelectNoMarriedChild.bind(this)
        })
    }, Laya.class(ChildAdultListView, "ChildAdultListView", ChildAdultListUI), ChildAdultListView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildAdultListUI.uiView, e)
    };
    var e = ChildAdultListView.prototype;
    e.OnClickMarry = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarrySelectView", {ChildId: this._200639267})
    }, e.OnStopMarry = function () {
        var e = this._200639267;
        jasmin.Info("取消联姻" + e), GetDataChildInterface().DoCancelMarry(e, function (i) {
            i.Result && GetDataChildInterface().event("ChildCancelMarry" + e)
        })
    }, e.OnClickRequest = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryRequestView", {OnClose: this.OnCloseRequest})
    }, e.OnCloseRequest = function () {
    }, e.OnSelectNoMarriedChild = function (e, i, t) {
        this._s8e65db3cfd99b636f8ec018c3d01ac(t)
    }, e._s8e65db3cfd99b636f8ec018c3d01ac = function (e) {
        this._200639267 = e.Id;
        var i = e.BeautyId, t = global.$Api.QueryDataSource("DataBeauty")._s08ba6a1ba12968cac41a4297977513(i),
            a = global.$Sys.GetTableService().GetTableRecord("beauty", i), r = global.$Cfg.Language,
            l = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(e.Id);
        if (this.list_Attr.array = [{
            Key: r.ChildAttrLv,
            KeyColor: "#8b6c57",
            Value: e.Lv,
            ValueColor: "#4b9f72"
        }, {
            Key: r.ChildAttrForce,
            KeyColor: "#8b6c57",
            Value: e.Attribute[1],
            ValueColor: "#4b9f72"
        }, {
            Key: r.ChildAttrBrain,
            KeyColor: "#8b6c57",
            Value: e.Attribute[2],
            ValueColor: "#4b9f72"
        }, {Key: r.ChildAttrFont, KeyColor: "#8b6c57", Value: l, ValueColor: "#4b9f72"}, {
            Key: r.ChildAttrPolitical,
            KeyColor: "#8b6c57",
            Value: e.Attribute[3],
            ValueColor: "#4b9f72"
        }, {
            Key: r.ChildAttrPrestige,
            KeyColor: "#8b6c57",
            Value: e.Attribute[4],
            ValueColor: "#4b9f72"
        }, {
            Key: r.ChildAttrMother,
            KeyColor: "#8b6c57",
            Value: a.Name,
            ValueColor: "#dc4d4d"
        }, {
            Key: r.ChildAttrLoveValue,
            KeyColor: "#8b6c57",
            Value: t.LoveValue,
            ValueColor: "#dc4d4d"
        }], this.lab_Name.text = e.Name, e.MarryRequest) {
            if (this.img_Qipao.visible = !0, 1 == e.MarryRequest.Type) this.html_Qipao.innerHTML = r.ChildMarryServerHtml; else {
                var o = e.MarryRequest.UserInfo,
                    n = jasmin._se91cf955e91eaa1aa510d4335edd4a(r.ChildMarryUserHtml, o.UserName, o.UserId);
                this.html_Qipao.innerHTML = n
            }
            this.html_Qipao.x = (this.img_Qipao.width - this.html_Qipao.getBounds().width) / 2, this.html_Qipao.y = (this.img_Qipao.height - this.html_Qipao.getBounds().height) / 2, this.btn_StopMarry.visible = !0, this.img_CountDown.visible = !0, this.btn_Marry.visible = !1
        } else this.btn_StopMarry.visible = !1, this.img_CountDown.visible = !1, this.btn_Marry.visible = !0, this.img_Qipao.visible = !1;
        GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_NoMarryBody, e.ChildType, e.Sex), this._s504e1bb882d87474d5e679d81997a4()
    }, e.OnSelectMarriedChild = function (e, i, t) {
        this._sfb408e95c6c2f05e9eb7951a1bc17d(t)
    }, e._sfb408e95c6c2f05e9eb7951a1bc17d = function (e) {
        var i = global.$Cfg.Language;
        this._s4d38693a39d4d74881ec76b1e50182(this.view_Qingjia, {
            Key: i.ChildAttrQingjia,
            KeyColor: "#735440",
            Value: e.Spouse.UserName,
            ValueColor: "#dd5a57"
        });
        var t = e.Spouse.ChildAttribute, a = 0;
        _.each(t, function (e) {
            a += e
        }), this._s4d38693a39d4d74881ec76b1e50182(this.view_Jiacheng, {
            Key: i.ChildAttrJiacheng,
            KeyColor: "#735440",
            Value: a,
            ValueColor: "#4b9f73"
        });
        var r = e.Spouse.Time;
        if (r) {
            var l = new Date(r);
            this.view_Time.visible = !0, this._s4d38693a39d4d74881ec76b1e50182(this.view_Time, {
                Key: jasmin._se91cf955e91eaa1aa510d4335edd4a(i.ChildAttrMarryTime, l.getFullYear(), l.getMonth() + 1, l.getDate()),
                KeyColor: "#735440",
                Value: ""
            })
        } else this.view_Time.visible = !1;
        GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_MarryBody1, e.ChildType, e.Sex), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_MarryBody2, e.Spouse.ChildType, e.Spouse.ChildSex)
    }, e.OnSelectType = function (e) {
        this.btn_Marry.visible = 0 == e, 0 == e ? this._sa99d8a4c02aa63edd5d8c0553ec42b() : this._s1350322fc0289061dcdc5b3edd256d()
    }, e._sa99d8a4c02aa63edd5d8c0553ec42b = function () {
        this._s8796fdc2c0b5eabb3ed48fe8f13ef5(), this._s3dde45ff8b9e628289e0f6d37903b8(!1), this.img_MarryBody1.visible = !1, this.img_MarryBody2.visible = !1, this.sp_Married.visible = !1;
        var e = {DataSource: GetDataChildInterface()._s56db96b734ebcc83e745d9407e46a7()};
        e.SelectItemIndex = 0, e.RetainSelect = !0, _.size(e.DataSource) > 0 ? (this.img_NoMarryBody.visible = !0, this.img_Qipao.visible = !0, this.sp_NoMarried.visible = !0, this.btn_Name.visible = !0) : (this.img_NoMarryBody.visible = !1, this.img_Qipao.visible = !1, this.sp_NoMarried.visible = !1, this.btn_Name.visible = !1), this._3513657938._se06d3ef81daf6f8c47c34c7ab850df(e)
    }, e._s3dde45ff8b9e628289e0f6d37903b8 = function (e) {
        this.list_Married.visible = e, this.list_NoMarried.visible = !e, this.sp_NoMarried.visible = !e, this.img_NoMarryBody.visible = !e, this.img_Qipao.visible = !e, this.btn_Name.visible = !e
    }, e._s1350322fc0289061dcdc5b3edd256d = function () {
        this._s3dde45ff8b9e628289e0f6d37903b8(!0);
        var e = {DataSource: GetDataChildInterface()._s01d617ae6d6c4410ea35279ef1fc22()};
        e.SelectItemIndex = 0, e.RetainSelect = !0, _.size(e.DataSource) > 0 ? (this.img_MarryBody1.visible = !0, this.img_MarryBody2.visible = !0, this.sp_Married.visible = !0) : (this.img_MarryBody1.visible = !1, this.img_MarryBody2.visible = !1, this.sp_Married.visible = !1), this._4167957872._se06d3ef81daf6f8c47c34c7ab850df(e)
    }, e.OnShow = function (e) {
        this.list_NoMarried.array = [], 0 == this.radio_type.selectedIndex ? this._sa99d8a4c02aa63edd5d8c0553ec42b() : this.radio_type.selectedIndex = 0;
        var i = GetDataChildInterface()._s56db96b734ebcc83e745d9407e46a7();
        this._1758518863 = [], _.each(i, function (e) {
            this._1758518863.push(e.Id)
        }.bind(this)), Laya.timer.loop(1e3, this, this.OnLoop), Laya.timer.loop(1e4, this, this.OnQueryRequest), this.OnCheckMarry(), GetDataChildInterface().on("GetNewMarry", this, this.OnGetNewMarry), GetDataChildInterface().on("NewMarry", this, this.OnNewMarry), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.btn_Request,
            NodeName: "btn_Request",
            OnCheckState: function () {
                var e = global.$Api.QueryDataSource("DataChild").GetValue("MarryRequest");
                return !jasmin._s2dedbd0e220887101c856bf900fc57(e)
            }.bind(this),
            Group: "Child",
            cover: !0
        })
    }, e.OnGetNewMarry = function () {
        this.OnNewMarry(), this.OnCheckMarry()
    }, e.OnNewMarry = function () {
        this.OnClose(), this.OnShow()
    }, e.OnQueryRequest = function () {
        GetDataChildInterface().DoQueryRequest()
    }, e.OnCheckMarry = function () {
        var e = GetDataChildInterface()._s01d617ae6d6c4410ea35279ef1fc22(), i = _.filter(e, function (e) {
            return e.Spouse.New
        }), t = _.first(i);
        t && GetDataChildInterface().DoNewMarry(t.Id, function (e) {
            e.Result && GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryRewardView", {
                ChildId: t.Id,
                OnClose: function () {
                    this.OnCheckMarry()
                }.bind(this)
            })
        }.bind(this))
    }, e.OnClose = function () {
        this._200639267 = null, this._s8796fdc2c0b5eabb3ed48fe8f13ef5(), _.each(this._1758518863, function (e) {
            GetDataChildInterface().off("ChildMarrySend" + e, this, this.OnChildMarrySend), GetDataChildInterface().off("ChildCancelMarry" + e, this, this.OnChildCancelMarry)
        }.bind(this)), GetDataChildInterface().off("NewMarry", this, this.OnNewMarry), GetDataChildInterface().off("GetNewMarry", this, this.OnGetNewMarry), Laya.timer.clear(this, this.OnLoop), Laya.timer.clear(this, this.OnQueryRequest)
    }, e.OnLoop = function () {
        this._s504e1bb882d87474d5e679d81997a4()
    }, e._s504e1bb882d87474d5e679d81997a4 = function () {
        if (0 == this.radio_type.selectedIndex && this._200639267) {
            var e = global.$Cfg.Language,
                i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._200639267);
            if (i.MarryRequest) {
                var t = i.MarryRequest.Time, a = global.$Cfg.Common.Child.MarryRequestValidTime,
                    r = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
                if (i.MarryRequest.Refuse) return void(this.lab_CountDown.text = global.$Cfg.Language.ChildMarryRefused);
                if (t + a < r) return void(this.lab_CountDown.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(e.CountDownFont, "00:00:00"));
                var l = t + a - r;
                this.lab_CountDown.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(e.CountDownFont, GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(l))
            }
        }
    }, e.OnCreateChildAttrItem = function (e, i) {
        var t = e.dataSource, a = e.getChildByName("view_Att");
        a.lab1.text = t.Key, a.lab1.color = t.KeyColor, a.lab2.text = t.Value, a.lab2.color = t.ValueColor, a.box.changeItems()
    }, e._s4d38693a39d4d74881ec76b1e50182 = function (e, i) {
        e.lab1.text = i.Key, e.lab2.text = i.Value, i.KeyColor && (e.lab1.color = i.KeyColor), i.ValueColor && (e.lab2.color = i.ValueColor), e.box.changeItems()
    }, e.OnCreateMarriedItem = function (e, i) {
        this._4167957872._sf4eade5683bb979fadd97b7d469c4d(e, i);
        var t = e.dataSource, a = global.$Cfg.Language, r = e.getChildByName("img_Body1"),
            l = e.getChildByName("img_Body2"), o = e.getChildByName("view_ChildName"),
            n = e.getChildByName("view_ChildType"), h = e.getChildByName("view_ChildAttr"),
            s = e.getChildByName("view_SpouseChildName"), d = e.getChildByName("view_SpouseChildType"),
            C = e.getChildByName("view_SpouseChildAttr"), a = global.$Cfg.Language,
            y = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(t.Id);
        this._s4d38693a39d4d74881ec76b1e50182(h, {
            Key: a.ChildAttrFont,
            KeyColor: "#8b6c57",
            Value: y,
            ValueColor: "#268458"
        });
        var u = global.$Sys.GetTableService().GetTableRecord("child_type", t.ChildType);
        this._s4d38693a39d4d74881ec76b1e50182(n, {
            Key: a.ChildAttrType,
            KeyColor: "#8b6c57",
            Value: u.Name,
            ValueColor: "#268458"
        }), this._s4d38693a39d4d74881ec76b1e50182(o, {
            Key: t.Name,
            KeyColor: 1 == t.Sex ? "#3d7ca8" : "#e06863",
            Value: ""
        }), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(r, t.ChildType, t.Sex);
        var m = t.Spouse, c = m.ChildAttribute, b = 0;
        _.each(c, function (e) {
            b += e
        }), this._s4d38693a39d4d74881ec76b1e50182(C, {
            Key: a.ChildAttrFont,
            KeyColor: "#8b6c57",
            Value: b,
            ValueColor: "#268458"
        });
        var u = global.$Sys.GetTableService().GetTableRecord("child_type", m.ChildType);
        this._s4d38693a39d4d74881ec76b1e50182(d, {
            Key: a.ChildAttrType,
            KeyColor: "#8b6c57",
            Value: u.Name,
            ValueColor: "#268458"
        }), this._s4d38693a39d4d74881ec76b1e50182(s, {
            Key: m.ChildName,
            KeyColor: 1 == m.ChildSex ? "#3d7ca8" : "#e06863",
            Value: ""
        }), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(l, m.ChildType, m.ChildSex)
    }, e._s6e3b3453ab5acad99fa310fbe68dd7 = function (e) {
    }, e._s8796fdc2c0b5eabb3ed48fe8f13ef5 = function () {
    }, e.OnCreateNoMarriedItem = function (e, i) {
        this._3513657938._sf4eade5683bb979fadd97b7d469c4d(e, i);
        var t = global.$Cfg.Language, a = e.dataSource, r = e.getChildByName("lab_MyChildName"),
            l = e.getChildByName("lab_MyChildAttribute"), o = e.getChildByName("lab_MyChildType"),
            n = e.getChildByName("img_Body"), h = e.getChildByName("img_Man"), s = e.getChildByName("img_Woman"),
            d = e.getChildByName("img_Refuse"), C = e.getChildByName("img_Marrying"),
            y = e.getChildByName("img_MarryInvalid");
        if (a.MarryRequest) if (a.MarryRequest.Refuse) d.visible = !0, C.visible = !1, y.visible = !1; else {
            d.visible = !1;
            var u = a.MarryRequest.Time, m = global.$Cfg.Common.Child.MarryRequestValidTime,
                c = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
            u + m < c ? (y.visible = !0, C.visible = !1, this._s6e3b3453ab5acad99fa310fbe68dd7(y), this.lab_CountDown.text = "00:00:00") : (y.visible = !1, C.visible = !0, this._s6e3b3453ab5acad99fa310fbe68dd7(C))
        } else d.visible = !1, C.visible = !1, y.visible = !1;
        r.text = a.Name, h.visible = 1 == a.Sex, s.visible = 1 != a.Sex;
        var b = global.$Sys.GetTableService().GetTableRecord("child_type", a.ChildType);
        o.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(t.ChildMarryType, b.Name);
        var M = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(a.Id);
        l.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(t.ChildMarryAttribute, M), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(n, a.ChildType, a.Sex), GetDataChildInterface().on("ChildMarrySend" + a.Id, this, this.OnChildMarrySend, [e, a.Id]), GetDataChildInterface().on("ChildCancelMarry" + a.Id, this, this.OnChildCancelMarry, [e, a.Id])
    }, e.OnChildMarrySend = function (e, i) {
        var t = e.getChildByName("img_Marrying");
        t.visible = !0, this._s6e3b3453ab5acad99fa310fbe68dd7(t);
        var a = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(i);
        this._s8e65db3cfd99b636f8ec018c3d01ac(a)
    }, e.OnChildCancelMarry = function (e, i) {
        var t = e.getChildByName("img_Refuse"), a = e.getChildByName("img_Marrying"),
            r = e.getChildByName("img_MarryInvalid");
        a.visible = !1, t.visible = !1, r.visible = !1;
        var l = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(i);
        this._s8e65db3cfd99b636f8ec018c3d01ac(l)
    }
}();
var ChildAdultView;
!function () {
    ChildAdultView = function () {
        ChildAdultView.super(this), this.list_Attribute.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildAdultView")
        })
    }, Laya.class(ChildAdultView, "ChildAdultView", ChildAdultUI), ChildAdultView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildAdultUI.uiView, e)
    };
    var e = ChildAdultView.prototype;
    e.OnClose = function () {
        this.m_OnClose()
    }, e.OnShow = function (e) {
        this.mouseEnabled = !1, Laya.timer.once(1e3, this, function () {
            this.mouseEnabled = !0
        }), this.m_OnClose = e.OnClose;
        var t = e.ChildId, i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(t),
            a = i.ChildType, l = global.$Sys.GetTableService().GetTableRecord("child_type", a), u = l.TypePath;
        this.ui_Tag.skin = u, GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_Body, i.ChildType, i.Sex), this.lab_Name.text = i.Name;
        var d = i.BeautyId, n = GetDataTransfer().GetTableRecord("beauty", d), o = n.Name, h = [];
        h.push({Key: gLanguage.ChildAdult_Mother, Value: o});
        var r = i.Attribute[CommonEnum.HeroAttribute.FORCE], s = i.Attribute[CommonEnum.HeroAttribute.BRAINS],
            C = i.Attribute[CommonEnum.HeroAttribute.POLITICS], m = i.Attribute[CommonEnum.HeroAttribute.PRESTIGE],
            A = r + s + C + m;
        h.push({Key: gLanguage.TotalAptitude, Value: A}), h.push({
            Key: gLanguage.ChildAdult_Force,
            Value: r
        }), h.push({Key: gLanguage.ChildAdult_Brains, Value: s}), h.push({
            Key: gLanguage.ChildAdult_Politics,
            Value: C
        }), h.push({Key: gLanguage.ChildAdult_Prestige, Value: m}), this.list_Attribute.array = h
    }, e.OnCreateItem = function (e, t) {
        var i = e.dataSource;
        e.getChildByName("lab_Key").text = i.Key, e.getChildByName("lab_Value").text = i.Value
    }
}();
var ChildBirthView;
!function () {
    ChildBirthView = function () {
        ChildBirthView.super(this), this.btn_Ok.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildBirthView"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildView")
        }), this.btn_Cancel.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildBirthView")
        })
    }, Laya.class(ChildBirthView, "ChildBirthView", ChildBirthUI), ChildBirthView.GetPreLoadResList = function (i) {
        i.push("res/role/child/z_zisi_0.png"), i.push("res/role/child/z_zisi_11.png"), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildBirthUI.uiView, i)
    };
    var i = ChildBirthView.prototype;
    i.OnShow = function (i) {
        var t = i.ChildId, e = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(t),
            h = 1 == e.Sex;
        this.ui_Boy.visible = h, this.ui_Girl.visible = !h, this.img_Body.skin = h ? "res/role/child/z_zisi_0.png" : "res/role/child/z_zisi_11.png";
        var l = e.Aptitude;
        this.ui_Aptitude.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ChildAptitudeFont, l)
    }
}();
var ChildChangeNameView;
!function () {
    ChildChangeNameView = function () {
        ChildChangeNameView.super(this), this.btn_Roll.on(Laya.Event.CLICK, this, this.OnClickRoll), this.btn_Ok.on(Laya.Event.CLICK, this, this.OnClickOk), this.btn_Cancel.on(Laya.Event.CLICK, this, this.OnClickCancel)
    }, Laya.class(ChildChangeNameView, "ChildChangeNameView", ChildChangeNameUI);
    var i = ChildChangeNameView.prototype;
    i.OnShow = function (i) {
        this._2886374030 = i.ChildId;
        var e = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._2886374030), a = e.Name;
        a ? this.ui_Input.text = a : this.OnClickRoll(), this._2748965782 = !a, this.lab_Info.visible = !this._2748965782, this._29901779 = i.OnOk, this.lab_CostGold.text = global.$Cfg.Common.Child.ChangeNameConsume[2]
    }, i.OnClickOk = function () {
        var i = this.ui_Input.text.trim();
        if ("" != i) {
            var e = Leo.GetDirtyWordsFilter()._s95d3edab3bfd008f58b6e1b086ebca(i);
            if (!e) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CreateRoleNameError]});
            var a = function (i) {
                i.Result && (this._sdfe99ac092cf7083e4732bdb919ef8(), this._29901779 && this._29901779())
            }.bind(this);
            return this._2748965782 ? void GetDataChildInterface().DoInitName(this._2886374030, i, a) : void GetDataChildInterface().DoChangeName(this._2886374030, i, a)
        }
    }, i.OnClickCancel = function () {
        this._sdfe99ac092cf7083e4732bdb919ef8()
    }, i._sdfe99ac092cf7083e4732bdb919ef8 = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildChangeNameView")
    }, i.OnClickRoll = function () {
        var i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._2886374030),
            e = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), a = e[0], t = a, l = i.Sex ? 1 : 2,
            n = global.$Sys.GetTableService().GetTableRecord("player_name", l),
            h = Math.round(Math.random() * (_.size(n) - 1) + 1), C = n[h].Name;
        this.ui_Input.text = t + C
    }
}();
var ChildChooseToMarryView;
!function () {
    ChildChooseToMarryView = function () {
        ChildChooseToMarryView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildChooseToMarryView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list.vScrollBarSkin = null, this.btn_Sort.on(Laya.Event.CLICK, this, this.OnSort)
    }, Laya.class(ChildChooseToMarryView, "ChildChooseToMarryView", ChildChooseToMarryUI), ChildChooseToMarryView.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildChooseToMarryUI.uiView, t)
    };
    var t = ChildChooseToMarryView.prototype;
    t.OnCreateItem = function (t, e) {
        var i = t.dataSource, a = t.getChildByName("img_Body"), o = t.getChildByName("lab_Name"),
            r = t.getChildByName("btn_Marry"), l = t.getChildByName("lab_Attribute"), n = t.getChildByName("img_Type");
        GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(a, i.ChildType, i.Sex), o.text = i.Name, l.text = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(i.Id);
        var h = global.$Sys.GetTableService().GetTableRecord("child_type", i.ChildType);
        n.skin = h.TypePath2, r.on(Laya.Event.CLICK, this, this.OnMarry, [t, i])
    }, t.OnMarry = function (t, e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryConsumeView", {
            ChildInfo: this._2895210461,
            MyChildId: e.Id,
            OnChoose: function (t, e, i) {
                GetDataChildInterface().DoAcceptUserMarry(t, e, i, function (e) {
                    e.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryRequestView"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryConsumeView"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildChooseToMarryView"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryRewardView", {
                        ChildId: t,
                        OnClose: function () {
                        }.bind(this)
                    }), GetDataChildInterface().event("NewMarry"))
                })
            }.bind(this)
        })
    }, t.OnShow = function (t) {
        this._2895210461 = t.SpouseInfo, this._3293960808 = !0, this.btn_Sort.label = global.$Cfg.Language.ChildAttrSortDown, this._s2e6efe8bf2e1ecbf2b82b708dbf10e()
    }, t._s2e6efe8bf2e1ecbf2b82b708dbf10e = function () {
        var t = this._2895210461.ChildType, e = this._2895210461.ChildSex,
            i = GetDataChildInterface()._s56db96b734ebcc83e745d9407e46a7(), a = _.filter(i, function (i) {
                return i.ChildType == t && i.Sex != e
            });
        a = _.values(a), this._3293960808 ? a.sort(function (t, e) {
            var i = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(t.Id),
                a = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(e.Id);
            return a - i
        }) : a.sort(function (t, e) {
            var i = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(t.Id),
                a = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(e.Id);
            return i - a
        }), this.list.array = a
    }, t.OnSort = function () {
        this._3293960808 = !this._3293960808, this.btn_Sort.label = this._3293960808 ? global.$Cfg.Language.ChildAttrSortDown : global.$Cfg.Language.ChildAttrSortUp, this._s2e6efe8bf2e1ecbf2b82b708dbf10e()
    }
}();
var ChildMarryConsumeView;
!function () {
    ChildMarryConsumeView = function () {
        ChildMarryConsumeView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryConsumeView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem)
    }, Laya.class(ChildMarryConsumeView, "ChildMarryConsumeView", ChildMarryConsumeUI), ChildMarryConsumeView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildMarryConsumeUI.uiView, e)
    };
    var e = ChildMarryConsumeView.prototype;
    e.OnCreateItem = function (e, i) {
        var a = e.dataSource, o = e.getChildByName("img_Icon"), t = e.getChildByName("lab_Consume"),
            C = e.getChildByName("lab_CurCount"), n = e.getChildByName("btn_Choose"),
            r = GameCommon._sd829d199a08f4ea0e8f4acd2566c18([a]), l = _.first(r), s = l[0], h = l[1];
        t.text = h + s;
        var d;
        d = 2 == a[0] ? global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(a[1]) : global.$Api.QueryDataSource("DataBase").GetValue("Gold");
        var m = GameCommon._s66eb52e60b9feb53711943e638c9c3(a[0], a[1]);
        o.destroyChildren(), o.addChild(m), C.text = d, n.on(Laya.Event.CLICK, this, this.OnClickChoose, [i])
    }, e.OnClickChoose = function (e) {
        this._2694527272(this._1532737176, this._4221723320, e)
    }, e.OnShow = function (e) {
        this._1532737176 = e.MyChildId, this._4221723320 = e.ChildInfo, this._2694527272 = e.OnChoose;
        var i = this._4221723320.ChildType, a = global.$Sys.GetTableService().GetTableRecord("child_type", i),
            o = a.MarryCustom, t = global.$Sys.GetTableService().GetTableRecord("consume", o), C = t.Consume;
        this.list.array = C
    }
}();
var ChildMarryRequestView;
!function () {
    ChildMarryRequestView = function () {
        ChildMarryRequestView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryRequestView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list.vScrollBarSkin = null, this.btn_OneKeyRefuse.on(Laya.Event.CLICK, this, this.OnOneKeyRefuse)
    }, Laya.class(ChildMarryRequestView, "ChildMarryRequestView", ChildMarryRequestUI), ChildMarryRequestView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildMarryRequestUI.uiView, e)
    };
    var e = ChildMarryRequestView.prototype;
    e.OnClose = function () {
        this.m_OnClose && this.m_OnClose()
    }, e.OnShow = function (e) {
        this.m_OnClose = e.OnClose, this._s2e6efe8bf2e1ecbf2b82b708dbf10e(), this.ui_labGold.text = global.$Api.QueryDataSource("DataBase").GetValue("Gold")
    }, e._s2e6efe8bf2e1ecbf2b82b708dbf10e = function () {
        var e = global.$Api.QueryDataSource("DataChild").GetValue("MarryRequest"), t = _.values(e);
        this.list.array = t
    }, e.OnCreateItem = function (e, t) {
        var i = e.dataSource, a = e.getChildByName("img_Body"), n = e.getChildByName("lab_Name"),
            s = e.getChildByName("btn_Refuse"), l = e.getChildByName("btn_Select"), r = e.getChildByName("img_Type"),
            o = e.getChildByName("lab_Attribute"), h = e.getChildByName("lab_Parent"),
            u = (e.getChildByName("img_Icon"), e.getChildByName("lab_Consume"));
        n.text = i.ChildName;
        var C = i.ChildAttribute, d = 0;
        _.each(C, function (e) {
            d += e
        }), o.text = d, h.text = i.UserName;
        var y = global.$Sys.GetTableService().GetTableRecord("child_type", i.ChildType);
        r.skin = y.TypePath2;
        var c = global.$Sys.GetTableService().GetTableRecord("consume", "MarrageLv" + i.ChildType).Consume, m = "";
        for (var R in c) {
            var f = GameCommon._sd829d199a08f4ea0e8f4acd2566c18([c[R]]), b = _.first(f), g = b[0], G = b[1];
            m += G + g, R != jasmin._s68574baea387d56114fc6a81d89c67(c) - 1 && (m += "/")
        }
        u.text = m, GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(a, i.ChildType, i.ChildSex), s.on(Laya.Event.CLICK, this, this.OnRefuse, [e, i]), l.on(Laya.Event.CLICK, this, this.OnSelect, [e, i])
    }, e.OnRefuse = function (e, t) {
        GetDataChildInterface().DoRefuseRequest(t.UserId, t.ChildId, function (e) {
            e.Result && this._s2e6efe8bf2e1ecbf2b82b708dbf10e()
        }.bind(this))
    }, e.OnOneKeyRefuse = function () {
        GetDataChildInterface().DoOneKeyRefuseRequest(function (e) {
            e.Result && this._s2e6efe8bf2e1ecbf2b82b708dbf10e()
        }.bind(this))
    }, e.OnSelect = function (e, t) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildChooseToMarryView", {SpouseInfo: t})
    }
}();
var ChildMarryRewardView;
!function () {
    ChildMarryRewardView = function () {
        ChildMarryRewardView.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryRewardView")
        })
    }, Laya.class(ChildMarryRewardView, "ChildMarryRewardView", ChildMarryRewardUI), ChildMarryRewardView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildMarryRewardUI.uiView, e)
    };
    var e = ChildMarryRewardView.prototype;
    e.OnShow = function (e) {
        this.mouseEnabled = !1, Laya.timer.once(2e3, this, function () {
            this.mouseEnabled = !0
        }), this.m_OnClose = e.OnClose;
        var t = e.ChildId, a = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(t),
            i = global.$Cfg.Language;
        this._s4d38693a39d4d74881ec76b1e50182(this.view_Name, {
            Key: a.Name,
            KeyColor: 1 == a.Sex ? "#94c3d5" : "#eb71d6",
            Value: ""
        }), this._s4d38693a39d4d74881ec76b1e50182(this.view_Parent, {
            Key: i.ChildAttrFather,
            KeyColor: "#e3ce99",
            Value: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
            ValueColor: "#e3ce99"
        }), this._s4d38693a39d4d74881ec76b1e50182(this.view_Attribute, {
            Key: i.ChildAttrFont,
            KeyColor: "#e3ce99",
            Value: global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(t),
            ValueColor: "#e3ce99"
        }), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_Body1, a.ChildType, a.Sex);
        var r = a.Spouse;
        this._s4d38693a39d4d74881ec76b1e50182(this.view_SpouseName, {
            Key: r.ChildName,
            KeyColor: 1 == r.ChildSex ? "#94c3d5" : "#eb71d6",
            Value: ""
        }), this._s4d38693a39d4d74881ec76b1e50182(this.view_SpouseParent, {
            Key: i.ChildAttrFather,
            KeyColor: "#e3ce99",
            Value: r.UserName,
            ValueColor: "#e3ce99"
        });
        var l = r.ChildAttribute, o = 0;
        _.each(l, function (e) {
            o += e
        }), this._s4d38693a39d4d74881ec76b1e50182(this.view_SpouseAttribute, {
            Key: i.ChildAttrFont,
            KeyColor: "#e3ce99",
            Value: o,
            ValueColor: "#e3ce99"
        }), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_Body2, r.ChildType, r.ChildSex);
        var h = new Leo.ImageActionManager({Image: this.img_Heart});
        h._sc95f42251335b3aa0013090797aec9("Breather", {
            BreatherTime: 2e3,
            ScaleX: 1.4,
            ScaleY: 1.4
        }), h._s2e4033b88e999ce7271844dbf3b2dc(), this._3186100802 = h
    }, e.OnClose = function () {
        this._3186100802._s54107fed721f2f5f6636c3b2747bef(), this.m_OnClose && this.m_OnClose()
    }, e._s4d38693a39d4d74881ec76b1e50182 = function (e, t) {
        e.lab1.text = t.Key, e.lab2.text = t.Value, t.KeyColor && (e.lab1.color = t.KeyColor), t.ValueColor && (e.lab2.color = t.ValueColor), e.box.changeItems()
    }
}();
var ChildMarrySelectView;
!function () {
    ChildMarrySelectView = function () {
        ChildMarrySelectView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarrySelectView")
        }), this.btn_ZQ.on(Laya.Event.CLICK, this, this.OnClickZQ), this.btn_TQ.on(Laya.Event.CLICK, this, this.OnClickTQ)
    }, Laya.class(ChildMarrySelectView, "ChildMarrySelectView", ChildMarrySelectUI), ChildMarrySelectView.GetPreLoadResList = function (i) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildMarrySelectUI.uiView, i)
    };
    var i = ChildMarrySelectView.prototype;
    i.OnClickZQ = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarrySelectView"), GetDataChildInterface()._sa51231bb9cc639f4ed409050395cad(this._2886374030)
    }, i.OnClickTQ = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarrySelectView"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildTiqinView", {
            ChildId: this._2886374030,
            OnChoose: function () {
            }
        })
    }, i.OnShow = function (i) {
        var e = i.ChildId;
        this._2886374030 = e
    }
}();
var ChildServerMarryListView;
!function () {
    ChildServerMarryListView = function () {
        ChildServerMarryListView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildServerMarryListView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.btn_Refresh.on(Laya.Event.CLICK, this, this.OnClickRefresh)
    }, Laya.class(ChildServerMarryListView, "ChildServerMarryListView", ChildServerMarryListUI), ChildServerMarryListView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildServerMarryListUI.uiView, e)
    };
    var e = ChildServerMarryListView.prototype;
    e.OnCreateItem = function (e, i) {
        var t = global.$Cfg.Language, a = e.dataSource, r = e.getChildByName("lab_Name"),
            l = e.getChildByName("lab_Parent"), n = e.getChildByName("lab_Type"), h = e.getChildByName("lab_Attribute"),
            s = e.getChildByName("img_Icon"), o = e.getChildByName("btn_Marry");
        r.text = a.ChildName;
        var d = a.ChildType, C = global.$Sys.GetTableService().GetTableRecord("child_type", d);
        n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(t.ChildMarryType, C.Name);
        var u = a.ChildAttribute, y = 0;
        _.each(u, function (e) {
            y += e
        }), h.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(t.ChildMarryAttribute, y), l.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(t.ChildMarryParent, a.UserName), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(s, d, a.ChildSex), o.on(Laya.Event.CLICK, this, this.OnClickMarry, [a])
    }, e.OnClickMarry = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryConsumeView", {
            ChildInfo: e,
            MyChildId: this._2886374030,
            OnChoose: this.OnDoMarry.bind(this)
        })
    }, e.OnDoMarry = function (e, i, t) {
        GetDataChildInterface().DoAcceptServerMarry(e, i, t, function (t) {
            t.Result && (GetDataChildInterface()._se6db896a86413ff1e33cbbad6fa4ef(i), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildMarryConsumeView"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildServerMarryListView"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildMarryRewardView", {
                ChildId: e,
                OnClose: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildAdultListView")
                }.bind(this)
            }), GetDataChildInterface().event("NewMarry"))
        })
    }, e.OnShow = function (e) {
        var i = e.ChildId;
        this._2886374030 = i, this.ui_labGold.text = global.$Api.QueryDataSource("DataBase").GetValue("Gold"), this._s98b318da65992d84e8abbf736bfba7(), this._s3c7b166750315af72018833de447b4(), this.OnLoop(), Laya.timer.loop(1e3, this, this.OnLoop)
    }, e._s13555691091c1ae608d3ed2e7469ad = function () {
        var e = this._2886374030, i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e),
            t = i.ChildType, a = i.Sex, r = global.$Api.QueryDataSource("DataChild").GetValue("ServerMarryList"),
            l = r[t][a], n = global.$Cfg.Common.Child.ServerMarryListRefreshCD,
            h = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), s = l + n - h;
        return s
    }, e.OnLoop = function () {
        var e = this._s13555691091c1ae608d3ed2e7469ad();
        if (e <= 0) this.lab_FreeRefresh.visible = !0, this.lab_CountDownFont.visible = !1, this.lab_CountDown.visible = !1; else {
            this.lab_FreeRefresh.visible = !1, this.lab_CountDownFont.visible = !0, this.lab_CountDown.visible = !0;
            var i = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(e);
            this.lab_CountDown.text = i
        }
    }, e.OnClickRefresh = function () {
        var e, i = this._2886374030, t = this._s13555691091c1ae608d3ed2e7469ad();
        return (e = t > 0) ? void GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeId: global.$Cfg.Common.Child.ServerMarryListRefreshConsume,
            UserData: {},
            Purpose: gLanguage.ChildRefreshMarryListFont,
            OnConfirmUse: function (t) {
                GetDataChildInterface().DoGetServerMarryList(i, e, function (e) {
                    e && (this._s3c7b166750315af72018833de447b4(), this.ui_labGold.text = global.$Api.QueryDataSource("DataBase").GetValue("Gold"))
                }.bind(this))
            }.bind(this)
        }) : void GetDataChildInterface().DoGetServerMarryList(i, e, function (e) {
            e && this._s3c7b166750315af72018833de447b4()
        }.bind(this))
    }, e.OnClose = function () {
        Laya.timer.clear(this, this.OnLoop)
    }, e._s3c7b166750315af72018833de447b4 = function () {
        var e = GetDataChildInterface()._s80581b9970e907a0ee0b3e53ed5687(this._2886374030);
        this.list.array = [], this.list.array.startIndex = 0, this.list.array = e
    }, e._s98b318da65992d84e8abbf736bfba7 = function () {
        var e = global.$Cfg.Language,
            i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._2886374030),
            t = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
        this.lab_ChildName.text = i.Name;
        var a = i.ChildType, r = global.$Sys.GetTableService().GetTableRecord("child_type", a);
        this.lab_Type.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(e.ChildMarryType, r.Name), this.lab_Attribute.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(e.ChildMarryAttribute, global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(this._2886374030)), this.lab_Parent.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(e.ChildMarryParent, t), GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_Icon, a, i.Sex)
    }
}();
var ChildTiqinView;
!function () {
    ChildTiqinView = function () {
        ChildTiqinView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildTiqinView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem)
    }, Laya.class(ChildTiqinView, "ChildTiqinView", ChildTiqinUI), ChildTiqinView.GetPreLoadResList = function (i) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildTiqinUI.uiView, i)
    };
    var i = ChildTiqinView.prototype;
    i.OnShow = function (i) {
        this._2886374030 = i.ChildId, this.input.text = "", this._s98b318da65992d84e8abbf736bfba7(), this._4221723320 = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._2886374030), this._2694527272 = i.OnChoose;
        var e = this._4221723320.ChildType, t = global.$Sys.GetTableService().GetTableRecord("child_type", e),
            a = t.MarryCustom, l = global.$Sys.GetTableService().GetTableRecord("consume", a), n = l.Consume;
        this.list.array = n
    }, i._s98b318da65992d84e8abbf736bfba7 = function () {
        var i = global.$Cfg.Language,
            e = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._2886374030),
            t = e.ChildType, a = global.$Sys.GetTableService().GetTableRecord("child_type", t);
        this.img_Type.skin = a.TypePath2, GameCommon._s92b07f7e084d9c5e9d3c011c98d0c1(this.img_Body, e.ChildType, e.Sex), this.lab_Name.text = e.Name;
        var l = global.$Api.QueryDataSource("DataChild")._sb6cd0f1638050b95bad348e5160f52(this._2886374030);
        this.lab_Attr.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(i.ChildMarryAttribute, l);
        var n = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
        this.lab_Parent.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ChildMarryParent, n)
    }, i.OnCreateItem = function (i, e) {
        var t = i.dataSource, a = i.getChildByName("img_Icon"), l = i.getChildByName("lab_Consume"),
            n = i.getChildByName("lab_CurCount"), h = i.getChildByName("btn_Choose"),
            d = GameCommon._sd829d199a08f4ea0e8f4acd2566c18([t]), o = _.first(d), C = o[0], r = o[1];
        l.text = r + C;
        var s;
        s = 2 == t[0] ? global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(t[1]) : global.$Api.QueryDataSource("DataBase").GetValue("Gold");
        var m = GameCommon._s66eb52e60b9feb53711943e638c9c3(t[0], t[1]);
        a.destroyChildren(), a.addChild(m), n.text = s, h.on(Laya.Event.CLICK, this, this.OnClickChoose, [e])
    }, i.OnClickChoose = function (i) {
        if (0 == this.rg.selectedIndex) {
            jasmin.Info("指定玩家提亲", this.input.text, this._2886374030, i);
            var e = this.input.text;
            GetDataChildInterface().DoMarryToUser(this._2886374030, e, i, function (i) {
                i.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildTiqinView"), GetDataChildInterface().event("ChildMarrySend" + this._2886374030))
            }.bind(this))
        } else jasmin.Info("全服提亲", this._2886374030, i), GetDataChildInterface().DoMarryToServer(this._2886374030, i, function (i) {
            i.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ChildTiqinView"), GetDataChildInterface().event("ChildMarrySend" + this._2886374030))
        }.bind(this))
    }
}();
var ChildView;
!function () {
    ChildView = function () {
        ChildView.super(this), this._s5ebc744d41802649eb5e8b914ddcc0()
    }, Laya.class(ChildView, "ChildView", ChildUI), ChildView.GetPreLoadResList = function (e) {
        e.push("res/role/child/z_zisi_0.png"), e.push("res/role/child/z_zisi_11.png"), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ChildUI.uiView, e)
    }, ChildView.Event = {
        LvUp: "LvUp",
        Recover: "Recover",
        ChangeName: "ChangeName",
        ExpandSeat: "ExpandSeat",
        OneKeyRecover: "OneKeyRecover",
        OneKeyLvUp: "OneKeyLvUp"
    };
    var e = ChildView.prototype;
    e._s5ebc744d41802649eb5e8b914ddcc0 = function () {
        this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.btn_Help.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Son"})
        }), this.btn_LvUp.on(Laya.Event.CLICK, this, this.OnClickLvUp), this.btn_ExpandSeat.on(Laya.Event.CLICK, this, this.OnClickExpandSeat), this.list_Energy.renderHandler = new Laya.Handler(this, this.OnCreateEnergy), this.btn_OneKeyLvUp.on(Laya.Event.CLICK, this, this.OnClickOneKeyLvUp), this.btn_OneKeyRecover.on(Laya.Event.CLICK, this, this.OnClickOneKeyRecover), this.btn_Kj.on(Laya.Event.CLICK, this, this.OnClickKj), this.btn_ChangeName.on(Laya.Event.CLICK, this, this.OnClickChangeName), this.btn_InitName.on(Laya.Event.CLICK, this, this.OnClickChangeName, [!0]), this.btn_Recover.on(Laya.Event.CLICK, this, this.OnClickRecover), this.list_Children.hScrollBarSkin = null, this.list_Children.renderHandler = new Laya.Handler(this, this.OnCreateChild), this._243014252 = Leo.ListExtend._sce82baeb3517cd19efefd5bad41c01(this.list_Children, {
            Type: "Radio",
            OnCreateItem: this.OnCreateChild.bind(this),
            OnStopSelectAnimation: function (e) {
                e.visible = !1
            },
            OnCanSelect: function (e, t) {
                return !!e
            }.bind(this),
            OnSelectAnimation: function (e) {
                e.visible = !0
            },
            OnGetSelectBorder: function (e) {
                return e.getChildByName("ui_Select")
            },
            OnSelectItem: this.OnSelectChild.bind(this)
        }), this.on(ChildView.Event.LvUp, this, function (e) {
            this.event("EventChild" + this._349104112, [e]), this.OnUpdateOneKeyUpBtn()
        }), this.on(ChildView.Event.Recover, this, function () {
            this.event("EventChild" + this._349104112), this.OnUpdateChild(this._349104112), this.OnUpdateOneKeyUpBtn()
        }), this.on(ChildView.Event.ChangeName, this, function () {
            this.event("EventChild" + this._349104112), this.OnUpdateName(this._349104112), this.OnUpdateOneKeyUpBtn()
        }), this.on(ChildView.Event.ExpandSeat, this, function () {
            this._s5319b41b568899ab44f4995aa88b80(null, !0), this.OnUpdateSeat()
        }), this.on(ChildView.Event.OneKeyLvUp, this, function (e) {
            this.isUp = !0, this.event("EventChild" + this._349104112), this._190866078 = e, _.each(e, function (e) {
                this._seb06054a5c6690a1edcb529b6f8292(e)
            }.bind(this)), this._s5319b41b568899ab44f4995aa88b80(null, !0), this.OnUpdateOneKeyUpBtn()
        }), this.on(ChildView.Event.OneKeyRecover, this, function () {
            this.event("EventChild" + this._349104112), this._s5319b41b568899ab44f4995aa88b80(null, !0), this.OnUpdateOneKeyUpBtn()
        })
    }, e.OnShow = function () {
        var e = this._sac344cc61b99b643ab94f5d3f58e69();
        _.first(e) && (this._349104112 = _.first(e).Id), this._s5319b41b568899ab44f4995aa88b80(0), this.OnUpdateChild(this._349104112), this.OnUpdateSeat(), this.OnUpdateCountdown(), this.timerLoop(1e3, this, this.OnUpdateCountdown), this.isUp = !1, e = this._sac344cc61b99b643ab94f5d3f58e69();
        var t = _.first(e);
        if (t) {
            var i = t.Lv;
            if (i <= global.$Cfg.Common.Child.BabyLv) return void GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5("res/sound/child/z_voice3_0.wav");
            var a = t.ChildPathIdx, n = t.Sex, l = t.VoiceIdx,
                h = global.$Sys.GetTableService().GetTableRecord("child_info", n, a), d = h.Voice;
            if (d) {
                var o = null;
                o = d[l] ? d[l] : _.first(d), this._2407806680 = o, GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(o)
            }
        }
    }, e.OnSelectChild = function (e, t, i) {
        this._349104112 = i.Id, this.OnUpdateChild(i.Id)
    }, e.OnUpdateName = function (e) {
        var t = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e);
        this.lab_Name.text = t.Name || gLanguage.ChildDefaultName;
        var i = GetDataChildInterface()._sa330c081a23c149d1e6c94d61361e7(e);
        this.btn_ChangeName.mouseEnabled = !i && t.Name, this.btn_InitName.visible = !i && !t.Name
    }, e.OnUpdateChild = function (e, t) {
        if (!e) return this.view_Child.visible = !1, this.view_ChildInfo.visible = !1, void(this.img_NoChildInfo.visible = !0);
        this.view_Child.visible = !0, this.view_ChildInfo.visible = !0, this.img_NoChildInfo.visible = !1;
        var i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e);
        GameCommon._sa4526a507708e80128c9c9277c5619(this.ui_Child, e), i.Lv <= global.$Cfg.Common.Child.BabyLv ? this.lab_Chat.text = gLanguage.BabyChat : this.lab_Chat.text = _.sample(gLanguage.ChildChat);
        var a = i.Aptitude, n = GetDataTransfer().GetTableRecord("child_aptitude", a);
        this.lab_Lv.text = i.Lv + "/" + n.MaxLv, this.lab_Force.text = i.Attribute[CommonEnum.HeroAttribute.FORCE], this.lab_Brains.text = i.Attribute[CommonEnum.HeroAttribute.BRAINS], this.lab_Politics.text = i.Attribute[CommonEnum.HeroAttribute.POLITICS], this.lab_Prestige.text = i.Attribute[CommonEnum.HeroAttribute.PRESTIGE], this.lab_Property.text = i.Attribute[CommonEnum.HeroAttribute.FORCE] + i.Attribute[CommonEnum.HeroAttribute.BRAINS] + i.Attribute[CommonEnum.HeroAttribute.POLITICS] + i.Attribute[CommonEnum.HeroAttribute.PRESTIGE], this.OnUpdateName(e);
        var l = i.BeautyId, h = global.$Api.QueryDataSource("DataBeauty")._s08ba6a1ba12968cac41a4297977513(l),
            d = GetDataTransfer().GetTableRecord("beauty", l);
        this.lab_BeautyName.text = d.Name, this.lab_BeautyLoveValue.text = h.LoveValue, this.ui_Man.visible = 1 == i.Sex, this.ui_Woman.visible = 1 != i.Sex;
        var o = GetDataTransfer().GetTableRecord("child_lv_up", i.Lv), s = o.Exp;
        if (n.MaxLv <= i.Lv || !jasmin._s8fc157faa910d1911d744e3a7cc831(s)) this.lab_Exp.text = gLanguage.ChildLvMax, this.progress_Exp.value = 1; else if (t) {
            var C = this.progress_Exp.value, r = i.Exp / s;
            0 == r && C >= .5 ? Laya.Tween.to(this.progress_Exp, {value: 1}, 500, null, Laya.Handler.create(this, function () {
                this.progress_Exp.value = 0, this.lab_Exp.text = i.Exp + "/" + s
            })) : Laya.Tween.to(this.progress_Exp, {value: r}, 500, null, Laya.Handler.create(this, function () {
                this.lab_Exp.text = i.Exp + "/" + s
            }))
        } else this.lab_Exp.text = i.Exp + "/" + s, this.progress_Exp.value = i.Exp / s;
        this.OnUpdateCountdown()
    }, e.OnUpdateEnergy = function () {
        for (var e = this._349104112, t = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e), i = global.$Api.QueryDataSource("DataChild")._s96e7daa02290854e2035ab6d17117c(e), a = GetDataVipProxy()._sb603263b318bf87c2f0c09cfb4b444(), n = a.MaxChildEnergy, l = i.Count, h = [], d = 1; d <= n; d++) d > l ? h.push(0) : h.push(1);
        var o = GetDataChildInterface()._sa330c081a23c149d1e6c94d61361e7(e);
        this.btn_Kj.visible = o, this.btn_LvUp.visible = !o && t.Name && 0 != l, this.btn_Recover.visible = !o && 0 == l, this.list_Energy.array = h
    }, e._sac344cc61b99b643ab94f5d3f58e69 = function () {
        var e = global.$Api.QueryDataSource("DataChild")._sadc2fbac9322854d15fef6b0e5043b(),
            t = _.filter(e, function (e) {
                return !e.Adult
            });
        t.sort(function (e, t) {
            var i = 100, a = 1e4, n = 1 == e.Sex ? i : a, l = 1 == t.Sex ? i : a;
            return n + e.Id - (l + t.Id)
        });
        for (var i = global.$Api.QueryDataSource("DataChild").GetValue("Seat"), a = [], n = 0; n < i; n++) a.push(t[n]);
        return a
    }, e._s5319b41b568899ab44f4995aa88b80 = function (e, t) {
        this._2158632725 = [];
        var i = this._sac344cc61b99b643ab94f5d3f58e69(), a = {DataSource: i};
        jasmin._s8fc157faa910d1911d744e3a7cc831(e) && (a.SelectItemIndex = e), t && (a.RetainSelect = !0), this.list_Children.array = [], this._243014252._se06d3ef81daf6f8c47c34c7ab850df(a)
    }, e.OnClickAddBtn = function () {
    }, e.OnCreateChild = function (e, t) {
        this._243014252._sf4eade5683bb979fadd97b7d469c4d(e, t);
        var i = e.dataSource, a = e.getChildByName("view_Child"), n = e.getChildByName("img_NoChild"),
            l = e.getChildByName("ui_Select");
        if (!i) return a.visible = !1, n.visible = !0, void(l.visible = !1);
        a.visible = !0, n.visible = !1;
        var h = a.getChildByName("ui_Man"), d = a.getChildByName("ui_Woman"), o = a.getChildByName("ui_Name"),
            s = a.getChildByName("ui_Lv"), C = a.getChildByName("ui_Energy"), r = a.getChildByName("img_Body");
        h.visible = 1 == i.Sex, d.visible = 1 != i.Sex, this.OnUpdateChildLv(i.Id, s), this.OnUpdateChildName(i.Id, o), this.OnUpdateChildEnergy(i.Id, C), this.OnUpdateChildBody(i.Id, r), this.on("EventChild" + i.Id, this, this.OnEventChild, [{
            childId: i.Id,
            ui_Lv: s,
            ui_Name: o,
            ui_Energy: C,
            img_Body: r
        }]), this._2158632725 = this._2158632725 || [];
        var u = !1;
        _.each(this._2158632725, function (t) {
            t.Cell == e && (t.Id = i.Id, u = !0)
        }), u || this._2158632725.push({Cell: e, Id: i.Id})
    }, e._seb06054a5c6690a1edcb529b6f8292 = function (e) {
        var t;
        if (_.each(this._2158632725, function (i) {
            i.Id == e && (t = i.Cell)
        }), t) {
            var i = t.getChildByName("view_Child"), a = i.getChildByName("ui_Name");
            GameCommon._s79de96ae82b954c6052c9d5eb90512(a, [{Info: global.$Cfg.Language.ChildLvUpFont}])
        }
    }, e.OnEventChild = function (e, t) {
        this.OnUpdateChildLv(e.childId, e.ui_Lv), this.OnUpdateChild(e.childId, t), this.OnUpdateChildName(e.childId, e.ui_Name), this.OnUpdateChildEnergy(e.childId, e.ui_Energy), this.OnUpdateChildBody(e.childId, e.img_Body)
    }, e.OnUpdateChildBody = function (e, t) {
        GameCommon._sa4526a507708e80128c9c9277c5619(t, e)
    }, e.OnUpdateChildEnergy = function (e, t) {
        var i = GetDataVipProxy()._sb603263b318bf87c2f0c09cfb4b444().MaxChildEnergy,
            a = global.$Api.QueryDataSource("DataChild")._s96e7daa02290854e2035ab6d17117c(e);
        t.text = a.Count + "/" + i
    }, e.OnUpdateChildName = function (e, t) {
        var i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e);
        i.Name ? t.color = "#73400e" : t.color = "#dc4d4d", t.text = i.Name || gLanguage.ChildDefaultName
    }, e.OnUpdateChildLv = function (e, t) {
        var i = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e), a = i.Aptitude,
            n = GetDataTransfer().GetTableRecord("child_aptitude", a);
        t.text = i.Lv + "/" + n.MaxLv
    }, e.OnClose = function () {
        this._2158632725 = null, this._3172760668 = null, this.clearTimer(this, this.OnUpdateCountdown), this._2407806680 && GetAudioHelper()._sbebf31910b4e9f79e270fea2f864b7(this._2407806680), this._2407806680 = null
    }, e.OnUpdateCountdown = function () {
        if (this._349104112) {
            this.OnUpdateEnergy();
            var e = global.$Api.QueryDataSource("DataChild")._s96e7daa02290854e2035ab6d17117c(this._349104112);
            if (e.Count > 0) return void(this.lab_CountDown.visible = !1);
            this.lab_CountDown.visible = !0;
            var t = e.RemainingTime, i = jasmin._s94a2f7c0f6d93408be9fb1bde96f94("(hh时)(mm分)(ss秒)", t),
                a = GetDataVipProxy()._sb603263b318bf87c2f0c09cfb4b444();
            this.lab_CountDown.x = 60 + 40 * a.MaxChildEnergy, this.lab_CountDown.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("(%s)", i), this.OnUpdateOneKeyUpBtn()
        }
    }, e.OnCreateEnergy = function (e, t) {
        var i = e.dataSource;
        e.getChildByName("ui_PointLight").visible = 1 == i
    }, e.OnClickExpandSeat = function () {
        var e = GetDataChildInterface()._sd077e2a95e57a14dbabb077833b285();
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeId: e,
            Purpose: gLanguage.ChildExpandSeat,
            OnConfirmUse: function (e) {
                GetDataChildInterface().DoExpandSeat(function (e) {
                    e.Result && (this.event(ChildView.Event.ExpandSeat), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ChildExpandSeatSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }, e.OnClickLvUp = function () {
        var e = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._349104112), t = e.Lv,
            i = jasmin._sdf8385ff3a74421ea218e043d47fdc(e.Attribute);
        GetDataChildInterface().DoLvUp(this._349104112, function (e) {
            if (e.Result) {
                GameCommon._sb95bbf091e97e2cc2b2904a7935a66(e.MiracleId), GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), this.event(ChildView.Event.LvUp, !0);
                var a = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(this._349104112);
                if (a.Lv > t) {
                    var n = jasmin._sdf8385ff3a74421ea218e043d47fdc(a.Attribute), l = {}, h = [];
                    _.each(n, function (e, t) {
                        var a = i[t];
                        if (e - a > 0) {
                            l[t] = e - a;
                            var n = "";
                            switch (parseInt(t)) {
                                case global.$Cfg.CommonEnum.HeroAttribute.FORCE:
                                    n = global.$Cfg.Language.Force;
                                    break;
                                case global.$Cfg.CommonEnum.HeroAttribute.BRAINS:
                                    n = global.$Cfg.Language.Brains;
                                    break;
                                case global.$Cfg.CommonEnum.HeroAttribute.POLITICS:
                                    n = global.$Cfg.Language.Politics;
                                    break;
                                case global.$Cfg.CommonEnum.HeroAttribute.PRESTIGE:
                                    n = global.$Cfg.Language.Prestige
                            }
                            h.push({Info: n + "+" + l[t]})
                        }
                    }), GameCommon._s79de96ae82b954c6052c9d5eb90512(this, h)
                }
            }
        }.bind(this))
    }, e.OnClickKj = function () {
        GetDataChildInterface().DoKJ(this._349104112, function (e) {
            e.Result && GetDataChildInterface()._s4afa5b1fa57e99018bac1eb9a3c982(this._349104112, function () {
                this._349104112 = null, this.OnShow()
            }.bind(this))
        }.bind(this))
    }, e.OnClickOneKeyRecover = function () {
        GetDataChildInterface().DoOneKeyRecover(function (e) {
            e.Result && (this.event(ChildView.Event.OneKeyRecover), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ChildEnergyRecoverSuccess]}))
        }.bind(this))
    }, e.OnClickOneKeyLvUp = function () {
        GetDataChildInterface().DoOneKeyLvUp(function (e, t) {
            if (e.Result) {
                var i = e.LvUpChildren, a = [];
                _.each(i, function (e) {
                    var t = e.Id;
                    a.push(t)
                }.bind(this)), this.event(ChildView.Event.OneKeyLvUp, [a]), GameCommon._sb95bbf091e97e2cc2b2904a7935a66(e.MiracleId, e.MiracleCnt)
            }
        }.bind(this))
    }, e.OnClickRecover = function () {
        var e = global.$Cfg.Common.Child.RecoverEnergyConsume;
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeId: e,
            Purpose: gLanguage.ChildRecoverEnergy,
            OnConfirmUse: function (e) {
                GetDataChildInterface().DoRecoverEnergy(this._349104112, function (e) {
                    e.Result && (this.event(ChildView.Event.Recover), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ChildEnergyRecoverSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }, e.OnClickChangeName = function (e, t) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildChangeNameView", {
            ChildId: this._349104112,
            OnOk: function () {
                this.event(ChildView.Event.ChangeName), t ? GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ChildInitNameSuccess]}) : GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ChildChangeNameSuccess]})
            }.bind(this)
        })
    }, e.OnUpdateSeat = function () {
        var e = global.$Api.QueryDataSource("DataChild")._sc17a1566ee8a0b9e9fd8fbcc7775d8(),
            t = global.$Api.QueryDataSource("DataChild").GetValue("Seat");
        this.lab_Seat.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ChildSeat, e, t);
        var i = t >= 5;
        this.lab_OneKeyLvUp.visible = !i;
        var a = GetDataChildInterface()._sd077e2a95e57a14dbabb077833b285();
        jasmin._s063e5ed8ab7e5caec9d7e0aa2ef499(a) ? this.btn_ExpandSeat.visible = !1 : this.btn_ExpandSeat.visible = !0, this.OnUpdateOneKeyUpBtn()
    }, e.OnUpdateOneKeyUpBtn = function () {
        var e = global.$Api.QueryDataSource("DataChild").GetValue("Seat"), t = e >= 5,
            i = global.$Api.QueryDataSource("DataChild")._s871bb9f92ec011834e36289cd17351(), a = !1, n = !0;
        _.each(i, function (e) {
            e.Name && (a = !0);
            var t = global.$Api.QueryDataSource("DataChild")._s13472c46c154c517190c8a1009303a(e.Id), i = t.Lv,
                l = t.Aptitude, h = global.$Sys.GetTableService().GetTableRecord("child_aptitude", l), d = h.MaxLv;
            i != d && global.$Api.QueryDataSource("DataChild")._sa26abf94d588327d3fa39328241446(t.Id) > 0 && (n = !1)
        }), this._349104112 && a && t ? (this.btn_OneKeyLvUp.visible = !n, this.btn_OneKeyRecover.visible = n) : (this.btn_OneKeyLvUp.visible = !1, this.btn_OneKeyRecover.visible = !1)
    }
}();
var CommonRankController;
!function () {
    CommonRankController = function (a) {
        this._1317894818 = a, this._1317894818.list_rank.renderHandler = Laya.Handler.create(this, this.OnCreateUserRankData, null, !1), this._1317894818.list_rank.vScrollBarSkin = null, this._1317894818.list_rank.array = []
    };
    var a = CommonRankController.prototype;
    CommonRankController._s44377e7cc909eaacd34555256b505d = function (a) {
        var e = new CommonRankController(a);
        return e
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function (a) {
        this._4122736007 = a, this._1317894818.list_rank.array = [], this._1317894818.list_rank.array = this._4122736007.RankList, _.each(this._4122736007.ShowTag, function (a, e) {
            var r = jasmin._se91cf955e91eaa1aa510d4335edd4a("node_%s", e);
            a ? a(this._1317894818[r], this._4122736007.MyRank) : this._sa9d431df0a92cafe3d56369da76fca(e, this._1317894818[r], this._4122736007.MyRank)
        }.bind(this))
    }, a.OnCreateUserRankData = function (a, e) {
        _.each(this._4122736007.ShowTag, function (r, n) {
            var t = jasmin._se91cf955e91eaa1aa510d4335edd4a("node_%s", n), o = a.getChildByName(t),
                i = this._4122736007.UserInfos[this._1317894818.list_rank.array[e]];
            r ? r(o, i, e) : this._sa9d431df0a92cafe3d56369da76fca(n, o, i, e)
        }.bind(this))
    }, a._sa9d431df0a92cafe3d56369da76fca = function (a, e, r, n) {
        switch (a) {
            case"Rank":
                if (e.destroyChildren(), r.Rank && r.Rank <= 3) var t = new Laya.Image(global.$Cfg.Common.RankIcon[r.Rank - 1]); else {
                    var t = new Laya.Label(r.Rank || gLanguage.NoJoinRank);
                    t.color = "#755848", t.fontSize = 23
                }
                t.centerX = 0, t.centerY = 0, e.addChild(t);
                break;
            case"Name":
                e.text = r.UserData ? r.UserData.Name : global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), e.color = this._GetRankColor(r.Rank);
                break;
            case"Score":
                e.text = jasmin._seb2d63e263badd8a69c54d151f6cc7(r.Score) ? r.Score : "-", e.color = this._GetRankColor(r.Rank);
                break;
            case"Office":
                if (!e) break;
                e.destroyChildren(), e.visible = !0;
                var o = null;
                if (r.UserData && r.UserData.KingId) {
                    var i = global.$Sys.GetTableService().GetTableRecord("throne", r.UserData.KingId);
                    o = new Laya.Image(i.NameFontPath)
                } else {
                    var s = r.UserData ? r.UserData.Office : global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                        l = global.$Sys.GetTableService().GetTableRecord("office", s).OfficeName;
                    o = new Laya.Label(l), o.color = this._GetRankColor(r.Rank), o.fontSize = 23
                }
                o.centerX = 0, o.centerY = 0, e.addChild(o);
                break;
            default:
                global.$$error("No Case !! Please Check")
        }
    }, a._GetRankColor = function (a) {
        return a && a <= 3 ? global.$Cfg.Common.RankColor[a - 1] : "#755848"
    }
}();
var CompoundDetail;
!function () {
    CompoundDetail = function () {
        CompoundDetail.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_compound.on(Laya.Event.CLICK, this, this.OnBtnCompoundClick)
    }, Laya.class(CompoundDetail, "CompoundDetail", CompoundDetailUI);
    var t = CompoundDetail.prototype;
    t.OnShow = function (t) {
        this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var t = this._4122736007.Data, e = global.$Sys.GetTableService().GetTableRecord("item_compound", t.TableId),
            o = global.$Sys.GetTableService().GetTableRecord("item", e.ItemId);
        this.spr_item.Icon && (this.spr_item.Icon.removeSelf(), this.spr_item.Icon.destroy(), this.spr_item.Icon = null);
        var i = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: o.ItemId});
        this.spr_item.Icon = i, this.spr_item.addChild(i), this.lab_itemName.text = o.ItemName, this.lab_itemName.color = global.$Cfg.Common.DetailQualityColor[o.Quality], this.lab_detail.text = o.ItemDesc;
        var a = GameCommon._s2df47cdc89238e8b6a0e6941092559(e.Consume);
        this.hBox_consume.destroyChildren(), _.each(a, function (t) {
            t.scaleX = .75, t.scaleY = .75, this.hBox_consume.addChild(t)
        }.bind(this)), this.hBox_consume.refresh(), this.lab_limit.visible = e.TriesLimit, e.TriesLimit && (compoundCnt = global.$Api.QueryDataSource("DataRecord").GetValue(["Compound", t.Id]), this.lab_limit.text = compoundCnt + "/" + e.TriesLimit);
        var n = global.$Api.GetAssetManager()._s3fe93204207ebad2b8c617add33b0a(e.Consume);
        this.btn_compound.disabled = !n.Result
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CompoundDetail")
    }, t.OnClose = function () {
        this.spr_item.Icon && (this.spr_item.Icon.removeSelf(), this.spr_item.Icon.destroy(), this.spr_item.Icon = null), this.hBox_consume.destroyChildren()
    }, t.OnBtnCompoundClick = function () {
        GetDataBagInterface().DoCompound(this._4122736007.Data.Id, function (t) {
            var e = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
            GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, e), this._4122736007.OnCompoundFinish && this._4122736007.OnCompoundFinish(), this._s4fb507d6d0f40b2d2a72f6007a938d()
        }.bind(this))
    }, CompoundDetail.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CompoundDetail.uiView, t)
    }
}();
var CompoundLayer;
!function () {
    CompoundLayer = function () {
        CompoundLayer.super(this)
    }, Laya.class(CompoundLayer, "CompoundLayer", CompoundLayerUI);
    var o = CompoundLayer.prototype;
    o.Init = function () {
        this.list_compound.renderHandler = Laya.Handler.create(this, this.OnCreateCompoundList, null, !1), this.list_compound.vScrollBarSkin = null, this._2971674952 ? this.OnRefresh() : GetDataBagInterface().DoGetCompoundList(function (o) {
            this._2971674952 = _.toArray(o.CompountList), this.OnRefresh()
        }.bind(this))
    }, o.OnRefresh = function () {
        this.list_compound.array = this._2971674952
    }, o._s8fe74bf472ff7bee45e634529a0437 = function (o, e) {
        var n = global.$Sys.GetTableService().GetTableRecord("item_compound", e);
        if (n.TriesLimit) {
            var t = global.$Api.QueryDataSource("DataRecord").GetValue(["Compound", o]);
            if (t >= n.TriesLimit) return !1
        }
        var i = global.$Api.GetAssetManager()._s3fe93204207ebad2b8c617add33b0a(n.Consume);
        return i.Result
    }, o.OnCreateCompoundList = function (o, e) {
        var n = o.getChildByName("lab_itemName"), t = o.getChildByName("img_itemIcon"),
            i = o.getChildByName("btn_compound"), a = o.getChildByName("img_Redpoint"), r = this.list_compound.array[e],
            s = global.$Sys.GetTableService().GetTableRecord("item_compound", r.TableId);
        n.text = s.Name, t.Icon && t.Icon.destroy(), t.Icon = null;
        var u = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: s.ItemId});
        t.Icon = u, t.addChild(u), i.offAll(Laya.Event.CLICK), i.on(Laya.Event.CLICK, this, function (o) {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("CompoundDetail", {
                Data: o, OnCompoundFinish: function () {
                    this.OnRefresh()
                }.bind(this)
            })
        }, [r]), a.visible = this._s8fe74bf472ff7bee45e634529a0437(r.Id, r.TableId)
    }, o.OnClose = function () {
        _.each(this.list_compound.cells, function (o) {
            var e = o.getChildByName("img_itemIcon");
            e.Icon && (e.Icon.destroy(), e.Icon = null)
        }), this.visible = !1
    }
}();

function ConfirmDialog() {
    ConfirmDialog.super(this), this.btn_Confirm.on(Laya.Event.CLICK, this, this.OnClickConfirm), this.btn_Cancel.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ConfirmDialog")
    })
}

var ConfirmDialog;
Laya.class(ConfirmDialog, "ConfirmDialog", ConfirmDialogUI), ConfirmDialog.GetPreLoadResList = function (i) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ConfirmDialog.uiView, i)
};
var _proto_ = ConfirmDialog.prototype;
_proto_.OnShow = function (i) {
    this._713989164 = i, this.lab_Message.text = this._713989164.Text || gLanguage.ConfirmDialog
}, _proto_.OnClickConfirm = function () {
    this._713989164.OnConfirm && this._713989164.OnConfirm(), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ConfirmDialog")
};

function CreateBanquetDialog() {
    CreateBanquetDialog.super(this), this.list_type.renderHandler = Laya.Handler.create(this, this.OnCreateTypeBox, null, !1), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, {ShowType: ["Gold"]})
}

CreateBanquetDialog.ART_FONT = ["res/ui/artfont/z_word_66.png", "res/ui/artfont/z_word_67.png"], CreateBanquetDialog.TYPE_BG_SKIN = ["res/ui/bg/z_bg_107.png", "res/ui/bg/z_bg_108.png"], CreateBanquetDialog.MAP_BG = ["res/ui/bg/z_bg_105.png", "res/ui/bg/z_bg_106.png"], CreateBanquetDialog.COLOR_RED = "#FF0000", CreateBanquetDialog.COLOR_GREEN = "#00FF00", Laya.class(CreateBanquetDialog, "CreateBanquetDialog", CreateBanquetDialogUI);
var _proto_ = CreateBanquetDialog.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetDataTransfer().GetTable("banquet_type");
    this.list_type.array = _.toArray(e), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_.OnCreateTypeBox = function (e, t) {
    var a = e.getChildByName("lab_seat"), n = e.getChildByName("lab_consume"), i = e.getChildByName("hBox_consume"),
        o = e.getChildByName("img_public"), r = o.getChildByName("checkBox_public"), l = e.getChildByName("btn_create"),
        s = e.getChildByName("img_bg"), u = e.getChildByName("img_type"), C = e.getChildByName("img_artFont");
    data = this.list_type.array[t], a.text = data.SeatCount;
    var g = GetDataTransfer().GetTableRecord("consume", data.Consume).Consume;
    i.destroyChildren(), _.each(g, function (e) {
        if (e[0] == CommonEnum.Asset.DataBase) n.text = e[2]; else {
            var t = GameCommon._s66eb52e60b9feb53711943e638c9c3(e[0], e[1]);
            i.addChild(t);
            var a = GameCommon._sc2670617ff77eb1396f5b63c0edc88(e[0], e[1]),
                o = new Laya.Label(jasmin._se91cf955e91eaa1aa510d4335edd4a("(%d/%d)", a, e[2]));
            o.color = CreateBanquetDialog[(a < e[2], "COLOR_GREEN")], o.fontSize = 20, t.addChild(o), o.centerX = 0, o.bottom = -30
        }
    }), o.visible = !t, l.offAll(Laya.Event.CLICK), l.on(Laya.Event.CLICK, this, this.OnCreateBanquet, [t + 1, r]), s.skin = CreateBanquetDialog.MAP_BG[t], u.skin = CreateBanquetDialog.TYPE_BG_SKIN[t], C.skin = CreateBanquetDialog.ART_FONT[t]
}, _proto_.OnCreateBanquet = function (e, t) {
    var a = {BanquetType: e, Public: t.selected};
    GetDataBanquetInterface().DoCreateBanquet(a, function (e) {
        e.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CreateBanquetDialog"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BanquetScene", e.BanquetData), GetGuiManager()._s2e22e694b9852084df200bc86f9340("BanquetOpenDialog", e.BanquetData))
    })
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CreateBanquetDialog")
}, _proto_.OnClose = function () {
    _.each(this.list_type.cells, function (e) {
        var t = e.getChildByName("hBox_consume");
        t.destroyChildren()
    })
}, CreateBanquetDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CreateBanquetDialog.uiView, e), jasmin._s3c96e1f3bee730222501b208d50190(e, CreateBanquetDialog.ART_FONT), jasmin._s3c96e1f3bee730222501b208d50190(e, CreateBanquetDialog.TYPE_BG_SKIN), jasmin._s3c96e1f3bee730222501b208d50190(e, CreateBanquetDialog.MAP_BG)
};
!function () {
    function e() {
        var t = laya.events.Event;
        e.super(this), this.SexManBtn.on(t.CLICK, this, function () {
            this.OnClickChooseSex(1)
        }), this.SexWoManBtn.on(t.CLICK, this, function () {
            this.OnClickChooseSex(2)
        }), this.RandomNameBtn.on(t.CLICK, this, this.OnClickRandomHeroName), this.CreateRoleBtn.on(t.CLICK, this, this.OnCreateRoleBtn), this.NameLabel.on(t.INPUT, this, this.OnInput)
    }

    Laya.class(e, "CreateRoleView", CreateRoleUI), e.OnPreLoadRes = function (e) {
        _.each(gCfg.HeadIconName[1], function (t) {
            e.push(t)
        }), _.each(gCfg.HeadIconName[2], function (t) {
            e.push(t)
        }), e.push(global.$Cfg.Common.CreateCloth);
        for (var t = 0; t < global.$Cfg.Common.CloudPath.length; t++) e.push(global.$Cfg.Common.CloudPath[t]);
        e.push("res/ui/common/z_image_13.png"), jasmin._s3c96e1f3bee730222501b208d50190(e, GameCommon._s44605232c95cb24f373304cee8baf4()), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TitleUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BottomMenuUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TopInfoUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(FuDi.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainCityUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CreateRoleUI.uiView, e)
    }, e.prototype.OnShow = function (e) {
        this._4122736007 = e;
        var t = Laya.Handler;
        this._993409835 = 0, this._s14f6bcba59b4f5374639024c70bc02(), this.TipLabel.text = gLanguage.CreateRoleName, this._4195712570 = this.CreateRoleImg.x, this._41957125701 = this.CreateRoleImg1.x, this._823919896 = !0, this._36917936 = 0, this._742501855 = 0, this._1520025459 = null, this._2245767442 = 6, this.NameLabel.text = this._sab7cf2207f2dad2d282e5367d9b4ba(), this.HeadChooseList.renderHandler = new t(this, this.OnUpdateItem), this.OnClickChooseSex(1);
        var i = {IndexArr: ["ViewOpen", "CreateRole"], Value: 1}, a = SetrRecord._s6a4dba9453762113ae0d1467dd81b3(i);
        a.Result && GetCmdProxy().DoCmd("SetrRecord", i, function (e) {
        }.bind(this), {NoBlock: !0, HideError: !0})
    }, e.prototype.OnUpdateItem = function (e, t) {
        var i = laya.events.Event, a = e.dataSource, o = e.getChildByName("HeadChooseBtn"),
            n = o.getChildByName("HeadImg");
        n.skin = a.HeadPath, this.OnClickHeadBtn(0, a.HeadPath), o.offAll(i.CLICK), o.on(i.CLICK, this, function () {
            this.OnClickHeadBtn(t, a.HeadPath)
        })
    }, e.prototype.OnClickHeadBtn = function (e, t) {
        if (this._36917936 != e || this._993409835 != this._742501855) {
            if (this._1520025459 = e + 1, this.CreateRoleHead1.skin = t, !this._823919896) {
                var i = Browser.clientWidth + this.CreateRoleImg.width + 100,
                    a = this.CreateRoleImg.width - Browser.clientWidth - 100;
                this._36917936 > e && (i = this.CreateRoleImg.width - Browser.clientWidth - 100, a = Browser.clientWidth + this.CreateRoleImg.width + 100), Tween.to(this.CreateRoleImg, {x: i}, 200, null, new Laya.Handler(this, function () {
                    this.CreateRoleImg.x = this._4195712570, this.CreateRoleHead.skin = t
                })), this.CreateRoleImg1.x = a, Tween.to(this.CreateRoleImg1, {x: this._4195712570}, 200, null, new Laya.Handler(this, function () {
                    this.CreateRoleImg1.x = this._41957125701
                })), this._36917936 = e
            }
            this._742501855 = this._993409835, this._823919896 = !1;
            for (var o = this.HeadChooseList._cells, n = 0; n < o.length; n++) {
                var s = o[n].getChildByName("HeadChooseBtn"), l = s.getChildByName("HeadSelectIcon");
                n == e ? l.visible = !0 : l.visible = !1
            }
        }
    }, e.prototype.OnInput = function () {
        "" == this.NameLabel.text ? this.TipLabel.visible = !0 : this.TipLabel.visible = !1
    }, e.prototype._s14f6bcba59b4f5374639024c70bc02 = function () {
        switch (this._993409835) {
            case 1:
                this.ManSelectBox.visible = !0, this.WoManSelectBox.visible = !1;
                break;
            case 2:
                this.ManSelectBox.visible = !1, this.WoManSelectBox.visible = !0;
                break;
            default:
                this.ManSelectBox.visible = !1, this.WoManSelectBox.visible = !1
        }
    }, e.prototype.OnClickChooseSex = function (e) {
        if (this._993409835 != e) {
            for (var t = [], i = 0; i < this._2245767442; i++) t[i] = {
                HeadPath: global.$Cfg.Common.HeadIconName[e][i + 1],
                id: i + 1
            };
            this._s00c83a0fcbc0402517581d2ec853e1(this.HeadChooseList), this.HeadChooseList.array = t
        }
        this.CreateRoleImg.skin = global.$Cfg.Common.CreateCloth, this._993409835 = e, this._s14f6bcba59b4f5374639024c70bc02(), this.OnClickRandomHeroName()
    }, e.prototype._s00c83a0fcbc0402517581d2ec853e1 = function (e) {
        if (e && e.array) for (var t = 0; t < e.array.length; t++) this.HeadChooseList.deleteItem(t)
    }, e.prototype.OnClickRandomHeroName = function () {
        var e = this._sab7cf2207f2dad2d282e5367d9b4ba();
        this.NameLabel.text = e, this.OnInput()
    }, e.prototype._sab7cf2207f2dad2d282e5367d9b4ba = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("player_name", 0),
            t = Math.round(Math.random() * (_.size(e) - 1) + 1), i = e[t].Name;
        e = global.$Sys.GetTableService().GetTableRecord("player_name", this._993409835), t = Math.round(Math.random() * (_.size(e) - 1) + 1);
        var a = e[t].Name;
        return i + a
    }, e.prototype.OnCreateRoleBtn = function () {
        var e = Leo.GetDirtyWordsFilter()._s95d3edab3bfd008f58b6e1b086ebca(this.NameLabel.text);
        return e ? "" == this.NameLabel.text.trim() ? void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CreateRoleNameIsEmpty]}) : void GetCmdProxy().DoCmd("CreateRole", {
            Sex: this._993409835,
            Name: this.NameLabel.text,
            HeroHeadId: this._1520025459
        }, function (e) {
            e.Result && GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InitialPlot", {})
        }) : void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CreateRoleNameError]})
    }, e.prototype.OnClose = function () {
        this._4122736007.OnClose && this._4122736007.OnClose()
    }
}();
!function () {
    function e() {
        e.super(this)
    }

    Laya.class(e, "CustomeRservice", CustomeRserviceUI), e.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CustomeRserviceUI.uiView, e)
    }, e.prototype.OnShow = function () {
        var e = laya.events.Event;
        this.TipLabel.text = "如果你遇到任何问题，可以联系客服";
        var t = GetServerInfoInterface().GetValue("ServerSetting");
        this.QQLabel.text = t ? t.QQ : "暂无", this.BaiDuLabel.text = "百度贴吧", this.WeChatNo.text = "微信公众号", this.CloseBtn.on(e.CLICK, this, this._OnCloseBtn)
    }, e.prototype._OnCloseBtn = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CustomeRservice")
    }
}();

function DailyTask() {
    DailyTask.super(this), this.list_task.vScrollBarSkin = null, this.list_task.renderHandler = Laya.Handler.create(this, this.OnCreateTaskBox, null, !1), this.list_liveness.renderHandler = Laya.Handler.create(this, this.OnCreateLivenessBox, null, !1), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

DailyTask.BUTTON_SKINS = ["res/ui/button/z_but_31.png", "res/ui/button/z_but_03.png"], DailyTask.REWARD_BOX_SKIN_1 = ["res/ui/common/z_baoxiang1.png", "res/ui/common/z_baoxiang1_1.png"], DailyTask.REWARD_BOX_SKIN_2 = ["res/ui/common/z_baoxiang2.png", "res/ui/common/z_baoxiang2_1.png"], DailyTask.MAX_LIVENESS = 150, DailyTask.INTERVAL = [11, 21, 21, 21, 21, 5], Laya.class(DailyTask, "DailyTask", DailyTaskUI);
var _proto_ = DailyTask.prototype;
_proto_.OnShow = function (a) {
    this._4122736007 = a, GetDataTaskInterface().DoRefreshTask({
        Callback: function () {
            this._sed6b8302d3f43ebeea87430f3bcf61()
        }.bind(this)
    })
}, _proto_._sed6b8302d3f43ebeea87430f3bcf61 = function () {
    this._se71818cc9fbdff6faea2307d1bc21b(), this._s477884aca73226bfc9fdcf2389fc87()
}, _proto_._s477884aca73226bfc9fdcf2389fc87 = function () {
    var a = global.$Api.QueryDataSource("DataTask")._scc5bc48a87f577d371d77cfc293711("Liveness"), e = a.Liveness || 0;
    this.lab_liveness.text = e;
    var s = global.$Api.QueryDataSource("DataTask")._se7a80ba4516d999f7a52608a9ce323("Liveness");
    jasmin._s3c96e1f3bee730222501b208d50190(s.TaskList, s.FinishList), s.TaskList.sort(function (a, e) {
        return a.ChainId > e.ChainId
    });
    var i = [];
    _.each(s.TaskList, function (a) {
        var e = GetDataTransfer().GetTableRecord("task_live", a.ChainId, a.TaskId), s = e.Target[0][2];
        i.push(s)
    }), i.push(150);
    var t = 0, n = 0;
    for (var r in i) {
        if (!(e >= i[r])) {
            var l = (e - n) / (i[r] - n) * DailyTask.INTERVAL[r];
            t += l;
            break
        }
        t += DailyTask.INTERVAL[r], n = i[r]
    }
    this.scroll_live.value = t / 100, this.list_liveness.array = s.TaskList
}, _proto_._se71818cc9fbdff6faea2307d1bc21b = function () {
    var a = global.$Api.QueryDataSource("DataTask")._se7a80ba4516d999f7a52608a9ce323("Daily");
    a.TaskList.sort(function (a, e) {
        var s = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329("Daily", a.ChainId, a.TaskId),
            i = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329("Daily", e.ChainId, e.TaskId);
        return Number(i) - Number(s)
    });
    var e = [];
    jasmin._s3c96e1f3bee730222501b208d50190(a.TaskList, a.FinishList);
    for (var s = 0; s < a.TaskList.length; s++) {
        var i = GetDataTransfer().GetTableRecord("task_daily", a.TaskList[s].ChainId, a.TaskList[s].TaskId);
        i.IsNotShow || e.push(a.TaskList[s])
    }
    this.list_task.array = e, this.list_task.scrollTo(0)
}, _proto_.OnCreateTaskBox = function (a, e) {
    var s = a.getChildByName("lab_name"), i = a.getChildByName("lab_dec"), t = a.getChildByName("lab_target"),
        n = a.getChildByName("btn_get"), r = a.getChildByName("img_get"), l = a.getChildByName("img_proceed"),
        o = this.list_task.array[e], _ = GetDataTransfer().GetTableRecord("task_daily", o.ChainId, o.TaskId);
    s.text = _.TaskName, i.text = _.TaskDec;
    var h = _.Target[0], k = h[2], d = GameCommon._sc2670617ff77eb1396f5b63c0edc88(h[0], h[1]);
    t.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", d, k), t.color = d < k ? "#ff0000" : "#5d3921";
    var T = d >= k;
    l.visible = !T, n.visible = T, n.off(Laya.Event.CLICK, this, this.OnBtnGetClick), n.on(Laya.Event.CLICK, this, this.OnBtnGetClick, [o]), r.visible = !1, global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3("Daily", o.ChainId, o.TaskId) && (n.visible = !1, l.visible = !1, r.visible = !0)
}, _proto_.OnCreateLivenessBox = function (a, e) {
    var s = a.getChildByName("btn_rewardBox"), i = a.getChildByName("lab_needLive"), t = this.list_liveness.array[e],
        n = GetDataTransfer().GetTableRecord("task_live", t.ChainId, t.TaskId), r = n.Target[0][2];
    i.text = r;
    var l = global.$Api.QueryDataSource("DataTask")._scc5bc48a87f577d371d77cfc293711("Liveness"), o = l.Liveness || 0;
    s.offAll(Laya.Event.CLICK), s.eff && (s.eff.removeSelf(), s.eff.destroy(), s.eff = null), o >= r ? global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3("Liveness", t.ChainId, t.TaskId) ? (s.on(Laya.Event.CLICK, this, this.OnShowRewardInfo, [t]), s.skin = e > 2 ? DailyTask.REWARD_BOX_SKIN_2[1] : DailyTask.REWARD_BOX_SKIN_1[1]) : (s.on(Laya.Event.CLICK, this, this.OnGetBoxReward, [t]), s.skin = e > 2 ? DailyTask.REWARD_BOX_SKIN_2[0] : DailyTask.REWARD_BOX_SKIN_1[0], Laya.loader.load("res/effect/z_tikx.png", Laya.Handler.create(this, function () {
        var a = new Effect,
            e = {Res: "res/effect/z_tikx.json", IsAutoRemove: !1, IsAutoHide: !1, Scale: .6, Size: [242, 261]};
        a.Init(e), a._s2e4033b88e999ce7271844dbf3b2dc([s.width / 2 - 10, s.height / 2]), s.addChild(a), s.eff = a
    }))) : (s.on(Laya.Event.CLICK, this, this.OnShowRewardInfo, [t]), s.skin = e > 2 ? DailyTask.REWARD_BOX_SKIN_2[0] : DailyTask.REWARD_BOX_SKIN_1[0])
}, _proto_.OnGetBoxReward = function (a) {
    GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item);
    var e = {
        Group: "Liveness", ChainId: a.ChainId, TaskId: a.TaskId, Callback: function () {
            this.list_liveness.refresh(), this.list_task.refresh()
        }.bind(this)
    };
    GetDataTaskInterface().DoTask(e)
}, _proto_.OnBtnGetClick = function (a) {
    GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item);
    var e = {
        Group: "Daily", ChainId: a.ChainId, TaskId: a.TaskId, Callback: function () {
            this.list_liveness.refresh(), this.list_task.refresh(), this._s477884aca73226bfc9fdcf2389fc87()
        }.bind(this)
    };
    GetDataTaskInterface().DoTask(e)
}, _proto_.OnClose = function () {
    _.each(this.list_liveness.cells, function (a) {
        var e = a.getChildByName("btn_rewardBox");
        e.offAll(Laya.Event.CLICK), e.eff && (e.eff.removeSelf(), e.eff.destroy(), e.eff = null)
    })
}, _proto_.OnShowRewardInfo = function (a) {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("LivenessReward", a)
}, _proto_.OnBtnCloseClick = function () {
    jasmin._s712167db7f08127d6dec4aed0f9846(this._4122736007.OnClose) ? this._4122736007.OnClose() : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
}, DailyTask.GetPreLoadResList = function (a) {
    jasmin._s3c96e1f3bee730222501b208d50190(a, DailyTask.BUTTON_SKINS), jasmin._s3c96e1f3bee730222501b208d50190(a, DailyTask.REWARD_BOX_SKIN_1), jasmin._s3c96e1f3bee730222501b208d50190(a, DailyTask.REWARD_BOX_SKIN_2), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DailyTask.uiView, a)
};
var DailyTotalItem;
!function () {
    DailyTotalItem = function (e, a) {
        DailyTotalItem.super(this), this._275936707 = 180, this._2755822550 = e, this._1783591077 = a, this._3928031220 = 1, this.Init()
    }, Laya.class(DailyTotalItem, "DailyTotalItem", DailyTotalItemUI);
    var e = DailyTotalItem.prototype;
    e.Init = function () {
        var e = global.$Cfg.Common.ActivityCfg.Recharge,
            a = global.$Sys.GetTableService().GetTableRecord(e.TaskTable, this._2755822550, "TableName"),
            t = global.$Sys.GetTableService().GetTableRecord(a, this._1783591077, this._3928031220), i = t.Target[0],
            s = GameCommon._sc2670617ff77eb1396f5b63c0edc88(i[0], i[1], {TaskType: this._2755822550}), h = i[2];
        this.lab_TitleCount.text = h, this.btn_GetReward.visible = !1, this.btn_ToRecharge.visible = !1, this.img_HasGetReward.visible = !1;
        var o = global.$Api.QueryDataSource("DataTask")._s94d065ffd48e0f1779210888982759(this._2755822550);
        o && global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(this._2755822550, this._1783591077, this._3928031220) ? (this.pro_RechargeCount.value = 1, this.lab_RechargeCount.text = h + "/" + h, this.img_HasGetReward.visible = !0) : global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(this._2755822550, this._1783591077, this._3928031220) ? (this.pro_RechargeCount.value = 1, this.lab_RechargeCount.text = h + "/" + h, this.btn_GetReward.visible = !0) : (this.pro_RechargeCount.value = s / h, this.lab_RechargeCount.text = s + "/" + h, this.btn_ToRecharge.visible = !0), this._1303233420 = h;
        for (var l = global.$Sys.GetTableService().GetTableRecord("reward", t.Reward), n = l.Award, r = 5, c = Math.ceil(n.length / r), m = 0, g = 0; g < c && !(m >= n.length); g++) {
            for (var u = new Laya.HBox, _ = 0; _ < r && n[m]; _++) {
                var b = GameCommon._se35db439c4ad2364b987453544666d(n[m], null, !0, n[m][2], {UseEff: !0});
                b.scaleX = .95, b.scaleY = .95, u.addChild(b), m++, u.changeItems()
            }
            u.space = 4, this.vBox_Icon.addChild(u)
        }
        this.vBox_Icon.changeItems(), this.height = this.vBox_Icon.height + this._275936707, this.left = 0, this.right = 0, this.btn_GetReward.on(Laya.Event.CLICK, this, this.OnGetReward), this.btn_ToRecharge.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeView", {
                OnClose: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeReward")
                }
            })
        })
    }, e.OnGetReward = function () {
        var e = this, a = {
            Group: this._2755822550, ChainId: this._1783591077, TaskId: this._3928031220, Callback: function (a) {
                a.Result && (e.mouseEnabled = !1, e.btn_GetReward.visible = !1, e.btn_ToRecharge.visible = !1, e.img_HasGetReward.visible = !0, Laya.Tween.from(e.img_HasGetReward, {
                    scaleX: 1.6,
                    scaleY: 1.6
                }, 200, null, Laya.Handler.create(this, function () {
                    e.mouseEnabled = !0, e.event("Update")
                })))
            }
        };
        GetDataTaskInterface().DoTask(a)
    }
}();
var DealAffairView;
!function () {
    DealAffairView = function () {
        DealAffairView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnClickClose), this.UseItemBtn.on(Laya.Event.CLICK, this, this.OnClickUseBtn), this.RewardBtn1.on(Laya.Event.CLICK, this, function (e) {
            this._s3c05bbadb530f7f3b8386875fac679(1, e.target)
        }), this.RewardBtn2.on(Laya.Event.CLICK, this, function (e) {
            this._s3c05bbadb530f7f3b8386875fac679(2, e.target)
        }), this.on("UpdateTopInfo", this, function () {
            var e = GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765();
            e.event("UpdateTopInfo")
        })
    }, Laya.class(DealAffairView, "DealAffairView", DealAffairUI), DealAffairView.GetPreLoadResList = function (e) {
        var t = global.$Sys.GetTableService().GetTable("approve_type");
        for (var a in t) e.push(t[a].BgPath);
        GameCommon._s06cdfd3fa57289d2a621c2a5c34f27(DealAffairUI, e)
    };
    var e = DealAffairView.prototype;
    e.OnShow = function (e) {
        this._713989164 = e, this.OnUpdateView(), this.OnTimeUpdate(), Laya.timer.loop(1e3, this, this.OnTimeUpdate)
    }, e.OnClose = function () {
        this.img_ItemIcon.destroyChildren(), Laya.timer.clear(this, this.OnTimeUpdate)
    }, e.OnClickClose = function () {
        this._713989164.OnClose && this._713989164.OnClose(), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DealAffairView")
    }, e.OnUpdateView = function () {
        if (this._s6d8a67e9a5ff6d8ac6e594adc68a79() > 0) this.view_Event.visible = !0, this.view_NoEvent.visible = !1, this._sa3a0b6cd1ec45101488a173bbcfe9f(); else {
            this.view_Event.visible = !1, this.view_NoEvent.visible = !0;
            var e = this._s1d9997cf83cbd5a7980d52dea34c3e(),
                t = GameCommon._sc2670617ff77eb1396f5b63c0edc88(e.Consume[0][0], e.Consume[0][1]),
                a = GameCommon._se35db439c4ad2364b987453544666d(e.Consume[0], !1, !1);
            this.img_ItemIcon.destroyChildren(), this.img_ItemIcon.addChild(a), this.ItemCountLabel.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ItemCount, t)
        }
        this._s03b3ea1d07f1b02b802bba0e62e378(), this._s53511ffc0282f1015b569236997728()
    }, e._sa3a0b6cd1ec45101488a173bbcfe9f = function () {
        var e = global.$Api.QueryDataSource("DataAffair")._sc00c2c4f465da42d5fe154689104cf(),
            t = GetDataTransfer().GetTableRecord("approve", e),
            a = GetDataTransfer().GetTableRecord("approve_type", t.ApproveType);
        this.lab_Tip.text = t.ApproveInfo, this.img_Affair.skin = a.BgPath;
        var i = GetDataTransfer().GetTableRecord("approve_result", e), n = i[1], o = i[2];
        this.lab_Reward1.text = "1." + n.ApproveResultInfo, this.lab_Reward2.text = "2." + o.ApproveResultInfo;
        var r = GetDataTransfer().GetTableRecord("reward", n.Reward).Award[0],
            s = GetDataTransfer().GetTableRecord("reward", o.Reward).Award[0],
            l = GameCommon._sf0a0854e48d4ebc005e689b65b3673(r[0], r[1]),
            u = GameCommon._sf0a0854e48d4ebc005e689b65b3673(s[0], s[1]), m = this._sbc7c203dd9ab8c8ba334df3aebd67b(),
            f = 0;
        if (e > 9) this.lab_RewardInfo1.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("(%s+%s)", l, r[2]); else {
            e <= 3 ? f = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(global.$Cfg.CommonEnum.HeroAttribute.BRAINS) : e <= 6 ? f = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(global.$Cfg.CommonEnum.HeroAttribute.POLITICS) : e <= 9 && (f = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(global.$Cfg.CommonEnum.HeroAttribute.PRESTIGE));
            var h = r[2], C = FormulaProxy[h]({Value: f, OfficeId: m});
            C >= 1e7 && (C = GameCommon._s5c693d8122a877499a10f605a128a3(C, 2)), this.lab_RewardInfo1.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("(%s+%s)", l, C)
        }
        var d = s[2], C = FormulaProxy[d]({Value: f, OfficeId: m});
        this.lab_RewardInfo2.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("(%s+%s)", u, GameCommon._s5c693d8122a877499a10f605a128a3(C, 2)), Laya.Tween.to(this.box_Tip, {alpha: 1}, 400, null, Laya.Handler.create(this, this.OnOpenMouseEnabled))
    }, e.OnOpenMouseEnabled = function () {
        this.view_Event.mouseEnabled = !0
    }, e.OnCloseMouseEnabled = function () {
        this.view_Event.mouseEnabled = !1
    }, e.OnTimeUpdate = function () {
        if (this._s6d8a67e9a5ff6d8ac6e594adc68a79() <= 0) {
            var e = this._s2302566324680243bf09907c1bd32d();
            this.TimerLabel.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(e.RemainingTime)
        } else 1 == this.view_NoEvent.visible && this.OnUpdateView();
        this._s53511ffc0282f1015b569236997728()
    }, e._s3c05bbadb530f7f3b8386875fac679 = function (e, t) {
        this.view_Event.mouseEnabled = !1;
        var a = function (t) {
            if (GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), !t.Result) return GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(t), void this.OnOpenMouseEnabled();
            if (t.Rewards) {
                var a = this.getChildByName("lab_ShowReward" + e);
                GameCommon._s5d340979c9fcfd9445217570f410e4(a, GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards)), this.event("UpdateTopInfo"), this.OnCloseMouseEnabled(), Laya.Tween.to(this.box_Tip, {alpha: 0}, 400, null, Laya.Handler.create(this, this.OnUpdateView))
            }
            this._s3ac7837b9a10e4e34124a5e3117ab3()
        }.bind(this);
        GetDataAffairInterface().DoDealAffair({Type: e, Callback: a})
    }, e.OnClickUseBtn = function () {
        var e = this._s84bf534974021135e0c1a23c1245d2() - this._s6d8a67e9a5ff6d8ac6e594adc68a79(),
            t = this._s1d9997cf83cbd5a7980d52dea34c3e(), a = t.Consume[0][1],
            i = GameCommon._sc2670617ff77eb1396f5b63c0edc88(t.Consume[0][0], t.Consume[0][1]);
        if (i <= 0) {
            var n = global.$Sys.GetTableService().GetTableRecord("item", a),
                o = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ItemNotEnoughDetail, n.ItemName);
            GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [o]})
        } else GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemSelectDialog", {
            ItemId: a,
            Max: Math.min(e, i),
            OnUseClick: function (e, t) {
                this._sf5d2217fdc400c5a27497168bf4820(t)
            }.bind(this)
        })
    }, e._sf5d2217fdc400c5a27497168bf4820 = function (e) {
        this._s2302566324680243bf09907c1bd32d();
        GetDataAffairInterface().DoUseItem({
            Count: e, Callback: function (e) {
                return e.Result ? (this.OnUpdateView(), void(this._s6d8a67e9a5ff6d8ac6e594adc68a79() == this._s84bf534974021135e0c1a23c1245d2() && GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.HasReachAffairMaxCount]}))) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(e)
            }.bind(this)
        })
    }, e._s53511ffc0282f1015b569236997728 = function () {
        var e = this._s6d8a67e9a5ff6d8ac6e594adc68a79() + "/" + this._s84bf534974021135e0c1a23c1245d2();
        this.AffairCount.text = e
    }, e._s3ac7837b9a10e4e34124a5e3117ab3 = function () {
        this._713989164.OnUpdateTopInfo && this._713989164.OnUpdateTopInfo()
    }, e._s03b3ea1d07f1b02b802bba0e62e378 = function () {
        var e = this._s690110ebcec0e403b35d6257a84698(), t = this._s78dcd95fd7d0efac9e26ac56bd7710();
        this.RecordProgress.value = t ? e / t : 1, this.lab_Exp.text = t ? e + "/" + t : e
    }, e._s690110ebcec0e403b35d6257a84698 = function () {
        return global.$Api.QueryDataSource("DataBase").GetValue("Exp")
    }, e._s78dcd95fd7d0efac9e26ac56bd7710 = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("office", this._sbc7c203dd9ab8c8ba334df3aebd67b());
        return e.NeedExp
    }, e._sbc7c203dd9ab8c8ba334df3aebd67b = function () {
        var e = global.$Api.QueryDataSource("DataBase")._2552118236.Office;
        return e
    }, e._s3e09ef5dd32a1b42b80afabb16f231 = function () {
        return global.$Api.Formula._sf43074ec6f050e76654809c702af79(this._sbc7c203dd9ab8c8ba334df3aebd67b())
    }, e._s84bf534974021135e0c1a23c1245d2 = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("office", this._sbc7c203dd9ab8c8ba334df3aebd67b());
        return e.MaxAffairsCount
    }, e._s6d8a67e9a5ff6d8ac6e594adc68a79 = function () {
        return Math.min(this._s2302566324680243bf09907c1bd32d().Count, this._s84bf534974021135e0c1a23c1245d2())
    }, e._s2302566324680243bf09907c1bd32d = function () {
        var e = global.$Api.ShareFunc._se589da605da2fd8d658becd4c5124a({
            CurTime: global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            Interval: this._s3e09ef5dd32a1b42b80afabb16f231(),
            StartTime: global.$Api.QueryDataSource("DataAffair")._s0dcf173986af63e29127ad08115954(),
            CurCount: global.$Api.QueryDataSource("DataAffair")._s6d8a67e9a5ff6d8ac6e594adc68a79(),
            MaxCount: this._s84bf534974021135e0c1a23c1245d2()
        });
        return e
    }, e._s1d9997cf83cbd5a7980d52dea34c3e = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("consume", global.$Cfg.Common.ApproveConsume);
        return e
    }
}();

function DebateCardDialog() {
    DebateCardDialog.super(this), this.list_reward.renderHandler = Laya.Handler.create(this, this.OnCreateReward, null, !1), this.list_reward.selectEnable = !0, this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

DebateCardDialog.TURN_TIME = 300, Laya.class(DebateCardDialog, "DebateCardDialog", DebateCardDialogUI);
var _proto_ = DebateCardDialog.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this.list_reward.array = new Array(6), this.list_reward.selectHandler = Laya.Handler.create(this, this.OnSelectReward), this.img_reward.visible = !1
}, _proto_.OnCreateReward = function (e, a) {
    var t = e.getChildByName("img_bg"), r = e.getChildByName("img_front"), i = r.getChildByName("lab_desc"),
        n = r.getChildByName("spr_icon");
    e._index = a;
    var o = this.list_reward.array[a];
    if (n.ItemIcon && (n.ItemIcon.removeSelf(), n.ItemIcon.destroy(), n.ItemIcon = null), !o) return t.scaleX = 1, void(r.scaleX = 0);
    var l = GameCommon._s66eb52e60b9feb53711943e638c9c3(o[0], o[1]);
    n.ItemIcon = l, n.addChild(l), i.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(o[0], o[1]) + "+" + o[2]
}, _proto_.OnSelectReward = function (e) {
    this._2308766331 = e, GetDataYamenInterface().DoGetCardReward({}, this.OnSelectCardCallback.bind(this))
}, _proto_.OnSelectCardCallback = function (e) {
    for (var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards)[0], t = GetDataTransfer().GetTableRecord("reward", global.$Cfg.Common.Yamen.CardRewardId).Award, r = [], i = 0; i < 6; i++) i == this._2308766331 ? r.push(a) : r.push(jasmin._s449f055209cd01229b1846559026f5(t));
    this.list_reward.array = r, _.each(this.list_reward.cells, function (e) {
        var t = e.getChildByName("img_bg"), r = e.getChildByName("img_front");
        e._index == this._2308766331 ? this._sc64f40fa0a5be7e13bf4b5adf7ec05(t, r, function () {
            this.img_reward.visible = !0, this.lab_desc.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(a[0], a[1]) + "+" + a[2]
        }) : Laya.timer.once(1.5 * DebateCardDialog.TURN_TIME, this, this._sc64f40fa0a5be7e13bf4b5adf7ec05.bind(this, t, r, this.OnSetPlayOver))
    }.bind(this))
}, _proto_._sc64f40fa0a5be7e13bf4b5adf7ec05 = function (e, a, t) {
    Laya.Tween.to(e, {scaleX: 0}, DebateCardDialog.TURN_TIME, null, Laya.Handler.create(this, function () {
        Laya.Tween.to(a, {scaleX: 1}, DebateCardDialog.TURN_TIME, null, Laya.Handler.create(this, t))
    }))
}, _proto_.OnSetPlayOver = function () {
    this._2779799143 = !0
}, _proto_.OnBtnCloseClick = function () {
    this._2779799143 && GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateCardDialog")
}, _proto_.OnClose = function () {
    this._2308766331 = null, this.list_reward.selectedIndex = -1, this._2779799143 = !1, this._4122736007.OnClose && this._4122736007.OnClose()
}, DebateCardDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateCardDialog.uiView, e)
};

function DebateDefeatedDialog() {
    DebateDefeatedDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(DebateDefeatedDialog, "DebateDefeatedDialog", DebateDefeatedDialogUI);
var _proto_ = DebateDefeatedDialog.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this.lab_score.text = this._4122736007.Score
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateDefeatedDialog"), this._4122736007.OnClose && this._4122736007.OnClose()
}, _proto_.OnClose = function () {
}, DebateDefeatedDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateDefeatedDialog.uiView, e)
};

function DebateDefendInfo() {
    DebateDefendInfo.super(this), this.list_record.renderHandler = Laya.Handler.create(this, this.OnCreateRecord, null, !1), this.list_record.vScrollBarSkin = null
}

Laya.class(DebateDefendInfo, "DebateDefendInfo", DebateDefendInfoUI);
var _proto_ = DebateDefendInfo.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = global.$Api.QueryDataSource("DataYamen")._sa1145d30006416cf307168a5330398();
    this.list_record.array = [], this.list_record.array = e.reverse()
}, _proto_.OnCreateRecord = function (e, a) {
    var t = e.getChildByName("lab_name"), r = e.getChildByName("lab_desc"), o = e.getChildByName("lab_score"),
        n = e.getChildByName("lab_ScoreFont"), i = e.getChildByName("lab_time"), l = e.getChildByName("lab_index"),
        s = e.getChildByName("lab_uid");
    l.text = a + 1;
    var c = this.list_record.array[a], d = c.Report;
    d.Rank.UserData || (d.Rank.UserData = {}), d.UserUid ? (s.visible = !0, s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.UidFont, d.UserUid)) : s.visible = !1, t.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.PlayerDesc, d.Rank.UserData.Name, d.Rank.Score), i.text = GameCommon._se02a7d4c4c833a7bf3503a3a5b8667(c.Time);
    var h = d.ChangeScore >= 0 ? "+" + d.ChangeScore : d.ChangeScore;
    o.text = "衙门分数" + h, d.ChangeScore > 0 ? (o.color = "#30875e", n.color = "#30875e") : (o.color = "#bd1c1c", n.color = "#bd1c1c");
    var m = gLanguage.Yamen.DefReport[d.Type][Number(d.AllDefeat)],
        f = global.$Sys.GetTableService().GetTableRecord("hero", d.HeroId).HeroName;
    r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(m, f, d.Count)
}, _proto_.OnClose = function () {
    this.visible = !1
};

function DebateEnemy() {
    DebateEnemy.super(this), this.list_record.renderHandler = Laya.Handler.create(this, this.OnCreateRecord, null, !1), this.list_record.vScrollBarSkin = null
}

Laya.class(DebateEnemy, "DebateEnemy", DebateEnemyUI);
var _proto_ = DebateEnemy.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = global.$Api.QueryDataSource("DataYamen")._sc73dd9d4b0a3faa075170ec7e75f6f();
    this.list_record.array = e
}, _proto_.OnCreateRecord = function (e, t) {
    var o = e.getChildByName("lab_name"), a = e.getChildByName("lab_power"), i = e.getChildByName("lab_office"),
        r = e.getChildByName("btn_fight"), l = e.getChildByName("lab_time"), n = e.getChildByName("lab_index");
    n.text = t + 1;
    var s = this.list_record.array[t];
    o.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.PlayerDesc, s.Name, s.Score), a.text = s.Attribute, s.Office && (i.text = global.$Sys.GetTableService().GetTableRecord("office", s.Office).OfficeName), l.text = GameCommon._se02a7d4c4c833a7bf3503a3a5b8667(s.Time), r.offAll(Laya.Event.CLICK), r.on(Laya.Event.CLICK, this, this.OnSelectHero, [s.Uid])
}, _proto_.OnSelectHero = function (e) {
    this._3902207494 = e;
    var t = GetDataYamenInterface()._s8909447fa2bbce8b2ebd4e79cc25a0(),
        o = global.$Cfg.Common.Yamen.ChallengeConsumeKey, a = {
            ShowType: ["Lv", "Aptitude", "TotalAptitude"],
            Callback: this.OnShowConsumeDialog.bind(this),
            Heros: t,
            Item: global.$Sys.GetTableService().GetTableRecord("consume", o).Consume[0][1],
            OnSort: function (e, t) {
                var o = global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 1) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 2) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 3) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 4),
                    a = global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 1) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 2) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 3) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 4);
                return a - o
            }
        };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateSelectHero", a)
}, _proto_.OnShowConsumeDialog = function (e) {
    this._1033097018 = e, GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectHero"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
        ConsumeId: global.$Cfg.Common.Yamen.ChallengeConsumeKey,
        Purpose: "复仇",
        OnConfirmUse: this.OnFightInit.bind(this)
    })
}, _proto_.OnFightInit = function () {
    var e = {DebateType: 3, UserId: this._3902207494, HeroId: this._1033097018};
    jasmin._se7a49036f5cfea7f559beac9db86e9(this._3902207494 && this._1033097018, "HeroId is Null or UserId is Null"), GetDataYamenInterface().DoDebateInit(e, function (e) {
        e.Result && (GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateRecord"))
    }.bind(this))
}, _proto_.OnClose = function () {
    this.visible = !1
};

function DebateFightScene() {
    DebateFightScene.super(this), this.btn_skip.on(Laya.Event.CLICK, this, this.OnBtnSkipClick)
}

Laya.class(DebateFightScene, "DebateFightScene", DebateFightSceneUI);
var _proto_ = DebateFightScene.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this.img_critBg.visible = !1, this._2779799143 = !1, this._1110078709 = e.Report, this._s4fb507d6d0f40b2d2a72f6007a938d(), this.OnShowNextReport()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = this._4122736007.StartAttribute;
    this._scb5e4cf3420f12213e590776ef3687(e);
    var t = global.$Sys.GetTableService().GetTableRecord("hero", e.HeroId[0]),
        a = global.$Sys.GetTableService().GetTableRecord("hero", e.HeroId[1]);
    this.lab_name1.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.HeroDesc, t.HeroName, e.Lv[0]), this.lab_name2.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.HeroDesc, a.HeroName, e.Lv[1]), this.lab_atk1.text = e.Atk[0], this.lab_atk2.text = e.Atk[1], GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_hero1, e.HeroId[0]), GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_hero2, e.HeroId[1])
}, _proto_._scb5e4cf3420f12213e590776ef3687 = function (e) {
    this.lab_hp1.text = Math.max(e.Hp[0], 0) + "/" + e.MaxHp[0], this.lab_hp2.text = Math.max(e.Hp[1], 0) + "/" + e.MaxHp[1], this.progress_hp1.value = Math.max(e.Hp[0], 0) / e.MaxHp[0], this.progress_hp2.value = Math.max(e.Hp[1], 0) / e.MaxHp[1]
}, _proto_.OnBtnSkipClick = function () {
    if (!this._2779799143) {
        this._2779799143 = !0, Laya.timer.clearAll(this), Laya.Tween.clearAll(this);
        var e = this._4122736007.Victory ? "DebateRewardDialog" : "DebateDefeatedDialog",
            t = jasmin._sdf8385ff3a74421ea218e043d47fdc(this._4122736007);
        t.OnClose = function () {
            return global.$Api.QueryDataSource("DataYamen")._s407e7203a7660b049de5d86572ee96() ? void GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateCardDialog", {OnClose: this.OnFinishCallback.bind(this)}) : void this.OnFinishCallback()
        }.bind(this), GetGuiManager()._s2e22e694b9852084df200bc86f9340(e, t)
    }
}, _proto_.OnFinishCallback = function () {
    if (!this._4122736007.Finish) return void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage");
    var e, t;
    this._4122736007.Victory ? (t = gLanguage.Yamen.HeroReport[2], e = gLanguage.Yamen.Toilsome) : this._4122736007.Count > 0 ? (t = gLanguage.Yamen.HeroReport[1], e = gLanguage.Yamen.Toilsome) : (t = gLanguage.Yamen.HeroReport[0], e = gLanguage.Yamen.Useless), GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateInfoDialog", {
        Button: [{Label: e}],
        ButtonSpace: 120,
        HeroId: this._4122736007.StartAttribute.HeroId[0],
        Info: jasmin._se91cf955e91eaa1aa510d4335edd4a(t, this._4122736007.StartAttribute.Name[1])
    }), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("YamenPage")
}, _proto_.OnClose = function () {
}, _proto_.OnShowNextReport = function (e) {
    if (!this._2779799143) {
        var t = this._1110078709.shift();
        t ? (this.img_hero1.scaleX = 1, this.img_hero2.scaleX = 1, this.img_hero1.scaleY = 1, this.img_hero2.scaleY = 1, Laya.timer.once(500, this, function () {
            this._s023078cf0d1a2dce14379a19221e17(t)
        }.bind(this))) : this.OnBtnSkipClick(), e && e()
    }
}, _proto_._s023078cf0d1a2dce14379a19221e17 = function (e) {
    this.img_hero1.filters = [], this.img_hero1.filters = [], async.waterfall([function (t) {
        var a = e.AtkRole ? this.img_hero1 : this.img_hero2, i = e.AtkRole ? this.img_hero2 : this.img_hero1;
        Laya.Tween.to(a, {scaleX: 1.2, scaleY: 1.2}, 200, null, Laya.Handler.create(this, function () {
            var e = [.3086, .6094, .082, 0, 0, .3086, .6094, .082, 0, 0, .3086, .6094, .082, 0, 0, 0, 0, 0, 1, 0],
                a = new Laya.ColorFilter(e);
            i.filters = [a], t()
        }))
    }.bind(this), function (t) {
        this.OnHeroAttackSay(t, e)
    }.bind(this), function (t) {
        this.OnPlayerCritEffect(t, e)
    }.bind(this), function (t) {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_hit), this.OnPlayEffect(t, e)
    }.bind(this), function (t) {
        this.OnHeroDefense(t, e)
    }.bind(this), function (t) {
        var a = e.AtkRole ? this.img_hero1 : this.img_hero2;
        Laya.Tween.to(a, {scaleX: 1, scaleY: 1}, 300, null, Laya.Handler.create(this, t))
    }.bind(this), function (e) {
        this.OnShowNextReport(e)
    }.bind(this)])
}, _proto_.OnHeroAttackSay = function (e, t) {
    var a = this._4122736007.StartAttribute, i = t.AtkRole ? 0 : 1,
        o = global.$Sys.GetTableService().GetTableRecord("hero", a.HeroId[i]), n = [];
    jasmin._s3c96e1f3bee730222501b208d50190(n, o.BrainsBook), jasmin._s3c96e1f3bee730222501b208d50190(n, o.ForceBook), jasmin._s3c96e1f3bee730222501b208d50190(n, o.PoliticalBook), jasmin._s3c96e1f3bee730222501b208d50190(n, o.PrestigeBook);
    var s = jasmin._s449f055209cd01229b1846559026f5(n), r = global.$Sys.GetTableService().GetTableRecord("book", s),
        h = r.BookDesc, l = t.AtkRole ? this.img_hero1 : this.img_hero2, g = l.getChildByName("box_dialog"),
        m = g.getChildByName("lab_desc");
    g.visible = !0, m.text = h, Laya.timer.once(800, this, function () {
        g.visible = !1, m.text = "", e()
    })
}, _proto_.OnPlayerCritEffect = function (e, t) {
    if (t.Crit) {
        var a = t.AtkRole ? this.spr_eff1 : this.spr_eff2;
        Laya.loader.load(global.$Cfg.Common.FightCritBgPng, Laya.Handler.create(this, function () {
            var t = new Effect, i = {
                Res: global.$Cfg.Common.FightCritBgEff,
                IsAutoRemove: !0,
                IsAutoHide: !0,
                Scale: 2.75,
                Size: [320, 190]
            };
            t.Init(i), t._s2e4033b88e999ce7271844dbf3b2dc([a.width / 2, a.height / 2], function () {
                e(), this.img_critBg.visible = !1
            }.bind(this)), a.addChild(t)
        })), this.img_critBg.visible = !0
    } else e()
}, _proto_.OnPlayEffect = function (e, t) {
    var a, i, o, n = t.AtkRole ? this.img_hero2 : this.img_hero1,
        s = t.AtkRole ? this.spr_fightEff2 : this.spr_fightEff1;
    t.Crit ? (a = global.$Cfg.Common.FightCritPng, i = global.$Cfg.Common.FightCritEff, o = [261, 247]) : (a = global.$Cfg.Common.InstanceBossFightPng, i = global.$Cfg.Common.InstanceBossFightEff, o = [400, 300]), Laya.loader.load(a, Laya.Handler.create(this, function () {
        var e = new Effect, t = {Res: i, IsAutoRemove: !0, IsAutoHide: !0, Scale: 2, Size: o};
        e.Init(t), e._s2e4033b88e999ce7271844dbf3b2dc([s.width / 2, s.height / 2]), s.addChild(e)
    }));
    var r = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], h = new Laya.ColorFilter(r);
    n.filters = [h], Laya.Tween.to(n, {scaleX: .9, scaleY: .9}, 250, null, Laya.Handler.create(this, function () {
        Laya.Tween.to(n, {scaleX: 1, scaleY: 1}, 250, null, Laya.Handler.create(this, function () {
            n.filters = [], e()
        }))
    }))
}, _proto_.OnHeroDefense = function (e, t) {
    if (!this._2779799143) {
        var a = t.AtkRole ? this.img_hero2 : this.img_hero1;
        cfg = {}, cfg.Info = -t.Atk, cfg.Font = "font3", cfg.Delay = 0, cfg.Time = 800, cfg.Dest = [a.x, a.y - 200, 0], cfg.Pos = [a.x, a.y - 100, 100];
        var i = new Leo.FloatInfo(cfg);
        if (i._sabbe27d79486b625a06ed3d6ebdec5(this), t.AtkRole) {
            this.lab_hp2.text = Math.max(t.Hp[1], 0) + "/" + t.MaxHp[1];
            var o = Math.max(t.Hp[1], 0) / t.MaxHp[1];
            Laya.Tween.to(this.progress_hp2, {value: o}, 800, null)
        } else {
            this.lab_hp1.text = Math.max(t.Hp[0], 0) + "/" + t.MaxHp[0];
            var o = Math.max(t.Hp[0], 0) / t.MaxHp[0];
            Laya.Tween.to(this.progress_hp1, {value: o}, 800, null)
        }
        var n = a.getChildByName("box_dialog"), s = n.getChildByName("lab_desc");
        n.visible = !0, s.text = jasmin._s449f055209cd01229b1846559026f5(gLanguage.Yamen.DefSay), Laya.timer.once(800, this, function () {
            n.visible = !1, s.text = "", e()
        })
    }
}, DebateFightScene.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateFightScene.uiView, e)
};

function DebateFindPlayer() {
    DebateFindPlayer.super(this), this.btn_find.on(Laya.Event.CLICK, this, this.OnBtnFindClick), this.btn_fight.on(Laya.Event.CLICK, this, this.OnBtnFightClick)
}

Laya.class(DebateFindPlayer, "DebateFindPlayer", DebateFindPlayerUI);
var _proto_ = DebateFindPlayer.prototype;
_proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    if (this.box_desc.visible = !!this._298084445, this._298084445) {
        var t = this._298084445.Data.UserData, e = this._298084445.Rank,
            i = GetDataTransfer().GetTableRecord("office", t.Office);
        this.lab_totalAttribute.text = t.TotalAttribute, this.lab_rank.text = e.Rank || gLanguage.NoJoinRank, this.lab_score.text = e.Score || gLanguage.NoJoinRank, this.lab_cnt.text = t.HeroCount, this.img_clothes.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing), this.img_headIcon.skin = global.$Cfg.Common.HeadIconName[t.Sex][t.HeadId], this.img_hand.skin = 1 == t.Sex ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, this.img_office.skin = i.OfficeIcon, this.lab_name.text = t.Name
    }
}, _proto_.OnClose = function () {
    this._298084445 = null, this.visible = !1, this._1005838456 = null
}, _proto_.OnBtnFindClick = function () {
    this.textInput_uid.text && GetDataYamenInterface().DoFind({User: this.textInput_uid.text}, function (t) {
        t.Result && (this._1005838456 = this.textInput_uid.text, this._298084445 = t, this._s4fb507d6d0f40b2d2a72f6007a938d())
    }.bind(this))
}, _proto_.OnBtnFightClick = function () {
    this._1005838456 && this.OnSelectHero(this._1005838456)
}, _proto_.OnSelectHero = function (t) {
    this._3902207494 = t;
    var e = GetDataYamenInterface()._s8909447fa2bbce8b2ebd4e79cc25a0(), i = global.$Cfg.Common.Yamen.ChaseConsumeKey,
        a = {
            ShowType: ["Lv", "Aptitude", "TotalAptitude"],
            Callback: this.OnShowConsumeDialog.bind(this),
            Heros: e,
            Item: global.$Sys.GetTableService().GetTableRecord("consume", i).Consume[0][1]
        };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateSelectHero", a)
}, _proto_.OnShowConsumeDialog = function (t) {
    this._1033097018 = t, GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectHero"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
        ConsumeId: global.$Cfg.Common.Yamen.ChaseConsumeKey,
        Purpose: "追杀",
        OnConfirmUse: this.OnFightInit.bind(this)
    })
}, _proto_.OnFightInit = function () {
    var t = {DebateType: 4, UserId: this._3902207494, HeroId: this._1033097018};
    jasmin._se7a49036f5cfea7f559beac9db86e9(this._3902207494 && this._1033097018, "HeroId is Null or UserId is Null"), GetDataYamenInterface().DoDebateInit(t, function (t) {
        t.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateRecord"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage"))
    }.bind(this))
}, DebateFindPlayer.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateFindPlayer.uiView, t)
};

function DebateInfoDialog() {
    DebateInfoDialog.super(this), this.html_desc.style.fontSize = 25, this.html_desc.style.align = "center"
}

DebateInfoDialog.BUTTON_SKIN = "res/ui/button/z_but_03.png", Laya.class(DebateInfoDialog, "DebateInfoDialog", DebateInfoDialogUI);
var _proto_ = DebateInfoDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = this._4122736007.HeroId;
    GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_role, t), this.html_desc.innerHTML = this._4122736007.Info, this.hBox_btn.destroyChildren(), _.each(this._4122736007.Button, function (t) {
        var e = new Laya.Button(DebateInfoDialog.BUTTON_SKIN);
        e.stateNum = 1, e.runtime = Leo.ScaleButton, e.label = t.Label, e.on(Laya.Event.CLICK, this, this.OnClick, [t.OnClick]), e.labelSize = 25, e.labelColors = "#7a4b29", this.hBox_btn.addChild(e)
    }.bind(this)), this.hBox_btn.space = this._4122736007.ButtonSpace || 120, this.hBox_btn.refresh()
}, _proto_.OnClick = function (t) {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateInfoDialog"), t && t()
}, DebateInfoDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateInfoDialog.uiView, t), t.push(DebateInfoDialog.BUTTON_SKIN)
};

function DebateMainPage() {
    DebateMainPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_hero.renderHandler = Laya.Handler.create(this, this.OnCreateHeroBox, null, !1), this.btn_buff.on(Laya.Event.CLICK, this, this.OnBtnBuffClick)
}

Laya.class(DebateMainPage, "DebateMainPage", DebateMainPageUI);
var _proto_ = DebateMainPage.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d(), global.$Api.QueryDataSource("DataYamen")._s2d19f4c76c8729b917517a9418a239() && !this.checkBtn_buff.selected && this.OnBtnBuffClick()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData"), t = e.HeroId, a = e.DabateHero,
        i = GetDataTransfer().GetTableRecord("hero", t);
    GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_role, t), this.lab_attribute.text = a.Atk, this.lab_atkBuff.text = a.Buffs.Atk / 100 + "%", this.lab_skillBuff.text = a.Buffs.Skill / 100 + "%", this.lab_hp.text = a.Hp + "/" + a.MaxHp, this.progress_hp.value = a.Hp / a.MaxHp, this.lab_heroName.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.HeroDesc, i.HeroName, a.Agi), this.lab_winCnt.text = global.$Api.QueryDataSource("DataYamen")._s2796ec143fe7fc07e20775d0cc0311(), this._1056589751 ? this.list_hero.array = this._1056589751 : global.$Api.QueryDataSource("DataYamen")._sa92864dea93fd57220565ea8f50362() ? GetDataYamenInterface().DoDebateGetInfo({}, this.OnRefreshHeroList.bind(this)) : GetDataYamenInterface().DoDebateSetOpponent({}, this.OnRefreshHeroList.bind(this))
}, _proto_.OnCreateHeroBox = function (e, t) {
    var a = e.getChildByName("img_quality"), i = e.getChildByName("img_headIcon"), n = e.getChildByName("img_flicker"),
        o = this.list_hero.array[t];
    a.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, o.Title), GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(i, o.HeroId), e.offAll(Laya.Event.CLICK), e.on(Laya.Event.CLICK, this, this.OnFight, [t]), n.Action || (n.Action = new Leo.ImageActionManager({Image: n}), n.Action._sc95f42251335b3aa0013090797aec9("Flicker", {Time: 2e3})), n.Action._s54107fed721f2f5f6636c3b2747bef(), n.Action._s2e4033b88e999ce7271844dbf3b2dc()
}, _proto_.OnFight = function (e) {
    this._fightFuc(e)
}, _proto_._fightFuc = function (e) {
    GetDataYamenInterface().DoDebate({Index: e}, function (e) {
        e.Result && (this._1056589751 = null, GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateFightScene", e))
    }.bind(this))
}, _proto_.OnRefreshHeroList = function (e) {
    if (e.Result) {
        this._1056589751 = e.HeroList, this.list_hero.array = this._1056589751;
        var t = global.$Api.QueryDataSource("DataYamen").GetValue("Opponent");
        this.lab_userName.text = t.Name, this.lab_score.text = Math.max(t.Score + t.ChangeScore, 0), this.lab_cnt.text = global.$Api.QueryDataSource("DataYamen")._s2796ec143fe7fc07e20775d0cc0311() + "/" + t.MaxHero, this.hBox_cnt.refresh(), this.hBox_score.refresh();
        var a = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
        this.lab_playerName.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.PlayerDesc, a, e.Score)
    }
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("YamenPage")
}, _proto_.OnClose = function () {
    _.each(this.list_hero.cells, function (e) {
        var t = e.getChildByName("img_flicker");
        t.Action && t.Action._s54107fed721f2f5f6636c3b2747bef()
    })
}, _proto_.OnBtnBuffClick = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateSelectBuff", {
        OnClose: function () {
            this._s4fb507d6d0f40b2d2a72f6007a938d()
        }.bind(this)
    })
}, DebateMainPage.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateMainPage.uiView, e)
};

function DebateRank() {
    DebateRank.super(this), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(DebateRank, "DebateRank", DebateRankUI);
var _proto_ = DebateRank.prototype;
_proto_.OnShow = function (a) {
    this._4122736007 = a, this._1092471860Data ? this._s4fb507d6d0f40b2d2a72f6007a938d() : GetDataYamenInterface().DoGetRank({}, function (a) {
        jasmin._se7a49036f5cfea7f559beac9db86e9(a.Result, "Get RankData Error!!!!"), this._1092471860Data = a, this._1092471860Data.ShowTag = {
            Rank: null,
            Name: null,
            Score: null,
            Office: null
        }, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }.bind(this))
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateRank")
}, _proto_.OnClose = function () {
};

function DebateRecord() {
    DebateRecord.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.radio_type.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1)
}

Laya.class(DebateRecord, "DebateRecord", DebateRecordUI);
var _proto_ = DebateRecord.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this.radio_type.selectedIndex = 0, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_.OnSelectType = function (e) {
    switch (this._s90746ef77ff05d47cb37e68d587694(), e) {
        case 0:
            this._437518151 || (this._437518151 = new DebateDefendInfo, this.ui_box.addChild(this._437518151)), this._437518151.visible = !0, this._437518151._s4fb507d6d0f40b2d2a72f6007a938d();
            break;
        case 1:
            this._3690355777 || (this._3690355777 = new DebateEnemy, this.ui_box.addChild(this._3690355777)), this._3690355777.visible = !0, this._3690355777._s4fb507d6d0f40b2d2a72f6007a938d();
            break;
        case 2:
            this._4192039649 || (this._4192039649 = new DebateFindPlayer, this.ui_box.addChild(this._4192039649)), this._4192039649.visible = !0, this._4192039649._s4fb507d6d0f40b2d2a72f6007a938d()
    }
}, _proto_._s90746ef77ff05d47cb37e68d587694 = function () {
    this._3690355777 && this._3690355777.OnClose(), this._437518151 && this._437518151.OnClose(), this._4192039649 && this._4192039649.OnClose()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
}, _proto_.OnClose = function () {
    this._s90746ef77ff05d47cb37e68d587694(), this.radio_type.selectedIndex = -1, GetDataYamenInterface().DoClearNewReport()
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateRecord")
}, DebateRecord.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateRecord.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateDefendInfo.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateEnemy.uiView, e)
};

function DebateReport() {
    DebateReport.super(this), this.list_report.renderHandler = Laya.Handler.create(this, this.OnCreateRecord, null, !1), this.list_report.vScrollBarSkin = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_closeCopy.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(DebateReport, "DebateReport", DebateReportUI);
var _proto_ = DebateReport.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    for (var e = this._4122736007.Report, t = {}, a = null, o = 0; o < e.length; o++) {
        var i = e[o].Report, l = i.Names, r = l[0], n = l[1];
        t[r] || (t[r] = {}), t[r][n] || (t[r][n] = 0), t[r][n]++, a ? a.Count < t[r][n] && (a = {
            Killer: r,
            Defender: n,
            Count: t[r][n]
        }) : a = {Killer: r, Defender: n, Count: t[r][n]}
    }
    this._2827241425 = a, this._2827241425 && this._2827241425.Count && this._2827241425.Count < 3 && (this._2827241425 = null), this._499107539 = [];
    for (var o = 0; o < e.length; o++) {
        var i = e[o].Report, l = i.Names, r = l[0], n = l[1];
        t[r][n] && t[r][n] >= 3 ? (this._499107539.push(t[r][n]), t[r][n]--) : this._499107539.push(null)
    }
    this.list_report.array = [], this.list_report.array = e, this._2827241425 ? (this.sp_haowai.visible = !0, this.html_haowai.style.fontSize = 25, this.html_haowai.innerHTML = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.Yamen.Haowai, this._2827241425.Killer, this._2827241425.Defender, this._2827241425.Count)) : this.sp_haowai.visible = !1
}, _proto_.OnCreateRecord = function (e, t) {
    var a = e.getChildByName("hBox_desc"), o = e.getChildByName("hBox_Name"), i = o.getChildByName("lab_recordName"),
        l = a.getChildByName("lab_recordHero"), r = a.getChildByName("lab_enemy"), n = e.getChildByName("lab_index"),
        s = a.getChildByName("lab_recordCnt"), h = e.getChildByName("lab_time"), m = e.getChildByName("btn_fight"),
        u = o.getChildByName("lab_liansha"), g = o.getChildByName("img_King"), d = this.list_report.array[t],
        b = this._499107539[t], p = d.Report, _ = gLanguage.Yamen,
        C = GetDataTransfer().GetTableRecord("hero", p.HeroId).HeroName;
    if (4 == p.Type) {
        var f = _[p.AllDefeat ? "AllDefeatType4" : "DefeatType4"];
        l.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(_.HeroDefeat, C, f), s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(_.HeroCountType4, p.Count)
    } else {
        var c = _[p.AllDefeat ? "AllDefeat" : "Defeat"];
        l.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(_.HeroDefeat, C, c), s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(_.HeroCount, p.Count)
    }
    var D = p.Uid ? "(编号 " + p.Uid + ")" : "";
    if (i.text = p.Names[0] + D, b ? (u.visible = !0, u.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.Yamen.Liansha, b), u.x = i.x + i.width + 20) : u.visible = !1, g.visible = !1, p.KingInfo) {
        var y = global.$Sys.GetTableService().GetTableRecord("throne", p.KingInfo.KingId);
        Laya.loader.load(y.NameFontPath, Laya.Handler.create(this, function () {
            g.skin = y.NameFontPath, g.visible = !0, o.changeItems()
        }))
    }
    o.changeItems(), r.text = p.Names[1], n.text = t + 1, h.text = jasmin._sf60b29247c48694418b19d6d5ef097("时间:  yyyy-MM-dd      hh:mm:ss", new Date(d.Time)), a.refresh(), m.offAll(Laya.Event.CLICK), m.on(Laya.Event.CLICK, this, this.OnSelectHero, [p.Uid])
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateReport")
}, _proto_.OnClose = function () {
}, _proto_.OnSelectHero = function (e) {
    this._3902207494 = e;
    var t = GetDataYamenInterface()._s8909447fa2bbce8b2ebd4e79cc25a0(),
        a = global.$Cfg.Common.Yamen.ChallengeConsumeKey, o = {
            ShowType: ["Lv", "Aptitude", "TotalAptitude"],
            Callback: this.OnShowConsumeDialog.bind(this),
            Heros: t,
            Item: global.$Sys.GetTableService().GetTableRecord("consume", a).Consume[0][1],
            OnSort: function (e, t) {
                var a = global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 1) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 2) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 3) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(e.Books, 4),
                    o = global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 1) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 2) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 3) + global.$Api.Formula._s54069e59e1b8f7b5a2c28630e34465(t.Books, 4);
                return a < o
            }
        };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateSelectHero", o)
}, _proto_.OnShowConsumeDialog = function (e) {
    this._1033097018 = e, GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectHero"), GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
        ConsumeId: global.$Cfg.Common.Yamen.ChallengeConsumeKey,
        Purpose: "挑战",
        OnConfirmUse: this.OnFightInit.bind(this)
    })
}, _proto_.OnFightInit = function () {
    var e = {DebateType: 2, UserId: this._3902207494, HeroId: this._1033097018};
    jasmin._se7a49036f5cfea7f559beac9db86e9(this._3902207494 && this._1033097018, "HeroId is Null or UserId is Null"), GetDataYamenInterface().DoDebateInit(e, function (e) {
        e.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateReport"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage"))
    }.bind(this))
}, DebateReport.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateReport.uiView, e)
};

function DebateRewardDialog() {
    DebateRewardDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(DebateRewardDialog, "DebateRewardDialog", DebateRewardDialogUI);
var _proto_ = DebateRewardDialog.prototype;
_proto_.OnShow = function (a) {
    this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var a = this._4122736007.Rewards;
    this.lab_score.text = "+" + this._4122736007.Score, this.lab_vindictive.text = "+" + (jasmin._s2dedbd0e220887101c856bf900fc57(a.DataYamen) ? 0 : a.DataYamen[0][2]), this.lab_exp.text = "+" + (jasmin._s2dedbd0e220887101c856bf900fc57(a.DataHero) ? 0 : a.DataHero[0][2]);
    var e = global.$Api.QueryDataSource("DataYamen")._s2796ec143fe7fc07e20775d0cc0311();
    this.lab_cnt.text = e, this.lab_needCnt.text = global.$Cfg.Common.Yamen.RewardNeedCount - e % global.$Cfg.Common.Yamen.RewardNeedCount
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateRewardDialog"), this._4122736007.OnClose && this._4122736007.OnClose()
}, _proto_.OnClose = function () {
}, DebateRewardDialog.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateRewardDialog.uiView, a)
};

function DebateSelectBuff() {
    DebateSelectBuff.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_buff.renderHandler = Laya.Handler.create(this, this.OnCreateBuffBox, null, !1), this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, {ShowType: ["Gold", "Vindictive"]})
}

Laya.class(DebateSelectBuff, "DebateSelectBuff", DebateSelectBuffUI);
var _proto_ = DebateSelectBuff.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e || {}, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d();
    var e = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData"), t = e.DabateHero;
    this.lab_atkBuff.text = Math.floor(t.Buffs.Atk / 1e4 * 100) + "%", this.lab_skillBuff.text = Math.floor(t.Buffs.Skill / 1e4 * 100) + "%", this.lab_hp.text = Math.floor(t.Hp / t.MaxHp * 100) + "%", this.progress_hp.value = t.Hp / t.MaxHp;
    var a = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData").Buffs;
    this.list_buff.array = a
}, _proto_.OnCreateBuffBox = function (e, t) {
    var a = e.getChildByName("lab_name"), f = e.getChildByName("img_get"), o = e.getChildByName("btn_addBuff"),
        l = e.getChildByName("img_icon"), n = e.getChildByName("spr_consume"), i = e.getChildByName("lab_consume"),
        s = e.getChildByName("hBox_buff"), r = s.getChildByName("lab_desc"), u = s.getChildByName("lab_buffValue"),
        c = this.list_buff.array[t], h = GetDataTransfer().GetTableRecord("debate_buff", c.BuffType, c.BuffId),
        B = GetDataTransfer().GetTableRecord("consume", c.Consume).Consume[0];
    a.text = h.Name, r.text = h.Des, u.text = Math.floor(jasmin._s2bf229f90aefd2aaf2b83aeca7017c(c.Buff, 0) / 100) + "%", s.refresh(), l.skin = h.BuffIcon, n.Icon && (n.Icon.removeSelf(), n.Icon.destroy(), n.Icon = null);
    var m = GameCommon._s66eb52e60b9feb53711943e638c9c3(B[0], B[1], !0);
    n.Icon = m, n.addChild(m), i.text = B[2];
    var d = global.$Api.QueryDataSource("DataYamen")._s2d19f4c76c8729b917517a9418a239();
    f.visible = c.Select, o.visible = d, o.offAll(Laya.Event.CLICK), o.on(Laya.Event.CLICK, this, this.OnBtnAddBuffClick, [t])
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectBuff")
}, _proto_.OnBtnAddBuffClick = function (e) {
    GetDataYamenInterface().DoAddBuff({Index: e}, function (t) {
        t.Result && this.OnPlayerEffect(e)
    }.bind(this))
}, _proto_.OnPlayerEffect = function () {
    this._s4fb507d6d0f40b2d2a72f6007a938d(), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectBuff")
}, _proto_.OnClose = function () {
    _.each(this.list_buff.cells, function (e) {
        var t = e.getChildByName("spr_consume"), a = e.getChildByName("btn_addBuff");
        t.Icon && (t.Icon.removeSelf(), t.Icon.destroy(), t.Icon = null), a.offAll(Laya.Event.CLICK)
    }), this._4122736007.OnClose && this._4122736007.OnClose()
}, DebateSelectBuff.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateSelectBuff.uiView, e)
};

function DebateSelectHero() {
    DebateSelectHero.super(this), this._1277725458 = HeroListController._s0daf7356f401bde6dc31ec8d9f8bc8(this.list_hero), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(DebateSelectHero, "DebateSelectHero", DebateSelectHeroUI);
var _proto_ = DebateSelectHero.prototype;
_proto_.OnShow = function (e) {
    var t = {ShowType: e.ShowType, Callback: e.Callback, Heros: e.Heros, OnSort: e.OnSort};
    this._1277725458.Init(t), this._3537444593 = e.Item, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetDataTransfer().GetTableRecord("item", this._3537444593);
    this.lab_title.text = e.ItemName + "x" + global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(this._3537444593), this._1277725458._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateSelectHero")
};

function DebateStartDialog() {
    DebateStartDialog.super(this), this.btn_cancel.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_ok.on(Laya.Event.CLICK, this, this.OnBtnOkClick)
}

Laya.class(DebateStartDialog, "DebateStartDialog", DebateStartDialogUI);
var _proto_ = DebateStartDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData").HeroId;
    GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_role, t)
}, _proto_.OnBtnOkClick = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateStartDialog")
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DebateStartDialog")
}, _proto_.OnClose = function () {
}, DebateStartDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DebateStartDialog.uiView, t)
};
var DebugWin;
!function () {
    DebugWin = function () {
        DebugWin.super(this), this._1361675139 = new Laya.Panel, this.addChild(this._1361675139), this._2693770134 = 40, this._s87b790bbce1408f4c9a9da4e4679b7(), this._sa83c886c057ed9bcc2e963e7e61c1b(), this._sc097f88077194b89dd7709e46a8f91(), this._s94a2e6692c6c285c471f1fffd5e006()
    }, Laya.class(DebugWin, "DebugWin", Laya.Dialog);
    var e = DebugWin.prototype;
    e._s94a2e6692c6c285c471f1fffd5e006 = function () {
        var e = new Laya.Panel;
        e.y = this._2693770134, this._1361675139.addChild(e), this._1529421458 = e, this._1529421458.vScrollBarSkin = null
    }, e._s87b790bbce1408f4c9a9da4e4679b7 = function () {
        this._3141556942 = new Laya.Sprite, this._3141556942.height = this._2693770134;
        var e = new Laya.Label;
        e.fontSize = 35, e.color = "#000000", this._3141556942.addChild(e), this._2552057814 = e, this._1361675139.addChild(this._3141556942)
    }, e._sa83c886c057ed9bcc2e963e7e61c1b = function () {
        var e = new Laya.Panel;
        e.y = this._2693770134, this._1361675139.addChild(e), this._2151681646 = e, this._2151681646.vScrollBarSkin = null
    }, e._sc097f88077194b89dd7709e46a8f91 = function () {
        var e = new Laya.Button(null, "X");
        e.labelSize = 35, e.labelColors = "#E51400", e.on(Laya.Event.CLICK, this, this._OnCloseBtnClick), e.y = 0, e.height = 30, e.width = 25, this._1361675139.addChild(e), this._2717454683 = e, e.zOrder = 3e3, this._1361675139.addChild(e)
    }, e._OnCloseBtnClick = function () {
        this.dialogCloseCallBack && this.dialogCloseCallBack(), this.close()
    }, e.OnShow = function (e) {
        this._sf16caabd8c4a0d3f83c5886891c9bc(e.Config), this._s5d9e872f72c208ce3b3631503f5d0c(e.Menus)
    }, e._sf16caabd8c4a0d3f83c5886891c9bc = function (e) {
        this._sc708c83f50feaf45abe0b8760d5dde(e), this._s633a5be952d57275ea8ec5dbece981(e), this._sc67a4fd7e5e456687ec297ad9a73b0(e)
    }, e._sc708c83f50feaf45abe0b8760d5dde = function (e) {
        this._1361675139.width = e.width, this._1361675139.height = e.height, this._1361675139.centerX = .5, this._1361675139.centerY = .5, this._1361675139.graphics.drawRect(0, 0, this._1361675139.width, this._1361675139.height, "#ffffff"), this._2717454683.x = e.width - 25
    }, e._s633a5be952d57275ea8ec5dbece981 = function (e) {
        this._3141556942.width = e.width, this._3141556942.graphics.drawRect(0, 0, e.width, this._2693770134, "#ffffff"), this._2552057814.text = e.title
    }, e._sc67a4fd7e5e456687ec297ad9a73b0 = function (e) {
        this._4188308503 = e.menuWidth, this._2151681646.width = this._4188308503, this._2151681646.height = this._1361675139.height - this._2693770134, this._2151681646.graphics.drawRect(0, 0, this._2151681646.width, this._2151681646.height, "#202e3b"), this._1529421458.x = this._4188308503, this._1529421458.width = this._1361675139.width - this._4188308503, this._1529421458.height = this._1361675139.height - this._2693770134, this._1529421458.graphics.drawRect(0, 0, this._1529421458.width, this._1529421458.height, "#d6d6d6"), this._795196612 = e.menuFontSize, this._3826113941 = e.subMenuWidth, this._3390600716 = e.subMenuFontSize, this._3299339398 = e.showSort
    }, e._s5d9e872f72c208ce3b3631503f5d0c = function (e) {
        this._2151681646._Menu && (this._2151681646._Menu.removeSelf(), this._2151681646._Menu.destroy(), this._2151681646._Menu = null);
        var i = new Laya.UIGroup;
        i.space = 10, i.direction = "vertical", this._2151681646.addChild(i), this._2151681646._Menu = i, i.initItems(), _.each(e, function (e, t) {
            var n = new Laya.Radio(null, t);
            n.height = 50, n.width = this._4188308503, n.labelColors = "#d5dde3", n.labelSize = this._795196612 || 30, n.labelPadding = "10,10,10,10", n.text.zOrder = 101, n.SubMenus = e, n.graphics.drawRect(0, 0, n.width - 5, n.height, null, "#ffffff"), i.addItem(n)
        }.bind(this)), i.on(Laya.Event.CHANGE, this, this._OnGroupChange), i.selectedIndex = 0
    }, e._OnGroupChange = function (e) {
        var i = this._2151681646._Menu.selection.SubMenus;
        this._1529421458.removeChildren();
        for (var t = 10, n = 1; ;) {
            if (t + n * this._3826113941 + (n - 1) * t >= this._1529421458.width) {
                n--;
                break
            }
            n++
        }
        var e = 0;
        _.each(i, function (i, h) {
            this._3299339398 && (h = e + 1 + "." + h);
            var a = new Laya.Button(null, h);
            a.width = this._3826113941, a.labelSize = this._3390600716 || 30, a.height = 50, a.labelColors = "#000000";
            var l = e % n, s = l * this._3826113941 + (l + 1) * t;
            a.x = s;
            var u = parseInt(e / n);
            a.y = 50 * u + (u + 1) * t, a.on(Laya.Event.CLICK, null, i), a.graphics.drawRect(0, 0, a.width, a.height, null, "#000000"), this._1529421458.addChild(a), e++
        }.bind(this))
    }
}();

function DetainDialog() {
    DetainDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnClick)
}

Laya.class(DetainDialog, "DetainDialog", DetainDialogUI);
var _proto_ = DetainDialog.prototype;
_proto_.OnShow = function (i) {
    this._4122736007 = i, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var i = this._4122736007.PrisonerId, a = GetDataTransfer().GetTableRecord("prisoner", i);
    this.lab_dialog.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.PrisonerChange, a.PrisonerName), GameCommon._sf6fcc5a5f43833128a7bdc3720f01f(this.img_prisoner, i), this.lab_title.text = gLanguage.PrisonerIndex[i]
}, _proto_.OnClose = function () {
}, _proto_.OnClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DetainDialog")
}, DetainDialog.GetPreLoadResList = function (i) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DetainDialog.uiView, i)
};

function DetainPrisonerDialog() {
    DetainPrisonerDialog.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnClick)
}

Laya.class(DetainPrisonerDialog, "DetainPrisonerDialog", DetainPrisonerDialogUI);
var _proto_ = DetainPrisonerDialog.prototype;
_proto_.OnShow = function (i) {
    this._4122736007 = i, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var i = this._4122736007.PrisonerId, o = GetDataTransfer().GetTableRecord("prisoner", i);
    this.lab_dialog.text = o.PrisonerName, GameCommon._sf6fcc5a5f43833128a7bdc3720f01f(this.img_prisoner, i)
}, _proto_.OnClose = function () {
    this._4122736007.OnClose && this._4122736007.OnClose()
}, _proto_.OnClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("DetainPrisonerDialog")
}, DetainPrisonerDialog.GetPreLoadResList = function (i) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(DetainPrisonerDialog.uiView, i)
};
var FightBossView;
!function () {
    FightBossView = function () {
        FightBossView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnClickClose), this.on("BossDead", this, this.OnBossDead)
    }, Laya.class(FightBossView, "FightBossView", LevelFightBossUI), FightBossView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LevelFightBossUI.uiView, e)
    };
    var e = FightBossView.prototype;
    e.OnBossDead = function (e) {
        var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
        GetFightInterface()._s360371f813388bc01c0779166acb18(t, function () {
            var e = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"), t = e - 1,
                a = global.$Sys.GetTableService().GetTableRecord("level", t), i = a.PrisonerID;
            return i && !GetInspection() ? void GetGuiManager()._s2e22e694b9852084df200bc86f9340("DetainPrisonerDialog", {
                PrisonerId: i,
                OnClose: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Level")
                }
            }, null, {
                popupEffect: function (e, t) {
                    var a = Laya.Tween.from(e, {
                        y: 100,
                        alpha: 0
                    }, 1e3, Laya.Ease.backOut, Laya.Handler.create(null, t));
                    return e.alpha = 0, a
                }
            }) : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Level")
        })
    }, e.OnClickClose = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Level")
    }, e.OnClose = function () {
        this._811026184._sde752cfc0009e77744b1da7ea3c4c7(), this._811026184 = null, this.m_OnClose && this.m_OnClose()
    }, e.OnShow = function (e) {
        var t = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"),
            a = global.$Api.QueryDataSource("DataLevel").GetValue("StageId");
        this._811026184 = new BossFightInterface({BossId: [t, a], UI: this, Interface: GetLevelBossInterface()});
        var i = global.$Sys.GetTableService().GetTableRecord("level", t), o = i.BossId,
            s = global.$Sys.GetTableService().GetTableRecord("npc", o);
        this.img_BossHead.skin = s.HeadPath
    }
}();
var GetBossViewFactory;
!function () {
    function e() {
        this._776227573 = {Level: 1}
    }

    GetBossViewFactory = jasmin._s1a533d19f32767fb032c0d5565ac3b(e);
    var t = e.prototype;
    e.Interface = {}, e.Interface._s1e5a7b543e3945664f81637be170c8 = function () {
    }, e.Interface._saeae558cedc343087af67e0bd01c99 = function () {
    }, e.Interface._sb8095e45252483116d01dd7708a595 = function () {
    }, e.Interface._s810f50ea59bab5e187685e1a2da38e = function () {
    }, t._s41590f6e0d88a235ec1afb8e9b06ae = function (e) {
        return this._776227573[e]
    }, t._se052477c848947f7a453615b0d70c2 = function (t, n) {
        switch (t) {
            case this._s41590f6e0d88a235ec1afb8e9b06ae("Level"):
                return this._s3479b69babae6a9211067311a7b99e(LevelBoss, e.Interface), new LevelBoss(n)
        }
    }, t._s3479b69babae6a9211067311a7b99e = function (e, t) {
        var n = _.functions(e.prototype);
        _.each(t, function (e, t) {
            jasmin._se7a49036f5cfea7f559beac9db86e9(_.indexOf(n, t) !== -1, "No Func Name " + t)
        })
    }
}();
var FightSelectHero;
!function () {
    FightSelectHero = function () {
        FightSelectHero.super(this), this.list_Hero.vScrollBarSkin = null, this.list_Hero.renderHandler = new Laya.Handler(this, this.OnCreateHero), this.btn_Sort.on(Laya.Event.CLICK, this, this.OnSortHero), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightSelectHero")
        }), this._1428207481 = FightSelectHero.SORT_DOWN
    }, Laya.class(FightSelectHero, "FightSelectHero", FightSelectHeroUI), FightSelectHero.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(FightSelectHeroUI.uiView, e)
    }, FightSelectHero.SORT_UP = 1, FightSelectHero.SORT_DOWN = 2;
    var e = FightSelectHero.prototype;
    e.OnShow = function (e) {
        this._3078968613 = e.HeroId, this._2973916417 = e.OnGetHeros, this.OnUpdateList()
    }, e.OnUpdateList = function () {
        this.list_Hero.array = [], this.list_Hero.array = this._2973916417()
    }, e.OnCreateHero = function (e, t) {
        var o = e.dataSource, r = o.HeroId, i = global.$Api.QueryDataSource("DataHero").GetHeroById(r),
            a = GetDataTransfer().GetTableRecord("hero", r),
            n = global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(r, CommonEnum.HeroAttribute.FORCE);
        e.getChildByName("lab_Name").text = a.HeroName, e.getChildByName("lab_Lv").text = i.Lv, e.getChildByName("lab_Force").text = n.Aptitude, e.getChildByName("lab_FightValue").text = global.$Api.ShareFunc._s9e6dd25308f0d2dacbf8918bf88f60(r);
        var l = e.getChildByName("btn_Fight");
        l.off(Laya.Event.CLICK, this, this.OnSelectHero), o.OnSelectHero ? (l.visible = !0, l.on(Laya.Event.CLICK, this, this.OnSelectHero, [o])) : l.visible = !1;
        var h = e.getChildByName("GuestHeadBgImg"),
            s = jasmin._se91cf955e91eaa1aa510d4335edd4a(gCfg.HeroQualityBcgPath, i.Title);
        Laya.loader.load(s, Laya.Handler.create(this, function () {
            h.skin = s
        }));
        var H = h.getChildByName("GuestHeadImg");
        GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(H, r), H.centerX = 0, H.centerY = 0;
        var c = e.getChildByName("btn_Recover");
        if (c.off(Laya.Event.CLICK, this, this.OnRecoverHero), o.OnRecoverHero) {
            if (o.OnCanRecoverHero && !o.OnCanRecoverHero(o.HeroId)) return void(c.visible = !1);
            c.visible = !0, c.on(Laya.Event.CLICK, this, this.OnRecoverHero, [o])
        } else c.visible = !1
    }, e.OnRecoverHero = function (e, t) {
        e.OnRecoverHero(e.HeroId, function () {
            this.OnUpdateList()
        }.bind(this))
    }, e.OnSelectHero = function (e) {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightSelectHero"), e.OnSelectHero()
    }, e.OnSortHero = function () {
        this._1428207481 == FightSelectHero.SORT_UP ? (this._1428207481 = FightSelectHero.SORT_DOWN, this.lab_Sort.text = global.$Cfg.Language.FightSelectHeroSortUp) : (this._1428207481 = FightSelectHero.SORT_UP, this.lab_Sort.text = global.$Cfg.Language.FightSelectHeroSortDown), this.list_Hero.array = [], this.list_Hero.array = this._2973916417(this._1428207481)
    }
}();
var FightView = function () {
    function t() {
        t.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightView")
        }), this.btn_StartFight.on(Laya.Event.CLICK, this, this.OnStartFight), Laya.getset(0, this.btn_StartFight, "mouseEnabled", function () {
            return !(Leo.ScaleButton._EnabledClickCD && Leo.ScaleButton._MouseEnabledCnt > 0) && this.__super.prototype._$get_mouseEnabled.call(this)
        }, function (t) {
            this.__super.prototype._$set_mouseEnabled.call(this, t)
        });
        var i = new Leo.ImageActionManager({Image: this.btn_StartFight});
        i._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: 1.1,
            ScaleY: 1.1,
            BreatherTime: 1e3
        }), this._1682291669 = i
    }

    return Laya.class(t, "FightView", FightNpcUI), t.GetPreLoadResList = function (t, i) {
        var e = i.Fighters.EnemyData.NpcId, a = "ani/FightEnemy" + e + ".ani",
            o = "res/atlas/atlas/fight/enemy" + e + ".atlas";
        t.push([{url: gCfg.Sound.UI.z_ui_hit, type: Laya.Loader.SOUND}, {
            url: "res/atlas/atlas/fight/hero1.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero1.ani", type: Laya.Loader.JSON}, {
            url: "res/atlas/atlas/fight/hero2.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero2.ani", type: Laya.Loader.JSON}, {
            url: "res/atlas/atlas/fight/hero3.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero3.ani", type: Laya.Loader.JSON}]);
        for (var h = 1; h <= 6; h++) {
            var a = "ani/FightEnemy" + h + ".ani", o = "res/atlas/atlas/fight/enemy" + h + ".atlas";
            t.push([{url: a, type: Laya.Loader.JSON}, {url: o, type: Laya.Loader.ATLAS}])
        }
        t.push(i.Bg), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(FightNpcUI.uiView, t)
    }, t._sabbe27d79486b625a06ed3d6ebdec5 = function (t) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("FightView", t)
    }, t.prototype.OnShow = function (t) {
        this._2327435916 = t, this.lab_AutoFight.visible = !!this._2327435916.AutoFight && global.$Api.QueryDataSource("DataBase").GetValue("Troops") > 0, GetBattleDirector().Init({
            Scene: this.sp_Play,
            StartPosX: this.sp_Play.width / 2,
            StartPosY: this.sp_Play.height / 2 - 60
        }), this._s712764213a4cadaada6f6702ffbde7(), this._sa56ed9a428c558114488c99befe3f3(), this.OnUpdateTitles(), this._ShowStartFightBtn(), this._sb66c90fe1e72aa4e19b53a54a3545d(), GetBattleDirector().on("FightUpdate", this, this.OnFightUpdate), GetBattleDirector().on("FightEnd", this, this.OnPlayFightEnd), this._2327435916.OnPlayFight ? (this.mouseEnabled = !1, this._2327435916.OnPlayFight(this.OnPlayFight.bind(this))) : this._s440b0159d824d162fc0b8a1fef7adf()
    }, t.prototype.OnFightUpdate = function (t) {
        var i = t.MyResidue, e = t.EnemyResidue;
        this._UpdateFighterSoldier(i, e)
    }, t.prototype._s712764213a4cadaada6f6702ffbde7 = function () {
        this.img_Bg.skin = this._2327435916.Bg
    }, t.prototype._ShowStartFightBtn = function () {
        return this.btn_StartFight.visible = !0, this._2327435916.AutoFight && 1 == global.$Api.QueryDataSource("DataLevel").GetValue("LevelId") && 1 == global.$Api.QueryDataSource("DataLevel").GetValue("StageId") && global.$Api.QueryDataSource("DataLevel").GetValue("Progress") < 3 ? void(this.lab_AutoFight.visible = !1) : void(this._2327435916.AutoFight && global.$Api.QueryDataSource("DataBase").GetValue("Troops") > 0 ? (this._2385572103 = 2, this.lab_AutoFight.visible = !0, this.lab_AutoFight.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.FightAutoFight, this._2385572103), Laya.timer.loop(1e3, this, this.OnAutoFightCountdown)) : this.lab_AutoFight.visible = !1)
    }, t.prototype.OnAutoFightCountdown = function () {
        this._2385572103--, this.lab_AutoFight.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.FightAutoFight, this._2385572103), 0 == this._2385572103 && this.OnStartFight()
    }, t.prototype._HideStartFightBtn = function () {
        this.btn_StartFight.visible = !1
    }, t.prototype.OnStartFight = function () {
        this.lab_AutoFight.visible = !1, Laya.timer.clear(this, this.OnAutoFightCountdown), this.mouseEnabled = !1, this._2327435916.OnStartFight(this.OnPlayFight.bind(this), function () {
            this.mouseEnabled = !0
        }.bind(this))
    }, t.prototype.OnClose = function () {
        Laya.timer.clear(this, this.OnAutoFightCountdown), GetBattleDirector()._s54107fed721f2f5f6636c3b2747bef(), this._1682291669._s54107fed721f2f5f6636c3b2747bef()
    }, t.prototype.OnPlayFight = function (t) {
        this._1674476013 = t, GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_fightstart), this._HideStartFightBtn(), jasmin._sf3bb8d264b010b7fe5e2e4665af22a(this._2327435916.Fighters.MyData, t.Fighters.MyData), jasmin._sf3bb8d264b010b7fe5e2e4665af22a(this._2327435916.Fighters.EnemyData, t.Fighters.EnemyData), GetBattleDirector().Start({
            MySoldier: t.Fighters.MyData.CurSoldier,
            EnemySoldier: t.Fighters.EnemyData.CurSoldier
        })
    }, t.prototype._UpdateFighterSoldier = function (t, i) {
        var e = this._2327435916.Fighters.EnemyData, a = this._2327435916.Fighters.MyData, o = a.MaxSoldier,
            h = e.MaxSoldier;
        this.lab_MySoldier.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.SoldierCount, t);
        var n = (this.pg_MySoldier.value, t / o);
        Laya.Tween.to(this.pg_MySoldier, {value: n}, 200), this.lab_EnemySoldier.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.SoldierCount, i);
        var r = (this.pg_EnemySoldier.value, i / h);
        Laya.Tween.to(this.pg_EnemySoldier, {value: r}, 200)
    }, t.prototype.OnPlayFightEnd = function (t) {
        var t = this._1674476013;
        this._2327435916.OnFightEnd(t, {
            OnUpdateFighters: this.OnUpdateFighters.bind(this),
            OnShowFightBtn: this.OnShowFightBtn.bind(this)
        })
    }, t.prototype.OnShowFightBtn = function () {
        this.mouseEnabled = !0, this.btn_StartFight.visible = !0
    }, t.prototype._s440b0159d824d162fc0b8a1fef7adf = function () {
        this.mouseEnabled = !1, Laya.timer.once(200, this, function () {
            this.mouseEnabled = !0
        })
    }, t.prototype.OnUpdateFighters = function (t) {
        this._s440b0159d824d162fc0b8a1fef7adf(), this._2327435916.Fighters = t, this._sa56ed9a428c558114488c99befe3f3(), this._ShowStartFightBtn(), this.OnUpdateTitles()
    }, t.prototype._sb66c90fe1e72aa4e19b53a54a3545d = function () {
        this.btn_StartFight.visible = !0, this._1682291669._s2e4033b88e999ce7271844dbf3b2dc()
    }, t.prototype.OnUpdateTitles = function () {
        var t = this._2327435916.OnCreateTitleNode();
        this.lab_Title.destroyChildren(), this.lab_Title.addChild(t)
    }, t.prototype._sa56ed9a428c558114488c99befe3f3 = function () {
        this._s8e2c61bcc25de4834785746361dcdd(), this._s58277784cc7b071a3ea041582ff349();
        var t = this._2327435916.Fighters.MyData.CurSoldier, i = this._2327435916.Fighters.EnemyData.CurSoldier;
        GetBattleDirector()._s6b62d5f4d13d1dce02135d67face32({
            MySoldier: t,
            EnemySoldier: i,
            EnemyId: this._2327435916.Fighters.EnemyData.NpcId
        })
    }, t.prototype._s8e2c61bcc25de4834785746361dcdd = function () {
        var t = this._2327435916.Fighters.MyData, i = t.MaxSoldier, e = t.Name, a = t.Force, o = t.Office,
            h = t.CurSoldier;
        return this.lab_MySoldier.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.SoldierCount, h), this.lab_MyName.text = e, this.lab_MyForce.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.ForceStr, a), this.lab_MyOffice.text = o, i <= 0 ? void(this.pg_MySoldier.value = 0) : void(this.pg_MySoldier.value = h / i)
    }, t.prototype._s58277784cc7b071a3ea041582ff349 = function () {
        var t = this._2327435916.Fighters.EnemyData, i = t.MaxSoldier, e = t.Name, a = t.Force, o = t.Office,
            h = t.CurSoldier;
        this.lab_EnemySoldier.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.SoldierCount, h), this.lab_EnemyName.text = e, this.lab_EnemyForce.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.ForceStr, a), this.lab_EnemyOffice.text = o, this.pg_EnemySoldier.value = h / i
    }, t
}();
var FortuneController;
!function () {
    FortuneController = function (e, a) {
        this._3257292081 = e, this._4122736007 = a || {}, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8 = function (e, a) {
        return new FortuneController(e, a)
    };
    var e = FortuneController.prototype;
    e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        for (var e in this._4122736007.ShowType) this._sde55c19a85e1f68fcf3094a3a598d1(this._4122736007.ShowType[e]), this._s7c1efd1ed0138f911a91821f984edb(this._4122736007.ShowType[e]);
        for (var e in this._4122736007.Custom) this._sde55c19a85e1f68fcf3094a3a598d1(e, this._4122736007.Custom[e]), this._s7c1efd1ed0138f911a91821f984edb(e, this._4122736007.Custom[e])
    }, e._sde55c19a85e1f68fcf3094a3a598d1 = function (e, a) {
        switch (e) {
            case"HeadIcon":
                var t = a || this._3257292081.ui_btnHeadIcon;
                if (!t.HeadIcon) {
                    t.on(Laya.Event.CLICK, this, this.OnClickMenu, ["HeadIcon"]);
                    var o = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
                        r = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
                        i = GameCommon._sd67b3ab0a989c863be8837018016c1(o, r);
                    t.addChild(i), t.HeadIcon = i
                }
                break;
            case"Recharge":
                var n = a || this._3257292081.ui_btnRecharge;
                n.on(Laya.Event.CLICK, this, this.OnClickMenu, [e]);
                break;
            case"BtnScene":
                var s = a || this._3257292081.ui_btnScene;
                if (!s) break;
                s.on(Laya.Event.CLICK, this, this.OnClickMenu, [e]);
                var c = s.getChildByName("img_Word");
                c.skin = this._4122736007.WordPathInSceneBtn, this._4062530855 = new Leo.ImageActionManager({Image: c}), this._4062530855._sc95f42251335b3aa0013090797aec9("Breather", {
                    ScaleX: .8,
                    ScaleY: .8,
                    BreatherTime: 2e3
                }), this._4062530855._s2e4033b88e999ce7271844dbf3b2dc()
        }
    }, e.OnClickMenu = function (e) {
        switch (e) {
            case"HeadIcon":
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PlayerInfo", {OnClose: this._4122736007.OnClose});
                break;
            case"Recharge":
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeView", {OnClose: this._4122736007.OnClose});
                break;
            case"BtnScene":
                this._4122736007.OnClickSceneBtn ? this._4122736007.OnClickSceneBtn() : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }
    }, e._s7c1efd1ed0138f911a91821f984edb = function (e, a) {
        switch (e) {
            case"Money":
                var t = a || this._3257292081.ui_labMoney,
                    o = global.$Api.QueryDataSource("DataBase").GetValue("Money");
                t.text = GameCommon._s5c693d8122a877499a10f605a128a3(parseInt(o));
                break;
            case"Food":
                var r = a || this._3257292081.ui_labFood, i = global.$Api.QueryDataSource("DataBase").GetValue("Food");
                r.text = GameCommon._s5c693d8122a877499a10f605a128a3(parseInt(i));
                break;
            case"Troops":
                var n = a || this._3257292081.ui_labTroops,
                    s = global.$Api.QueryDataSource("DataBase").GetValue("Troops");
                n.text = GameCommon._s5c693d8122a877499a10f605a128a3(parseInt(s));
                break;
            case"Gold":
                var c = a || this._3257292081.ui_labGold, l = global.$Api.QueryDataSource("DataBase").GetValue("Gold");
                c.text = GameCommon._s5c693d8122a877499a10f605a128a3(parseInt(l));
                break;
            case"TotalProp":
                var u = a || this._3257292081.ui_labTotalProp;
                u.text = GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee();
                break;
            case"Exp":
                var m = a || this._3257292081.lab_Exp, h = a || this._3257292081.progress_Exp,
                    d = global.$Api.QueryDataSource("DataBase").GetValue("Exp"),
                    _ = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                    b = GetDataTransfer().GetTableRecord("office", _).NeedExp;
                if (!b) return h.value = 1, void(m.text = d);
                m.text = d + "/" + b, h.value = d / b;
                break;
            case"Force":
                var p = a || this._3257292081.lab_Force;
                p.text = GetDataBaseInterface()._s0482008760f4879b888db96e2ce282();
                break;
            case"Office":
                var I = a || this._3257292081.ui_labOffice;
                I.text = global.$Sys.GetTableService().GetTableRecord("office", global.$Api.QueryDataSource("DataBase").GetValue("Office")).OfficeName;
                break;
            case"Vindictive":
                var f = a || this._3257292081.ui_labVindictive;
                f.text = global.$Api.QueryDataSource("DataYamen").GetValue("Vindictive");
                break;
            case"Name":
                var C = a || this._3257292081.ui_labName;
                C.text = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
                break;
            case"Brain":
                var G = a || this._3257292081.ui_labBrain;
                G.text = GetDataBaseInterface()._sdeda9d19cb6fc0e164b574762d83fc()
        }
    }, e._s83da2ed5f110da620ce9dd285c678e = function (e) {
        e && e.HeadIcon && (e.HeadIcon.destroy(), e.HeadIcon.removeSelf(), e.HeadIcon = null)
    }, e._s368acb2686a0a07ac871d80150549a = function (e, a) {
        var t = this._3257292081.ui_sprEffect;
        Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: t,
            NodeName: e,
            OnCheckState: TargetCheck.OnCheckOfficeUp,
            cover: !0,
            Group: "OfficeUp",
            OnExecute: GameCommon.OnAddHeadEffect
        })
    }, e._s54107fed721f2f5f6636c3b2747bef = function () {
        this._3257292081.ui_btnHeadIcon;
        this._4062530855 && this._4062530855._s54107fed721f2f5f6636c3b2747bef()
    }
}();

function FortunePrefab(e) {
    FortunePrefab.super(this), this._4122736007 = e, this.ui_btn.on(Laya.Event.CLICK, this, this._4122736007.OnBtnClick), this.ui_img.skin = this._4122736007.Skin, this.OnUpdata = this._4122736007.OnUpdata, this._UpData()
}

function GetFortuneLayer() {
    return FortuneLayer.Instance || (FortuneLayer.Instance = new FortuneLayer), FortuneLayer.Instance
}

function FortuneLayer() {
    FortuneLayer.super(this), Leo.Console._s73d1ee4f47e7c50e5fdea978255995(this), this._s2d421e2e01497058702faf9064c5ab(["Diamond", "Money", "Soul"])
}

Laya.class(FortunePrefab, "FortunePrefab", FortunePrefabUI), FortunePrefab.prototype._UpData = function (e) {
    this.ui_lab.text = this._4122736007.OnUpdata()
}, Laya.class(FortuneLayer, "FortuneLayer", FortuneLayerUI), FortuneLayer.prototype._seb3cca4dee3870dbd0ffbca3694001 = function (e) {
    var n = {};
    switch (e) {
        case"Diamond":
            return n.OnBtnClick = this.OnClickBtnChargeDiamond, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("Diamond")
            }, n.Skin = global.$Cfg.Common.DiamondIcon, new FortunePrefab(n);
        case"Money":
            return n.OnBtnClick = this.OnClickBtnChargeMoney, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("Money")
            }, n.Skin = global.$Cfg.Common.MoneyIcon, new FortunePrefab(n);
        case"Soul":
            return n.OnBtnClick = this.OnClickBtnChargeSoul, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("Soul")
            }, n.Skin = global.$Cfg.Common.SoulIcon, new FortunePrefab(n);
        case"SkillPoint":
            return n.OnBtnClick = this.OnClickBtnChargeSkillPoint, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("SkillPoint")
            }, n.Skin = global.$Cfg.Common.skillPointIcon, new FortunePrefab(n);
        case"RefineDust":
            return n.OnBtnClick = this.OnClickBtnChargeSkillPoint, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("RefineDust")
            }, n.Skin = global.$Cfg.Common.RefineDustIcon, new FortunePrefab(n);
        case"Prestige":
            return n.OnBtnClick = this.OnClickBtnChargeDiamond, n.OnUpdata = function () {
                return global.$Api.QueryDataSource("DataBase").GetValue("Prestige")
            }, n.Skin = global.$Cfg.Common.PrestigeIcon, new FortunePrefab(n)
    }
}, FortuneLayer.prototype._s2d421e2e01497058702faf9064c5ab = function (e) {
    if (!jasmin._seb2d63e263badd8a69c54d151f6cc7(e) || "Def" == e) return void this._s2d421e2e01497058702faf9064c5ab(["Diamond", "Money", "Soul"]);
    this.ui_hbox.destroyChildren(), this._2743425278 = [];
    for (var n in e) {
        var t = this._seb3cca4dee3870dbd0ffbca3694001(e[n]);
        this._2743425278.push(t), this.ui_hbox.addChild(t)
    }
    this.ui_hbox.refresh()
}, FortuneLayer.prototype.OnRefresh = function () {
    for (var e in this._2743425278) this._2743425278[e]._UpData()
}, FortuneLayer.prototype.OnClickBtnChargeMoney = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("RechargeMoneyDialog")
}, FortuneLayer.prototype.OnClickBtnChargeDiamond = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("RechargeDiamondDialog")
}, FortuneLayer.prototype.OnClickBtnChargeSoul = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("RechargeSoulDialog")
}, FortuneLayer.prototype.OnClickBtnChargeSkillPoint = function () {
    var e = {};
    e.Bg = {}, e.Bg.skin = "./res/scale9gridimage/kuang_bg1.png", e.Bg.sizeGrid = "14,14,14,14,0", e.Bg.width = 200, e.Bg.height = 50, e.Margin = 3, e.PopType = "y";
    var n = new Laya.HTMLDivElement;
    n.innerHTML = " <lab color='#F9F2DE' x='10'  width='180' height='50' bold='true' fontsize='18' align='center' valign='middle'>请到主线剧情关卡获取</lab>", e.Info = n;
    var t = {isModal: !0, closeOnSide: !0, useMgrEffect: !1, popupCenter: !1, popupEffect: !1};
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("PopInfo", e, "PopInfo", t)
};
var FuDi;
!function () {
    FuDi = function () {
        FuDi.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.panel.hScrollBarSkin = null;
        var e = global.$Cfg.Common.ModuleOpen;
        this.btn_GoHome._ModuleOpenId = e.Beauty, this.btn_GoHome.on(Laya.Event.CLICK, this, function () {
            var e = this.btn_GoHome._ModuleOpenId;
            if (!IsDebug() && this.btn_GoHome._ModuleOpenId) {
                var i = global.$Sys.GetTableService().GetTableRecord("module_open", this.btn_GoHome._ModuleOpenId),
                    t = i.Condition,
                    n = global.$Api.GetAssetManager()._sf591a4a71c68d6c62f9d5c59258ec3(t[0], t[1], t[2]);
                if (!n.Result) {
                    i = global.$Sys.GetTableService().GetTableRecord("module_open", e);
                    var a = i.ConditionDetail, o = global.$Cfg.Language.BeautyUnlockWay;
                    return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [jasmin._se91cf955e91eaa1aa510d4335edd4a(o, a)]})
                }
            }
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BeautyView", {
                OnEnterFinish: function () {
                    GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5("res/sound/beauty/z_voice2_hongyan.wav")
                }
            })
        }), this.btn_GoSchool.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Academy")
        }), this.ui_HomeBtn1.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("BusinessAssets", {
                OnClose: function () {
                    this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this), OnUpdateTopInfo: function () {
                    this.event("UpdateTopInfo")
                }.bind(this)
            })
        }), this.ui_HomeBtn2.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("DealAffairView", {
                OnClose: function () {
                    this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this), OnUpdateTopInfo: function () {
                    this.event("UpdateTopInfo")
                }.bind(this)
            })
        }), this.btn_Child.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildView")
        }), this.btn_MeiPo.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildAdultListView")
        }), this._609883226 = BottomMenuController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_BottomMenu, {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
            }
        });
        var i = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
            },
            ShowType: ["Money", "Food", "Troops", "Gold", "TotalProp", "Office", "HeadIcon", "Recharge", "Name"],
            Custom: {},
            OnClickSceneBtn: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
            },
            WordPathInSceneBtn: global.$Cfg.Common.FuDiOut
        };
        this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_TopInfo, i), this._3399175475._s368acb2686a0a07ac871d80150549a("OfficeUpInFudi"), this._3402150980 = MainTaskController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_mainTask, {
            OnClose: function () {
                GameCommon._s8309ef797f42a26c507d05ee4868de(), this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d(), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)
        });
        var t = this.ui_mainTask.getChildByName("img_bg").getChildByName("img_icon");
        this._3867091397 = new Leo.ImageActionManager({Image: t}), this._3867091397._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: .8,
            ScaleY: .8,
            BreatherTime: 2e3
        }), this._3902629732 = new Leo.ImageActionManager({Image: this.box_TweenWord}), this._3902629732._sc95f42251335b3aa0013090797aec9("Distance", {
            Time: 4e3,
            DistanceY: -10
        }), this._4062530855 = new Leo.ImageActionManager({Image: this.img_OutFuDi}), this._4062530855._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: .8,
            ScaleY: .8,
            BreatherTime: 2e3
        }), this.on("UpdateTopInfo", this, function () {
            this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d(), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
        }), this._s5e3c21d35c43a1bf5013a3f5744c11(), this.DealOrBussiness = 1;
        var n = ActivityButtonConstroller._s238e079a6201226a795e84988b36f9({});
        this.addChild(n), this._1915007891 = n, this._1915007891.y = 170
    }, Laya.class(FuDi, "FuDi", FuDiUI);
    var e = FuDi.prototype;
    e._s5e3c21d35c43a1bf5013a3f5744c11 = function () {
        GetDataChildInterface()._sfe1752b19d638ce8af005c2ead7597()
    }, e._s6feae2ad97e862cd705fedbb94bf0e = function () {
        this._sbf49dc756367d435f9231d73f4daea(this.img_ShuYuanRed, "Academy", TargetCheck.OnCheckAcademy, !0, function (e, i) {
            this.img_ShuYuanRed.visible = !!i
        }.bind(this)), this._sbf49dc756367d435f9231d73f4daea(this.img_HongYanRed, "Beauty", TargetCheck.OnCheckBeauty, !0, function (e, i) {
            this.img_HongYanRed.visible = !!i
        }.bind(this)), this._sbf49dc756367d435f9231d73f4daea(this.img_ZiSiRed, "Child", TargetCheck.OnCheckChild, !0, function (e, i) {
            this.img_ZiSiRed.visible = !!i
        }.bind(this)), this._sbf49dc756367d435f9231d73f4daea(this.img_MeiPoRed, "AdultChild", TargetCheck.OnCheckAdultChild, !0, function (e, i) {
            this.img_MeiPoRed.visible = !!i
        }.bind(this)), this._sbf49dc756367d435f9231d73f4daea(this.img_ZhengWuRed, "DealAffair", TargetCheck.OnCheckDealAffair, !0, function (e, i) {
            this.img_ZhengWuRed.visible = !!i
        }.bind(this)), this._sbf49dc756367d435f9231d73f4daea(this.img_ZiChanRed, "BusinessAssets", TargetCheck.OnCheckBusiness, !0, function (e, i) {
            this.img_ZiChanRed.visible = !!i
        }.bind(this))
    }, e._sbf49dc756367d435f9231d73f4daea = function (e, i, t, n, a) {
        Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: e,
            NodeName: i,
            OnCheckState: t,
            cover: n,
            OnExecute: a
        })
    }, e.OnUpdateView = function () {
        this._sbc7c203dd9ab8c8ba334df3aebd67b() >= 2 && !GetInspection() ? this.box_HongYan.visible = !0 : this.box_HongYan.visible = !1, this.img_HongYanWord.visible = this.box_HongYan.visible, this.box_ZiSi.visible = global.$Api.QueryDataSource("DataChild")._sa3faa3dc1ba9c1a2fe8e6d31d8c718() > 0, this.img_ZiSiWord.visible = this.box_ZiSi.visible, this.box_MeiPo.visible = global.$Api.QueryDataSource("DataChild")._sae58289528bc727c177ef413b3b04a() > 0, this.img_MeiPoWord.visible = this.box_MeiPo.visible
    }, e.OnTimeUpdate = function () {
        TargetCheck.OnCheckAcademy() && (Leo.GetNodeAdditionalManager()._s562cd74417e6a2e4054bde0106eee0("Academy"), Leo.GetNodeAdditionalManager()._s67db71535265aebbaaebe9a029b9a0("Academy")), this._s6feae2ad97e862cd705fedbb94bf0e()
    }, e._s2302566324680243bf09907c1bd32d = function () {
        var e = global.$Api.ShareFunc._se589da605da2fd8d658becd4c5124a({
            CurTime: global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            Interval: this._s3e09ef5dd32a1b42b80afabb16f231(),
            StartTime: global.$Api.QueryDataSource("DataAffair")._s0dcf173986af63e29127ad08115954(),
            CurCount: global.$Api.QueryDataSource("DataAffair")._s6d8a67e9a5ff6d8ac6e594adc68a79(),
            MaxCount: this._s84bf534974021135e0c1a23c1245d2()
        });
        return e
    }, e._sbc7c203dd9ab8c8ba334df3aebd67b = function () {
        var e = global.$Api.QueryDataSource("DataBase")._2552118236.Office;
        return e
    }, e.OnUpdateCloud = function (e) {
        var i = this.img_YunBg.getChildByName("Cloud2");
        i && (i.removeSelf(), i.destroy());
        var t = jasmin._s449f055209cd01229b1846559026f5(global.$Cfg.Common.FuDiCloudPath), n = new Laya.Image(t);
        n.name = "Cloud2", n.x = e ? _.random(200, 600) : -n.width, n.y = _.random(0, 20);
        var a = this.img_YunBg.width, o = 1e3 * _.random(30, 60);
        this.img_YunBg.addChild(n), Laya.Tween.to(n, {x: a}, o, null, Laya.Handler.create(this, this.OnUpdateCloud))
    }, e.OnShow = function (e) {
        this._3867091397._s2e4033b88e999ce7271844dbf3b2dc(), this._4062530855._s2e4033b88e999ce7271844dbf3b2dc(), this._3902629732._s2e4033b88e999ce7271844dbf3b2dc(), GameCommon._s751fe3068f6886bddb070f080cb5ee("home"), Laya.timer.callLater(this, function () {
            var e = this.img_Bg.width / 2 - 320, i = .2 * -e;
            this.img_YunBg.x = i, this.panel.scrollTo(e, 0)
        }), this.OnUpdateCloud(1), this.OnUpdateView(), this.OnTimeUpdate(), GetDataTaskInterface()._s82dd437e0d798ae5596d8ec68ec545(function () {
            GameCommon._s8309ef797f42a26c507d05ee4868de()
        }), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d(), this._609883226._s8c5be7d6d51a594d27451cfb623f26(), Laya.timer.loop(1e3, this, this.OnTimeUpdate), e && e.OnEnter && e.OnEnter(), this._1915007891._s4fb507d6d0f40b2d2a72f6007a938d(), this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d(), IsOffLine() || (this._2325891651 = Leo.GetChatSystem_P(), this._526051148 = this._2325891651._saeb2814548eac60bb4139b67d6fbb9(), this._526051148.left = 0, this._526051148.bottom = 110, this.addChild(this._526051148));
        var i = ["Area"];
        jasmin._seb2d63e263badd8a69c54d151f6cc7(GetGuildProxy()._s29a41a18394428f794cfc156c4edd1()) && i.push("Guild"), this._2325891651 && (this._2325891651._s6f061e4f6f62e63e4188bd53fa50e3(i), this._2325891651.OnSetDefIndex("Area"), this._2325891651._s89054e77b7a538cfcf6055d9d64058()), GetVersionCfgManager().GetValue("NoCheckCrossReward") || this.OnCheckCrossReward()
    }, e.OnClose = function () {
        this.img_ItemIcon.destroyChildren(), this._3867091397._s54107fed721f2f5f6636c3b2747bef(), this._4062530855 && this._4062530855._s54107fed721f2f5f6636c3b2747bef(), this._3902629732._s54107fed721f2f5f6636c3b2747bef(), Laya.timer.clear(this, this.OnTimeUpdate);
        var e = this.img_YunBg.getChildByName("Cloud2");
        e && (e.removeSelf(), e.destroy()), this._2325891651 && this._2325891651._sb21e9331a1c6425ce2218185c68d93(), this._526051148 && this._526051148.removeSelf(), this._3399175475._s54107fed721f2f5f6636c3b2747bef(), this._1915007891._s54107fed721f2f5f6636c3b2747bef()
    }, FuDi.OnPreLoadRes = function (e) {
        for (var i = 0; i < global.$Cfg.Common.CloudPath.length; i++) e.push(global.$Cfg.Common.CloudPath[i]);
        e.push("res/ui/common/z_image_13.png");
        for (var t in global.$Cfg.Common.FuDiCloudPath) e.push(global.$Cfg.Common.FuDiCloudPath[t]);
        e.push(global.$Cfg.Common.FuDiOut), e.push(global.$Cfg.Common.FuDiIn), _.each(GetDataBaseInterface()._s890c56d6eca7b89fa2db74b563f432(), function (i) {
            e.push(i)
        }), jasmin._s3c96e1f3bee730222501b208d50190(e, MainTaskController._s6ea328e154c15cc2fb730cc9ed1dd4()), jasmin._s3c96e1f3bee730222501b208d50190(e, GameCommon._s44605232c95cb24f373304cee8baf4()), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TitleUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(NoticeItemUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(NoticeBoardUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainTaskUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BottomMenuUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TopInfoUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(FuDi.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainCityUI.uiView, e)
    }, e.OnCheckCrossReward = function () {
        var e = this;
        Laya.timer.clear(e, e.OnCheckCrossReward);
        var i = global.$Api.QueryDataSource("DataRecord").GetValue("IsGetCrossReward");
        i || GetServerInfoInterface().GetValue("NoReturnReward") || GetCmdProxy().DoCmd("CrossServerReward", {}, function (i) {
            var t = global.$Api.QueryDataSource("DataRecord").GetValue("IsGetCrossReward");
            t || Laya.timer.once(3e4, e, e.OnCheckCrossReward)
        })
    }
}();

function GroupWalfareLayer() {
    GroupWalfareLayer.super(this)
}

Laya.class(GroupWalfareLayer, "GroupWalfareLayer", GroupWalfareLayerUI);
var _proto_ = GroupWalfareLayer.prototype;
_proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetServerInfoInterface().GetValue("ServerSetting");
    this.lab_groupNum.text = e ? e.QQ : "暂无"
}, _proto_.OnCloseCopy = function () {
    alert("todo复制群号")
}, _proto_._s90746ef77ff05d47cb37e68d587694 = function () {
}, GroupWalfareLayer.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GroupWalfareLayer.uiView, e)
};
var GuestChoose;
!function () {
    GuestChoose = function (e) {
        var t = laya.events.Event;
        GuestChoose.super(this), this.Close_Btn.on(t.CLICK, this, this.OnCloseBtn), this.radio_type.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1)
    }, Laya.class(GuestChoose, "GuestChoose", ChooseGuestListUI), GuestChoose.prototype.OnShow = function (e) {
        this._661559221 = e.Id, this._1601210776 = e.CallBack;
        var t = Laya.Handler;
        this.GuestList.renderHandler = new t(this, this.OnUpdateItem), this.GuestList.vScrollBarSkin = "";
        var a = global.$Api.QueryDataSource("DataBase").GetValue("Office");
        this.EarningsLabel.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.EarningsLabel, global.$Api.Formula._sfce40945ed6de7fe771561f6811359(a), global.$Api.Formula._sf1b3354516bc5aea5f05a806327013(a)), this.StudyTimeLabel.text = "3小时", this.radio_type.selectedIndex = 0, this._sd34538c73f0ba9532be5c65bbd2540()
    }, GuestChoose.prototype._sd34538c73f0ba9532be5c65bbd2540 = function () {
        function e(e, t) {
            return t.Aptitude - e.Aptitude
        }

        for (var t = [], a = [], o = [], i = this._1056589751, r = 0; r < i.length; r++) {
            var s = i[r].HeroId, n = !1;
            _.each(global.$Api.QueryDataSource("DataAcademy").GetValue("Seat"), function (e) {
                e.HeroId == s && (n = !0)
            });
            var l = 0;
            _.each(global.$Cfg.CommonEnum.HeroAttribute, function (e) {
                l += ShareFunc._sf5c4c05dceefc9148e471ef985221d(s, e).Aptitude
            });
            var u = {HeroId: i[r].HeroId, HeroExp: i[r].SkillExp, IsStudy: n, Aptitude: l};
            n ? arr = a : arr = o, arr.push(u)
        }
        a.sort(e), o.sort(e), t = o.concat(a), this.GuestList.array = [], this.GuestList.array = t
    }, GuestChoose.prototype.OnUpdateItem = function (e, t) {
        var a = laya.events.Event, o = e.dataSource, i = e.getChildByName("GuestName"),
            r = e.getChildByName("SkillExp"), s = e.getChildByName("Send_Btn"), n = e.getChildByName("SendLabel"),
            l = e.getChildByName("GuestHeadImg"), u = e.getChildByName("img_HeadBg"), h = e.getChildByName("BookExp"),
            d = o.HeroId, p = GetDataTransfer().GetTableRecord("hero", d),
            c = global.$Api.QueryDataSource("DataHero").GetHeroById(d),
            C = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, c.Title);
        GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(l, d), u.skin = C, i.text = p.HeroName, r.text = c.SkillExp, h.text = c.BookExp;
        for (var y in c.ItemAttribute) {
            var m = e.getChildByName("lab_prop" + y),
                G = global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(d, parseInt(y)).TotalValue;
            m.text = G
        }
        o.IsStudy ? (s.visible = !1, n.visible = !0) : (s.visible = !0, n.visible = !1), s.offAll(a.CLICK), s.on(a.CLICK, this, function () {
            this.OnSendBtn(d)
        })
    }, GuestChoose.prototype.OnSendBtn = function (e) {
        GetCmdProxy().DoCmd("GuestStudy", {Idx: this._661559221, HeroId: e, Cnt: 1}, function (e) {
            e.Result && (this._1601210776(), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuestChoose"))
        }.bind(this))
    }, GuestChoose.prototype.OnSelectType = function (e) {
        if (e != -1) {
            var t = global.$Api.QueryDataSource("DataHero")._s6b8b55436407229b07aeec45efb78d();
            if (0 == e) return this._1056589751 = t, void this._sd34538c73f0ba9532be5c65bbd2540();
            var a = _.filter(t, function (t) {
                var a = global.$Sys.GetTableService().GetTableRecord("hero", t.HeroId);
                return _.intersection(a.SpecialtyID, [e, 5, 6]).length
            });
            this._1056589751 = a, this._sd34538c73f0ba9532be5c65bbd2540()
        }
    }, GuestChoose.prototype.OnCloseBtn = function () {
        this._1601210776(), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuestChoose")
    }
}();
var Guild1;
!function () {
    Guild1 = function () {
        Guild1.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.btn_Create.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildCreate")
        }), this.btn_Query.on(Laya.Event.CLICK, this, this.OnClickQuery), this.btn_RandomJoin.on(Laya.Event.CLICK, this, this.OnClickRandomJoin), this.btn_Rank.on(Laya.Event.CLICK, this, this.OnClickRank)
    }, Laya.class(Guild1, "Guild1", Guild1UI), Guild1.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(Guild1UI.uiView, e)
    };
    var e = Guild1.prototype;
    e.OnClickQuery = function () {
        var e = null, i = {
            OnSelect: function (i, a) {
                GetCmdProxy().DoCmd("GuildGetInfo", {GuildId: i}, function (i) {
                    if (i.Result && !i.GuildInfo.Deleted) {
                        e = i.GuildInfo;
                        var t = [];
                        for (var n in e) {
                            var l, o;
                            switch (n) {
                                case"Name":
                                    l = gLanguage.GuildNameText, o = e[n] + "（等级：" + e.Lv + "）";
                                    break;
                                case"LeaderId":
                                    l = gLanguage.GuildLeaderNameText, o = e.Members[e.LeaderId].UserData.PlayerName;
                                    break;
                                case"Exp":
                                    l = gLanguage.GuildExpText;
                                    var u = global.$Sys.GetTableService().GetTableRecord("guild_lv", e.Lv);
                                    o = e.Exp + "/" + u.Exp;
                                    break;
                                case"Asset":
                                    l = gLanguage.GuildAssetText, o = e.Asset;
                                    break;
                                case"QQ":
                                    l = gLanguage.GuildQQText, o = e.QQ;
                                    break;
                                case"Notice":
                                    l = gLanguage.GuildNoticeText, o = e.Notice;
                                    break;
                                default:
                                    l = null, o = null
                            }
                            if (l && o && t.push({Key: l, Value: o}), 4 == t.length) {
                                var d = 0, r = e.Members;
                                for (var n in r) 10004974755 != n && (d += r[n].UserData.TotalAttribute);
                                t.push({
                                    Key: gLanguage.GuildTotalAttributeText,
                                    Value: d
                                }), t.push({Key: gLanguage.GuildMembersText, Value: _.size(r)})
                            }
                        }
                        a && a(t)
                    }
                }.bind(this))
            }.bind(this), OnHandle: function (i) {
                if (i && e) {
                    var a = e.Members, t = global.$Sys.GetTableService().GetTableRecord("guild_lv", e.Lv);
                    if (a >= t.MemberLimit) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.Guild_MembersEnough});
                    var n = {GuildId: e.GuildId, PlayerId: global.$Api.QueryDataSource("DataBase").GetValue("Uid")};
                    GetCmdProxy().DoCmd("GuildAdd", n, function (e) {
                        e.Result && GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildAskJoinSuccess]})
                    }.bind(this))
                }
            }.bind(this)
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("SelectDialog", i)
    }, e.OnClickRandomJoin = function () {
        var e = {PlayerId: global.$Api.QueryDataSource("DataBase").GetValue("Uid")},
            i = GuildRandomAdd._s6a4dba9453762113ae0d1467dd81b3();
        return i.Result ? void GetCmdProxy().DoCmd("GuildRandomAdd", e, function (e) {
            if (e.Result) {
                GetGuildInterface()._s19807ae6c4ef3c3187372d1afc3a1a();
                var i = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildJoinSuccess, e.GuildName);
                GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [i]})
            }
        }.bind(this)) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(i)
    }, e.OnClickRank = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildRank")
    }, e.OnTimeHandle = function () {
        var e = global.$Api.QueryDataSource("DataRecord").GetValue("ExitGuildTime"), i = !0, a = null;
        if (e) {
            var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
            a = t - e, a <= global.$Cfg.Common.Guild.ExitTime && (i = !1)
        }
        i ? (this.lab_CantJoin.visible = !1, this.lab_CanJoin.text = gLanguage.GuildCanJoin, this.lab_CanJoin.visible = !0) : (this.lab_CantJoin.visible = !0, this.lab_CanJoin.visible = !1, this.lab_JoinTime.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(global.$Cfg.Common.Guild.ExitTime - a))
    }, e.OnShow = function (e) {
        GameCommon._s751fe3068f6886bddb070f080cb5ee("guild"), this.OnTimeHandle(), Laya.timer.loop(1e3, this, this.OnTimeHandle)
    }, e.OnClose = function () {
        Laya.timer.clear(this, this.OnTimeHandle)
    }
}();
var GuildJoinAsker;
!function () {
    function e() {
        e.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildJoinAsker")
        }), this.btn_AllRefuse.on(Laya.Event.CLICK, this, this.OnClickAllRefuse), this.checkRandom.on(Laya.Event.CLICK, this, this.OnClickcheckRandom), this.list_Players.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1), this.list_Players.vScrollBarSkin = null
    }

    Laya.class(e, "GuildJoinAsker", GuildJoinAskerUI), e.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, t)
    };
    var t = e.prototype;
    t.OnClickcheckRandom = function () {
        GetGuildInterface().DoChangeRandomJoin(function (e) {
            if (!e.Result) return void(this.check_Randomn.selected = !this.check_Randomn.selected)
        }.bind(this))
    }, t.OnClickAllRefuse = function () {
        GetGuildInterface().DoAllRefuse(function (e) {
            e.Result && (this.OnShow(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildDealSuccess]}))
        }.bind(this))
    }, t.OnCreateBox = function (e, t) {
        var a = e.getChildByName("lab_PlayerName");
        a.text = this._1140402225[t].UserData.PlayerName;
        var i = e.getChildByName("img_Head"),
            l = global.$Cfg.Common.HeadIconName[this._1140402225[t].UserData.PlayerSex][this._1140402225[t].UserData.PlayerHeroHeadId];
        Laya.loader.load(l, Laya.Handler.create(this, function () {
            i.skin = l
        }));
        var n = e.getChildByName("lab_TotalText"), s = n.getChildByName("lab_Total");
        s.text = this._1140402225[t].UserData.TotalAttribute;
        var o = global.$Sys.GetTableService().GetTableRecord("office", this._1140402225[t].UserData.Office),
            h = e.getChildByName("lab_OfficeText"), r = h.getChildByName("lab_Office");
        r.text = o.OfficeName;
        var d = e.getChildByName("lab_IdText"), c = d.getChildByName("lab_Id");
        c.text = this._1140402225[t].Uid;
        var u = e.getChildByName("btn_Agree");
        u.on(Laya.Event.CLICK, this, this.OnDeal, [t, 1]);
        var m = e.getChildByName("btn_Refuse");
        m.on(Laya.Event.CLICK, this, this.OnDeal, [t, 0]), this._303566979 ? u.visible = !0 : u.visible = !1, m.visible = u.visible
    }, t.OnDeal = function (e, t) {
        GetGuildInterface().DoDeal(this._1140402225[e].Uid, t, function (e) {
            return e.Error && e.Error == global.$Cfg.ErrorCode.Guild_JoinPlayerHasGuild ? void this.OnShow() : void(e.Result && (this.OnShow(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildDealSuccess]})))
        }.bind(this))
    }, t.OnShow = function () {
        var e = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("JoinRequests");
        this._1140402225 = _.values(e), this.list_Players.array = this._1140402225, this.lab_Count.text = this._1140402225.length || 0, this.hBox_Count.changeItems(), this.checkRandom.selected = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("CanRandomJoin");
        var t = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34(),
            a = global.$Sys.GetTableService().GetTableRecord("guild_office", t);
        this._303566979 = a.CanApprovalNewcomer, this._303566979 ? (this.lab_CheckRandom.visible = !0, this.btn_AllRefuse.visible = !0, this.img_List.height = 687) : (this.lab_CheckRandom.visible = !1, this.btn_AllRefuse.visible = !1, this.img_List.height = 754)
    }
}();
var GuildBossReportView = function () {
    function t() {
        t.super(this), this.html_Killer.style.fontSize = 25, this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBossReportView")
        }), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = {}, this.list_rank.vScrollBarSkin = null
    }

    return Laya.class(t, "GuildBossReportView", GuildBossReportUI), t.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildBossReportUI.uiView, t)
    }, t.prototype.OnShow = function (t) {
        this._1325570255 = t.Record, this._897923444 = t.Killer;
        var e = t.BossId, r = global.$Sys.GetTableService().GetTableRecord("guild_boss", e), i = r.BossName,
            a = r.GuildExp, s = this._897923444.UserName;
        this.html_Killer.innerHTML = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildBossReport, s, i, a), this.html_Killer.width = this.html_Killer.contextWidth, this.html_Killer.x = this.width / 2 - this.html_Killer.width / 2;
        var n = this._s2a3bec377bd1e13c0632b98835ef6a();
        this._1092471860Data = this._s1f0ea850a46e91285cce22c0386d23(n), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t.prototype._s1f0ea850a46e91285cce22c0386d23 = function (t) {
        var e = global.$Api.QueryDataSource("DataBase").GetValue("Uid"), r = {}, i = [], a = {};
        for (var s in t) {
            var n = t[s], o = parseInt(s) + 1,
                l = {Rank: o, Score: n.Atk, UserData: {Name: n.UserName, Contribution: n.Contribution}};
            n.UserId == e && (r = l), i.push(o), a[o] = l
        }
        var u = null, h = null, o = null, m = function (t, e, r) {
            t && (t.text = e.UserData && e.UserData.Contribution ? e.UserData.Contribution : 0)
        }, d = {Rank: o, Name: h, Score: u, Contribute: m};
        return {MyRank: r, RankList: i, UserInfos: a, ShowTag: d}
    }, t.prototype._s2a3bec377bd1e13c0632b98835ef6a = function () {
        var t = this._1325570255, e = {};
        _.each(t, function (t) {
            e[t.UserId] || (e[t.UserId] = {
                UserId: t.UserId,
                UserName: t.UserName,
                Atk: 0,
                Contribution: 0
            }), e[t.UserId].Atk += t.Atk, e[t.UserId].Contribution += t.Contribution
        });
        var r = _.values(e);
        return r.sort(function (t, e) {
            return t.Atk < e.Atk
        }), r
    }, t.prototype._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
    }, t
}();
var GuildBossView;
!function () {
    GuildBossView = function () {
        GuildBossView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBossView")
        }), this.list_Boss.renderHandler = new Laya.Handler(this, this.OnCreateBoss), this.list_Boss.vScrollBarSkin = null
    }, Laya.class(GuildBossView, "GuildBossView", GuildBossUI), GuildBossView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildBossUI.uiView, e)
    };
    var e = GuildBossView.prototype;
    e.OnShow = function (e) {
        this._sba337f850cf82856dedd36fa1dee97(), this._sa4a95e1ae2426793b0a8777fced7fe()
    }, e.OnClose = function () {
        this.off("UpdateBossInfo"), this._sba8dccb7f9520b22fcad20277b05d9()
    }, e._sa4a95e1ae2426793b0a8777fced7fe = function () {
        this.timerLoop(1e3, this, this.OnTimerLoop)
    }, e._sba8dccb7f9520b22fcad20277b05d9 = function () {
        this.clearTimer(this, this.OnTimerLoop)
    }, e.OnTimerLoop = function () {
        this.event("UpdateBossInfo")
    }, e._sba337f850cf82856dedd36fa1dee97 = function () {
        var e = this._s3cc1d8d2fa26afe187d813d4b75fb0();
        this.list_Boss.array = [], this.list_Boss.array = e
    }, e._s3cc1d8d2fa26afe187d813d4b75fb0 = function () {
        var e = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Lv"),
            s = global.$Sys.GetTableService().GetTable("guild_boss"), t = _.filter(s, function (s, t) {
                return s.NeedGuildLv <= e
            }), i = _.values(t);
        i.sort(function (e, s) {
            return e.BossLv - s.BossLv
        });
        var o = _.pluck(i, "BossLv");
        return o
    }, e.OnCreateBoss = function (e, s) {
        var t = e.getChildByName("lab_Name"), i = e.getChildByName("lab_Reward"), o = e.getChildByName("btn_EnterBoss"),
            n = e.getChildByName("btn_OpenBoss"), a = e.getChildByName("img_Icon"), l = e.getChildByName("progress_Hp"),
            r = e.getChildByName("lab_Hp"), u = (e.getChildByName("lab_CountDown"), e.getChildByName("btn_OpenReport")),
            d = e.dataSource, B = global.$Sys.GetTableService().GetTableRecord("guild_boss", d),
            G = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildBossContributionFont, B.GuildContribution),
            h = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildBossAddExp, B.GuildExp);
        i.text = G + "\n" + h;
        var f = B.BossName;
        t.text = f;
        var g = GetGuildInterface()._sae894b3a984bd72a127f950e4201bf(d);
        l.value = g, 0 == g ? r.text = gLanguage.GuildBossKilled : r.text = Math.min(parseInt(100 * g), 100) + "%", GameCommon._s27fc438782f610661f6303b55a7630(a, d);
        B.GuildExp, B.Contribution;
        this.on("UpdateBossInfo", this, function (e, s) {
            this._se8bddbaad67a0add77592ccf0035da(e, s)
        }, [d, e]), this._se8bddbaad67a0add77592ccf0035da(d, e), o.on(Laya.Event.CLICK, this, this.OnEnterBoss, [d]), n.on(Laya.Event.CLICK, this, this.OnOpenBoss, [d]), u.on(Laya.Event.CLICK, this, this.OnOpenReport, [d])
    }, e._se8bddbaad67a0add77592ccf0035da = function (e, s) {
        var t = (s.getChildByName("lab_Hp"), s.getChildByName("lab_CountDown")), i = s.getChildByName("btn_EnterBoss"),
            o = s.getChildByName("btn_OpenBoss"), n = s.getChildByName("btn_OpenReport"), e = s.dataSource;
        if (e) {
            var a = (global.$Sys.GetTableService().GetTableRecord("guild_boss", e), GetGuildInterface()._sb17be1cfa27ed43a05a603ffb9e9cc(e));
            i.visible = a, o.visible = !a;
            var l = GetGuildInterface()._sae894b3a984bd72a127f950e4201bf(e);
            0 == l ? (i.visible = !1, o.visible = !1, n.visible = !0) : n.visible = !1;
            var r = GetGuildInterface()._scc68d4b041a72a5b2116beefd39a2d(e);
            if (!r) return void(t.visible = !1);
            t.visible = !0;
            var u = jasmin._s94a2f7c0f6d93408be9fb1bde96f94(gLanguage.CountDownFormat, r);
            t.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildBossCountDown, u)
        }
    }, e.OnOpenBoss = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBossOpenView", {BossLv: e})
    }, e.OnEnterBoss = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBossFightView", {
            BossId: e, OnClose: function () {
                this._sba337f850cf82856dedd36fa1dee97()
            }.bind(this)
        }, null, {useMgrEffect: !1})
    }, e.OnOpenReport = function (e) {
        var s = GetGuildInterface()._s6b337be562ae7de6d0538fdd3dee51(e);
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBossReportView", {
            Record: s.Record,
            Killer: s.Killer,
            BossId: e
        })
    }
}();
var GuildBossFightView;
!function () {
    GuildBossFightView = function () {
        GuildBossFightView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBossFightView")
        }), this.btn_LookReport.on(Laya.Event.CLICK, this, this.OnBtnLookReport), this.check_More.on("change", this, this.OnSelectRecord), this.list_Record.renderHandler = new Laya.Handler(this, this.OnCreateRecordItem), this.list_Record.vScrollBarSkin = null, this.on("AttackEnd", this, this.OnAttackEnd)
    }, Laya.class(GuildBossFightView, "GuildBossFightView", GuildBossFightUI), GuildBossFightView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildBossFightUI.uiView, e)
    };
    var e = GuildBossFightView.prototype;
    e.OnAttackEnd = function (e) {
        if (e.Rewards) {
            var i = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
            GameCommon._s5d340979c9fcfd9445217570f410e4(this, i)
        }
        this._s2da73e952fcb2ee3de154ec3c04a5c()
    }, e._s8f5096f64b01e0d2b0b452c2d76445 = function () {
        this.mouseEnabled = !1
    }, e._s6032882d4d27b65773611ddfdd5bb7 = function () {
        this.mouseEnabled = !0
    }, e.OnSelectRecord = function (e) {
        this._s8f5096f64b01e0d2b0b452c2d76445(), this.check_More.selected ? this._s18457984dd06940f2ec7a1bdc4eb1f() : this._sfa345e69666c74aadd4bd5c1a9d73f()
    }, e.OnShow = function (e) {
        this._s6032882d4d27b65773611ddfdd5bb7(), this.check_More.selected = !1, this._3597063358 = e.BossId, this.m_OnClose = e.OnClose, this.btn_LookReport.visible = !1, this.img_BossDeadFont.visible = !1, this._811026184 = new BossFightInterface({
            BossId: e.BossId,
            UI: this,
            Interface: GetGuildBossInterface(),
            OnBossDeadForUI: this.OnBossDeadForUI.bind(this),
            BossDeadHideAll: !0
        }), this._s2da73e952fcb2ee3de154ec3c04a5c()
    }, e.OnBtnLookReport = function () {
        var e = GetGuildInterface()._s6b337be562ae7de6d0538fdd3dee51(this._3597063358);
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBossReportView", {
            Record: e.Record,
            Killer: e.Killer,
            BossId: this._3597063358
        })
    }, e.OnBossDeadForUI = function () {
        this.img_Boss.visible = !1, this.img_Hero.visible = !1, this.lab_NoHero.visible = !1, this.img_HeroPower.visible = !1, this.btn_Fight.visible = !1, this.lab_Name.visible = !1, this.progress_Hp.visible = !1, this.progress_ShadowHp.visible = !1, this.lab_Hp.visible = !1, this.img_NameBg && (this.img_NameBg.visible = !1), this.btn_LookReport.visible = !0, this.img_BossDeadFont.visible = !0
    }, e.OnClose = function () {
        this._811026184._sde752cfc0009e77744b1da7ea3c4c7(), this._811026184 = null, this.m_OnClose && this.m_OnClose()
    }, e._s2da73e952fcb2ee3de154ec3c04a5c = function () {
        var e = GetGuildInterface()._sf55140b7f401868ee9c1c43f9a2422(this._3597063358), i = _.first(e);
        if (!i) return this.lab_UserName.visible = !1, void(this.html_RecordInfo.visible = !1);
        this.lab_UserName.visible = !0, this.html_RecordInfo.visible = !0, this.lab_UserName.text = i.UserName;
        var t = i.HeroId, s = global.$Sys.GetTableService().GetTableRecord("hero", t);
        this.html_RecordInfo.innerHTML = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildBossRecordHTML, s.HeroName, i.Atk)
    }, e._s7592eccc062e288cc7e286750ec36d = function () {
        this._s2da73e952fcb2ee3de154ec3c04a5c();
        var e = GetGuildInterface()._sf55140b7f401868ee9c1c43f9a2422(this._3597063358);
        this.list_Record.array = [], this.list_Record.array = e
    }, e.OnCreateRecordItem = function (e, i) {
        var t = e.dataSource, s = e.getChildByName("lab_UserName"), o = e.getChildByName("html_Record"),
            r = e.getChildByName("lab_Time"), n = e.getChildByName("lab_Sort");
        n.text = i + 1, s.text = t.UserName;
        var a = t.HeroId, l = global.$Sys.GetTableService().GetTableRecord("hero", a);
        o.innerHTML = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildBossRecordHTML, l.HeroName, t.Atk);
        var h = jasmin._sf60b29247c48694418b19d6d5ef097("yyyy-MM-dd hh:mm:ss", new Date(t.Time));
        r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildBossRecordTime, h)
    }, e._s18457984dd06940f2ec7a1bdc4eb1f = function () {
        this._s7592eccc062e288cc7e286750ec36d(), Laya.Tween.to(this.img_Records, {y: 260}, 100, null, Laya.Handler.create(this, function () {
            this._s6032882d4d27b65773611ddfdd5bb7()
        }))
    }, e._sfa345e69666c74aadd4bd5c1a9d73f = function () {
        Laya.Tween.to(this.img_Records, {y: 1138}, 100, null, Laya.Handler.create(this, function () {
            this._s6032882d4d27b65773611ddfdd5bb7()
        }))
    }
}();
var GuildBossOpenView;
!function () {
    GuildBossOpenView = function () {
        GuildBossOpenView.super(this), this.list_Boss.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBossOpenView")
        })
    }, Laya.class(GuildBossOpenView, "GuildBossOpenView", GuildOpenBossUI), GuildBossOpenView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildOpenBossUI.uiView, e)
    };
    var e = GuildBossOpenView.prototype;
    e.OnShow = function (e) {
        this._2226589541 = e.BossLv;
        var s = global.$Sys.GetTableService().GetTableRecord("guild_boss", this._2226589541);
        this.lab_BossName.text = s.BossName, this._s9f1625f0ddd68ef4aea152a6852c7a()
    }, e._s9f1625f0ddd68ef4aea152a6852c7a = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("guild_boss", this._2226589541), s = e.Consume,
            t = global.$Sys.GetTableService().GetTableRecord("consume", s), a = t.Consume;
        this.list_Boss.array = a
    }, e.OnSelect = function (e, s) {
        GetGuildInterface().DoOpenBoss(this._2226589541, e, this.OnOpenBossSuccess.bind(this))
    }, e.OnOpenBossSuccess = function () {
        this._s9f1625f0ddd68ef4aea152a6852c7a(), GetGuildInterface().event("UpdateGuildInfo"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBossOpenView")
    }, e.OnCreateItem = function (e, s) {
        var t = e.getChildByName("lab_Name"), a = e.getChildByName("lab_Need"), i = e.getChildByName("lab_Cur"),
            n = e.getChildByName("lab_NeedValue"), o = e.getChildByName("lab_CurValue"),
            l = e.getChildByName("btn_Select"), u = e.getChildByName("sp_Icon"), d = e.dataSource, r = d[0], G = d[1],
            m = d[2], B = GameCommon._sf0a0854e48d4ebc005e689b65b3673(r, G);
        9 == r && 2 == G && (B = global.$Cfg.Language.GuildOpenBossByAssetsName), t.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildOpenBossBy, B), a.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildOpenBossNeed, B), i.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildOpenBossCur, B), n.text = m;
        var g = global.$Cfg.CommonEnum;
        if (r == g.Asset.DataBase && G == g.DataBase.Gold && (o.text = global.$Api.QueryDataSource("DataBase").GetValue("Gold")), r == g.Asset.DataGuild && G == g.DataGuild.GuildAsset && (o.text = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7().Asset), u.destroyChildren(), 9 == r && 2 == G) {
            var c = new Laya.Image("res/icon/z_item_icon_143.png");
            u.addChild(c)
        } else {
            var c = GameCommon._s66eb52e60b9feb53711943e638c9c3(r, G, m);
            u.addChild(c)
        }
        l.on(Laya.Event.CLICK, this, this.OnSelect, [s, e])
    }
}();
var GuildBuildView;
!function () {
    GuildBuildView = function () {
        GuildBuildView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildBuildView")
        });
        var e = {ShowType: ["Gold"], Custom: {}};
        this._2141111536 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8({ui_labGold: this.ui_labGold}, e), this.list_Build.vScrollBarSkin = null, this.list_Build.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list_Build.array = []
    }, Laya.class(GuildBuildView, "GuildBuildView", GuildBuildUI), GuildBuildView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildBuildUI.uiView, e)
    };
    var e = GuildBuildView.prototype;
    e.OnShow = function (e) {
        this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d(), this._s9f1625f0ddd68ef4aea152a6852c7a()
    }, e.OnClose = function () {
        for (var e = 0; e < this.list_Build.array.length; e++) {
            var i = this.list_Build.getCell(e), l = i.getChildByName("box_Consume");
            l.destroyChildren();
            var t = i.getChildByName("sp_Icon");
            t.destroyChildren()
        }
    }, e._s9f1625f0ddd68ef4aea152a6852c7a = function () {
        var e = global.$Sys.GetTableService().GetTable("guild_build"), i = _.values(e);
        i.sort(function (e, i) {
            return e.ShowSort - i.ShowSort
        }), this.list_Build.array = [], this.list_Build.array = i
    }, e.OnCreateItem = function (e, i) {
        var l = global.$Api.QueryDataSource("DataDailyRecord")._scc5bc48a87f577d371d77cfc293711(["Guild", "BuildId"]),
            t = e.dataSource;
        e.getChildByName("lab_Name").text = t.Name, e.getChildByName("btn_Build").visible = 0 == l;
        var a = e.getChildByName("btn_Build");
        a.on(Laya.Event.CLICK, this, this.OnClickBuild, [t.BuildId, a]), e.getChildByName("lab_HaveBuild").visible = t.BuildId == l;
        var o = t.Consume, d = global.$Sys.GetTableService().GetTableRecord("consume", o), r = d.Consume[0], n = r[0],
            u = r[1], s = r[2], h = e.getChildByName("box_Consume");
        h.destroyChildren();
        var m = "#0b8f4f", C = 23, G = !1;
        if (n == global.$Cfg.CommonEnum.Asset.DataBag) {
            var c = global.$Sys.GetTableService().GetTableRecord("item", u), y = c.ItemName, B = new Laya.Label(y);
            B.color = m, B.fontSize = C, h.addChild(B)
        } else {
            G = !0;
            var b = GameCommon._s66eb52e60b9feb53711943e638c9c3(n, u, !0);
            b.scale(.6, .6), h.addChild(b)
        }
        var v = new Laya.Label("x" + s);
        v.color = m, v.fontSize = C, h.addChild(v);
        var f = e.getChildByName("sp_Icon");
        f.destroyChildren();
        var w = GameCommon._s66eb52e60b9feb53711943e638c9c3(n, u, G);
        f.addChild(w);
        var g = e.getChildByName("lab_Desc"), S = t.Reward,
            L = global.$Sys.GetTableService().GetTableRecord("reward", S), I = L.Award,
            R = GameCommon._sd829d199a08f4ea0e8f4acd2566c18(I), N = "";
        _.each(R, function (e) {
            N += e[0] + "+" + e[1] + "、"
        }), N = N.substr(0, N.length - 1), g.text = N
    }, e.OnClickBuild = function (e, i) {
        GetGuildInterface().DoBuildGuild(e, function (e) {
            if (e.Result) {
                this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d(), this._s9f1625f0ddd68ef4aea152a6852c7a();
                var l = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards),
                    t = i._parent.localToGlobal(new Laya.Point(i.x, i.y)),
                    a = this.globalToLocal(new Laya.Point(t.x, t.y));
                GetGuildInterface().event("UpdateGuildInfo"), GetGuildInterface().event("UpdateMyContribution"), GameCommon._s5d340979c9fcfd9445217570f410e4(this, l, null, {
                    X: a.x,
                    Y: a.y
                })
            }
        }.bind(this))
    }
}();

function GuildChangeNameDialog() {
    GuildChangeNameDialog.super(this), this.btn_Confirm.on(Laya.Event.CLICK, this, this.OnClickConfirm), this.btn_Cancel.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildChangeNameDialog")
    })
}

var GuildChangeNameDialog;
Laya.class(GuildChangeNameDialog, "GuildChangeNameDialog", GuildChangeNameDialogUI), GuildChangeNameDialog.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildChangeNameDialog.uiView, a)
};
var _proto_ = GuildChangeNameDialog.prototype;
_proto_.OnShow = function (a) {
    this._713989164 = a
}, _proto_.OnClickConfirm = function () {
    var a = this.textInput_Name.text.trim();
    if (a && "" != a) {
        var i = {
            ConsumeId: "GuildNameChange", Purpose: "进行改名", OnConfirmUse: function (i) {
                var e = {Name: a};
                GetCmdProxy().DoCmd("GuildSetInfo", {Info: e, ConsumeId: "GuildNameChange"}, function (a) {
                    a.Result && (GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildChangeNameSuccess]}), this._713989164.Callback && this._713989164.Callback())
                }.bind(this))
            }.bind(this)
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", i), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildChangeNameDialog")
    }
};

function GuildChangeOfficeView() {
    GuildChangeOfficeView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildChangeOfficeView")
    }), this.list_Change.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1);
    var e = global.$Sys.GetTableService().GetTable("guild_office");
    this._4223643952 = _.size(e) - 1
}

Laya.class(GuildChangeOfficeView, "GuildChangeOfficeView", GuildChangeOfficeUI), GuildChangeOfficeView.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildChangeOfficeUI.uiView, e)
};
var _proto_ = GuildChangeOfficeView.prototype;
_proto_.OnShow = function (e) {
    this._713989164 = e, this._s8253daee5c9ba8e7895aafa21e8168()
}, _proto_._s8253daee5c9ba8e7895aafa21e8168 = function () {
    var e = [], i = global.$Sys.GetTableService().GetTableRecord("guild_office", this._713989164.Office);
    i.CanAppointDeputy && 2 != this._713989164.NowOffice && e.push(2), i.CanAppointElite && 3 != this._713989164.NowOffice && e.push(3), i.CanAppointNormal && 4 != this._713989164.NowOffice && e.push(4), this.list_Change.array = e, this.img_Bg.height = 60 * (e.length - 1) + 173
}, _proto_.OnCreateBox = function (e, i) {
    var a = e.dataSource, t = global.$Sys.GetTableService().GetTableRecord("guild_office", a),
        n = e.getChildByName("btn_Change");
    n.label = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildChangeName, t.Name), n.on(Laya.Event.CLICK, this, this.OnClickChange, [a])
}, _proto_.OnClickChange = function (e) {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("ConfirmDialog", {
        Text: gLanguage.GuildConfirmChangeOffice,
        OnConfirm: function () {
            this._713989164.Callback && this._713989164.Callback(e), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildChangeOffice")
        }.bind(this)
    })
};
var GuildCreate;
!function () {
    GuildCreate = function () {
        GuildCreate.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildCreate")
        }), this.btn_Create.on(Laya.Event.CLICK, this, this.OnDoCreate)
    }, Laya.class(GuildCreate, "GuildCreate", GuildCreateUI), GuildCreate.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildCreateUI.uiView, t)
    };
    var t = GuildCreate.prototype;
    t.OnShow = function (t) {
    }, t.OnDoCreate = function () {
        var t = {}, e = this.input_Name.text.trim();
        "" != e && (t.Name = e);
        var i = this.input_Password.text.trim();
        "" != i && (t.Password = i);
        var a = this.input_WebChat.text.trim();
        "" != a && (t.WebChat = a);
        var n = this.input_QQ.text.trim();
        "" != n && (t.QQ = n);
        var r = this.input_Notice.text.trim();
        "" != r && (t.Notice = r), t.CanRandomJoin = this.check_Randomn.selected;
        for (var o in t) if ("CanRandomJoin" != o) {
            var u = Leo.GetDirtyWordsFilter()._s95d3edab3bfd008f58b6e1b086ebca(t[o]);
            if (!u) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.TextError]})
        }
        GetGuildInterface().DoCreateGuild(t, this.OnCreateSuccess.bind(this))
    }, t.OnCreateSuccess = function (t) {
        t.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildCreate"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("GuildMain"))
    }
}();
var GuildExchangeView;
!function () {
    GuildExchangeView = function () {
        GuildExchangeView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildExchangeView")
        }), this.list_Item.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list_Item.vScrollBarSkin = null
    }, Laya.class(GuildExchangeView, "GuildExchangeView", GuildExchangeUI), GuildExchangeView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildExchangeUI.uiView, e)
    };
    var e = GuildExchangeView.prototype;
    e.OnCreateItem = function (e, t) {
        var a = e.dataSource, i = e.getChildByName("img_Lock");
        if (a.NextLv) {
            i.visible = !0;
            var n = i.getChildByName("lab_GuildLv"), l = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Lv") + 1,
                r = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildLvFont1, l);
            n.text = r
        } else i.visible = !1;
        var o = a.ExchangeId, d = global.$Sys.GetTableService().GetTableRecord("guild_exchange_item", o), u = d.Reward,
            c = d.Consume, s = global.$Sys.GetTableService().GetTableRecord("reward", u), h = s.Award[0][1],
            g = global.$Sys.GetTableService().GetTableRecord("consume", c), G = g.Consume[0][2],
            C = (a.GuildLv, global.$Sys.GetTableService().GetTableRecord("item", h));
        e.getChildByName("lab_Name").text = C.ItemName;
        var m = e.getChildByName("sp_Icon");
        m.destroyChildren();
        var v = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: h, Width: 115, Height: 115});
        m.addChild(v), m._Icon = v, e.getChildByName("lab_Contribute").text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildContribute, G), this._sd4362a3b6627ce634918feeda2f563(o, a.NextLv, e);
        var b = e.getChildByName("btn_Exchange");
        b.on(Laya.Event.CLICK, this, this.OnClickExchange, [o, e, b])
    }, e._sd4362a3b6627ce634918feeda2f563 = function (e, t, a) {
        var i = a.getChildByName("sp_Count"), n = i.getChildByName("lab_Count"), l = a.getChildByName("sp_Icon"),
            r = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Lv");
        t && r++;
        var o = GuildExchange._s586990735935036ea823d0d905fb5e(e, r, {});
        o.Result ? (i.visible = !0, l._Icon.gray = !1) : (i.visible = !1, l._Icon.gray = !0);
        var d = global.$Sys.GetTableService().GetTableRecord("guild_exchange", r, e);
        n.text = d.TimeLimit
    }, e.OnClickExchange = function (e, t, a) {
        GetGuildInterface().DoExchange(e, this.OnExchangeFinish.bind(this), [e, t, a])
    }, e.OnExchangeFinish = function (e, t) {
        var a = t[2], i = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
        GameCommon._s5d340979c9fcfd9445217570f410e4(a, i);
        var n = t[0], l = t[1];
        GetGuildInterface().event("UpdateMyContribution"), this._se209e5d483fcc32f5f1d845d0c91b5(), this._sd4362a3b6627ce634918feeda2f563(n, null, l)
    }, e.OnClose = function () {
        for (var e = 0; e < this.list_Item.array.length; e++) {
            var t = this.list_Item.getCell(e);
            if (t) {
                var a = t.getChildByName("sp_Icon");
                a.destroyChildren()
            }
        }
    }, e.OnShow = function (e) {
        var t = GetGuildInterface()._s470db0d36e590d249c90c1422786d8();
        this.list_Item.array = t, this._se209e5d483fcc32f5f1d845d0c91b5()
    }, e._se209e5d483fcc32f5f1d845d0c91b5 = function () {
        var e = global.$Api.QueryDataSource("DataGuild").GetValue("Contribution"),
            t = GetGuildInterface()._s95fcf4eec1203efb0214290ba46406(),
            a = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildGXInfo, e, t);
        this.lab_MyContribute.text = a
    }
}();
var GuildMain;
!function () {
    GuildMain = function () {
        GuildMain.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.btn_Cur.on(Laya.Event.CLICK, this, function () {
            return this.ui_GuildInfo.visible ? void this._scb05ed1aa298062c36d84a1d7ec92b() : void this._sa624b690996ec51331199fbfb6a39f()
        }), this._4090207699 = 300, this.img_LvBg.on(Laya.Event.CLICK, this, function () {
            var t = global.$Api.QueryDataSource("DataGuild").GetValue("GuildId");
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildRankMessage", {GuildId: t})
        }), this.btn_Build.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBuildView")
        }), this.btn_Members.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildMembers")
        }), this.btn_Exchange.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildExchangeView")
        }), this.btn_Boss.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildBossView")
        }), this.btn_Rank.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildRank")
        }), this.btn_Manage.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildManage")
        }), this.list_Record.renderHandler = new Laya.Handler(this, this.OnCreateRecordItem), this.list_Record.vScrollBarSkin = null, this.check_LookMore.on("change", this, this.OnSelectRecord), this._3540225501 = this.btn_Cur.x
    }, Laya.class(GuildMain, "GuildMain", GuildMainUI), GuildMain.GetPreLoadResList = function (t) {
        t.push("res/ui/common/z_image_13.png"), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildMainUI.uiView, t)
    };
    var t = GuildMain.prototype;
    t.OnCreateRecordItem = function (t, i) {
        var e = t.dataSource, n = t.getChildByName("lab_UserName"), a = t.getChildByName("html_Record"),
            s = t.getChildByName("lab_Time"), o = t.getChildByName("lab_Sort");
        o.text = i + 1;
        var h = e.RecordData;
        h.UserName ? (n.text = h.UserName, n.color = global.$Cfg.Common.GuildReportNameColor) : (n.text = global.$Cfg.Language.GuildReportNoName, n.color = global.$Cfg.Common.GuildReportNoNameColor);
        var l = GetGuildInterface()._sedac83ee94d96f58554395c0d3db50(e.OperId, h);
        l && (a.innerHTML = l);
        var u = jasmin._sf60b29247c48694418b19d6d5ef097("yyyy-MM-dd hh:mm:ss", new Date(e.Time));
        s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.GuildBossRecordTime, u)
    }, t._s8f5096f64b01e0d2b0b452c2d76445 = function () {
        this.mouseEnabled = !1
    }, t._s6032882d4d27b65773611ddfdd5bb7 = function () {
        this.mouseEnabled = !0
    }, t.OnSelectRecord = function (t) {
        this._s8f5096f64b01e0d2b0b452c2d76445(), this.check_LookMore.selected ? this._s18457984dd06940f2ec7a1bdc4eb1f() : this._sfa345e69666c74aadd4bd5c1a9d73f()
    }, t._s2da73e952fcb2ee3de154ec3c04a5c = function () {
        var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7().Record;
        t.sort(function (t, i) {
            return i.Time - t.Time
        });
        var i = _.first(t);
        if (!i) return this.lab_UserName.visible = !1, void(this.html_RecordInfo.visible = !1);
        this.lab_UserName.visible = !0, this.html_RecordInfo.visible = !0, i.RecordData.UserName ? this.lab_UserName.text = i.RecordData.UserName : this.lab_UserName.text = global.$Cfg.Language.GuildReportNoName;
        var e = GetGuildInterface()._sedac83ee94d96f58554395c0d3db50(i.OperId, i.RecordData);
        if (e) {
            if (this.html_RecordInfo.innerHTML = e, this.html_RecordInfo.height > 36) return void(this.lab_Point.visible = !0);
            this.lab_Point.visible = !1
        }
        this.lab_Point.visible = !1
    }, t._s7592eccc062e288cc7e286750ec36d = function () {
        this._s2da73e952fcb2ee3de154ec3c04a5c(), this.list_Record.array = [];
        var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7().Record;
        t.sort(function (t, i) {
            return i.Time - t.Time
        }), this.list_Record.array = t
    }, t._s18457984dd06940f2ec7a1bdc4eb1f = function () {
        this._s7592eccc062e288cc7e286750ec36d(), Laya.Tween.to(this.img_Records, {y: 260}, 100, null, Laya.Handler.create(this, function () {
            this._s6032882d4d27b65773611ddfdd5bb7()
        }))
    }, t._sfa345e69666c74aadd4bd5c1a9d73f = function () {
        Laya.Tween.to(this.img_Records, {y: 1138}, 100, null, Laya.Handler.create(this, function () {
            this._s6032882d4d27b65773611ddfdd5bb7()
        }))
    }, t.OnUpdateGuildInfo = function () {
        var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7();
        if (this.lab_GuildName.text = t.Name, this.lab_Lv.text = t.Lv, this.lab_GuildId.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildId, t.GuildId), this.lab_Asset.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildAsset, t.Asset), this.lab_Members.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildMembers, _.size(t.Members), GetGuildInterface()._s675368fb7c2a7eac5610cc08572774()), GetGuildInterface()._s45855bea835d992a01dbb6890d7214()) this.progress_Exp.value = 1, this.lab_ExpProgress.text = gLanguage.GuildMaxLv; else {
            var i = GetGuildInterface()._saad44d7367e01601cf48b52889cc81(),
                e = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Exp");
            this.progress_Exp.value = e / i, this.lab_ExpProgress.text = e + "/" + i
        }
    }, t._scb517a521974777d0b9eb06f054f03 = function () {
        var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Lv"),
            i = global.$Sys.GetTableService().GetTable("guild_boss"), e = _.filter(i, function (i, e) {
                return i.NeedGuildLv <= t
            }), n = _.values(e);
        n.sort(function (t, i) {
            return t.BossLv - i.BossLv
        });
        var a = _.pluck(n, "BossLv");
        for (var s in a) {
            var o = GetGuildInterface()._sb17be1cfa27ed43a05a603ffb9e9cc(a[s]);
            if (o) return !0
        }
        return !1
    }, t.OnShow = function (t) {
        GameCommon._s751fe3068f6886bddb070f080cb5ee("guild"), this.OnUpdateGuildInfo(), this.OnUpdateMyContribution(), this.ui_GuildInfo.visible || this._sa624b690996ec51331199fbfb6a39f(), this._scb517a521974777d0b9eb06f054f03() ? this.lab_SayText.text = gLanguage.GuildBossHasOpen : this.lab_SayText.text = gLanguage.GuildNpcSayText;
        var i = GetGuildInterface()._s10ae0a959d1577c834c725d9fb32ec();
        this.lab_Office.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildMyOffice, i), this.lab_Notice.text = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("InsideNotice") || gLanguage.GuildDefaultGonggao;
        var e = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        e <= 2 ? this.btn_Manage.visible = !0 : this.btn_Manage.visible = !1, GetGuildInterface().on("UpdateMyContribution", this, this.OnUpdateMyContribution), GetGuildInterface().on("UpdateGuildInfo", this, this.OnUpdateGuildInfo), this._s2da73e952fcb2ee3de154ec3c04a5c(), IsOffLine() || (this._2325891651 = Leo.GetChatSystem_P(), this._526051148 = this._2325891651._saeb2814548eac60bb4139b67d6fbb9(), this._526051148.left = 0, this._526051148.bottom = 0, this.ui_Chat.addChild(this._526051148));
        var n = ["Area"];
        jasmin._seb2d63e263badd8a69c54d151f6cc7(GetGuildProxy()._s29a41a18394428f794cfc156c4edd1()) && n.push("Guild"), this._2325891651 && (this._2325891651._s6f061e4f6f62e63e4188bd53fa50e3(n), this._2325891651.OnSetDefIndex("Guild"), this._2325891651._s89054e77b7a538cfcf6055d9d64058())
    }, t.OnClose = function () {
        GetGuildInterface().off("UpdateMyContribution", this, this.OnUpdateMyContribution), GetGuildInterface().off("UpdateGuildInfo", this, this.OnUpdateGuildInfo), this.check_LookMore.selected = !1, this._2325891651 && this._2325891651._sb21e9331a1c6425ce2218185c68d93(), this._526051148.removeSelf()
    }, t.OnUpdateMyContribution = function () {
        this.lab_GXValue.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildGXInfo, GetGuildInterface()._sbf3eba4534d59be688e57886d66d5c(), GetGuildInterface()._sfa80f2d23d3995db97998f5a7f70eb())
    }, t._sdaee5ac98dced4e7057aa5e0741494 = function () {
        this.ui_Shield.mouseEnabled = !0
    }, t._s5387c1b258ac7c40b7d5c3192572ed = function () {
        this.ui_Shield.mouseEnabled = !1
    }, t._s85fe2866e1adc733f88bb37bf08393 = function (t) {
        Laya.Tween.to(this.btn_Cur, {x: this._3540225501 - 500}, 100, null, Laya.Handler.create(this, t))
    }, t._sbfc96d4b9ea6cf37fe6cd3f34a72cb = function (t, i) {
        this.btn_Cur.y = t, Laya.Tween.to(this.btn_Cur, {x: this._3540225501}, 100, null, Laya.Handler.create(this, i))
    }, t._scb05ed1aa298062c36d84a1d7ec92b = function () {
        this._sdaee5ac98dced4e7057aa5e0741494();
        var t = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        t <= 2 ? this.btn_Manage.visible = !0 : this.btn_Manage.visible = !1, this.img_NpcQipao.visible = !0, Laya.Tween.to(this.img_NpcQipao, {
            scaleX: 0,
            scaleY: 0
        }, 100, null, Laya.Handler.create(this, function () {
            this._s85fe2866e1adc733f88bb37bf08393(function () {
                this.img_NpcQipao.visible = !1, this.DownInfo(function () {
                    this.ui_GuildInfo.visible = !1, this.ui_GuildOper.visible = !0, this._sf8492244a67180b861d97ab602a193(function () {
                        var t = this.ui_Chat.height + this.ui_Chat.y - this.btn_Cur.height;
                        this._sbfc96d4b9ea6cf37fe6cd3f34a72cb(t, function () {
                            this._s5387c1b258ac7c40b7d5c3192572ed()
                        }.bind(this))
                    }.bind(this))
                }.bind(this))
            }.bind(this))
        }))
    }, t._sa624b690996ec51331199fbfb6a39f = function () {
        this._sdaee5ac98dced4e7057aa5e0741494();
        var t = GetGuildInterface()._s10ae0a959d1577c834c725d9fb32ec();
        this.lab_Office.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildMyOffice, t), this.lab_Notice.text = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("InsideNotice") || gLanguage.GuildDefaultGonggao, this._s85fe2866e1adc733f88bb37bf08393(function () {
            this.DownOper(function () {
                this.ui_GuildInfo.visible = !0, this.ui_GuildOper.visible = !1, this._s0c3272aaf88989d8a14c7bd1640d9c(function () {
                    var t = this.ui_Chat.height + this.ui_Chat.y - this.btn_Cur.height;
                    this._sbfc96d4b9ea6cf37fe6cd3f34a72cb(t, function () {
                        this._scb517a521974777d0b9eb06f054f03() ? this.lab_SayText.text = gLanguage.GuildBossHasOpen : this.lab_SayText.text = gLanguage.GuildNpcSayText, this.img_NpcQipao.visible = !0, Laya.Tween.to(this.img_NpcQipao, {
                            scaleX: 1,
                            scaleY: 1
                        }, 100, null, Laya.Handler.create(this, function () {
                            this._s5387c1b258ac7c40b7d5c3192572ed()
                        }))
                    }.bind(this))
                }.bind(this))
            }.bind(this))
        }.bind(this))
    }, t.DownInfo = function (t) {
        Laya.Tween.to(this.ui_Chat, {y: this.ui_Chat.y + this.ui_GuildInfo.height}, this._4090207699, null, Laya.Handler.create(this, function () {
            t && t()
        }))
    }, t._s0c3272aaf88989d8a14c7bd1640d9c = function (t) {
        Laya.Tween.to(this.ui_Chat, {y: this.ui_Chat.y - this.ui_GuildInfo.height}, this._4090207699, null, Laya.Handler.create(this, function () {
            t && t()
        }))
    }, t.DownOper = function (t) {
        Laya.Tween.to(this.ui_Chat, {y: this.ui_Chat.y + this.ui_GuildOper.height}, this._4090207699, null, Laya.Handler.create(this, function () {
            t && t()
        }))
    }, t._sf8492244a67180b861d97ab602a193 = function (t) {
        Laya.Tween.to(this.ui_Chat, {y: this.ui_Chat.y - this.ui_GuildOper.height}, this._4090207699, null, Laya.Handler.create(this, function () {
            t && t()
        }))
    }
}();
var GuildManage;
!function () {
    function i() {
        i.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnClickClose), this.btn_Message.on(Laya.Event.CLICK, this, function () {
            var i = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34(),
                e = global.$Sys.GetTableService().GetTableRecord("guild_office", i);
            e.CanEditGuild ? GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildMessage") : GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildNotEditMessage"), this.OnClickClose()
        }), this.btn_JoinAsker.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildJoinAsker"), this.OnClickClose()
        }), this.btn_Trans.on(Laya.Event.CLICK, this, this.OnClickTrans), this.btn_Dissolve.on(Laya.Event.CLICK, this, this.OnClickDissolve)
    }

    Laya.class(i, "GuildManage", GuildManageUI), i.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(i.uiView, e)
    };
    var e = i.prototype;
    e.OnShow = function () {
        var i = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        i <= 1 ? (this.img_Bg.height = 303, this.btn_Trans.visible = !0) : (this.img_Bg.height = 222, this.btn_Trans.visible = !1), this.btn_Dissolve.visible = this.btn_Trans.visible
    }, e.OnClickClose = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildManage")
    }, e.OnClickDissolve = function () {
        var i = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        return 1 != i ? void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.Guild_OfficeNoEnouth}) : void GetGuiManager()._s2e22e694b9852084df200bc86f9340("ConfirmDialog", {
            Text: gLanguage.GuildConfirmDissolve,
            OnConfirm: function () {
                GetGuildInterface().DoDissolve(function (i) {
                    i.Result && (this.OnClickClose(), GetGuildInterface()._s19807ae6c4ef3c3187372d1afc3a1a(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildDissolveSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }, e.OnClickTrans = function () {
        var i = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        1 == i ? (GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildTrans"), this.OnClickClose()) : GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.Guild_OfficeNoEnouth})
    }
}();
var GuildMembers;
!function () {
    GuildMembers = function () {
        GuildMembers.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildMembers")
        }), this.btn_Exit.on(Laya.Event.CLICK, this, this.OnExitGuild), this.list_Members.renderHandler = new Laya.Handler(this, this.OnCreateMember), this.list_Members.vScrollBarSkin = null
    }, Laya.class(GuildMembers, "GuildMembers", GuildMembersUI), GuildMembers.GetPreLoadResList = function (e) {
        var i = global.$Sys.GetTableService().GetTable("guild_build");
        for (var t in i) e.push(i[t].Path);
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildMembersUI.uiView, e)
    };
    var e = GuildMembers.prototype;
    e.OnExitGuild = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ConfirmDialog", {
            Text: gLanguage.GuildConfirmExit,
            OnConfirm: function () {
                GetGuildInterface().DoExitGuild(function (e) {
                    e.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildMembers"), GetGuildInterface()._s19807ae6c4ef3c3187372d1afc3a1a(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildExitSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }, e.OnShow = function (e) {
        var i = GetGuildInterface()._s675368fb7c2a7eac5610cc08572774(),
            t = GetGuildInterface()._sbbc403aa5016f1f6bb1f61c0c44a54();
        this.lab_Member.text = t + "/" + i;
        var a = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Members"), l = [];
        for (var r in a) {
            var n = a[r];
            n.UserData.PlayerId = r, l.push(n)
        }
        l.sort(function (e, i) {
            return e.GuildOffice == i.GuildOffice ? i.UserData.TotalAttribute - e.UserData.TotalAttribute : e.GuildOffice - i.GuildOffice
        }), this.list_Members.array = l, this.myOffice = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34(), 1 == this.myOffice ? (this.btn_Exit.visible = !1, this.img_List.height = 871) : (this.btn_Exit.visible = !0, this.img_List.height = 804)
    }, e.OnCreateMember = function (e, i) {
        var t = e.dataSource, a = t.UserData.PlayerName, l = t.GuildOffice || 4,
            r = global.$Sys.GetTableService().GetTableRecord("guild_office", l), n = r.Name;
        e.getChildByName("lab_NameOffice").text = a + "(" + n + ")";
        var o = e.getChildByName("ui_Build");
        o.visible = !1;
        var s = t.BuildInfo;
        if (s) {
            var u = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), f = new Date(u),
                G = new Date(s.BuildTime);
            if (f.getYear() == G.getYear() && f.getMonth() == G.getMonth() && f.getDate() == G.getDate()) {
                var c = global.$Sys.GetTableService().GetTableRecord("guild_build", s.BuildId);
                o.skin = c.Path, o.visible = !0
            }
        }
        var m = t.UserData.Office, d = global.$Sys.GetTableService().GetTableRecord("office", m);
        e.getChildByName("lab_Office").text = d.OfficeName;
        var b = e.getChildByName("ui_Icon");
        b.removeChildren();
        var h = t.UserData.PlayerSex, g = t.UserData.PlayerHeroHeadId,
            C = GameCommon._sd67b3ab0a989c863be8837018016c1(h, g);
        C.y = -38, C.centerX = 0, b.addChild(C), b.offAll(Laya.Event.CLICK), b.on(Laya.Event.CLICK, this, function () {
            GetPalaceInterface().DoGetPlayerInfo(t.UserData.PlayerId, function (e) {
                e.Id = t.UserData.PlayerId, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", e)
            })
        }), e.getChildByName("lab_Shili").text = t.UserData.TotalAttribute, e.getChildByName("lab_Contribution").text = t.UserData.Contribution + "/" + t.UserData.TotalContribution;
        var y = e.getChildByName("lab_LoginTime");
        y.text = GameCommon._s35a1b0c6766e811873de21d05b47cc(t.UserData.LastEntryTime).Text, r = global.$Sys.GetTableService().GetTableRecord("guild_office", this.myOffice);
        var v = e.getChildByName("btn_DeleteMember");
        global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
        v.visible = !!(r.CanDelMember && l > this.myOffice), v.on(Laya.Event.CLICK, this, this.OnClickDelete, [i]);
        var D = e.getChildByName("btn_ChangeOffice");
        D.on(Laya.Event.CLICK, this, this.OnClickChange, [i, l]);
        var M = this._sc50b71dde301fdcad097b546c2014d(l);
        r[M] ? D.visible = !0 : D.visible = !1
    }, e._sc50b71dde301fdcad097b546c2014d = function (e) {
        var i = null;
        switch (e) {
            case 2:
                i = "CanAppointDeputy";
                break;
            case 3:
                i = "CanAppointElite";
                break;
            case 4:
                i = "CanAppointNormal"
        }
        return i
    }, e.OnClickDelete = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ConfirmDialog", {
            Text: gLanguage.GuildConfirmDeleteMember,
            OnConfirm: function () {
                var i = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Members"), t = null;
                for (var a in i) if (i[a].UserData.PlayerName == this.list_Members.array[e].UserData.PlayerName) {
                    t = a;
                    break
                }
                GetGuildInterface().DoDeleteMember(t, function (e) {
                    e.Result && (this.OnShow(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildDeleteMemberSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }, e.OnClickChange = function (e, i) {
        var t = function (i) {
            var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Members"), a = null;
            for (var l in t) if (t[l].UserData.PlayerName == this.list_Members.array[e].UserData.PlayerName) {
                a = l;
                break
            }
            GetGuildInterface().DoChangeOffice(a, i, function (e) {
                e.Result && (this.OnShow(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildChangeOfficeSuccess]}))
            }.bind(this))
        }, a = {Office: this.myOffice, NowOffice: i, Callback: t.bind(this)};
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildChangeOfficeView", a)
    }
}();

function GuildMessage() {
    GuildMessage.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildMessage")
    }), this.btn_SaveMessage.on(Laya.Event.CLICK, this, this.OnClickSave), this.btn_ChangeName.on(Laya.Event.CLICK, this, this.OnClickChangeName)
}

var GuildMessage;
Laya.class(GuildMessage, "GuildMessage", GuildMessageUI), GuildMessage.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildMessage.uiView, e)
};
var _proto_ = GuildMessage.prototype;
_proto_.OnShow = function () {
    GetGuildInterface()._s37f95bcf0af000a96636e6f5bb45cb(function (e) {
        e.Result && (e.DailyRecord && GetGuildInterface()._sc2d5e549554e1b3140e8425bfc3f25(e.DailyRecord), e.GuildInfo && (GetGuildInterface()._s8220ec0f21bc298637aad23f7e5c41(e.GuildInfo), this._56951466 = e.GuildInfo, this._sc9209ae0dd3fdb06533b36ec4474b1()), GetGuildInterface().event("UpdateGuildInfo"))
    }.bind(this));
    var e = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34(),
        t = global.$Sys.GetTableService().GetTableRecord("guild_office", e);
    t.CanEditGuild ? (this.textArea_WebChat.editable = !0, this.textArea_QQ.editable = !0, this.textArea_InsideNotice.editable = !0, this.textArea_Notice.editable = !0) : (this.textArea_WebChat.editable = !1, this.textArea_QQ.editable = !1, this.textArea_InsideNotice.editable = !1, this.textArea_Notice.editable = !1)
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    var e = this._56951466, t = global.$Api.QueryDataSource("DataBase").GetValue("Uid"), i = e.Members[t].GuildOffice,
        a = global.$Sys.GetTableService().GetTableRecord("guild_office", i);
    this.btn_ChangeName.visible = !!a.CanChangeName, a.CanEditGuild ? (this.img_Notice.height = 194, this.btn_SaveMessage.visible = !0) : (this.img_Notice.height = 271, this.btn_SaveMessage.visible = !1), this.lab_GuildName.text = e.Name + "   ", this.hBox_GuildName.changeItems();
    var o = global.$Sys.GetTableService().GetTableRecord("guild_lv", e.Lv);
    this.lab_LeaderName.text = e.Members[e.LeaderId].UserData.PlayerName, this.lab_Lv.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildInfoLv, e.Lv, e.Exp, o.Exp), this.lab_MembersCount.text = _.size(e.Members) + "/" + o.MemberLimit, this.lab_Asset.text = e.Asset, this.textArea_WebChat.text = e.WebChat ? e.WebChat : "", this.textArea_QQ.text = e.QQ ? e.QQ : "", this.textArea_InsideNotice.text = e.InsideNotice ? e.InsideNotice : "", this.textArea_Notice.text = e.Notice ? e.Notice : ""
}, _proto_.OnClickChangeName = function () {
    var e = {
        Callback: function () {
            this.OnShow()
        }.bind(this)
    };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildChangeNameDialog", e)
}, _proto_.OnClickSave = function () {
    var e = {}, t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("ForbigChangeInfo");
    if (t) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.ForbigChangeGuildInfo]});
    var i, a, o = this.textArea_QQ.text.trim();
    if (a = /\d*/, i = o.match(a), i != o) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.INPUT_ERROR});
    if (o && "" != o && o != this._56951466.QQ && (e.QQ = o), o = this.textArea_WebChat.text.trim(), o && "" != o && o != this._56951466.WebChat && (e.WebChat = o), o = this.textArea_InsideNotice.text.trim(), o && "" != o && o != this._56951466.InsideNotice && (e.InsideNotice = o), o = this.textArea_Notice.text.trim(), o && "" != o && o != this._56951466.Notice && (e.Notice = o), _.size(e) <= 0) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildNoChangeMessage]});
    for (var s in e) {
        var n = Leo.GetDirtyWordsFilter()._s95d3edab3bfd008f58b6e1b086ebca(e[s]);
        if (!n) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.TextError]})
    }
    GetCmdProxy().DoCmd("GuildSetInfo", {Info: e}, function (t) {
        t.Result && (this._56951466.QQ = e.QQ || this._56951466.QQ, this._56951466.WebChat = e.WebChat || this._56951466.WebChat, this._56951466.InsideNotice = e.InsideNotice || this._56951466.InsideNotice, this._56951466.Notice = e.Notice || this._56951466.Notice, GetGuildInterface()._s8220ec0f21bc298637aad23f7e5c41(this._56951466), GetGuildInterface().event("UpdateGuildInfo"), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildChangeMessageSuccess]}))
    }.bind(this))
};

function GuildNotEditMessage() {
    GuildNotEditMessage.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildNotEditMessage")
    }), this.btn_SaveMessage.on(Laya.Event.CLICK, this, this.OnClickSave), this.btn_ChangeName.on(Laya.Event.CLICK, this, this.OnClickChangeName)
}

var GuildNotEditMessage;
Laya.class(GuildNotEditMessage, "GuildNotEditMessage", GuildNotEditMessageUI), GuildNotEditMessage.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildNotEditMessage.uiView, e)
};
var _proto_ = GuildNotEditMessage.prototype;
_proto_.OnShow = function () {
    GetGuildInterface()._s37f95bcf0af000a96636e6f5bb45cb(function (e) {
        e.Result && (e.DailyRecord && GetGuildInterface()._sc2d5e549554e1b3140e8425bfc3f25(e.DailyRecord), e.GuildInfo && (GetGuildInterface()._s8220ec0f21bc298637aad23f7e5c41(e.GuildInfo), this._56951466 = e.GuildInfo, this._sc9209ae0dd3fdb06533b36ec4474b1()), GetGuildInterface().event("UpdateGuildInfo"))
    }.bind(this));
    var e = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34(),
        t = global.$Sys.GetTableService().GetTableRecord("guild_office", e);
    t.CanEditGuild ? (this.textArea_WebChat.editable = !0, this.textArea_QQ.editable = !0, this.textArea_InsideNotice.editable = !0, this.textArea_Notice.editable = !0) : (this.textArea_WebChat.editable = !1, this.textArea_QQ.editable = !1, this.textArea_InsideNotice.editable = !1, this.textArea_Notice.editable = !1)
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    var e = this._56951466, t = global.$Api.QueryDataSource("DataBase").GetValue("Uid"), i = e.Members[t].GuildOffice,
        a = global.$Sys.GetTableService().GetTableRecord("guild_office", i);
    this.btn_ChangeName.visible = !!a.CanChangeName, a.CanEditGuild ? (this.img_Notice.height = 194, this.btn_SaveMessage.visible = !0) : (this.img_Notice.height = 271, this.btn_SaveMessage.visible = !1), this.lab_GuildName.text = e.Name + "   ", this.hBox_GuildName.changeItems();
    var o = global.$Sys.GetTableService().GetTableRecord("guild_lv", e.Lv);
    this.lab_LeaderName.text = e.Members[e.LeaderId].UserData.PlayerName, this.lab_Lv.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildInfoLv, e.Lv, e.Exp, o.Exp), this.lab_MembersCount.text = _.size(e.Members) + "/" + o.MemberLimit, this.lab_Asset.text = e.Asset, this.textArea_WebChat.text = e.WebChat ? e.WebChat : "", this.textArea_QQ.text = e.QQ ? e.QQ : "", this.textArea_InsideNotice.text = e.InsideNotice ? e.InsideNotice : "", this.textArea_Notice.text = e.Notice ? e.Notice : ""
}, _proto_.OnClickChangeName = function () {
    var e = {
        Callback: function () {
            this.OnShow()
        }.bind(this)
    };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildChangeNameDialog", e)
}, _proto_.OnClickSave = function () {
    var e, t, i = {}, a = this.textArea_QQ.text.trim();
    return t = /\d*/, e = a.match(t), e != a ? void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.INPUT_ERROR}) : (a && "" != a && a != this._56951466.QQ && (i.QQ = a), a = this.textArea_WebChat.text.trim(), a && "" != a && a != this._56951466.WebChat && (i.WebChat = a), a = this.textArea_InsideNotice.text.trim(), a && "" != a && a != this._56951466.InsideNotice && (i.InsideNotice = a), a = this.textArea_Notice.text.trim(), a && "" != a && a != this._56951466.Notice && (i.Notice = a), _.size(i) <= 0 ? void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildNoChangeMessage]}) : void GetCmdProxy().DoCmd("GuildSetInfo", i, function (e) {
        e.Result && (this._56951466.QQ = i.QQ || this._56951466.QQ, this._56951466.WebChat = i.WebChat || this._56951466.WebChat, this._56951466.InsideNotice = i.InsideNotice || this._56951466.InsideNotice, this._56951466.Notice = i.Notice || this._56951466.Notice, GetGuildInterface()._s8220ec0f21bc298637aad23f7e5c41(this._56951466), GetGuildInterface().event("UpdateGuildInfo"), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildChangeMessageSuccess]}))
    }.bind(this)))
};
var GuildRank;
!function () {
    GuildRank = function () {
        GuildRank.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildRank")
        }), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = null, this.list_rank.vScrollBarSkin = null
    }, Laya.class(GuildRank, "GuildRank", GuildRankUI), GuildRank.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildRankUI.uiView, a)
    };
    var a = GuildRank.prototype;
    a.OnShow = function (a) {
        var e = "GuildRank", a = {TableName: e};
        GetCmdProxy().DoCmd("GuildGetRank", a, function (a) {
            if (a.Result) {
                var e = function (a, e, t) {
                    if (a) {
                        var i = global.$Api.QueryDataSource("DataGuild").GetValue("GuildId");
                        i ? a.visible = !1 : a.visible = !0, a.on(Laya.Event.CLICK, this, this.OnClickJoin, [t])
                    }
                }.bind(this), t = function (a, e, t) {
                    if (a) {
                        e = e.UserData;
                        var i = a.getChildByName("node_LeaderName");
                        i.text = e ? e.LeaderName : gLanguage.GuildRankNoGuild
                    }
                }, i = function (a, e, t) {
                    if (a) {
                        e = e.UserData;
                        var i = a.getChildByName("node_TotalValue");
                        i.text = e.TotalAttribute
                    }
                }, n = function (a, e, t) {
                    if (a) {
                        e = e.UserData;
                        var i = a.getChildByName("node_MembersCount");
                        i.text = e.MemberCount + "/" + e.MaxMemberCount
                    }
                }, o = function (a, e, t) {
                    a.text = e.UserData ? e.UserData.Name : global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), a.underline = !0, a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(e.Rank), a.offAll(Laya.Event.CLICK), a.on(Laya.Event.CLICK, this, function () {
                        var a = this._1092471860Data.RankList[t];
                        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildRankMessage", {GuildId: a})
                    })
                }.bind(this);
                this._1092471860Data = a, this._1092471860Data.ShowTag = {
                    Rank: null,
                    Name: o,
                    AskJoin: e,
                    LeaderText: t,
                    TotalText: i,
                    MembersText: n
                }, this._s4fb507d6d0f40b2d2a72f6007a938d()
            }
        }.bind(this))
    }, a._sb3df77da8dd199cc8f2c9b1b4bff73 = function (a) {
        return a && a <= 3 ? global.$Cfg.Common.RankColor[a - 1] : "#755848"
    }, a.OnClickJoin = function (a) {
        this._s8514bf0542a94045d1f149a3c1566f(a)
    }, a._s8514bf0542a94045d1f149a3c1566f = function (a) {
        var e = this._1092471860Data.RankList[a],
            t = global.$Api.QueryDataSource("DataRecord").GetValue("ExitGuildTime");
        if (t) {
            var i = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
            if (i - t <= global.$Cfg.Common.Guild.ExitTime) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({
                Result: !1,
                Error: global.$Cfg.ErrorCode.Guild_JoinNotTime
            })
        }
        var n = {
            GuildId: e,
            PlayerId: global.$Api.QueryDataSource("DataBase").GetValue("Uid"),
            UserData: global.$Api._sd4ea324199f5ab1dce80d5ef886d90()
        };
        GetCmdProxy().DoCmd("GuildAdd", n, function (a) {
            a.Result && GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildAskJoinSuccess]})
        }.bind(this))
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
    }
}();

function GuildRankMessage() {
    GuildRankMessage.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildRankMessage")
    }), this.list_Members.renderHandler = Laya.Handler.create(this, this.OnCreateMember, null, !1), this.list_Members.vScrollBarSkin = null
}

var GuildRankMessage;
Laya.class(GuildRankMessage, "GuildRankMessage", GuildRankMessageUI), GuildRankMessage.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildRankMessageUI.uiView, e)
};
var _proto_ = GuildRankMessage.prototype;
_proto_.OnShow = function (e) {
    this._713989164 = e;
    var t = e.GuildId;
    GetGuildInterface().DoGetGuildInfo(t, function (e) {
        return e.Result ? (this._56951466 = e.GuildInfo, void this._sc9209ae0dd3fdb06533b36ec4474b1()) : (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildRankMessage"), void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(e))
    }.bind(this))
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    var e = this._56951466;
    this.lab_GuildName.text = e.Name, this.lab_Lv.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildRankMessageLv, e.Lv), this.hBox_GuildName.changeItems();
    var t = global.$Sys.GetTableService().GetTableRecord("guild_lv", e.Lv);
    this.lab_Exp.text = e.Exp + "/" + t.Exp, this.lab_Asset.text = e.Asset;
    var a = e.Members, i = 0;
    for (var s in a) i += a[s].UserData.TotalAttribute;
    i >= 1e8 && (i = GameCommon._s5c693d8122a877499a10f605a128a3(i, 2)), this.lab_Attribute.text = i, this.lab_QQ.text = e.QQ ? e.QQ : "", this.lab_Notice.text = e.Notice ? e.Notice : "", this.lab_MemberCount.text = _.size(e.Members) + "/" + t.MemberLimit;
    var l = _.values(e.Members);
    l.sort(function (e, t) {
        return e.GuildOffice - t.GuildOffice
    }), this.list_Members.array = l
}, _proto_.OnCreateMember = function (e, t) {
    var a = e.dataSource;
    if (0 == t) {
        var i = e.getChildByName("img_BoxImg");
        i.visible = !1
    }
    var s = e.getChildByName("lab_Name");
    s.text = a.UserData.PlayerName;
    var l = a.GuildOffice, r = global.$Sys.GetTableService().GetTableRecord("guild_office", l),
        n = e.getChildByName("lab_OfficeName");
    n.text = r.Name
};
var GuildTrans;
!function () {
    GuildTrans = function () {
        GuildTrans.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildTrans")
        }), this.list_Members.renderHandler = new Laya.Handler(this, this.OnCreateMember)
    }, Laya.class(GuildTrans, "GuildTrans", GuildTransUI), GuildTrans.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildTransUI.uiView, e)
    };
    var e = GuildTrans.prototype;
    e.OnShow = function (e) {
        var a = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Asset");
        this.lab_GuildAsset.text = a, this.hBox_Asset.changeItems();
        var t = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Members"), i = [];
        for (var r in t) 2 == t[r].GuildOffice && i.push(t[r]);
        this.list_Members.array = i, this.myOffice = GetGuildInterface()._sf04aae5c2a56196045c829e98e8c34();
        var n = global.$Sys.GetTableService().GetTableRecord("consume", "GuildTransferConsume").Consume;
        this.lab_Consume.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildTrainsConsume, n[0][2]), this.lab_EntryTime.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildTrainsEntryTime, global.$Cfg.Common.Guild.TransEntryTime)
    }, e.OnCreateMember = function (e, a) {
        var t = e.dataSource, i = t.UserData.PlayerName, r = t.GuildOffice,
            n = global.$Sys.GetTableService().GetTableRecord("guild_office", r), s = n.Name;
        e.getChildByName("lab_NameOffice").text = i + "(" + s + ")";
        var l = t.UserData.Office, o = global.$Sys.GetTableService().GetTableRecord("office", l);
        e.getChildByName("lab_Office").text = o.OfficeName;
        var u = e.getChildByName("ui_Icon");
        u.removeChildren();
        var d = t.UserData.PlayerSex, G = t.UserData.PlayerHeroHeadId,
            m = GameCommon._sd67b3ab0a989c863be8837018016c1(d, G);
        m.y = -50, u.addChild(m), e.getChildByName("lab_Shili").text = t.UserData.TotalAttribute, e.getChildByName("lab_Contribution").text = t.UserData.Contribution + "/" + t.UserData.TotalContribution;
        var f = e.getChildByName("lab_LoginTime"), c = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
        c -= t.UserData.LastEntryTime, parseInt(c / 864e5) ? f.text = parseInt(c / 864e5) + "天前" : parseInt(c / 36e5) ? f.text = parseInt(c / 36e5) + "小时前" : f.text = parseInt(c / 6e4) + "分钟前";
        var T = e.getChildByName("btn_Trans");
        T.on(Laya.Event.CLICK, this, this.OnClickTrains, [a]), c > 2592e5 && (T.disabled = !0)
    }, e.OnClickTrains = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ConfirmDialog", {
            Text: gLanguage.GuildConfirmTrains,
            OnConfirm: function () {
                var a = GetGuildInterface()._se2616c132d91322e8cae632a6d14f7("Members"), t = null;
                for (var i in a) if (a[i].UserData.PlayerName == this.list_Members.array[e].UserData.PlayerName) {
                    t = i;
                    break
                }
                GetGuildInterface().DoTrainsGuild(t, function (e) {
                    e.Result && (GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildTrans"), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.GuildTrainsSuccess]}))
                }.bind(this))
            }.bind(this)
        })
    }
}();

function HeroBookLayer() {
    HeroBookLayer.super(this), this.list_books.renderHandler = Laya.Handler.create(this, this.OnCreateBooks, null, !1), this.list_books.vScrollBarSkin = null, this.list_books.scrollBar.elasticDistance = 500
}

HeroBookLayer.STAR_SIZE = 15, Laya.class(HeroBookLayer, "HeroBookLayer", HeroBookLayerUI);
var _proto_ = HeroBookLayer.prototype;
_proto_.OnRefresh = function (o) {
    this._4122736007 = o;
    var t = [], e = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId).Books, a = 0;
    for (var r in e) t.push(e[r]), a += e[r].Aptitude * e[r].Lv;
    t.sort(function (o, t) {
        var e = GetDataTransfer().GetTableRecord("book", o.Id), a = GetDataTransfer().GetTableRecord("book", t.Id);
        return e.Attribute == a.Attribute ? t.Star - o.Star : e.Attribute - a.Attribute
    }), this.lab_totalAptitude.text = a, this.list_books.array = t, this.hbox_tltle.width = this.lab_totalAptitude.measureWidth + this.lab_bookText.measureWidth, this.hbox_tltle.refresh()
}, _proto_.OnClose = function () {
}, _proto_.OnCreateBooks = function (o, t) {
    var e = o.getChildByName("img_book"), a = o.getChildByName("box_star"), r = a.getChildByName("list_star"),
        i = o.getChildByName("lab_aptitudeName"), s = o.getChildByName("lab_aptitude"),
        l = o.getChildByName("hbox_bookName"), n = o.getChildByName("lab_bookName"), h = l.getChildByName("lab_bookLv");
    o.name = "bookbox" + t;
    var d = this.list_books.array[t], k = GetDataTransfer().GetTableRecord("book", d.Id);
    e.skin = global.$Cfg.Common.BookIconPath[k.Attribute], i.text = gLanguage.Aptitudes[k.Attribute], s.text = global.$Api.Formula._GetBookAttribute(d.Lv, d.Aptitude), n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("《%s》", k.BookName), h.text = d.Lv, l.refresh(), r.array = new Array(k.Star), r.x = (7 - k.Star) * HeroBookLayer.STAR_SIZE / 2, o.offAll(Laya.Event.CLICK), dialogParams = {
        HeroId: this._4122736007.HeroId,
        BookId: d.Id,
        OnClickCallback: function (o, t) {
            this.OnRefresh(this._4122736007), this.event("HeroBookUp")
        }.bind(this)
    }, o.on(Laya.Event.CLICK, this, this.OnShowBookDialog, [dialogParams]), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: e,
        NodeName: "HeroBook" + t,
        OnCheckState: TargetCheck.OnCheckHeroBook.bind(this, this._4122736007.HeroId, d.Id),
        Group: "HeroBook",
        cover: !0
    })
}, _proto_.OnShowBookDialog = function (o) {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("BookUpDialog", o)
};

function HeroDetailPage() {
    HeroDetailPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_lvUp.on(Laya.Event.CLICK, this, this.OnBtnLvUpClick), this.btn_titleUp.on(Laya.Event.CLICK, this, this.OnBtnTitleUpClick), this.btn_help.on(Laya.Event.CLICK, this, this.OnBtnHelpClick), this.btn_selectUp.on(Laya.Event.CLICK, this, this.OnBtnSelectUpClick), this.btn_rule.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Hero"})
    }), this.group_tag.selectHandler = Laya.Handler.create(this, this.OnSelectTag, null, !1);
    var e = {ShowType: ["Money"]};
    this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, e)
}

HeroDetailPage.PLAYTIME = 300, Laya.class(HeroDetailPage, "HeroDetailPage", HeroDetailPageUI);
var _proto_ = HeroDetailPage.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e || {}, jasmin._se7a49036f5cfea7f559beac9db86e9(this._4122736007.HeroId, "Hero ID ==0 || Hero ID is NUll");
    var t = global.$Sys.GetTableService().GetTableRecord("hero", this._4122736007.HeroId), a = t.HeroVoice;
    t.HaloAId || t.HaloBId && t.HaloBId.length > 0 ? this.radio_halo.visible = !0 : this.radio_halo.visible = !1, a && (this._3803844753 = a, GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(a)), this._2550199603 = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId), jasmin._se7a49036f5cfea7f559beac9db86e9(this._2550199603, "Hero ID Is ERROR,Can not found Hero"), this._4042304080 = GetDataTransfer().GetTableRecord("hero", this._4122736007.HeroId), this._s4fb507d6d0f40b2d2a72f6007a938d(), this._sc3adbecf8e393df3c46a024200461c(), this._saab1eaed09b4535d477f7aa5418832(), this.group_tag.selectedIndex = 0
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this._2550199603 = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId), this.lab_lv.text = this._2550199603.Lv;
    var e = this._4042304080.SpecialtyID, t = "";
    _.each(e, function (e) {
        "" != t && (t += "、"), t += gLanguage.Specialty[e]
    }), this.lab_specialty.text = t;
    for (var a = 0, i = 1; i <= 4; i++) {
        var o = jasmin._se91cf955e91eaa1aa510d4335edd4a("lab_prop%s", i),
            r = global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(this._4122736007.HeroId, i).TotalValue;
        this[o].text = r, a += r
    }
    this.lab_totalProp.text = a, this.img_name.skin = this._4042304080.NameIcon;
    var s = GetDataTransfer().GetTableRecord("title", this._2550199603.Title).MaxHeroLv,
        l = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv;
    this.btn_lvUp.visible = this._2550199603.Lv < s, this.lab_selectUp.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.OneKeyUpText, global.$Cfg.Common.HeroCfg.OpenQuickLvUpVip), this.btn_selectUp.visible = this._2550199603.Lv < s && l >= global.$Cfg.Common.HeroCfg.OpenQuickLvUpVip, this.lab_selectUp.visible = this._2550199603.Lv < s && l < global.$Cfg.Common.HeroCfg.OpenQuickLvUpVip, this.btn_titleUp.visible = this._2550199603.Lv >= s, this.img_titleIcon.skin = global.$Cfg.Common.HeroTitleIcon[this._2550199603.Title], this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d(), this._2550199603.Title == global.$Cfg.Common.MaxHeroTitle && (this.btn_titleUp.visible = !1), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.radio_book,
        NodeName: "HeroBook",
        OnCheckState: TargetCheck.OnCheckHeroAllBooks.bind(this, this._4122736007.HeroId),
        cover: !0
    }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.radio_skill,
        NodeName: "HeroSkill",
        OnCheckState: TargetCheck.OnCheckHeroAllSkills.bind(this, this._4122736007.HeroId),
        cover: !0
    }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.radio_halo,
        NodeName: "HeroHero",
        OnCheckState: TargetCheck.OnCheckHeroHalos.bind(this, this._4122736007.HeroId),
        cover: !0
    }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.btn_titleUp,
        NodeName: "TitleUp",
        OnCheckState: TargetCheck.OnCheckHeroCanUpTitle.bind(null, this._4122736007.HeroId),
        cover: !0
    })
}, _proto_._sc3adbecf8e393df3c46a024200461c = function (e, t) {
    var a, i, o = GetDataTransfer().GetTableRecord("title", this._2550199603.Title).MaxHeroLv;
    if (this._2550199603.Lv >= o) a = 1, i = gLanguage.ChildLvMax; else {
        var r = this._2550199603.Exp,
            s = GetDataTransfer()._s8f1240e4405a1fdea7c0adbf78e9a7("hero_lv_up", this._2550199603.Lv + 1).NeedExp,
            l = global.$Api.Formula._s9593100eb2365b500bb6a88364d7be(s - r);
        i = gLanguage.Hero.NeedExp + l, a = r / s
    }
    e ? 0 == a ? Laya.Tween.to(this.bar_exp, {value: 1}, HeroDetailPage.PLAYTIME, null, Laya.Handler.create(this, function () {
        this.bar_exp.value = 0, this.lab_needMoney.text = i, t && t()
    }.bind(this))) : Laya.Tween.to(this.bar_exp, {value: a}, HeroDetailPage.PLAYTIME, null, Laya.Handler.create(this, function () {
        this.lab_needMoney.text = i, t && t()
    }.bind(this))) : (this.bar_exp.value = a, this.lab_needMoney.text = i, t && t())
}, _proto_._saab1eaed09b4535d477f7aa5418832 = function () {
    GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_hero, this._4122736007.HeroId)
}, _proto_.OnClose = function () {
    this.group_tag.selectedIndex = -1, this._3803844753 && GetAudioHelper()._sbebf31910b4e9f79e270fea2f864b7(this._3803844753), this._3803844753 = null, this.img_hero.skin = "", this.img_name.skin = "", this._1620433139 && this._1620433139.OnClose()
}, _proto_.OnBtnCloseClick = function () {
    this._4122736007.OnClose ? this._4122736007.OnClose() : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SelectHeroPage")
}, _proto_.OnBtnLvUpClick = function () {
    this.btn_lvUp.disabled = !0, this.btn_lvUp.gray = !1, GetDataHeroInterface().DoHeroLvUp({
        HeroId: this._4122736007.HeroId,
        Callback: this.OnBtnLvUpCallback.bind(this)
    })
}, _proto_.OnBtnLvUpCallback = function (e) {
    return e ? (this.mouseEnabled = !1, void async.waterfall([function (e) {
        this._sc3adbecf8e393df3c46a024200461c(!0, e)
    }.bind(this), function (e) {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_qianghua);
        var t = function () {
            this._s4fb507d6d0f40b2d2a72f6007a938d(), this.btn_lvUp.disabled = !1, this.mouseEnabled = !0, e()
        };
        Laya.loader.load("res/effect/z_effect_shenjitishi.png", Laya.Handler.create(this, function () {
            var e = new Effect, a = {
                Res: "res/effect/z_effect_shenjitishi.json",
                IsAutoRemove: !0,
                IsAutoHide: !0,
                Scale: 1.7,
                Interval: 70,
                Size: [292, 411]
            };
            e.Init(a), e._s2e4033b88e999ce7271844dbf3b2dc([this.img_hero.width / 2, this.img_hero.height / 2], t.bind(this)), this.img_hero.addChild(e), this.img_hero.Eff = e
        })), e()
    }.bind(this)])) : void(this.btn_lvUp.disabled = !1)
}, _proto_.OnBtnTitleUpClick = function () {
    var e = {
        HeroId: this._4122736007.HeroId, OnClose: function () {
            this._s4fb507d6d0f40b2d2a72f6007a938d(), this._sc3adbecf8e393df3c46a024200461c()
        }.bind(this)
    };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("TitleUpDialog", e)
}, _proto_.OnSelectTag = function (e) {
    switch (this._608090791 && (this._608090791.visible = !1), this._2501741466 && (this._2501741466.visible = !1), this._3568742206 && (this._3568742206.visible = !1), this._1620433139 && (this._1620433139.visible = !1), e) {
        case 0:
            this._3568742206 || (this._3568742206 = new HeroBookLayer, this._3568742206.on("HeroBookUp", this, function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)), this.ui_panel.addChild(this._3568742206)), this._3568742206.visible = !0, this._3568742206.OnRefresh({HeroId: this._4122736007.HeroId});
            break;
        case 1:
            this._608090791 || (this._608090791 = new HeroSkillLayer, this.ui_panel.addChild(this._608090791)), this._608090791.visible = !0, this._608090791.OnRefresh({HeroId: this._4122736007.HeroId});
            break;
        case 2:
            this._1620433139 || (this._1620433139 = new HeroPelletLayer, this._1620433139.on("UsePelletSuccess", this, function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)), this.ui_panel.addChild(this._1620433139)), this._1620433139.visible = !0, this._1620433139.OnRefresh({HeroId: this._4122736007.HeroId});
            break;
        case 3:
            this._2501741466 || (this._2501741466 = new HeroHaloLayer, this._2501741466.on("HeroHaloUp", this, function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)), this.ui_panel.addChild(this._2501741466)), this._2501741466.visible = !0, this._2501741466.OnRefresh({HeroId: this._4122736007.HeroId})
    }
}, _proto_.OnBtnHelpClick = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("AttributeHelpDialog", {HeroId: this._4122736007.HeroId})
}, _proto_.OnBtnSelectUpClick = function () {
    GetDataHeroInterface().DoQuickLvUp({HeroId: this._4122736007.HeroId}, this.OnBtnLvUpCallback.bind(this))
}, HeroDetailPage.GetPreLoadResList = function (e, t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroDetailPage.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroSkillLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroBookLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroHaloLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroPelletLayer.uiView, e);
    var a = GetDataTransfer().GetTableRecord("hero", t.HeroId);
    bodyIcon = a.BodyPath || "res/role/mengke/shanzaimengke.png", e.push(bodyIcon)
};

function HeroHaloLayer() {
    HeroHaloLayer.super(this), this.list_Halo.renderHandler = Laya.Handler.create(this, this.OnCreateHalo, null, !1), this.list_Halo.vScrollBarSkin = null, this.list_Halo.scrollBar.elasticDistance = 500, this._811371222 = [{
        TableName: "halo_a",
        OnGetHaloLv: this.OnGetHaloALv.bind(this),
        OnGetNeedText: this.OnGetHaloANeedText.bind(this),
        ShowLvUpBtn: !1,
        OnGetHaloText: this.OnGetHaloAText.bind(this)
    }, {
        TableName: "halo_b_up",
        OnGetHaloLv: this.OnGetHaloBLv.bind(this),
        OnGetNeedText: this.OnGetHaloBNeedText.bind(this),
        ShowLvUpBtn: !0,
        OnGetHaloText: this.OnGetHaloBText.bind(this)
    }], this._2986700086 = 4
}

Laya.class(HeroHaloLayer, "HeroHaloLayer", HeroHaloLayerUI);
var _proto_ = HeroHaloLayer.prototype;
_proto_.OnRefresh = function (e) {
    this._4122736007 = e || this._4122736007 || {};
    var a = [], t = global.$Sys.GetTableService().GetTableRecord("hero", this._4122736007.HeroId);
    t.HaloAId && a.push({HaloId: t.HaloAId, HaloType: 0});
    var o = t.HaloBId;
    for (var l in o) a.push({HaloId: o[l], HaloType: 1});
    this.list_Halo.array = a
}, _proto_.OnClose = function () {
}, _proto_.OnGetHaloALv = function (e) {
    var a = this._4122736007.HeroId, t = global.$Api.QueryDataSource("DataHero").GetValue("Heros"), o = t[a];
    if (o) {
        var l = global.$Sys.GetTableService().GetTableRecord("hero", a), r = l.HaloAId;
        if (r) {
            var n = 0;
            for (var i in t) l = global.$Sys.GetTableService().GetTableRecord("hero", i), l.HaloAId == r && n++;
            return n
        }
    }
}, _proto_.OnGetHaloBLv = function (e) {
    var a = this._4122736007.HeroId, t = global.$Api.QueryDataSource("DataHero").GetHeroById(a), o = t.HaloB[e];
    return o
}, _proto_._sd70417c703a62941254cc8266bcb88 = function (e) {
    for (var a = {}, t = {}, o = 0; o < e.length; o++) if (!a[o]) {
        t[o] = [], t[o].push(e[o]), a[o] = !0;
        for (var l = o + 1; l < e.length; l++) a[l] || e[o][1] != e[l][1] || e[o][2] != e[l][2] || (t[o].push(e[l]), a[l] = !0)
    }
    return t
}, _proto_.OnGetHaloAText = function (e) {
    var a = this._sd70417c703a62941254cc8266bcb88(e), t = "", o = null;
    for (var l in a) {
        var r = a[l], n = "";
        for (var i in r) n += gLanguage.Specialty[r[i][0]] + "、", o || (o = r[i][2], 2 == r[i][1] && (o += "%"), o += "，");
        n = n.substring(0, n.length - 1), t += jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.HaloText, n, o), o = null
    }
    return t = t.substring(0, t.length - 1)
}, _proto_.OnGetHaloBText = function (e) {
    var a = "", t = e[0];
    if (t.length >= 4) a += gLanguage.AllAttribute; else {
        for (var o in t) a += gLanguage.Specialty[t[o]] + "、";
        a = a.substring(0, a.length - 1)
    }
    var l = e[2];
    return 2 == e[1] && (l += "%"), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.HaloText, a, l)
}, _proto_.OnGetHaloANeedText = function (e) {
    var a = e.HaloId, t = e.HeroCount, o = global.$Sys.GetTableService().GetTableRecord("halo_b", a).HaloName,
        l = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.HaloLvUpTerm, t, o);
    return l
}, _proto_.OnGetHaloBNeedText = function (e) {
    var a = global.$Sys.GetTableService().GetTableRecord("consume", e.Consume).Consume, t = a[0][0], o = a[0][1],
        l = a[0][2], r = GameCommon._sc2670617ff77eb1396f5b63c0edc88(t, o),
        n = global.$Sys.GetTableService().GetTableRecord("item", o), i = n.ItemName + "(" + r + "/" + l + ")";
    return i
}, _proto_.OnCreateHalo = function (e, a) {
    var t = e.getChildByName("img_Halo"), o = e.getChildByName("lab_curDetail"), l = e.getChildByName("lab_nextDetail"),
        r = e.getChildByName("lab_need"), n = e.getChildByName("hbox_HaloName"), i = n.getChildByName("lab_HaloLv"),
        s = n.getChildByName("lab_HaloName"), H = e.getChildByName("btn_HaloUp"), h = e.getChildByName("lab_maxLvInfo"),
        u = e.dataSource, d = u.HaloId, b = global.$Sys.GetTableService().GetTableRecord("halo_b", d);
    t.skin = b.ImagePath, s.text = b.HaloName;
    var c = (this._4122736007.HeroId, this._811371222[u.HaloType]), v = c.OnGetHaloLv(d);
    i.text = v, n.changeItems();
    var g = global.$Sys.GetTableService().GetTableRecord(c.TableName, d);
    v <= 0 ? o.text = "------------" : o.text = c.OnGetHaloText(g[v].Effect), H.visible = c.ShowLvUpBtn, v >= _.size(g) ? (h.visible = !0, H.visible = !1, l.text = "------------", r.text = "------------") : (h.visible = !1, H.visible = c.ShowLvUpBtn, l.text = c.OnGetHaloText(g[v + 1].Effect), r.text = c.OnGetNeedText(g[v + 1]), H.off(Laya.Event.CLICK, this, this.OnBtnHaloUpClick), H.on(Laya.Event.CLICK, this, this.OnBtnHaloUpClick, [a, t]))
}, _proto_.OnBtnHaloUpClick = function (e, a) {
    var t = this.list_Halo.array[e].HaloId, o = {
        HeroId: this._4122736007.HeroId, HaloId: t, Callback: function (e) {
            e && (Laya.loader.load("res/effect/z_buff_1.png", Laya.Handler.create(this, function () {
                var e = new Effect,
                    t = {Res: "res/effect/z_buff_1.json", IsAutoRemove: !0, IsAutoHide: !0, Scale: 1, Size: [100, 176]};
                e.Init(t), e._s2e4033b88e999ce7271844dbf3b2dc([a.width / 2, a.height / 2]), a.addChild(e)
            })), GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_qianghua), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.LvUpSucceed]}), this.OnRefresh(), this.event("HeroHaloUp"))
        }.bind(this)
    };
    GetDataHeroInterface().DoHeroHaloUp(o)
};
var HeroListController;
!function () {
    HeroListController = function (t) {
        this._2743425278 = t, this._2743425278.renderHandler = Laya.Handler.create(this, this.OnCreateHeroBox, null, !1), this._2743425278.vScrollBarSkin = null
    };
    var t = HeroListController.prototype;
    HeroListController._s0daf7356f401bde6dc31ec8d9f8bc8 = function (t) {
        return new HeroListController(t)
    }, t.Init = function (t) {
        this._4122736007 = t || {};
        var e = this._4122736007.Heros || global.$Api.QueryDataSource("DataHero")._s6b8b55436407229b07aeec45efb78d();
        this._4122736007.OnSort && e.sort(this._4122736007.OnSort), this._2743425278.array = [], this._2743425278.array = e
    }, t.OnCreateHeroBox = function (t, e) {
        var r = t.getChildByName("lab_heroName"), a = t.getChildByName("img_headIcon"),
            i = t.getChildByName("img_quality"), o = t.getChildByName("btn_btn"), n = this._2743425278.array[e],
            l = GetDataTransfer().GetTableRecord("hero", n.HeroId);
        GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(a, n.HeroId), i.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, n.Title), r.text = l.HeroName, _.each(this._4122736007.ShowType, function (e, r) {
            var a = t.getChildByName(jasmin._se91cf955e91eaa1aa510d4335edd4a("hBox_info%s", r)),
                i = a.getChildByName(jasmin._se91cf955e91eaa1aa510d4335edd4a("lab_title%s", r)),
                o = a.getChildByName(jasmin._se91cf955e91eaa1aa510d4335edd4a("lab_info%s", r));
            i.text = this._s4669f1de78e9d681ad4f976073306b(e), o.text = this._sec7f755672f880a895671a145f51c2(e, n, l), a.refresh()
        }.bind(this)), o.offAll(Laya.Event.CLICK), o.on(Laya.Event.CLICK, this, this.OnBtnClick, [n.HeroId, t]), this._4122736007.OnCustom && this._4122736007.OnCustom(t, n)
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._2743425278.refresh()
    }, t.OnBtnClick = function (t, e) {
        this._4122736007.Callback(t, e), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4669f1de78e9d681ad4f976073306b = function (t) {
        return gLanguage[t] + ":"
    }, t._sec7f755672f880a895671a145f51c2 = function (t, e) {
        switch (t) {
            case"Lv":
                return e.Lv;
            case"TotalAptitude":
                for (var r = 0, a = 1; a <= 4; a++) r += global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, a).TotalValue;
                return r;
            case"BookExp":
                return e.BookExp;
            case"SkillExp":
                return e.SkillExp;
            case"Aptitude":
                for (var r = 0, a = 1; a <= 4; a++) r += global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, a).Aptitude;
                return r;
            case"Force":
                return global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, 1).TotalValue;
            case"Brains":
                return global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, 2).TotalValue;
            case"Politics":
                return global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, 3).TotalValue;
            case"Prestige":
                return global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, 4).TotalValue
        }
    }
}();

function HeroSkillLayer() {
    HeroSkillLayer.super(this), this.list_skills.renderHandler = Laya.Handler.create(this, this.OnCreateSkills, null, !1), this.list_skills.vScrollBarSkin = null, this.list_skills.scrollBar.elasticDistance = 500
}

Laya.class(HeroSkillLayer, "HeroSkillLayer", HeroSkillLayerUI);
var _proto_ = HeroSkillLayer.prototype;
_proto_.OnRefresh = function (l) {
    this._4122736007 = l || this._4122736007 || {};
    var e = [], a = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId), i = a.Skills;
    for (var t in i) e.push(i[t]);
    this.lab_skillExp.text = a.SkillExp, this.list_skills.array = e, this.hbox_skillExp.refresh(), Laya.timer.callLater(this, function () {
        this.hbox_skillExp.centerX = 0
    })
}, _proto_.OnClose = function () {
}, _proto_.OnCreateSkills = function (l, e) {
    var a = l.getChildByName("img_skill"), i = l.getChildByName("lab_curDetail"),
        t = l.getChildByName("lab_nextDetail"), s = l.getChildByName("lab_needSkillExp"),
        r = l.getChildByName("hbox_skillName"), o = r.getChildByName("lab_skillLv"),
        n = r.getChildByName("lab_skillName"), h = l.getChildByName("btn_skillUp"),
        _ = l.getChildByName("lab_maxLvInfo"), k = this.list_skills.array[e],
        d = GetDataTransfer().GetTableRecord("skill", k.Id);
    a.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.SkillIconPath, d.SkillIcon), o.text = k.Lv, n.text = d.SkillName, h.offAll(Laya.Event.CLICK);
    var c, m, f = d.DesignFormulas, u = Formula[f](d, k.Lv) / 100 + "%" + d.Desc;
    k.Lv < 200 ? (c = Formula[f](d, k.Lv + 1) / 100 + "%" + d.Desc, m = GetDataTransfer().GetTableRecord("skill_lv_up", k.Lv + 1, k.Id).NeedExp, h.visible = !0, h.on(Laya.Event.CLICK, this, this.OnBtnSkillUpClick, [k, a]), _.visible = !1) : (c = "------------", m = "------------", _.visible = !0, h.visible = !1), i.text = u, t.text = c, s.text = m
}, _proto_.OnBtnSkillUpClick = function (l, e) {
    var a = {
        HeroId: this._4122736007.HeroId, SkillId: l.Id, Callback: function (l) {
            l && (Laya.loader.load("res/effect/z_buff_1.png", Laya.Handler.create(this, function () {
                var l = new Effect,
                    a = {Res: "res/effect/z_buff_1.json", IsAutoRemove: !0, IsAutoHide: !0, Scale: 1, Size: [100, 176]};
                l.Init(a), l._s2e4033b88e999ce7271844dbf3b2dc([e.width / 2, e.height / 2]), e.addChild(l)
            })), GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_qianghua), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.LvUpSucceed]}), this.OnRefresh())
        }.bind(this)
    };
    GetDataHeroInterface().DoHeroSkillUp(a)
};
var Home;
!function () {
    Home = function () {
        Home.super(this), this.panel.hScrollBarSkin = null, this._609883226 = BottomMenuController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_BottomMenu, {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Home")
            }
        });
        var e = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Home")
            },
            ShowType: ["Money", "Food", "Troops", "Gold", "TotalProp", "Office", "HeadIcon", "Recharge", "Name"],
            Custom: {}
        };
        this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_TopInfo, e), this._3399175475._s368acb2686a0a07ac871d80150549a("OfficeUpInHome"), this._3402150980 = MainTaskController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_mainTask, {
            OnClose: function () {
                this._sf32e4df9738f00fb323aeda6ebb185()
            }.bind(this)
        }), this.btn_HuiFu.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        });
        var t = this.ui_mainTask.getChildByName("img_bg").getChildByName("img_icon"),
            i = new Leo.ImageActionManager({Image: t});
        i._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: .8,
            ScaleY: .8,
            BreatherTime: 2e3
        }), this._3867091397 = i, this.ui_CloseBtn.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this._47676010 = new Leo.ImageActionManager({Image: this.ui_CloseBtn}), this._47676010._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: .9,
            ScaleY: .9,
            BreatherTime: 2e3
        }), this.ui_HomeBtn3.on(Laya.Event.CLICK, this, this.OnClickHomeBtn, [3]), this.ui_HomeBtn4.on(Laya.Event.CLICK, this, this.OnClickHomeBtn, [4]), this.ui_HomeBtn5.on(Laya.Event.CLICK, this, this.OnClickHomeBtn, [5]);
        var a = new Leo.ImageActionManager({Image: this.img_Beauty});
        a._sc95f42251335b3aa0013090797aec9("Distance", {Time: 2e3, DistanceY: -10}), this._38670913973 = a;
        var n = new Leo.ImageActionManager({Image: this.img_Child});
        n._sc95f42251335b3aa0013090797aec9("Distance", {Time: 2e3, DistanceY: -10}), this._38670913974 = n
    }, Laya.class(Home, "Home", HomeUI), Home.OnPreLoadRes = function (e, t) {
        e.push("res/ui/map/z_denglong_1.png"), e.push("res/ui/map/z_denglong_2.png"), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BottomMenuUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TopInfoUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HomeUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainTaskUI.uiView, e), jasmin._s3c96e1f3bee730222501b208d50190(e, MainTaskController._s6ea328e154c15cc2fb730cc9ed1dd4())
    };
    var e = Home.prototype;
    e._sf32e4df9738f00fb323aeda6ebb185 = function () {
        this._3402150980._s4fb507d6d0f40b2d2a72f6007a938d(), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnShow = function () {
        GameCommon._s751fe3068f6886bddb070f080cb5ee("home"), GetDataTaskInterface()._s82dd437e0d798ae5596d8ec68ec545(function () {
            GameCommon._s8309ef797f42a26c507d05ee4868de()
        }), this.ui_HomeBtn3.visible = _.size(global.$Api.QueryDataSource("DataBeauty")._s3c6764f4e488ee747495208eef7d9b()) > 0, this.ui_HomeBtn4.visible = global.$Api.QueryDataSource("DataChild")._sa3faa3dc1ba9c1a2fe8e6d31d8c718() > 0, this.ui_HomeBtn5.visible = global.$Api.QueryDataSource("DataChild")._sae58289528bc727c177ef413b3b04a() > 0, this._sf32e4df9738f00fb323aeda6ebb185();
        var e = this._3867091397;
        e._s2e4033b88e999ce7271844dbf3b2dc(), this.OnTimeUpdate(), this._609883226._s8c5be7d6d51a594d27451cfb623f26(), Laya.timer.loop(1e3, this, this.OnTimeUpdate), Laya.timer.callLater(this, function () {
            this.panel.scrollTo(400, 0)
        }), Laya.loader.load("particle/Yezi.part", Laya.Handler.create(this, function (e) {
            var t = new Laya.Particle2D(e);
            t.emitter.start(), t.play(), t.zOrder = 100, this.bg2.addChild(t), this._2029868072 = t
        }), null, Laya.Loader.JSON), this._47676010._s2e4033b88e999ce7271844dbf3b2dc();
        var t = this._38670913973;
        t._s2e4033b88e999ce7271844dbf3b2dc();
        var i = this._38670913974;
        i._s2e4033b88e999ce7271844dbf3b2dc()
    }, e.OnClose = function () {
        this._47676010._s54107fed721f2f5f6636c3b2747bef();
        var e = this._38670913973;
        e._s54107fed721f2f5f6636c3b2747bef();
        var t = this._38670913974;
        t._s54107fed721f2f5f6636c3b2747bef();
        var i = this._3867091397;
        i._s54107fed721f2f5f6636c3b2747bef(), Laya.timer.clear(this, this.OnTimeUpdate), this._2029868072 && this._2029868072.destroy(), this._2029868072 = null, this._3399175475._s54107fed721f2f5f6636c3b2747bef()
    }, e.OnTimeUpdate = function () {
        this._sac64c2139a1af0e5b5423b1758b2aa() > 0 ? this.img_Beauty.visible = !0 : this.img_Beauty.visible = !1, this._s87db262c53a951f1a57c5ca864a84f() > 0 ? this.img_Child.visible = !0 : this.img_Child.visible = !1, GetDataChildInterface()._s4565b19a649378b2d077cbafad5473() > 0 ? this.img_Marry.visible = !0 : this.img_Marry.visible = !1
    }, e._s87db262c53a951f1a57c5ca864a84f = function () {
        var e = global.$Api.QueryDataSource("DataChild")._s871bb9f92ec011834e36289cd17351();
        for (var t in e) {
            var i = global.$Api.QueryDataSource("DataChild")._sa26abf94d588327d3fa39328241446(e[t].Id);
            if (i > 0) return i
        }
        return 0
    }, e._sac64c2139a1af0e5b5423b1758b2aa = function () {
        return GetBeautyInterface()._sa26abf94d588327d3fa39328241446()
    }, e._s0d8f06ea08b72d5f94dfa468b4b47c = function () {
        for (var e = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(global.$Cfg.CommonEnum.HeroAttribute.BRAINS), t = global.$Api.QueryDataSource("DataBase")._2552118236.Office, i = global.$Sys.GetTableService().GetTableRecord("office", t), a = 0; a < 3; a++) {
            var n;
            switch (a) {
                case 0:
                    n = i.MaxFoodCount;
                case 1:
                    n = i.MaxMoneyCount;
                case 2:
                    n = i.MaxSoldierCount;
                default:
                    n = i.MaxFoodCount
            }
            var o = global.$Api.ShareFunc._se589da605da2fd8d658becd4c5124a({
                Interval: global.$Api.Formula._s7088b0d790d6aeeb0b582d0c15fb31(e),
                StartTime: global.$Api.QueryDataSource("DataBusinessAssets")._s0dcf173986af63e29127ad08115954(a),
                CurCount: global.$Api.QueryDataSource("DataBusinessAssets")._s6d8a67e9a5ff6d8ac6e594adc68a79(a),
                MaxCount: n
            }), r = Math.min(o.Count, n);
            if (r > 0) return r
        }
        return 0
    }, e._s573300aab58e50e43079fb95d9ed1b = function () {
        var e = global.$Api.QueryDataSource("DataBase")._2552118236.Office,
            t = global.$Sys.GetTableService().GetTableRecord("office", e),
            i = global.$Api.ShareFunc._se589da605da2fd8d658becd4c5124a({
                Interval: global.$Api.Formula._sf43074ec6f050e76654809c702af79(e),
                StartTime: global.$Api.QueryDataSource("DataAffair")._s0dcf173986af63e29127ad08115954(),
                CurCount: global.$Api.QueryDataSource("DataAffair")._s6d8a67e9a5ff6d8ac6e594adc68a79(),
                MaxCount: t.MaxAffairsCount
            });
        return Math.min(i.Count, t.MaxAffairsCount)
    }, e.OnClickHomeBtn = function (e) {
        switch (e) {
            case 1:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BusinessAssets");
                break;
            case 2:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DealAffairView");
                break;
            case 3:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BeautyView", {
                    OnEnterFinish: function () {
                        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5("res/sound/beauty/z_voice2_hongyan.wav")
                    }
                });
                break;
            case 4:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildView");
                break;
            case 5:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ChildAdultListView")
        }
    }
}();

function InitialPlot() {
    InitialPlot.super(this)
}

var InitialPlot;
Laya.class(InitialPlot, "InitialPlot", InitialPlotUI);
var _proto_ = InitialPlot.prototype;
_proto_.OnShow = function () {
    GameCommon._s751fe3068f6886bddb070f080cb5ee("story");
    for (var t = global.$Sys.GetTableService().GetTable("guide_dialog"), o = [], i = 1; i < 6; i++) {
        var n = t[i];
        for (var l in n) o.push(n[l])
    }
    this.OnStartNext(o, function (t) {
        if (t) return void this.OnStopPlot();
        GameCommon._s751fe3068f6886bddb070f080cb5ee("home");
        var i = global.$Sys.GetTableService().GetTableRecord("guide_dialog", 6);
        o = _.values(i), this.OnStartNext(o, function (t) {
            this.OnStopPlot()
        }.bind(this))
    }.bind(this), global.$Cfg.Common.InitialPlotCloth)
}, _proto_.OnStartNext = function (t, o, i) {
    var n = {
        Record: t, CanSkip: !0, PlayerClothPath: i, onClose: function (t) {
            o && o(t)
        }.bind(this)
    };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("SayDialog", n, null, {
        isModal: !1,
        closeEffect: null,
        popupEffect: null
    })
}, _proto_.OnStopPlot = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi", {
        OnEnter: function () {
        }
    }, {release: !0}), GetServerInfoInterface()._s95a8b1f36825b7b47c4e542efd1229()
}, InitialPlot.GetPreLoadResList = function (t) {
    t.push(global.$Cfg.Common.InitialPlotBtn), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InitialPlotUI.uiView, t)
};

function Instance() {
    Instance.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }), this.btn_Fight.on(Laya.Event.CLICK, this, this.OnFight), this.btn_Rank.on(Laya.Event.CLICK, this, this.OnClickRank), this.btn_Change.on(Laya.Event.CLICK, this, this.OnClickChange), this.list_BossWin.vScrollBarSkin = null, this.list_BossWin.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1), this._3597063358 = 1
}

Laya.class(Instance, "Instance", InstanceUI);
var _proto_ = Instance.prototype;
Instance.GetPreLoadResList = function (t) {
    t.push(global.$Cfg.Common.Instance1), t.push(global.$Cfg.Common.Instance2), t.push(global.$Cfg.Common.Instance1Win), t.push(global.$Cfg.Common.Instance2Win), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(Instance.uiView, t)
}, _proto_.OnClickRank = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstanceRankDialog")
}, _proto_.OnClickChange = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstanceChangeDialog")
}, _proto_.OnFight = function () {
    switch (this._1315757236) {
        case 1:
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InstanceFight");
            break;
        case 2:
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InstanceBoss", {BossId: this._3597063358});
            break;
        default:
            jasmin.Error("No Case NowInstance")
    }
}, _proto_.OnTimeUpdate = function () {
    this._sf3d3a5add2282095fbcbc04e55e24e();
    var t, n = !1;
    if (this.nowTime > this.instance1StartTime && this.nowTime < this.instance1EndTime) this.img_InstanceName.skin = global.$Cfg.Common.Instance1, this._1315757236 = 1, n = !0; else if (this.nowTime > this.instance2StartTime && this.nowTime < this.instance2EndTime) this.img_InstanceName.skin = global.$Cfg.Common.Instance2, this._1315757236 = 2, n = !0; else {
        this._1315757236 = 0;
        var e = this.instance1StartTime - this.instance2StartTime, i = 0, a = 0, s = null, o = null;
        e >= 0 ? (i = this.instance2StartTime, a = this.instance1StartTime, s = global.$Cfg.Common.Instance2, o = global.$Cfg.Common.Instance1) : (i = this.instance1StartTime, a = this.instance2StartTime, s = global.$Cfg.Common.Instance1, o = global.$Cfg.Common.Instance2), this.nowTime <= i ? (this.img_InstanceName.skin = s, t = i - this.nowTime) : this.nowTime <= a ? (this.img_InstanceName.skin = o, t = a - this.nowTime) : (this.img_InstanceName.skin = s, i += 864e5, t = i - this.nowTime)
    }
    this.lab_TimeDown.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(t), this.nowTime += 1e3, n ? (this.lab_TimeDown.visible = !1, this.lab_CanFight.visible = !0, this._sd312f486fa1d9c39b1fe51ae33fe58() ? (this.btn_Fight.visible = !1, this._s4e3dbf49a579356aaaa4824630a864(), this.img_Win.visible = !0) : (this.btn_Fight.visible = !0, this.img_Win.visible = !1, this.lab_CanFight.text = gLanguage.InstanceIsFighting)) : (this.lab_TimeDown.visible = !0, this.btn_Fight.visible = !1, this.img_Win.visible = !1, this.lab_CanFight.visible = !1)
}, _proto_._sd312f486fa1d9c39b1fe51ae33fe58 = function () {
    switch (this._1315757236) {
        case 0:
            return !1;
        case 1:
            var t = global.$Api.QueryDataSource("DataInstanceAnshi").GetValue("FightOver");
            return t;
        case 2:
            var n = GetInstanceBossInterface()._sb93254d1301712a4cba3fe97373967(this._3597063358);
            return n <= 0;
        default:
            jasmin.Error("No Case NowInstance")
    }
}, _proto_._s4e3dbf49a579356aaaa4824630a864 = function () {
    switch (this._1315757236) {
        case 0:
            return !1;
        case 1:
            this.img_WinTitle.skin = global.$Cfg.Common.Instance1Win, this.lab_AnshiWin.visible = !0, this.list_BossWin.visible = !1, this.lab_CanFight.text = gLanguage.InstanceAnshiHasKilled;
            break;
        case 2:
            if (this._1139991027) break;
            this.img_WinTitle.skin = global.$Cfg.Common.Instance2Win, this.lab_AnshiWin.visible = !1, this.list_BossWin.array = this._1629512807, this.list_BossWin.visible = !0, this._1139991027 = !0, this.lab_CanFight.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.InstanceBossHasKilled, GetInstanceBossInterface()._s9399ea126ac4336aef43d7c62c7a83(this._3597063358));
            break;
        default:
            jasmin.Error("No Case NowInstance")
    }
}, _proto_.OnCreateBox = function (t, n) {
    var e = t.getChildByName("lab_Rank");
    e.text = n + 1;
    var i = t.getChildByName("lab_PlayerName");
    i.text = this._1629512807[n].PlayerName;
    var a = t.getChildByName("lab_HurtNumber");
    a.text = this._1629512807[n].Hurt
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    this.lab_WillFightTime.text = gLanguage.InstanceWillFightTime, this.lab_CanFight.text = gLanguage.InstanceIsFighting, this.lab_Instance1Name.text = gLanguage.Instance1Name, this.lab_Instance2Name.text = gLanguage.Instance2Name, this.lab_Instance1TimeText.text = gLanguage.Instance1TimeText, this.lab_Instance2TimeText.text = gLanguage.Instance2TimeText, this.lab_Instance1Time.text = gLanguage.InstanceTimeText + " " + global.$Cfg.Common.Instance1StartTime + "-" + global.$Cfg.Common.Instance1EndTime, this.lab_Instance2Time.text = gLanguage.InstanceTimeText + " " + global.$Cfg.Common.Instance2StartTime + "-" + global.$Cfg.Common.Instance2EndTime
}, _proto_.OnTweenBtn = function (t) {
    t ? Laya.Tween.to(this.btn_Fight, {
        scaleX: .9,
        scaleY: .9
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn)) : Laya.Tween.to(this.btn_Fight, {
        scaleX: 1,
        scaleY: 1
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn, [1]))
}, _proto_.OnShow = function () {
    GameCommon._s751fe3068f6886bddb070f080cb5ee("raid"), Laya.Tween.clearAll(this.btn_Fight), this.OnTweenBtn(1), this._sf3d3a5add2282095fbcbc04e55e24e(), GetInstanceBossInterface()._sb1b16b0d3b624ace42e2c8ddb262a5(function () {
        global.$Api.QueryDataSource("DataInstanceAnshi")._s66360cdb564a7aa09fe84a34fb83e9();
        var t = GetInstanceBossInterface()._s51029a153a3417605fbea13d53c0f3(this._3597063358), n = _.values(t);
        n.sort(function (t, n) {
            return n.Hurt - t.Hurt
        }), this._1629512807 = n, this._sc9209ae0dd3fdb06533b36ec4474b1(), this._1315757236 = 0, this._1139991027 = !1, this.OnTimeUpdate(), Laya.timer.loop(1e3, this, this.OnTimeUpdate)
    }.bind(this))
}, _proto_._sf3d3a5add2282095fbcbc04e55e24e = function () {
    this.nowTime = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
    var t = new Date(this.nowTime), n = t.getYear() + 1900, e = t.getMonth() + 1, i = t.getDate(),
        a = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance1StartTime);
    this.instance1StartTime = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, e, i, a.Hour, a.Minute, a.Second);
    var a = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance1EndTime);
    this.instance1EndTime = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, e, i, a.Hour, a.Minute, a.Second);
    var a = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance2StartTime);
    this.instance2StartTime = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, e, i, a.Hour, a.Minute, a.Second);
    var a = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance2EndTime);
    this.instance2EndTime = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, e, i, a.Hour, a.Minute, a.Second)
}, _proto_._se7db998f1acd3c087065e525e08a6f = function (t) {
    t = t.trim();
    var n = t.split(":"), e = {};
    return e.Hour = n[0] ? parseInt(n[0]) : 0, e.Minute = n[1] ? parseInt(n[1]) : 0, e.Second = n[2] ? parseInt(n[2]) : 0, e
}, _proto_.OnClose = function () {
    Laya.timer.clear(this, this.OnTimeUpdate)
};

function InstanceBoss() {
    InstanceBoss.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Instance")
    }), this.on("BossDead", this, this.OnBossDead), this.on("AttackEnd", this, this.OnAttackEnd), this.list_Message.vScrollBarSkin = null, this.list_Message.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1)
}

Laya.class(InstanceBoss, "InstanceBoss", InstanceBossUI);
var _proto_ = InstanceBoss.prototype;
InstanceBoss.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstanceBoss.uiView, t)
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function (t) {
    if (t) this.box_UI.visible = !1, this.box_Win.visible = !0; else {
        this.box_UI.visible = !0, this.box_Win.visible = !1;
        var e = global.$Sys.GetTableService().GetTableRecord("fb_worldboss", this._713989164.BossId);
        Laya.loader.load(e.HeadPath, Laya.Handler.create(this, function () {
            this.img_BossHead.skin = e.HeadPath ? e.HeadPath : null
        }))
    }
}, _proto_.OnBossDead = function () {
    this._sc9209ae0dd3fdb06533b36ec4474b1(1)
}, _proto_.OnAttackEnd = function (t) {
    if (t.Rewards) {
        var e = global.$Sys.GetTableService().GetTableRecord("fb_worldboss", this._713989164.BossId),
            a = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards), s = new InstanceWinUI;
        s.lab_FightMessage.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.InstanceAttackBoss, e.Name);
        for (var n in a) {
            var i = a[n];
            i[0] == global.$Cfg.CommonEnum.Asset.DataInstance && i[1] == global.$Cfg.CommonEnum.DataInstance.InstanceScore && (s.lab_InstanceScore1.text = "+" + i[2]), i[0] == global.$Cfg.CommonEnum.Asset.DataInstance && i[1] == global.$Cfg.CommonEnum.DataInstance.ChangeScore && (s.lab_InstanceScore2.text = "+" + i[2])
        }
        s.ui_listRewardIcons.visible = !1, s.img_WinText.visible = !1, s.box_Score.centerY = .5, s.on(Laya.Event.CLICK, this, function () {
            s.removeSelf(), s.destroy()
        }), this.addChild(s)
    }
    this._sab3f378b7f9cbcd0bb7f2a82534eea()
}, _proto_._s263a27336ea752d8c7a633d713ab89 = function () {
    Laya.Tween.to(this.img_Say, {alpha: 1}, 1e3), this.lab_SayMessage.text = jasmin._s449f055209cd01229b1846559026f5(gLanguage.FbWorldBossChat), Laya.timer.once(4e3, this, this.OnSayOver)
}, _proto_.OnSayOver = function () {
    Laya.Tween.to(this.img_Say, {alpha: 0}, 1e3)
}, _proto_._sab3f378b7f9cbcd0bb7f2a82534eea = function () {
    var t = GetInstanceBossInterface()._s51029a153a3417605fbea13d53c0f3(this._713989164.BossId), e = _.values(t);
    e.sort(function (t, e) {
        return e.Hurt - t.Hurt
    }), this._1629512807 = e, this.list_Message.array = this._1629512807, this.list_Message.visible = !0
}, _proto_.OnCreateBox = function (t, e) {
    var a = t.getChildByName("lab_PlayerName");
    a.text = e + 1 + ". " + this._1629512807[e].PlayerName;
    var s = t.getChildByName("box_Message"), n = s.getChildByName("lab_HurtText");
    n.text = gLanguage.InstanceBossHurt;
    var i = s.getChildByName("lab_HurtNumber");
    i.text = this._1629512807[e].Hurt, s.changeItems()
}, _proto_.OnTweenBtn = function (t) {
    t ? Laya.Tween.to(this.btn_Fight, {
        scaleX: .9,
        scaleY: .9
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn)) : Laya.Tween.to(this.btn_Fight, {
        scaleX: 1,
        scaleY: 1
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn, [1]))
}, _proto_.OnShow = function (t) {
    this._713989164 = t, Laya.Tween.clearAll(this.btn_Fight), this.OnTweenBtn(1), this._sc9209ae0dd3fdb06533b36ec4474b1();
    var e = GetInstanceBossInterface();
    e._sb1b16b0d3b624ace42e2c8ddb262a5(function () {
        var t = this._713989164.BossId;
        this._811026184 = new BossFightInterface({
            BossId: t,
            UI: this,
            Interface: e
        }), this._s263a27336ea752d8c7a633d713ab89(), this._sab3f378b7f9cbcd0bb7f2a82534eea()
    }.bind(this))
}, _proto_.OnClose = function () {
    this._811026184._sde752cfc0009e77744b1da7ea3c4c7(), this._811026184 = null
};

function InstanceChangeDialog() {
    InstanceChangeDialog.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstanceChangeDialog")
    }), this.list_ChangItem.vScrollBarSkin = null, this.list_ChangItem.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1)
}

var InstanceChangeDialog;
Laya.class(InstanceChangeDialog, "InstanceChangeDialog", InstanceChangeDialogUI);
var _proto_ = InstanceChangeDialog.prototype;
InstanceChangeDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstanceChangeDialog.uiView, e)
}, _proto_.OnShow = function () {
    this._s8253daee5c9ba8e7895aafa21e8168()
}, _proto_.OnClose = function () {
    for (var e = 0; e < this.list_ChangItem.array.length; e++) {
        var a = this.list_ChangItem.getCell(e), t = a.getChildByName("img_Item");
        t.destroyChildren()
    }
}, _proto_._s8253daee5c9ba8e7895aafa21e8168 = function () {
    var e = global.$Sys.GetTableService().GetTable("fb_exchange"), a = _.values(e);
    this.list_ChangItem.array = a, this._s92e1892d9e3b11a8836de4060fc69e()
}, _proto_.OnCreateBox = function (e, a) {
    var t = e.getChildByName("img_Item"), n = this.list_ChangItem.array[a].Id,
        r = global.$Sys.GetTableService().GetTableRecord("item", n),
        o = GameCommon._s66eb52e60b9feb53711943e638c9c3(2, n);
    t.addChild(o);
    var i = e.getChildByName("lab_ItemName");
    i.text = r.ItemName;
    var l = global.$Api.QueryDataSource("DataDailyRecord").GetValue("Record"), h = 0;
    l.InstanceChange && l.InstanceChange[this.list_ChangItem.array[a].ChangeId] && (h = l.InstanceChange[this.list_ChangItem.array[a].ChangeId]);
    var s = global.$Sys.GetTableService().GetTableRecord("fb_exchange", this.list_ChangItem.array[a].ChangeId),
        C = global.$Sys.GetTableService().GetTableRecord("consume", s.Consume),
        g = e.getChildByName("lab_NeedScoreText"), c = g.getChildByName("lab_NeedScore");
    c.text = FormulaProxy[C.Consume[0][2]]({Count: h});
    var m = e.getChildByName("lab_ChangeCountText"), I = m.getChildByName("lab_ChangeCount");
    I.text = this.list_ChangItem.array[a].Times - h;
    var d = e.getChildByName("btn_Change");
    d.on(Laya.Event.CLICK, this, this.OnClickChange, [e, a])
}, _proto_.OnClickChange = function (e, a) {
    var t = global.$Api.QueryDataSource("DataDailyRecord").GetValue("Record"), n = 0;
    t.InstanceChange && t.InstanceChange[this.list_ChangItem.array[a].ChangeId] && (n = t.InstanceChange[this.list_ChangItem.array[a].ChangeId]);
    var r = this.list_ChangItem.array[a].ChangeId, o = {ChangeId: r},
        i = InstanceChange._s6a4dba9453762113ae0d1467dd81b3(o);
    return i.Result ? void GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
        ConsumeId: this.list_ChangItem.array[a].Consume,
        UserData: {Count: n},
        Purpose: "进行兑换",
        OnConfirmUse: function (a) {
            GetInstanceInterface().DoChange(r, function (a) {
                if (a.Rewards) {
                    var t = e._parent.localToGlobal(new Laya.Point(e.x, e.y));
                    this.lab_Reward.x = t.x + e.width / 2, this.lab_Reward.y = t.y + e.height / 2, GameCommon._s5d340979c9fcfd9445217570f410e4(this.lab_Reward, GetDataTransfer()._s31a203589c4395257a9214becf0195(a.Rewards))
                }
                this._s8253daee5c9ba8e7895aafa21e8168()
            }.bind(this))
        }.bind(this)
    }) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(i)
}, _proto_._s92e1892d9e3b11a8836de4060fc69e = function () {
    this.lab_Score.text = global.$Api.QueryDataSource("DataInstance")._s33297e0a3b8e090eeed6550616b8a8(), this.hBox_Score.changeItems()
};

function InstanceFight() {
    InstanceFight.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Instance")
    }), this.on("BossDead", this, this.OnBossDead), this.on("AttackEnd", this, this.OnAttackEnd), this.list_Message.vScrollBarSkin = null, this.list_Message.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1)
}

Laya.class(InstanceFight, "InstanceFight", InstanceFightUI);
var _proto_ = InstanceFight.prototype;
InstanceFight.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstanceFight.uiView, e)
}, _proto_.OnBossDead = function () {
    var e = global.$Api.QueryDataSource("DataInstanceAnshi")._s5fd6f0bd43701d15b32b951b99bee7();
    1 == e ? this._sc9209ae0dd3fdb06533b36ec4474b1() : (this._811026184._sa405a260b804286bebffe34e22bc3a(e), this._s263a27336ea752d8c7a633d713ab89())
}, _proto_.OnAttackEnd = function () {
    this._sab3f378b7f9cbcd0bb7f2a82534eea()
}, _proto_._s263a27336ea752d8c7a633d713ab89 = function () {
    Laya.Tween.to(this.img_Say, {alpha: 1}, 1e3), this.lab_SayMessage.text = jasmin._s449f055209cd01229b1846559026f5(gLanguage.FbBossChat), Laya.timer.once(4e3, this, this.OnSayOver)
}, _proto_.OnSayOver = function () {
    Laya.Tween.to(this.img_Say, {alpha: 0}, 1e3)
}, _proto_._sab3f378b7f9cbcd0bb7f2a82534eea = function () {
    GetInstanceInterface().DoGetAnshiRecord(function (e) {
        this.list_Message.array = [], this._1629512807 = e, this.list_Message.array = this._1629512807, this.list_Message.visible = !0
    }.bind(this))
}, _proto_.OnCreateBox = function (e, t) {
    var a = e.getChildByName("lab_PlayerName");
    a.text = t + 1 + ". " + this._1629512807[t].PlayerName;
    var s = e.getChildByName("box_Message"), n = s.getChildByName("lab_PlayerKilled");
    n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.InstanceFightKillMessage, GetInstanceAnshiInterface()._s9399ea126ac4336aef43d7c62c7a83(this._1629512807[t].BossId));
    var i = s.getChildByName("lab_ItemName"), o = this._1629512807[t].Reward, l = null;
    switch (o[0]) {
        case 1:
            o[1] == global.$Cfg.CommonEnum.DataBase.Gold && (l = gLanguage.UnitText + " x" + o[2]);
            break;
        case 2:
            var r = global.$Sys.GetTableService().GetTableRecord("item", o[1]);
            l = r.ItemName + " x" + o[2]
    }
    i.text = l, s.changeItems()
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    var e = global.$Api.QueryDataSource("DataInstanceAnshi").GetValue("FightOver");
    if (e) this.box_Win.visible = !0, this.box_UI.visible = !1; else {
        this.box_Win.visible = !1, this.box_UI.visible = !0;
        var t = global.$Api.QueryDataSource("DataInstanceAnshi")._s5fd6f0bd43701d15b32b951b99bee7(),
            a = global.$Sys.GetTableService().GetTableRecord("fb_rebellion", t);
        Laya.loader.load(a.HeadPath, Laya.Handler.create(this, function () {
            this.img_BossHead.skin = a.HeadPath ? a.HeadPath : null
        })), this._811026184 = new BossFightInterface({
            BossId: t,
            UI: this,
            Interface: GetInstanceAnshiInterface()
        }), this._s263a27336ea752d8c7a633d713ab89()
    }
}, _proto_.OnTweenBtn = function (e) {
    e ? Laya.Tween.to(this.btn_Fight, {
        scaleX: .9,
        scaleY: .9
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn)) : Laya.Tween.to(this.btn_Fight, {
        scaleX: 1,
        scaleY: 1
    }, 750, null, Laya.Handler.create(this, this.OnTweenBtn, [1]))
}, _proto_.OnShow = function (e) {
    Laya.Tween.clearAll(this.btn_Fight), this.OnTweenBtn(1), this._sc9209ae0dd3fdb06533b36ec4474b1(), this._sab3f378b7f9cbcd0bb7f2a82534eea()
}, _proto_.OnClose = function () {
    this._811026184._sde752cfc0009e77744b1da7ea3c4c7(), this._811026184 = null
};

function InstanceRankDialog() {
    InstanceRankDialog.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstanceRankDialog")
    }), this.radio_ListType.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1), this.list_Killer.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = null, this.list_rank.vScrollBarSkin = null, this.list_Killer.vScrollBarSkin = null
}

Laya.class(InstanceRankDialog, "InstanceRankDialog", InstanceRankDialogUI);
var _proto_ = InstanceRankDialog.prototype;
InstanceRankDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstanceRankDialog.uiView, e)
}, _proto_.OnShow = function () {
    this._1092471860Data ? this._s4fb507d6d0f40b2d2a72f6007a938d() : GetInstanceInterface().DoGetScoreRank({}, function (e) {
        return e.Result ? (this._1092471860Data = e, this._1092471860Data.ShowTag = {
            Rank: null,
            Name: null,
            Score: null
        }, void this._s4fb507d6d0f40b2d2a72f6007a938d()) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.GET_RANK_ERROR})
    }.bind(this)), this._s8253daee5c9ba8e7895aafa21e8168(function (e) {
        this._1935170205 = e, this.list_Killer.array = this._1935170205
    }.bind(this)), this.node_Killer.text = "无", this.radio_ListType.selectedIndex = 0
}, _proto_.OnClose = function () {
}, _proto_.OnSelectType = function (e) {
    switch (e) {
        case 0:
            this.list_rank.visible = !0, this.box_MyRank.visible = !0, this.node_Killer.visible = !1, this.list_Killer.visible = !1;
            break;
        case 1:
            this.list_rank.visible = !1, this.box_MyRank.visible = !1, this.node_Killer.visible = !0, this.list_Killer.visible = !0;
            break;
        default:
            jasmin.Error("No Select Radio")
    }
}, _proto_._s8253daee5c9ba8e7895aafa21e8168 = function (e) {
    this._1935170205 = GetInstanceInterface().DoGetKillers(1, e)
}, _proto_.OnCreateBox = function (e, t) {
    var i = e.getChildByName("node_Rank");
    i.text = t + 1;
    var a = e.getChildByName("node_Time"), n = this._1935170205[t].KillTime;
    n = new Date(n);
    var l = jasmin._sf60b29247c48694418b19d6d5ef097("yyyy-MM-dd\thh:mm:ss", n);
    a.text = l;
    var s = e.getChildByName("node_Name");
    s.text = this._1935170205[t].PlayerName, 0 == t && (this.node_Killer.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.InstanceKiller, this._1935170205[t].PlayerName))
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
};

function InstituteBooks() {
    InstituteBooks.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_books.renderHandler = Laya.Handler.create(this, this.OnCreateBooks, null, !1), this.list_books.vScrollBarSkin = null
}

Laya.class(InstituteBooks, "InstituteBooks", InstituteBooksUI);
var _proto_ = InstituteBooks.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d(), this.list_books.scrollTo(global.$Api.QueryDataSource("DataInstitute").GetValue("BooksLv"))
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = global.$Sys.GetTableService().GetTable("hanlin_book"), e = _.toArray(t);
    this.list_books.array = e, this.lab_exp.text = gLanguage.Institute.Exp + "：" + global.$Api.QueryDataSource("DataInstitute").GetValue("InstituteExp")
}, _proto_.OnCreateBooks = function (t, e) {
    var o = t.getChildByName("img_lock"), i = t.getChildByName("img_unLock"), a = t.getChildByName("img_desc"),
        s = a.getChildByName("lab_name"), n = t.getChildByName("img_lv"), l = n.getChildByName("lab_lv"),
        r = t.getChildByName("box_consume"), u = r.getChildByName("btn_upLv"), k = r.getChildByName("lab_exp"),
        g = t.getChildByName("img_bg"), b = this.list_books.array[e],
        c = global.$Api.QueryDataSource("DataInstitute").GetValue("BooksLv");
    jasmin._se7a49036f5cfea7f559beac9db86e9(jasmin._seb2d63e263badd8a69c54d151f6cc7(c), "BooksLv is Null , Please Check!!!");
    var B = b.HanLinId;
    if (l.text = B, o.visible = !1, i.visible = !1, r.visible = !1, t.disabled = !1, u.offAll(Laya.Event.CLICK), B <= c) i.visible = !0; else if (B == c + 1) {
        r.visible = !0;
        var h = b.Exp, _ = global.$Sys.GetTableService().GetTableRecord("consume", h).Consume[0];
        k.text = gLanguage.Institute.Exp + "：" + _[2], u.on(Laya.Event.CLICK, this, this.OnBtnUpLvClick, [b])
    } else o.visible = !0, t.disabled = !0;
    var C = b.BookId, d = global.$Sys.GetTableService().GetTableRecord("book", C);
    s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.BooksIDesc, d.BookName);
    var m = d.Attribute;
    g.skin = gCfg.BookBgSkin[m][0], a.skin = gCfg.BookBgSkin[m][1]
}, _proto_.OnBtnUpLvClick = function (t) {
    GetDataInstituteInterface().DoBookUp({}, function (t) {
        t.Result && (this.OnUpCallback(t), this._s4fb507d6d0f40b2d2a72f6007a938d())
    }.bind(this))
}, _proto_.OnUpCallback = function (t) {
    global.$Sys.GetTableService().GetTableRecord("book", t.BookId).BookName;
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("HanlinBookUpRewardView", {Ret: t})
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteBooks")
}, _proto_.OnClose = function () {
}, InstituteBooks.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteBooks.uiView, t), _.each(gCfg.BookBgSkin, function (e) {
        jasmin._s3c96e1f3bee730222501b208d50190(t, e)
    })
};

function InstituteBreakReward() {
    InstituteBreakReward.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(InstituteBreakReward, "InstituteBreakReward", InstituteBreakRewardUI);
var _proto_ = InstituteBreakReward.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = this._4122736007.Mail, e = t.Report.ETime - t.Report.STime;
    this.lab_exp.text = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards)[0][2], this.lab_time.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.TimeInfo, e / 6e4), this.hBox_exp.refresh(), this.lab_info.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.EnemyInfo, t.Report.Enemy);
    var a = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        i = global.$Api.QueryDataSource("DataInstitute").GetValue("QuitTime") + global.$Cfg.Common.Institute.JoinCdTime - a;
    i > 0 && (this.lab_cd.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(i), this.lab_cd.visible = !0), this.lab_cd.visible = !1
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteBreakReward")
}, _proto_.OnClose = function () {
}, InstituteBreakReward.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteBreakReward.uiView, t)
};

function InstituteCreateDialog() {
    InstituteCreateDialog.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_create.on(Laya.Event.CLICK, this, this.OnBtnCreateClick)
}

Laya.class(InstituteCreateDialog, "InstituteCreateDialog", InstituteCreateDialogUI);
var _proto_ = InstituteCreateDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv, e = t >= global.$Cfg.Common.Institute.PasswordOpenLv;
    this.inputText_password.editable = e;
    var a = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        i = GetDataTransfer().GetTableRecord("office", a), o = GetDataTransfer().GetTableRecord("institute_exp", a);
    this.lab_office.text = i.OfficeName, this.lab_desc.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.RewardInfo, o.Exp);
    var n = GetDataTransfer().GetTableRecord("consume", global.$Cfg.Common.Institute.ConsumeKey).Consume[0],
        s = GameCommon._sf0a0854e48d4ebc005e689b65b3673(n[0], n[1]),
        r = GameCommon._sc2670617ff77eb1396f5b63c0edc88(n[0], n[1]);
    this.lab_consume.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%s(%d/%d)", s, r, n[2]), this.lab_consume.color = r < n[2] ? "#7f2710" : "#21ad5f"
}, _proto_.OnBtnCreateClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteCreateDialog"), GetDataInstituteInterface().DoCreate({Password: this.inputText_password.text || null}, function (t) {
        t.Result && (GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InstituteDetailPage", {Data: t.Data}), GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstituteCreateInfoDialog"))
    })
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteCreateDialog")
}, _proto_.OnClose = function () {
}, InstituteCreateDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteCreateDialog.uiView, t)
};

function InstituteCreateInfoDialog() {
    InstituteCreateInfoDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(InstituteCreateInfoDialog, "InstituteCreateInfoDialog", InstituteCreateInfoDialogUI);
var _proto_ = InstituteCreateInfoDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this.lab_id.text = global.$Api.QueryDataSource("DataBase").GetValue("Uid")
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteCreateInfoDialog")
}, _proto_.OnClose = function () {
}, InstituteCreateInfoDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteCreateInfoDialog.uiView, t)
};

function InstituteDetailPage() {
    InstituteDetailPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_seat.renderHandler = Laya.Handler.create(this, this.OnCreateRole, null, !1), this.list_report.renderHandler = Laya.Handler.create(this, this.OnCreateReport, null, !1), this.list_report.vScrollBarSkin = null, this._3321166218 = new Leo.ImageActionManager({Image: this.box_dialog}), this._3321166218._sc95f42251335b3aa0013090797aec9("Distance", {
        Time: 2e3,
        DistanceY: -10
    }), this._262033591 = {}, this._3704167874 = []
}

Laya.class(InstituteDetailPage, "InstituteDetailPage", InstituteDetailPageUI);
var _proto_ = InstituteDetailPage.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d(), this.OnRefreshTime(), Laya.timer.loop(1e3, this, this.OnRefreshTime), this._3321166218._s2e4033b88e999ce7271844dbf3b2dc()
}, _proto_.OnRefreshTime = function () {
    var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        t = this._4122736007.Data.STime + global.$Cfg.Common.Institute.ValidTime - e;
    this.lab_time.text = t > 0 ? GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(t) : gLanguage.TimeOver
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = this._4122736007.Data.Seat;
    this.list_seat.array = [e[0], e[1], e[2]], this._s2989dae70c9bd031a45c97cde99b7e(), this.list_report.array = this._4122736007.Data.Report, this.img_lock.visible = this._4122736007.Data.Password
}, _proto_._s2989dae70c9bd031a45c97cde99b7e = function () {
    var e = this._4122736007.Data.UserData, t = global.$Sys.GetTableService().GetTableRecord("office", e.Office);
    if (e.KingInfo) {
        var a = global.$Sys.GetTableService().GetTableRecord("throne", e.KingInfo.KingId);
        this.img_role.skin = a.ClothPath, this.img_hand.skin = ""
    } else this.img_role.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(gCfg.ClothesPath, t.Clothing), this.img_hand.skin = gCfg[1 == e.Sex ? "Palace_PlayerManHand" : "Palace_PlayerWomanHand"];
    this.img_head.skin = gCfg.HeadIconName[e.Sex][e.HeadId];
    var i = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        n = Formula.OnGetInstituteExp(e.Office, i - this._4122736007.Data.STime);
    this.lab_dialog.text = gLanguage.Institute.Exp + "：" + n, this.lab_name.text = e.Name + "：", this.lab_office.text = t.OfficeName, this.hBox_name.refresh();
    var n = global.$Sys.GetTableService().GetTableRecord("institute_exp", e.Office, "Exp");
    this.lab_desc.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.RewardInfo, n)
}, _proto_.OnCreateRole = function (e, t) {
    var a = e.getChildByName("spr_role"), i = a.getChildByName("img_role"), n = a.getChildByName("img_head"),
        o = a.getChildByName("img_hand"), s = a.getChildByName("box_dialog"), r = s.getChildByName("lab_dialog"),
        l = e.getChildByName("img_name"), f = l.getChildByName("lab_name"), m = l.getChildByName("lab_office"),
        h = e.getChildByName("img_table"), c = e.getChildByName("btn_DaYa"), g = this.list_seat.array[t];
    c.off(Laya.Event.CLICK, this, this.OnJoinRoom), e.off(Laya.Event.CLICK, this, this.OnJoinRoom);
    var d = g ? g.Uid : this._4122736007.Data.Uid;
    if (c.on(Laya.Event.CLICK, this, this.OnJoinRoom, [d, t]), c.visible = !1, h.eff && (h.eff.destroy(), h.eff = null), !g) return l.visible = !1, a.visible = !1, c.visible = !1, e.on(Laya.Event.CLICK, this, this.OnJoinRoom, [d, t]), void(global.$Api.QueryDataSource("DataInstitute").GetValue("InstituteId") || Laya.loader.load(global.$Cfg.Common.FuDiJianTou, Laya.Handler.create(this, function () {
        var e = new Effect, t = 1, a = {
            Res: global.$Cfg.Common.FuDiJiaoTouEffect,
            IsAutoRemove: !1,
            IsAutoHide: !1,
            Scale: t,
            Size: [202, 202]
        };
        e.Init(a), e._s2e4033b88e999ce7271844dbf3b2dc([169, 20]), h.addChild(e), this._3704167874.push(e), h.eff = e
    })));
    l.visible = !0, a.visible = !0;
    var _ = this._4122736007.SeatInfo[t];
    this.OnCheckCanFight(_, function (e) {
        c.visible = e
    }.bind(this));
    var u = global.$Sys.GetTableService().GetTableRecord("office", _.Office);
    if (_.KingInfo) {
        var C = global.$Sys.GetTableService().GetTableRecord("throne", _.KingInfo.KingId);
        i.skin = C.ClothPath, o.skin = ""
    } else i.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(gCfg.ClothesPath, u.Clothing), o.skin = gCfg[1 == _.Sex ? "Palace_PlayerManHand" : "Palace_PlayerWomanHand"];
    n.skin = gCfg.HeadIconName[_.Sex][_.HeadId];
    var p = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        I = Formula.OnGetInstituteExp(this._4122736007.Data.UserData.Office, p - g.JTime);
    r.text = gLanguage.Institute.Exp + "：" + I, f.text = _.Name;
    var b = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
    if (_.Uid == b ? f.color = "#66ffff" : f.color = "#ddd38e", m.text = u.OfficeName, s.Action) s.Action._s54107fed721f2f5f6636c3b2747bef(); else {
        var y = new Leo.ImageActionManager({Image: s});
        y._sc95f42251335b3aa0013090797aec9("Distance", {Time: 2e3, DistanceY: -10}), s.Action = y
    }
    s.Action._s2e4033b88e999ce7271844dbf3b2dc()
}, _proto_.OnCheckCanFight = function (e, t) {
    var a = e.KingInfo ? global.$Sys.GetTableService().GetTableRecord("throne", e.KingInfo.KingId).ThroneLv : 0;
    GetPalaceInterface().DoCheckIsKing(function (i) {
        var n = !0, o = i ? i.KingId : null,
            s = o ? global.$Sys.GetTableService().GetTableRecord("throne", o).ThroneLv : 0, r = e.Office,
            l = global.$Api.QueryDataSource("DataBase").GetValue("Office");
        a == s && r > l && (n = !1);
        var f = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
        this._4122736007.Data.Uid == f && (n = !1);
        for (var m in this._4122736007.SeatInfo) {
            var h = this._4122736007.SeatInfo[m].Uid;
            if (h == f) {
                n = !1;
                break
            }
        }
        t && t(n)
    }.bind(this))
}, _proto_.OnJoinRoom = function (e, t) {
    if (this._4122736007.SeatInfo) {
        var a = this._4122736007.SeatInfo[t];
        return a ? void this.OnCheckCanFight(a, function (a) {
            a && GetDataInstituteInterface().DoJoin(e, t, this._4122736007.Data, function (e) {
                this.OnJoinCallback(e, t)
            }.bind(this))
        }.bind(this)) : void GetDataInstituteInterface().DoJoin(e, t, this._4122736007.Data, function (e) {
            this.OnJoinCallback(e, t)
        }.bind(this))
    }
}, _proto_.OnJoinCallback = function (e, t) {
    if (e.Result) switch (e.JoinType) {
        case 1:
            GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: ["加入成功!!"],
                Colors: ["#ffffff"]
            }), GetDataInstituteInterface().DoInRoom(e.Data);
            break;
        case 4:
            GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: ["请求数据已过期!!"],
                Colors: ["#ffffff"]
            }), GetDataInstituteInterface().DoInRoom(e.Data);
            break;
        default:
            var a = this._4122736007.SeatInfo[t];
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InstituteFight", {
                SetInfo: a,
                JoinType: e.JoinType,
                Report: e.Report,
                DataSource: e.Data
            })
    }
}, _proto_.OnCreateReport = function (e, t) {
    var a = e.getChildByName("lab_name"), i = e.getChildByName("lab_desc"), n = e.getChildByName("lab_time"),
        o = this.list_report.array[t];
    a.text = t + 1 + ". " + o.Name[0], i.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.ReportInfo[o.Type], o.Name[1]), n.text = jasmin._sf60b29247c48694418b19d6d5ef097("hh:mm:ss", new Date(o.Time)), a.color = 2 == o.Type ? "#ff0000" : "#704d44", i.color = 2 == o.Type ? "#ff0000" : "#704d44", n.color = 2 == o.Type ? "#ff0000" : "#704d44"
}, _proto_.OnBtnCloseClick = function () {
    var e = !1, t = this._4122736007.Data, a = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
    t.Uid == a && (e = !0);
    for (var i in t.Seat) if (t.Seat[i].Uid == a) {
        e = !0;
        break
    }
    e ? GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity") : GetDataInstituteInterface()._s2ae4f6fc306e49e99425fd62e762eb()
}, _proto_.OnClose = function () {
    _.each(this._3704167874, function (e) {
        e._parent && (e._parent.eff = null), e.destroy()
    }), this._3704167874 = [], Laya.timer.clearAll(this), this._3321166218._s54107fed721f2f5f6636c3b2747bef()
}, InstituteDetailPage.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteDetailPage.uiView, e)
};
var InstituteFight;
!function () {
    InstituteFight = function () {
        InstituteFight.super(this), this.vBox_report.sortItem = function () {
        }, this.vBox_report.space = 10
    }, Laya.class(InstituteFight, "InstituteFight", InstituteFightUI);
    var e = InstituteFight.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = this._4122736007.SetInfo, t = {
            Name: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
            Office: global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            Sex: global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
            HeadId: global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId")
        };
        GetPalaceInterface().DoCheckIsKing(function (a) {
            var i = a ? a.KingId : null;
            i && (t.KingInfo = {KingId: i}), this._sfb20a5677e00cd69e3390afaccbd29(this.box_defender, e), this._sfb20a5677e00cd69e3390afaccbd29(this.box_challenger, t);
            var n = this._4122736007.Report,
                o = gLanguage.Institute.FightReport[n.Type][Number(3 == this._4122736007.JoinType)], l = {
                    NAME_1: t.Name,
                    NAME_2: e.Name,
                    OFFICE_1: n.Office ? global.$Sys.GetTableService().GetTableRecord("office", n.Office[0]).OfficeName : null,
                    OFFICE_2: n.Office ? global.$Sys.GetTableService().GetTableRecord("office", n.Office[1]).OfficeName : null,
                    EXP_1: n.Exp ? n.Exp[0] : null,
                    EXP_2: n.Exp ? n.Exp[1] : null,
                    KING_1: n.KingId[0] ? global.$Sys.GetTableService().GetTableRecord("throne", n.KingId[0]).Name : null,
                    KING_2: n.KingId[1] ? global.$Sys.GetTableService().GetTableRecord("throne", n.KingId[1]).Name : null
                };
            this.vBox_report.destroyChildren(), this.OnPlayReport(jasmin._sdf8385ff3a74421ea218e043d47fdc(o), l, function () {
                GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstituteFightResult", {
                    OnClose: function () {
                        GetDataInstituteInterface().DoInRoom(this._4122736007.DataSource)
                    }.bind(this), Result: 2 == this._4122736007.JoinType, Type: n.Type
                })
            }.bind(this))
        }.bind(this))
    }, e._sfb20a5677e00cd69e3390afaccbd29 = function (e, t) {
        var a = e.getChildByName("img_cloth"), i = e.getChildByName("img_head"), n = e.getChildByName("img_hand"),
            o = e.getChildByName("lab_name"), l = e.getChildByName("lab_office"),
            r = global.$Sys.GetTableService().GetTableRecord("office", t.Office);
        if (t.KingInfo) {
            var s = global.$Sys.GetTableService().GetTableRecord("throne", t.KingInfo.KingId);
            a.skin = s.ClothPath, n.skin = ""
        } else a.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(gCfg.ClothesPath, r.Clothing), n.skin = gCfg[1 == t.Sex ? "Palace_PlayerManHand" : "Palace_PlayerWomanHand"];
        i.skin = gCfg.HeadIconName[t.Sex][t.HeadId], o.text = t.Name, l.text = r.OfficeName
    }, e._s03a8baf7fdfab56b09779382d20a5d = function (e, t) {
        var a = new RegExp("\\$[^$]*\\$", "gi"), i = e.match(a);
        for (var n in i) {
            var o = jasmin._sd02e70f0c0165656f303cd19ab5606(i[n], "$", "$"),
                l = jasmin._s3c26e979d2edc3daffb7451583ff07(t, o);
            jasmin._s2005e5016e164fe57540f2ee806320(l) || (l = ""), e = jasmin._s23eed9dc2e4b3346e7e436bca6ef73(e, i[n], l)
        }
        return e
    }, e.OnClose = function () {
    }, e.OnPlayReport = function (e, t, a, i) {
        if (!i) var i = 0;
        var n = e.shift();
        if (!n) return void(a && a());
        n = this._s03a8baf7fdfab56b09779382d20a5d(n, t);
        var o = new Laya.Label(n);
        o.fontSize = 23, o.color = i % 2 == 1 ? "#ff0000" : "#704d44", o.alpha = 0, this.vBox_report.addChild(o), this.vBox_report.refresh(), i++, Laya.Tween.to(o, {alpha: 1}, 500, null, Laya.Handler.create(this, this.OnPlayReport, [e, t, a, i]))
    }, InstituteFight.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteFight.uiView, e)
    }
}();
var InstituteFightResult;
!function () {
    InstituteFightResult = function () {
        InstituteFightResult.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
    }, Laya.class(InstituteFightResult, "InstituteFightResult", InstituteFightResultUI), InstituteFightResult.TITLE_SKIN = ["res/ui/bg/z_bg_guandou2.png", "res/ui/bg/z_bg_guandou.png"], InstituteFightResult.BG_SKIN = ["res/ui/bg/z_bg_72.png", "res/ui/bg/z_bg_71.png"];
    var t = InstituteFightResult.prototype;
    t.OnShow = function (t) {
        this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this.img_title.skin = InstituteFightResult.TITLE_SKIN[Number(this._4122736007.Result)], this.img_bg.skin = InstituteFightResult.BG_SKIN[Number(this._4122736007.Result)], this.lab_title.text = gLanguage.Institute[this._4122736007.Result ? "Victory" : "Defeated"], this.lab_info.text = gLanguage.Institute.FightInfo[this._4122736007.Type]
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteFightResult")
    }, t.OnClose = function () {
        this._4122736007.OnClose && this._4122736007.OnClose()
    }, InstituteFightResult.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteFightResult.uiView, t)
    }
}();

function InstituteFindDialog() {
    InstituteFindDialog.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_find.on(Laya.Event.CLICK, this, this.OnBtnFindClick), this.btn_join.on(Laya.Event.CLICK, this, this.OnBtnJoinClick)
}

Laya.class(InstituteFindDialog, "InstituteFindDialog", InstituteFindDialogUI);
var _proto_ = InstituteFindDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._298084445 = null, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    if (!this._298084445) return void(this.box_data.visible = !1);
    this.box_data.visible = !0, this.lab_name.text = this._298084445.UserData.Name;
    var t = this._298084445.UserData.Office, i = global.$Sys.GetTableService().GetTableRecord("office", t);
    this.lab_office.text = i.OfficeName, this.lab_count.text = "(" + _.size(this._298084445.Seat) + "/3)";
    var e = global.$Sys.GetTableService().GetTableRecord("institute_exp", t, "Exp");
    this.lab_reward.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.RewardInfo, e);
    var a = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        n = this._298084445.STime + global.$Cfg.Common.Institute.ValidTime - a;
    this.lab_time.text = n > 0 ? GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(n) : gLanguage.TimeOver
}, _proto_.OnBtnJoinClick = function () {
    if (this._298084445) {
        var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            i = this._298084445.STime + global.$Cfg.Common.Institute.ValidTime - t;
        if (i < 0) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: ["翰林已结束"], Colors: ["#ffffff"]});
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("InstituteDetailPage", {Data: this._298084445}), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteFindDialog")
    }
}, _proto_.OnBtnFindClick = function () {
    var t = this.textInput_id.text;
    t && GetDataInstituteInterface().DoFind({USER: t}, function (t) {
        if (t.Result) {
            if (!t.Data) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: ["该玩家未创建翰林"],
                Colors: ["#ffffff"]
            });
            this._298084445 = t.Data, this._s4fb507d6d0f40b2d2a72f6007a938d()
        }
    }.bind(this))
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteFindDialog")
}, _proto_.OnClose = function () {
}, InstituteFindDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteFindDialog.uiView, t)
};

function InstituteRewardDialog() {
    InstituteRewardDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(InstituteRewardDialog, "InstituteRewardDialog", InstituteRewardDialogUI);
var _proto_ = InstituteRewardDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = this._4122736007.Mail, e = t.Report.ETime - t.Report.STime;
    this.lab_exp.text = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards)[0][2], this.lab_time.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.TimeInfo, e / 6e4), this.hBox_exp.refresh()
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("InstituteRewardDialog")
}, _proto_.OnClose = function () {
}, InstituteRewardDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteRewardDialog.uiView, t)
};

function InstituteScene() {
    InstituteScene.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_institute.renderHandler = Laya.Handler.create(this, this.OnCreateInstitute, null, !1), this.list_bg.renderHandler = Laya.Handler.create(this, this.OnCreateBg, null, !1), this.btn_create.on(Laya.Event.CLICK, this, this.OnBtnCreateClick), this.list_institute.vScrollBarSkin = null, this.list_institute._scrollBar.on("change", this, this.OnScrollChange.bind(this)), this.list_bg.vScrollBarSkin = null, this.btn_book.on(Laya.Event.CLICK, this, this.OnBtnBookClick), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.btn_book,
        NodeName: "InstituteBook",
        OnCheckState: TargetCheck.OnCheckInstituteBooks,
        cover: !0
    }), this.btn_find.on(Laya.Event.CLICK, this, this.OnBtnFindClick), this._1193197536 = 0, this._3337510074 = []
}

InstituteScene.BG_SKIN = ["res/ui/bg/z_bg_hanlin.png", "res/ui/bg/z_bg_hanlin_1.png"], Laya.class(InstituteScene, "InstituteScene", InstituteSceneUI);
var _proto_ = InstituteScene.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d(), this._sa4a95e1ae2426793b0a8777fced7fe(), this.OnTimerLoop(), GameCommon._s751fe3068f6886bddb070f080cb5ee("story")
}, _proto_.OnScrollChange = function (t) {
    var e = this.list_institute._scrollBar.value;
    this._1193197536 != e && (this._1193197536 = e, this.list_bg._scrollBar.value = e)
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this.list_institute.array = [];
    var t = jasmin._sdf8385ff3a74421ea218e043d47fdc(this._4122736007.List);
    t.unshift(null, null), t.push(null, null), this.list_institute.array = t, this.list_bg.array = new Array(Math.ceil(t.length / 8))
}, _proto_.OnCreateInstitute = function (t, e) {
    var i = t.getChildByName("img_role0"), n = t.getChildByName("img_role1"), o = t.getChildByName("img_role2"),
        a = t.getChildByName("lab_name"), s = t.getChildByName("lab_office"), l = t.getChildByName("lab_time");
    t.offAll(Laya.Event.CLICK);
    var r = this.list_institute.array[e];
    if (t.visible = !!r, r) {
        i.visible = !jasmin._s2dedbd0e220887101c856bf900fc57(r.Seat[0]), n.visible = !jasmin._s2dedbd0e220887101c856bf900fc57(r.Seat[1]), o.visible = !jasmin._s2dedbd0e220887101c856bf900fc57(r.Seat[2]), a.text = r.UserData.Name, s.text = global.$Sys.GetTableService().GetTableRecord("office", r.UserData.Office).OfficeName, t.on(Laya.Event.CLICK, this, this.OnBtnInstituteClick, [r]);
        var m = "UpdateTime" + e;
        this.offAll(m), this.on(m, this, function () {
            var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
                e = r.STime + global.$Cfg.Common.Institute.ValidTime - t;
            l.text = e > 0 ? GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(e) : gLanguage.TimeOver
        }), this._3337510074.indexOf(m) == -1 && this._3337510074.push(m)
    }
}, _proto_.OnCreateBg = function (t, e) {
    var i = t.getChildByName("img_bg");
    i.skin = InstituteScene.BG_SKIN[0 == e ? 0 : 1]
}, _proto_.OnBtnCreateClick = function () {
    var t = global.$Cfg.Common.Institute.moduleOpenId,
        e = global.$Sys.GetTableService().GetTableRecord("module_open", t), i = e.Condition,
        n = global.$Api.GetAssetManager()._sf591a4a71c68d6c62f9d5c59258ec3(i[0], i[1], i[2]);
    if (!n.Result) {
        var o = e.ConditionDetail, a = global.$Cfg.Language.BeautyUnlockWay;
        return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [jasmin._se91cf955e91eaa1aa510d4335edd4a(a, o)]})
    }
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstituteCreateDialog")
}, _proto_.OnBtnInstituteClick = function (t) {
    var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        i = t.STime + global.$Cfg.Common.Institute.ValidTime - e;
    return i <= 0 ? void GameCommon._sd701ab0ea7b927938ca76f91a4368c({
        Texts: [gLanguage.TimeOver],
        Colors: ["#ffffff"]
    }) : void GetDataInstituteInterface().DoInRoom(t)
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
}, _proto_.OnBtnBookClick = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstituteBooks", {})
}, _proto_.OnBtnFindClick = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("InstituteFindDialog", {})
}, InstituteScene.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(InstituteScene.uiView, t), jasmin._s3c96e1f3bee730222501b208d50190(t, InstituteScene.BG_SKIN)
}, _proto_._sa4a95e1ae2426793b0a8777fced7fe = function () {
    this.timerLoop(1e3, this, this.OnTimerLoop)
}, _proto_._sba8dccb7f9520b22fcad20277b05d9 = function () {
    this.clearTimer(this, this.OnTimerLoop)
}, _proto_.OnTimerLoop = function () {
    for (var t in this._3337510074) this.event(this._3337510074[t]);
    var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
        i = global.$Api.QueryDataSource("DataInstitute").GetValue("QuitTime") + global.$Cfg.Common.Institute.JoinCdTime - e;
    i > 0 ? (this.lab_cdTime.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(i), this.lab_cdTime.visible = !0) : this.lab_cdTime.visible = !1
}, _proto_.OnClose = function () {
    jasmin.Info(this), this._sba8dccb7f9520b22fcad20277b05d9();
    for (var t in this._3337510074) this.offAll(this._3337510074[t])
};

function ItemBag() {
    ItemBag.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.redioGroup_type.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1)
}

Laya.class(ItemBag, "ItemBag", ItemBagUI);
var _proto_ = ItemBag.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e || {}, this.redioGroup_type.selectedIndex = 0, this._sc9209ae0dd3fdb06533b36ec4474b1()
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    var e = this.redioGroup_type.getChildByName("item1");
    GetDataBagInterface().DoGetCompoundList(function (t) {
        var i = _.toArray(t.CompountList);
        Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: e,
            NodeName: "Bag_CompoundBtn",
            OnCheckState: function () {
                var e = !1;
                for (var t in i) if (this._s8fe74bf472ff7bee45e634529a0437(i[t].Id, i[t].TableId)) {
                    e = !0;
                    break
                }
                return e
            }.bind(this),
            Group: "Bag",
            cover: !0
        })
    }.bind(this));
    var t = this.redioGroup_type.getChildByName("item0"), i = this._GetBagList();
    Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: t,
        NodeName: "Bag_PropBtn",
        OnCheckState: function () {
            var e = !1;
            for (var t in i) {
                var a = global.$Api.QueryDataSource("DataBag")._s72b19c90da671cbd3366ce1bad756f(i[t].ItemId),
                    o = global.$Sys.GetTableService().GetTableRecord("item", i[t].ItemId),
                    s = a && a.Count && (o.ItemStatus == -1 || o.ItemStatus == -2);
                if (s) {
                    e = !0;
                    break
                }
            }
            return e
        }.bind(this),
        Group: "Bag",
        cover: !0
    }), this.OnSelectType(this.redioGroup_type.selectedIndex)
}, _proto_._s8fe74bf472ff7bee45e634529a0437 = function (e, t) {
    var i = global.$Sys.GetTableService().GetTableRecord("item_compound", t);
    if (i.TriesLimit) {
        var a = global.$Api.QueryDataSource("DataRecord").GetValue(["Compound", e]);
        if (a >= i.TriesLimit) return !1
    }
    var o = global.$Api.GetAssetManager()._s3fe93204207ebad2b8c617add33b0a(i.Consume);
    return o.Result
}, _proto_._GetBagList = function () {
    var e = global.$Api.QueryDataSource("DataBag")._s233bcecc9537a12cc7f6c574185461();
    return _.filter(e, function (e) {
        var t = global.$Sys.GetTableService().GetTableRecord("item", e.ItemId, "ItemStatus");
        return t != -2
    })
}, _proto_.OnSelectType = function (e) {
    switch (this._s90746ef77ff05d47cb37e68d587694(), e) {
        case 0:
            this._65449132 || (this._65449132 = new ItemBagList, this.panel_detail.addChild(this._65449132)), this._65449132.visible = !0, this._65449132._sc15aa45842119777df953d125f71a3(this._GetBagList);
            break;
        case 1:
            if (IsOffLine()) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: [gLanguage.ModuleNoExist],
                Colors: ["#ffffff"]
            });
            this._4113483203 || (this._4113483203 = new CompoundLayer, this.panel_detail.addChild(this._4113483203), this._4113483203.Init()), this._4113483203.visible = !0, this._4113483203.OnRefresh();
            break;
        case 2:
            this._1699491843 || (this._1699491843 = new ItemBagList(e), this.panel_detail.addChild(this._1699491843)), this._1699491843.visible = !0, this._1699491843._sc15aa45842119777df953d125f71a3(function () {
                var e = GetDataTransfer().GetTable("item");
                return GameCommon._s5e76e2c61a5a8d61275dec4b0a3809(e, -2)
            })
    }
}, _proto_._s90746ef77ff05d47cb37e68d587694 = function () {
    this._65449132 && this._65449132.OnClose(), this._1699491843 && this._1699491843.OnClose(), this._4113483203 && this._4113483203.OnClose()
}, _proto_.OnClose = function () {
    this._s90746ef77ff05d47cb37e68d587694(), this.redioGroup_type.selectedIndex = -1, GetDataBagInterface().DoClearNewItemRecord()
}, _proto_.OnBtnCloseClick = function () {
    return this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
}, ItemBag.GetPreLoadResList = function (e) {
    e.push("res/ui/artfont/z_word_134.png"), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ItemBag.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ItemBagList.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CompoundLayer.uiView, e)
};

function ItemBagList(e) {
    ItemBagList.super(this), this.list_item.renderHandler = Laya.Handler.create(this, this.OnCreateItem, null, !1), this.list_item.selectEnable = !0, this.list_item.vScrollBarSkin = null, this.box_detail.visible = !1, this._1336424902 = Leo.ListExtend._sce82baeb3517cd19efefd5bad41c01(this.list_item, {
        Type: "Radio",
        OnGetSelectBorder: function (e) {
            return e.getChildByName("RadioBox")
        },
        OnCanSelect: function (e, t) {
            return !jasmin._s2dedbd0e220887101c856bf900fc57(e)
        }.bind(this),
        OnSelectItem: this.OnSelectItem.bind(this)
    }), this._2772377481 = e
}

Laya.class(ItemBagList, "ItemBagList", ItemBagListUI);
var _proto_ = ItemBagList.prototype;
_proto_._sc15aa45842119777df953d125f71a3 = function (e) {
    this._4270556819 = e, this._s563a9655b3d78d78f854d080286f21(this._4270556819()), Laya.timer.clear(this, this.OnTimeHandler), Laya.timer.loop(1e3, this, this.OnTimeHandler), this.lab_ItemTime.visible = !1, this.lab_TimeOut.visible = !1
}, _proto_._s563a9655b3d78d78f854d080286f21 = function (e) {
    for (var t = this.list_item.repeatX, i = this.list_item.repeatY, a = e.length; a < t * i; a++) e.push({});
    for (var m = e.length % t; m % t != 0; m++) e.push({});
    var s = 0;
    this._806646565 && _.some(e, function (e, t) {
        return e.ItemId == this._806646565 && (s = t, !0)
    }.bind(this)), this._1336424902._se06d3ef81daf6f8c47c34c7ab850df({DataSource: e, SelectItemIndex: s})
}, _proto_.OnCreateItem = function (e, t) {
    this._1336424902._sf4eade5683bb979fadd97b7d469c4d(e, t), e.ItemIcon && (e.ItemIcon.removeSelf(), e.ItemIcon.destroy(), e.ItemIcon = null);
    var i = this.list_item.array[t];
    if (!jasmin._s2dedbd0e220887101c856bf900fc57(i)) {
        var a = !0;
        2 == this._2772377481 && (a = !1);
        var m = GameCommon._s66eb52e60b9feb53711943e638c9c3(global.$Cfg.CommonEnum.Asset.DataBag, i.ItemId, !1, a, null, !0);
        e.ItemIcon = m, e.addChild(m), m.centerX = 0, m.centerY = 0;
        var s = global.$Api.QueryDataSource("DataBag")._s72b19c90da671cbd3366ce1bad756f(i.ItemId);
        m.gray = !(s && s.Count);
        var n = global.$Sys.GetTableService().GetTableRecord("item", i.ItemId),
            o = s && s.Count && (n.ItemStatus == -1 || n.ItemStatus == -2);
        if (n.UseType == global.$Cfg.CommonEnum.UseType.GET_HERO) {
            var l = global.$Cfg.CommonEnum.UseType.GET_HERO - 1e4;
            global.$Api.QueryDataSource("DataHero").GetHeroById(l) && (o = !1)
        }
        if (!m.redPoint) {
            var r = new Laya.Image("leoui/NodeAdditionalManager_P/h_image_1.png");
            r.left = 0, r.top = 0, r.zOrder = 3e3, m.addChild(r), m.redPoint = r
        }
        m.redPoint.visible = o, Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: m,
            NodeName: "Bag_" + i.ItemId,
            OnCheckState: TargetCheck.OnCheckItem.bind(this, i.ItemId),
            Group: "Bag",
            OnExecute: GameCommon.OnAddNewTitle,
            cover: !0
        })
    }
}, _proto_.OnTimeHandler = function () {
    if (this._806646565) {
        var e = global.$Api.QueryDataSource("DataBag")._s72b19c90da671cbd3366ce1bad756f(this._806646565),
            t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            i = global.$Sys.GetTableService().GetTableRecord("item", this._806646565).ExpiredTime;
        if (!e || e.Count <= 0 || !i) return this.lab_ItemTime.visible = !1, void(this.lab_TimeOut.visible = !1);
        var a = i - (t - e.AddTime);
        if (a < 0) this.lab_TimeOut.visible = !0, this.lab_ItemTime.visible = !1; else {
            this.lab_TimeOut.visible = !1;
            var m = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(a);
            this.lab_ItemTime.text = m, this.lab_ItemTime.visible = !0
        }
    }
}, _proto_.OnSelectItem = function (e) {
    var t = e[0];
    t && (this.box_detail.visible = !0, this.lab_noItem.visible = !1, this._806646565 = t.ItemId, this._s6bfd18c06cb7352600f7bf0659cb01())
}, _proto_._s6bfd18c06cb7352600f7bf0659cb01 = function () {
    var e = GetDataTransfer().GetTableRecord("item", this._806646565);
    if (e) {
        this.lab_itemName.text = e.ItemName, this.lab_itemDetail.text = e.ItemDesc, this.lab_itemName.color = global.$Cfg.Common.ItemQualityColor[e.Quality], this.lab_outUp.text = e.ItemOutUp, this.img_itemIcon.ItemIcon && (this.img_itemIcon.ItemIcon.removeSelf(), this.img_itemIcon.ItemIcon.destroy(), this.img_itemIcon.ItemIcon = null);
        var t = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({
            Id: this._806646565,
            ShowCnt: !1,
            NoShowDet: !0
        });
        this.img_itemIcon.ItemIcon = t, this.img_itemIcon.addChild(t);
        var i = global.$Api.QueryDataSource("DataBag")._s72b19c90da671cbd3366ce1bad756f(this._806646565),
            a = i ? i.Count : 0;
        this.lab_itemCount.text = a, this.lab_itemCount.visible = 2 != this._2772377481 && !!a, this.btn_useItem.offAll(Laya.Event.CLICK);
        var m = !0;
        if (e.UseType == global.$Cfg.CommonEnum.UseType.GET_HERO) {
            var s = global.$Cfg.CommonEnum.UseType.GET_HERO - 1e4;
            global.$Api.QueryDataSource("DataHero").GetHeroById(s) && (this.btn_useItem.visible = !1, m = !1)
        }
        m && (!a || e.ItemStatus != -1 && e.ItemStatus != -2 ? this.btn_useItem.visible = !1 : (this.btn_useItem.visible = !0, this.btn_useItem.on(Laya.Event.CLICK, this, this.OnBtnUseItemClick))), this.vBox_detail.refresh(), this.OnUpdateBtnLabel(e), this.OnTimeHandler()
    }
}, _proto_.OnUpdateBtnLabel = function (e) {
    var t = "";
    e.UseType == CommonEnum.UseType.KingItem && e.Reward ? GetPalaceInterface().DoCheckIsKing(function (i) {
        var a = global.$Sys.GetTableService().GetTableRecord("reward", e.Reward);
        t = a && i && a.Award[0][1] == i.KingId ? gLanguage.NoClothText : gLanguage.ChangeClothItem
    }.bind(this)) : t = gLanguage.UseItemText, this.btn_useItem.label = t
}, _proto_.OnBtnUseItemClick = function () {
    var e = {};
    e.ItemId = this._806646565, e.OnRefreshBag = function (e, t) {
        if (this._sed6b8302d3f43ebeea87430f3bcf61(!0), !t) {
            var i = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards), a = !1,
                m = _.filter(i, function (e) {
                    return 101 != e[0] || 4 != e[1] || (a = !0, !1)
                });
            if (a) {
                var s = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv;
                GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                    Texts: [jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.VipLvUpInfo, s)],
                    Colors: ["#ffffff"]
                })
            }
            GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, m)
        }
    }.bind(this), e.OnUpdateBtnLabel = this.OnUpdateBtnLabel.bind(this), GetDataBagInterface().DoUseItem(e)
}, _proto_._sed6b8302d3f43ebeea87430f3bcf61 = function (e) {
    if (e) {
        var t = _.filter(this.list_item.array, function (e) {
            return !jasmin._s2dedbd0e220887101c856bf900fc57(e)
        }), i = this._4270556819();
        for (var a in i) {
            var m, s = _.some(t, function (e, t) {
                return m = t, i[a].ItemId == e.ItemId
            });
            s ? t[m] = i[a] : t.push(i[a])
        }
        this._s563a9655b3d78d78f854d080286f21(t)
    }
    this.list_item.refresh(), this._s6bfd18c06cb7352600f7bf0659cb01()
}, _proto_.OnClose = function () {
    _.each(this.list_item.cells, function (e) {
        e.ItemIcon && (e.ItemIcon.removeSelf(), e.ItemIcon.destroy(), e.ItemIcon = null)
    }), this.img_itemIcon.ItemIcon && this.img_itemIcon.ItemIcon.destroy(), this.img_itemIcon.ItemIcon = null, this.box_detail.visible = !1, this.lab_noItem.visible = !0, this._1336424902._se2cf2090e849af0bcf89ccef442e23(), Laya.timer.clear(this, this.OnTimeHandler), this._806646565 = null, this.visible = !1
};

function ItemDetail() {
    ItemDetail.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
}

Laya.class(ItemDetail, "ItemDetail", ItemDetailUI);
var _proto_ = ItemDetail.prototype;
_proto_.OnShow = function (t) {
    this._3537444593 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = global.$Sys.GetTableService().GetTableRecord("item", this._3537444593);
    this.lab_itemName.text = t.ItemName, this.lab_itemDetail.text = t.ItemDesc, this.lab_itemName.color = global.$Cfg.Common.DetailQualityColor[t.Quality], this.lab_outUp.text = t.ItemOutUp, this.spr_itemIcon.ItemIcon && (this.spr_itemIcon.ItemIcon.removeSelf(), this.spr_itemIcon.ItemIcon.destroy(), this.spr_itemIcon.ItemIcon = null);
    var e = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: this._3537444593, NoShowDet: !0});
    this.spr_itemIcon.ItemIcon = e, this.spr_itemIcon.addChild(e), this.vBox_detail.refresh()
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ItemDetail")
}, _proto_.OnClose = function () {
    this.spr_itemIcon.ItemIcon && (this.spr_itemIcon.ItemIcon.removeSelf(), this.spr_itemIcon.ItemIcon.destroy(), this.spr_itemIcon.ItemIcon = null)
}, ItemDetail.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ItemDetail.uiView, t)
};

function ItemSelectDialog() {
    ItemSelectDialog.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_use.on(Laya.Event.CLICK, this, this.OnBtnUseClick), this.scrollBar_cnt.changeHandler = Laya.Handler.create(this, this.OnChangeCnt, null, !1), this.scrollBar_cnt._scrollSize = 100
}

Laya.class(ItemSelectDialog, "ItemSelectDialog", ItemSelectDialogUI);
var _proto_ = ItemSelectDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var t = this._4122736007.ItemId, e = global.$Api.QueryDataSource("DataBag")._s72b19c90da671cbd3366ce1bad756f(t),
        i = GetDataTransfer().GetTableRecord("item", t),
        o = jasmin._seb2d63e263badd8a69c54d151f6cc7(this._4122736007.Max) ? Math.min(this._4122736007.Max, e.Count) : e.Count;
    this.lab_name.text = i.ItemName, this.lab_name.color = global.$Cfg.Common.ItemQualityColor[i.Quality], this.lab_dec.text = i.ItemDesc, this.lab_maxCnt.text = o, this.scrollBar_cnt.max = 100 * o, this.OnChangeCnt(100), this.img_icon.ItemIcon && (this.img_icon.ItemIcon.removeSelf(), this.img_icon.ItemIcon.destroy(), this.img_icon.ItemIcon = null);
    var a = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: t});
    this.img_icon.ItemIcon = a, this.img_icon.addChild(a)
}, _proto_.OnClose = function () {
    this.scrollBar_cnt.value = 100, this.img_icon.ItemIcon && (this.img_icon.ItemIcon.removeSelf(), this.img_icon.ItemIcon.destroy(), this.img_icon.ItemIcon = null)
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ItemSelectDialog")
}, _proto_.OnBtnUseClick = function () {
    var t = this._1955251297, e = this._4122736007.ItemId;
    this._4122736007.OnUseClick(e, t), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ItemSelectDialog")
}, _proto_.OnChangeCnt = function (t) {
    this.progress_cnt.value = t / this.scrollBar_cnt.max, t = Math.floor(t / 100), 0 == t && (t = 1), this._1955251297 = t, this.lab_nowCnt.text = t, this.hbox_cnt.refresh()
}, ItemSelectDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ItemSelectDialog.uiView, t)
};

function ItemUseDialog() {
    ItemUseDialog.super(this), this.btn_Confirm.on(Laya.Event.CLICK, this, this.OnConfirmUse), this.btn_Cancel.on(Laya.Event.CLICK, this, this.OnCancelUse)
}

var ItemUseDialog;
Laya.class(ItemUseDialog, "ItemUseDialog", ItemUseDialogUI);
var _proto_ = ItemUseDialog.prototype;
_proto_.OnConfirmUse = function () {
    this._4122736007.OnConfirmUse(this.consumeCount), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ItemUseDialog")
}, _proto_.OnCancelUse = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ItemUseDialog")
}, _proto_.OnShow = function (e) {
    this._4122736007 = e, this._s55b947627a9c6a8e673afeca2d9df4()
}, _proto_._s55b947627a9c6a8e673afeca2d9df4 = function () {
    this.box_Confirm.destroyChildren();
    var e, o = this._4122736007.ConsumeId;
    if (o) {
        var t = global.$Sys.GetTableService().GetTableRecord("consume", o).Consume;
        e = t[0]
    } else e = this._4122736007.ConsumeInfo;
    var i = e[0], a = e[1];
    this.consumeCount = e[2], this.consumeCount = GetDataTransfer()._s72d5ab1107fd8bab5bc09f72932a43(this.consumeCount, this._4122736007.UserData);
    var n = GameCommon._s3c28725f2d273f38327479132c6eba(i, a), s = null;
    this.box_Confirm.centerY = .5, n.ItemId && (s = GameCommon._s66eb52e60b9feb53711943e638c9c3(i, a, null, !0), this.box_Confirm.centerY = 63);
    var m = 25, r = "#66492b", l = "#0a620e", C = gLanguage.ItemUseDialogFont1, h = new Laya.Label(C);
    if (h.color = r, h.fontSize = m, this.box_Confirm.addChild(h), i == global.$Cfg.CommonEnum.Asset.DataBag) {
        var c = global.$Sys.GetTableService().GetTableRecord("item", a), _ = c.ItemName, g = new Laya.Label(_);
        g.color = l, g.fontSize = m, this.box_Confirm.addChild(g)
    } else {
        var I;
        if (n.ItemId) I = GameCommon._s66eb52e60b9feb53711943e638c9c3(i, a, !0), I.scale(.6, .6); else {
            var d = GameCommon._sf0a0854e48d4ebc005e689b65b3673(i, a);
            I = new Laya.Label(d), I.fontSize = 25, I.color = "#a47761"
        }
        this.box_Confirm.addChild(I)
    }
    var f = new Laya.Label("x" + this.consumeCount);
    f.color = l, f.fontSize = m, this.box_Confirm.addChild(f);
    var u = new Laya.Label(this._4122736007.Purpose);
    u.color = r, u.fontSize = m, this.box_Confirm.addChild(u), this._1263065792 = s, this.img_ItemIconBig.addChild(s), this.box_Confirm.changeItems(), this.box_Confirm.centerX = .5
}, _proto_.OnClose = function () {
    this._1263065792 && this._1263065792.removeSelf(), this._1263065792 && this._1263065792.destroy(), this.box_Confirm.destroyChildren(), this.img_ItemIconBig.removeChildren(), this.img_ItemIconBig.destroyChildren()
}, ItemUseDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ItemUseDialog.uiView, e)
};
!function () {
    function e() {
        e.super(this), this.ui_CloseBtn.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.btn_Help.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Level"})
        }), this._394089020 = [];
        var t = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
            }, ShowType: ["Exp", "Force", "Troops", "TotalProp", "Office", "HeadIcon"], Custom: {}
        };
        this._1658958566 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_TopInfo, t), this._1658958566._s368acb2686a0a07ac871d80150549a("OfficeUpInLevel")
    }

    Laya.class(e, "Level", LevelUI), e.GetPreLoadResList = function (e) {
        _.each(GetDataBaseInterface()._s890c56d6eca7b89fa2db74b563f432(), function (t) {
            e.push(t)
        }), e.push("res/ui/artfont/z_word_shanzhai.png"), e.push("res/ui/common/z_knife_image.png"), e.push("res/ui/common/z_knife_image_1.png"), e.push("res/ui/progress/progress_3.png"), e.push("res/ui/progress/progress_3$bar.png"), e = e.concat(global.$Cfg.Common.LevelBgs), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TopInfoLevelUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LevelProgressNodeUI.uiView, e)
    }, e.prototype.OnClose = function () {
        this.ui_Bg.skin = "", _.each(this._394089020, function (e) {
            e.removeSelf(), e.destroy()
        }), this._394089020 = [], this._1658958566._s54107fed721f2f5f6636c3b2747bef()
    }, e.prototype.OnShow = function (e) {
        GameCommon._s751fe3068f6886bddb070f080cb5ee("level"), e = e || {}, this._4277568730 = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"), this._3940870005 = global.$Api.QueryDataSource("DataLevel").GetValue("StageId"), this._4284629566 = global.$Api.QueryDataSource("DataLevel").GetValue("Progress"), this._CheckData(), this._UpdateLevelName(), this._UpdateLevelInfo(), this._UpdateLevelBg(), GetDataLevelInterface()._s1ac89ee09d9618ee565591217574ee(this._4277568730, function () {
            this._UpdateLevelProgress()
        }.bind(this)), this._1658958566._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.prototype._CheckData = function () {
        jasmin._se7a49036f5cfea7f559beac9db86e9(this._4277568730, "[Level] Level Need A Valid Id!!!");
        var e = GetDataTransfer().GetTableRecord("level", this._4277568730);
        jasmin._se7a49036f5cfea7f559beac9db86e9(e, "[Level] Level Data Error, Id:" + this._4277568730);
        var t = ["Name", "BgId"];
        _.each(t, function (t) {
            jasmin._se7a49036f5cfea7f559beac9db86e9(e[t], "[Level] Level Data Error, Id:" + this._4277568730 + ", Key:" + t)
        }), this._3293062338 = e
    }, e.prototype._UpdateLevelName = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("level", this._3293062338.LevelId);
        this.img_Title.skin = e.NamePath
    }, e.prototype._UpdateLevelBg = function () {
        var e = this._3293062338.BgId, t = global.$Sys.GetTableService().GetTableRecord("stage_pos", e), a = t.BgPath;
        this.ui_Bg.skin = a
    }, e.prototype._GetStagePos = function (e, t) {
    }, e.prototype._UpdateLevelProgress = function () {
        for (var e = 1; e <= this._3940870005; e++) this._s319b2f4c262afe70f95d5dd9937b13(e)
    }, e.prototype._s319b2f4c262afe70f95d5dd9937b13 = function (e) {
        for (var t = GetDataTransfer().GetTableRecord("level", this._4277568730), a = t.BgId, o = GetDataTransfer().GetTableRecord("stage", this._4277568730, this._3940870005), r = o.IsBoss, i = GetDataTransfer().GetTableRecord("stage_pos", a), l = [""], s = 1; s <= 6; s++) l.push(i["Pos" + s]);
        var n = LevelProgressNode.Type.PASSED;
        e == this._3940870005 && (n = r ? LevelProgressNode.Type.BOSS : LevelProgressNode.Type.PLAYING);
        var u = LevelProgressNode._se052477c848947f7a453615b0d70c2({
            Type: n,
            OnClick: this.OnStartFight.bind(this, e),
            BossId: t.BossId
        });
        u.name = "node", this.sp_StageNodes.addChild(u), this._394089020.push(u), u.x = l[e][0], u.y = l[e][1]
    }, e.prototype._s0b579fe002d85a9b9811b0f9ba93f1 = function (e) {
        if (1 != global.$Api.QueryDataSource("DataLevel").GetValue("Progress")) return void e();
        var t = GetDataTransfer().GetTableRecord("stage", this._4277568730, this._3940870005);
        if (!t.DialogId) return void e();
        var a = GetDataTempInterface().GetValue("LevelStory");
        a || (a = {}, GetDataTempInterface()._sdbb730f79fe415639ea2aec361dfd2("LevelStory", a));
        var o = this._4277568730 + "_" + this._3940870005;
        if (a[o]) return void e();
        var r = GetDataTransfer().GetTableRecord("dialog_info", t.DialogId), i = _.values(r);
        i.sort(function (e, t) {
            return e.Id - t.Id
        }), GetGuiManager()._s2e22e694b9852084df200bc86f9340("SayDialog", {
            Record: i, onClose: function () {
                a[o] = !0, GetDataTempInterface()._sdbb730f79fe415639ea2aec361dfd2("LevelStory", a), e()
            }.bind(this)
        }, null, {isModal: !0, closeEffect: null, popupEffect: null})
    }, e.prototype.OnStartFight = function (e) {
        var t = GetDataTransfer().GetTableRecord("level", this._4277568730),
            a = (t.BgId, GetDataTransfer().GetTableRecord("stage", this._4277568730, this._3940870005));
        this._s0b579fe002d85a9b9811b0f9ba93f1(function () {
            var e = a.IsBoss;
            if (e) return void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FightBossView", {Type: GetBossViewFactory()._s41590f6e0d88a235ec1afb8e9b06ae("Level")});
            var t = this._sa75896fbed50d08e2752cd686fb937(), o = t[0], r = t[1], i = a.BgId;
            FightView._sabbe27d79486b625a06ed3d6ebdec5({
                AutoFight: !0,
                Bg: "res/ui/bg/level/stage/z_zhandou_bg" + i + ".png",
                Fighters: {MyData: o, EnemyData: r},
                OnCreateTitleNode: function () {
                    var e = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"),
                        t = global.$Api.QueryDataSource("DataLevel").GetValue("StageId"),
                        a = global.$Api.QueryDataSource("DataLevel").GetValue("Progress"),
                        o = global.$Sys.GetTableService().GetTableRecord("stage", e, t), r = new LevelFightTitleUI;
                    return r.lab_Name.text = t + "." + o.StageName, r.lab_Progress.text = a, r.lab_MaxProgress.text = "/" + o.Progress, r.box.changeItems(), r
                },
                OnStartFight: function (e, t) {
                    GetFightInterface()._s6868d455030400d9622b2d0e4db74c(function (t) {
                        var a = global.$Api.QueryDataSource("DataLevel").GetValue("Npc"), o = {
                            Success: t.Success,
                            Rewards: t.Rewards,
                            Fighters: {
                                MyData: {CurSoldier: global.$Api.QueryDataSource("DataBase").GetValue("Troops")},
                                EnemyData: {CurSoldier: t.Success ? 0 : a.SoldierCount}
                            }
                        };
                        e(o)
                    }.bind(this), function () {
                        t && t()
                    }.bind(this))
                }.bind(this),
                OnFightEnd: function (e, t) {
                    this._1658958566._s4fb507d6d0f40b2d2a72f6007a938d();
                    var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
                    GetFightInterface()._s360371f813388bc01c0779166acb18(a, function () {
                        this.OnFightProgressEnd(e, t)
                    }.bind(this), !0)
                }.bind(this)
            })
        }.bind(this))
    }, e.prototype._sa75896fbed50d08e2752cd686fb937 = function () {
        var e = global.$Api.QueryDataSource("DataBase").GetValue("Troops"),
            t = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            a = global.$Sys.GetTableService().GetTableRecord("office", t), o = {
                MaxSoldier: e,
                Force: ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(1),
                Name: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                Office: a.OfficeName,
                CurSoldier: e
            }, r = global.$Api.QueryDataSource("DataLevel").GetValue("Npc"),
            i = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"),
            l = global.$Api.QueryDataSource("DataLevel").GetValue("StageId"),
            s = global.$Sys.GetTableService().GetTableRecord("stage", i, l), n = s.Soldier,
            u = GetDataTransfer().GetTableRecord("npc", r.Id), g = {
                NpcId: r.Id,
                MaxSoldier: n,
                Force: r.ForceValue,
                Name: u.NpcName,
                Office: "",
                CurSoldier: r.SoldierCount
            };
        return [o, g]
    }, e.prototype.OnFightProgressEnd = function (e, t) {
        var a = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"),
            o = global.$Api.QueryDataSource("DataLevel").GetValue("StageId");
        if (1 == a && 1 == o && 2 == global.$Api.QueryDataSource("DataLevel").GetValue("Progress")) {
            var r = GetDataTransfer().GetTableRecord("guide_dialog", global.$Cfg.Common.PlotTwoStep);
            return r = _.values(r), r.sort(function (e, t) {
                return e.Id - t.Id
            }), void GetGuiManager()._s2e22e694b9852084df200bc86f9340("SayDialog", {
                Record: r, onClose: function () {
                    if (1 == global.$Api.QueryDataSource("DataLevel").GetValue("Progress")) this.OnGoNextStage(); else {
                        var e = this._sa75896fbed50d08e2752cd686fb937(), a = e[0], o = e[1];
                        t.OnUpdateFighters({MyData: a, EnemyData: o})
                    }
                    Leo.GetGuideSystem()._sd900aa372084b8f59701ad66c750cc()
                }.bind(this), OnBeforeClose: function (e) {
                    GetStorage()._s54216acbc0200500c827232db13a75("TempData", {Dialog2End: !0}), e && e()
                }
            }, null, {isModal: !1, closeEffect: null, popupEffect: null})
        }
        if (!e.Success) return t.OnShowFightBtn(), void LevelFailed._sabbe27d79486b625a06ed3d6ebdec5();
        if (this.mouseEnabled = !1, this.timerOnce(500, this, function () {
            this.mouseEnabled = !0
        }), 1 == global.$Api.QueryDataSource("DataLevel").GetValue("Progress")) this.OnGoNextStage(); else {
            var i = this._sa75896fbed50d08e2752cd686fb937(), l = i[0], s = i[1], n = {MyData: l, EnemyData: s};
            t.OnUpdateFighters(n)
        }
    }, e.prototype.OnReShow = function () {
        this._1658958566._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.prototype.OnGoNextStage = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightView"), this._4277568730 = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"), this._3940870005 = global.$Api.QueryDataSource("DataLevel").GetValue("StageId"), this._4284629566 = global.$Api.QueryDataSource("DataLevel").GetValue("Progress"), this.mouseEnabled = !1, _.last(this._394089020)._scbd425e99668a9892f455888df2804(function () {
            this._s319b2f4c262afe70f95d5dd9937b13(_.size(this._394089020) + 1), this.mouseEnabled = !0
        }.bind(this))
    }, e.prototype._UpdateLevelInfo = function () {
        this.ui_LevelTitle.text = this._3293062338.LevelId + "." + this._3293062338.Name, this.ui_LevelInfo.text = "     " + this._3293062338.BossInfo
    }
}();
var LevelDesc;
!function () {
    LevelDesc = function () {
        LevelDesc.super(this)
    }, Laya.class(LevelDesc, "LevelDesc", LevelDescUI), LevelDesc.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LevelDescUI.uiView, e)
    };
    var e = LevelDesc.prototype;
    e.OnShow = function (e) {
        this.m_OnClose = e.OnClose;
        var s = e.LevelId, t = global.$Sys.GetTableService().GetTableRecord("level", s);
        this.img_Name.skin = t.NamePath, this.lab_Desc.text = t.BossInfo, this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LevelDesc")
        }), this.mouseEnabled = !1, this.timerOnce(1e3, this, function () {
            this.mouseEnabled = !0
        })
    }, e.OnClose = function () {
        this.m_OnClose && this.m_OnClose(), this.m_OnClose = null
    }
}();
var LevelFailed;
!function () {
    LevelFailed = function () {
        LevelFailed.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LevelFailed"), this._713989164.OnClose && this._713989164.OnClose()
        }), this.btn_Go.on(Laya.Event.CLICK, this, this.OnGo)
    }, Laya.class(LevelFailed, "LevelFailed", LevelFailedUI), LevelFailed.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LevelFailedUI.uiView, e)
    }, LevelFailed._sabbe27d79486b625a06ed3d6ebdec5 = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("LevelFailed", e, null, {useMgrEffect: !1})
    };
    var e = LevelFailed.prototype;
    e.OnShow = function (e) {
        this._713989164 = e || {}, this.img_FailedNode.visible = !this._713989164.NoShowFailed, this._713989164.NoShowFailed || GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_fight_fail), this.img_Tips.visible = !this._713989164.NoShowTips
    }, e.OnGo = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LevelFailed"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightView"), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi", {View: 0})
    }
}();
var LevelProgressNode;
!function () {
    LevelProgressNode = function (s) {
        if (LevelProgressNode.super(this), this._713989164 = s, this._CheckData(), this.ui_PlayBg.visible = !this._s70b2978b1874a80106fc9129ee0f0f(), this.ui_PassBg.visible = this._s70b2978b1874a80106fc9129ee0f0f(), this.ui_PassTag.visible = this._s70b2978b1874a80106fc9129ee0f0f(), Laya.timer.once(1, this, function () {
            this._s70b2978b1874a80106fc9129ee0f0f() && this.ui_SwordAni.gotoAndStop(5)
        }), this.ui_SwordAni.autoPlay = this._s71f2838412b0e635f214e4749059d1(), this.ui_Head.visible = this._s348d39a0689c8190ec4c0f571df5fc(), this._s348d39a0689c8190ec4c0f571df5fc()) {
            var e = this._713989164.BossId, i = global.$Sys.GetTableService().GetTableRecord("npc", e);
            this.ui_Head.skin = i.HeadPath || "res/ui/artfont/z_word_shanzhai.png"
        } else this.ui_Head.skin = "";
        this.ui_BossTag.visible = this._s348d39a0689c8190ec4c0f571df5fc(), this.ui_SwordAni.visible = !this._s348d39a0689c8190ec4c0f571df5fc(), this._s70b2978b1874a80106fc9129ee0f0f() || this.on(Laya.Event.CLICK, this, this.OnClick)
    }, Laya.class(LevelProgressNode, "LevelProgressNode", LevelProgressNodeUI), LevelProgressNode.Type = {
        PASSED: 1,
        BOSS: 2,
        PLAYING: 3
    }, LevelProgressNode._se052477c848947f7a453615b0d70c2 = function (s) {
        return new LevelProgressNode(s)
    };
    var s = LevelProgressNode.prototype;
    s.OnClick = function () {
        this._713989164.OnClick()
    }, s._CheckData = function () {
        var s = this._713989164;
        jasmin._se7a49036f5cfea7f559beac9db86e9(s.Type === LevelProgressNode.Type.PASSED || s.Type === LevelProgressNode.Type.BOSS || s.Type === LevelProgressNode.Type.PLAYING, "[LevelProgressNode] Type Error!!!"), this._s348d39a0689c8190ec4c0f571df5fc() && jasmin._se7a49036f5cfea7f559beac9db86e9(jasmin._s8fc157faa910d1911d744e3a7cc831(this._713989164.BossId), "[LevelProgressNode] BossId Error!!!"), this._s70b2978b1874a80106fc9129ee0f0f() || jasmin._se7a49036f5cfea7f559beac9db86e9(jasmin._s712167db7f08127d6dec4aed0f9846(this._713989164.OnClick), "[LevelProgressNode] No Click Handler!!!")
    }, s._GetBossHeadPath = function (s) {
        return "res/role/head/" + s + ".png"
    }, s._scbd425e99668a9892f455888df2804 = function (s) {
        this.ui_PassBg.visible = !0, this.ui_PlayBg.visible = !1, this.ui_SwordAni.autoPlay = !1, this.ui_SwordAni.gotoAndStop(5), this.off(Laya.Event.CLICK, this, this.OnClick);
        var e = this.ui_PassTag;
        e.visible = !0, Laya.Tween.from(e, {scaleX: 2, scaleY: 2}, 300, null, Laya.Handler.create(null, function () {
            s & s()
        }))
    }, s._s71f2838412b0e635f214e4749059d1 = function () {
        return this._713989164.Type == LevelProgressNode.Type.PLAYING
    }, s._s348d39a0689c8190ec4c0f571df5fc = function () {
        return this._713989164.Type == LevelProgressNode.Type.BOSS
    }, s._s70b2978b1874a80106fc9129ee0f0f = function () {
        return this._713989164.Type == LevelProgressNode.Type.PASSED
    }
}();

function LevelRewardComponent() {
}

var _proto_ = LevelRewardComponent.prototype;
_proto_.Init = function (e, t) {
    t.Rewards.length < 4 && (e.ui_listRewardIcons.centerX = .5);
    var i, r = Math.ceil(t.Rewards.length / 4);
    0 == r ? i = 0 : (e.ui_listRewardIcons.repeatY = Math.min(2, r), i = e.ui_listRewardIcons.height);
    var o = t.PrestigeRewards, n = (e.img_Bg.height, 130 + i);
    return o || (n -= 40), e.img_Bg.height = n, e.img_Bg.centerY = .5, o ? (e.hbox.visible = !0, e.lab_Prestige.text = "+" + o[2], e.lab_Prestige2.text = "+" + o[2], e.hbox.changeItems(), void(e.hbox.centerX = .5)) : void(e.hbox.visible = !1)
};
var LimitActivityDetail;
!function () {
    LimitActivityDetail = function () {
        LimitActivityDetail.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_reward.renderHandler = Laya.Handler.create(this, this.OnCreateActivity, null, !1), this.list_reward.vScrollBarSkin = null
    }, Laya.class(LimitActivityDetail, "LimitActivityDetail", LimitActivityDetailUI), LimitActivityDetail.MAX_COUNT = 4;
    var a = LimitActivityDetail.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a;
        var t = this._4122736007.SType;
        this._124281148 = a.GroupName, this._s4fb507d6d0f40b2d2a72f6007a938d(), this.img_title.skin = this._4122736007.IconSkin;
        var i = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("activity_rank", "Limit", t);
        this.btn_rank.visible = !!i, this.btn_rank.offAll(Laya.Event.CLICK), this.btn_rank.on(Laya.Event.CLICK, this, this.OnBtnRankClick, [i]);
        var e = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(this._124281148), r = 0;
        for (var l in e) {
            var n = global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(this._124281148, e[l], 1);
            if (!n) {
                r = l;
                break
            }
        }
        this.list_reward.scrollTo(r)
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(this._124281148);
        _.sortBy(a, function (a) {
            return parseInt(a)
        }), this.list_reward.array = a
    }, a.OnCreateActivity = function (a, t) {
        var i = a.getChildByName("hBox_target"), e = i.getChildByName("lab_targetName"),
            r = i.getChildByName("lab_target"), l = a.getChildByName("btn_get"), n = a.getChildByName("lab_title"),
            s = a.getChildByName("hBox_reward"), o = a.getChildByName("img_finish");
        s.destroyChildren();
        var m = this.list_reward.array[t], c = this._124281148, h = m, d = 1,
            y = global.$Sys.GetTableService().GetTableRecord("activity_limit", this._124281148).TableName,
            C = global.$Sys.GetTableService().GetTableRecord(y, h, d), u = C.Target[0],
            v = GameCommon._sc2670617ff77eb1396f5b63c0edc88(u[0], u[1], {TaskType: c});
        r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%s / %s", GameCommon._s5c693d8122a877499a10f605a128a3(v, 2), GameCommon._s5c693d8122a877499a10f605a128a3(u[2], 2)), r.color = v < u[2] ? "#aa2424" : "#2a8d2a", n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("第%d档", h), e.text = C.TaskName + "：";
        var g = global.$Sys.GetTableService().GetTableRecord("reward", C.Reward), b = 0;
        for (_.each(g.Award, function (a) {
            var t = GameCommon._se35db439c4ad2364b987453544666d(a, !1, !0, a[2], {UseEff: !0});
            s.addChild(t), t.scaleX = .9, t.scaleY = .9, b++
        }); b < LimitActivityDetail.MAX_COUNT;) {
            var f = new Laya.Image("res/ui/bg/z_bg_30.png");
            f.width = 105, f.height = 105, s.addChild(f), b++
        }
        s.refresh(), i.refresh();
        var D = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(c, h, d),
            G = global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(c, h, d);
        o.visible = !1, l.visible = !1, l.disabled = !0, l.offAll(Laya.Event.CLICK), G ? o.visible = !0 : (l.visible = !0, D && (l.disabled = !1, l.on(Laya.Event.CLICK, this, this.OnGetReward, [c, h, d, o])));
        var o = a.getChildByName("img_finish")
    }, a.OnGetReward = function (a, t, i, e) {
        var r = this, l = {
            Group: a, ChainId: t, TaskId: i, Callback: function (a) {
                a.Result && (r.mouseEnabled = !1, e.visible = !0, e.scaleX = 2, e.scaleY = 2, Laya.Tween.to(e, {
                    scaleX: 1,
                    scaleY: 1
                }, 300, null, Laya.Handler.create(this, function () {
                    r._s4fb507d6d0f40b2d2a72f6007a938d(), r.mouseEnabled = !0
                })), GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item))
            }
        };
        GetDataTaskInterface().DoTask(l)
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LimitActivityDetail")
    }, a.OnClose = function () {
        this._4122736007.OnClose && this._4122736007.OnClose(), _.each(this.list_reward.cells, function (a) {
            var t = a.getChildByName("hBox_reward");
            t.destroyChildren()
        }), this.list_reward.array = [], this.list_reward.scrollTo(0)
    }, a.OnBtnRankClick = function (a) {
        var t = {};
        t.TableName = a.RankName, GetCmdProxy().DoCmd("GetRank", t, function (a) {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("ActivityRankDialog", a)
        })
    }, LimitActivityDetail.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LimitActivityDetail.uiView, a)
    }
}();
var LimitActivityPage;
!function () {
    LimitActivityPage = function () {
        LimitActivityPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_activity.renderHandler = Laya.Handler.create(this, this.OnCreateActivity, null, !1), this.list_activity.vScrollBarSkin = null, this._3337510074 = []
    }, Laya.class(LimitActivityPage, "LimitActivityPage", LimitActivityPageUI);
    var t = LimitActivityPage.prototype;
    t.OnShow = function (t) {
        this._4122736007 = t || {}, this._s4fb507d6d0f40b2d2a72f6007a938d(), this._sa4a95e1ae2426793b0a8777fced7fe(), this.OnTimerLoop(), this.list_activity.scrollTo(0)
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var t = GetActivityManager()._sf6027486c9ce1855a4057ea0b9a5f8("Limit", ActivityBase.STATUS.Start);
        if (jasmin._s2dedbd0e220887101c856bf900fc57(t)) return void jasmin.Error("Limit Activity Not Open!");
        var i = [];
        for (var e in t) for (var a = t[e], n = GetActivityManager()._s2530ec62a690afe1794dbbf94f21a1(a, ActivityBase.STATUS.Stop), s = GetActivityManager()._s2530ec62a690afe1794dbbf94f21a1(a, ActivityBase.STATUS.Start), r = GetActivityManager()._sde9f114875db61d769f11ca1b7d1fa(a), o = 0; o < r.length; o++) i.push({
            eTime: n,
            sTime: s,
            stype: r[o].SType,
            rewardTable: r[o].RewardTable,
            Guid: a
        });
        this.list_activity.array = i
    }, t.OnCreateActivity = function (t, i) {
        var e = t.getChildByName("img_title"), a = t.getChildByName("btn_start"), n = t.getChildByName("lab_date"),
            s = t.getChildByName("lab_time"), r = t.getChildByName("lab_eDate"), o = this.list_activity.array[i],
            l = o.stype, m = o.sTime, c = o.eTime, h = o.rewardTable;
        h || (h = global.$Sys.GetTableService().GetTableRecord("activity", "Limit", l).GroupName);
        var v = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(h),
            y = global.$Api.QueryDataSource("DataTask")._sa69b1309e5cfc70cc602f9d2816295(h, v[0]),
            u = Math.min(y.Progress, y.LastTaskId),
            T = global.$Sys.GetTableService().GetTableRecord(global.$Cfg.Common.ActivityCfg.Limit.TaskTable, h).TableName,
            L = global.$Sys.GetTableService().GetTableRecord(T, v[0], u);
        e.skin = L.IconName, a.off(Laya.Event.CLICK), a.on(Laya.Event.CLICK, this, this.OnShowDetail, [h, l, L.IconName]);
        var f = jasmin._sf60b29247c48694418b19d6d5ef097("MM月dd日hh:mm", new Date(m)),
            g = jasmin._sf60b29247c48694418b19d6d5ef097("MM月dd日hh:mm", new Date(c));
        if (n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("开始时间：%s", f), r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("结束时间：%s", g), IsDebug()) {
            t._DebugLabel && (t._DebugLabel.destroy(), t._DebugLabel = null);
            var C = new Laya.Label;
            C.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("GUID: %s \nTGroup: %s ", o.Guid, h), C.color = "#ffff50", C.fontSize = 20, C.x = 20, C.y = 5, t._DebugLabel = C, t.addChild(C)
        }
        var d = "UpdateTime" + i;
        this.offAll(d), this.on(d, this, function () {
            var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), i = c - t;
            s.text = i > 0 ? GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(i) : gLanguage.TimeOver
        }), this.event(d), this._3337510074.indexOf(d) == -1 && this._3337510074.push(d), Leo.GetNodeAdditionalManager().OnShowRedPoint(a, TargetCheck._CheckCanFinishTask(h))
    }, t.OnShowDetail = function (t, i, e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("LimitActivityDetail", {
            GroupName: t,
            SType: i,
            IconSkin: e,
            OnClose: function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)
        })
    }, t.OnBtnCloseClick = function () {
        return this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Fudi")
    }, t._s6f2b2aada0f026093af57dc5976169 = function (t) {
        for (var i in t) if (!t[i].Finish) return i;
        return _.last(_.keys(t))
    }, t._sa4a95e1ae2426793b0a8777fced7fe = function () {
        this.timerLoop(1e3, this, this.OnTimerLoop)
    }, t._sba8dccb7f9520b22fcad20277b05d9 = function () {
        this.clearTimer(this, this.OnTimerLoop)
    }, t.OnTimerLoop = function () {
        for (var t in this._3337510074) this.event(this._3337510074[t])
    }, t.OnClose = function () {
        this._sba8dccb7f9520b22fcad20277b05d9();
        for (var t in this._3337510074) this.offAll(this._3337510074[t])
    }, LimitActivityPage.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LimitActivityPage.uiView, t)
    }
}();

function LivenessReward() {
    LivenessReward.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnClose), this._1512865556 = this.height, this.list_reward.renderHandler = Laya.Handler.create(this, this.OnCreateReward, null, !1)
}

Laya.class(LivenessReward, "LivenessReward", LivenessRewardUI);
var _proto_ = LivenessReward.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetDataTransfer().GetTableRecord("task_live", this._4122736007.ChainId, this._4122736007.TaskId),
        t = GetDataTransfer().GetTableRecord("reward", e.Reward).Award;
    this.lab_target.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.LiveTarget, e.Target[0][2]);
    for (var a = this.list_reward.repeatX, r = jasmin._sdf8385ff3a74421ea218e043d47fdc(t), s = r.length % a; s % a != 0; s++) r.push(null);
    this.list_reward.repeatY = r.length / a, this.height = this._1512865556 + 123 * this.list_reward.repeatY, this.centerY = -20, this.list_reward.array = r
}, _proto_.OnCreateReward = function (e, t) {
    var a = this.list_reward.array[t];
    if (this._s8d5e5fe6004372f8cdf8b604ad1a61(e), a) {
        var r = (GameCommon._s3c28725f2d273f38327479132c6eba(a[0], a[1]).ItemId, GameCommon._s66eb52e60b9feb53711943e638c9c3(a[0], a[1]));
        r.centerX = 0, r.centerY = 0, e.addChild(r), e.RewardIcon = r
    }
}, _proto_._s8d5e5fe6004372f8cdf8b604ad1a61 = function (e) {
    e.RewardIcon && (e.RewardIcon.removeSelf(), e.RewardIcon.destroy(), e.RewardIcon = null)
}, _proto_.OnBtnClose = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LivenessReward")
}, _proto_.OnClose = function () {
    _.each(this.list_reward.cells, function (e) {
        this._s8d5e5fe6004372f8cdf8b604ad1a61(e)
    }.bind(this))
}, LivenessReward.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LivenessReward.uiView, e)
};
var LoadResView;
!function () {
    LoadResView = function () {
        LoadResView.super(this), this.ui_ProgressBar.value = 0
    }, Laya.class(LoadResView, "LoadResView", LoadResUI), LoadResView.GetPreLoadResList = function (e) {
        var a = GetSkinRes();
        e.push(a.LoadViewBg), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LoadResUI.uiView, e)
    };
    var e = LoadResView.prototype;
    e.OnShow = function (e) {
        var a = GetSkinRes();
        this.img_LoadBg.skin = a.LoadViewBg, this.ui_ProgressBar.value = 0;
        var s = e.Res, i = e.OnLoadComplete;
        if (0 == s.length) return void(i && i());
        this._2119973035 = !1;
        Laya.loader.load(s, Laya.Handler.create(this, function () {
            Laya.stage.timerOnce(300, null, function () {
                i && i()
            })
        }), Laya.Handler.create(this, function (e) {
            this.ui_ProgressBar._s03b3ea1d07f1b02b802bba0e62e378(e, 1), this.ui_ProgressLabel.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.LoadResInfo, parseInt(100 * e))
        }, null, !1));
        var o = global.$Cfg.Language,
            t = jasmin._se91cf955e91eaa1aa510d4335edd4a(o.LoginMarkedWordsFormat, _.sample(o.LoginMarkedWords));
        this.lab_Tips.text = t
    }
}();

function LuckUpDialog() {
    LuckUpDialog.super(this), this.list_luckUp.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1), this.list_luck.renderHandler = Laya.Handler.create(this, this.OnCreateLuckIcon, null, !1), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, {ShowType: ["Money", "Food", "Gold"]}), this.scroll_auto.changeHandler = Laya.Handler.create(this, this.OnChangeLuck, null, !1);
    var t = global.$Api.QueryDataSource("DataSearch")._s837696e6c60842cd34bbaeadab476f();
    this.scroll_auto.value = t.Luck, this.btn_useMoney.selected = t.UseMoney, this.btn_useFood.selected = t.UseFood
}

Laya.class(LuckUpDialog, "LuckUpDialog", LuckUpDialogUI);
var _proto_ = LuckUpDialog.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t || {}, this._s4fb507d6d0f40b2d2a72f6007a938d(), this._2404717962 = 0, Laya.timer.loop(100, this, this.OnRotationImg)
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d();
    for (var t = global.$Api.QueryDataSource("DataSearch")._s76981ce7b348e018daaefe5a92c2f9(), e = parseInt((t + 9) / 10), a = jasmin._sc0e3cc5b6d5d591d0c26bfbd7189c4(e, !0), o = e; o < 10; o++) a.push(!1);
    this.list_luck.array = a, this.lab_luck.text = t, this.list_luckUp.array = global.$Cfg.Common.LuckUpConsume;
    var n = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv,
        i = global.$Sys.GetTableService().GetTableRecord("vip", n).FreeChangeLuck;
    this.lab_freeUp.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.LuckFreeUpInfo, n, i)
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LuckUpDialog")
}, _proto_.OnRotationImg = function () {
    this._2404717962 > 360 && (this._2404717962 = this._2404717962 % 360), this.img_bagua.rotation = this._2404717962, this._2404717962++
}, _proto_.OnClose = function () {
    var t = global.$Api.QueryDataSource("DataSearch")._s837696e6c60842cd34bbaeadab476f();
    this.scroll_auto.value == t.Luck && this.btn_useMoney.selected == t.UseMoney && this.btn_useFood.selected == t.UseFood || GetDataSearchInterface().DoSetAutoInfo({
        Luck: this.scroll_auto.value,
        UseMoney: this.btn_useMoney.selected,
        UseFood: this.btn_useFood.selected
    }), _.each(this.list_luckUp.cells, function (t) {
        var e = t.getChildByName("img_icon");
        this._s92a26e04090def6b8e27a0033ebac9(e)
    }.bind(this)), this._4122736007.Callback && this._4122736007.Callback(), Laya.timer.clearAll(this)
}, _proto_.OnChangeLuck = function (t) {
    this.lab_autoLuck.text = t, this.bar_auto.value = t / global.$Cfg.Common.AutoRecoverLimit
}, _proto_.OnCreateBox = function (t, e) {
    var a = t.getChildByName("btn_luckUp"), o = t.getChildByName("lab_type"), n = t.getChildByName("lab_consume"),
        i = t.getChildByName("lab_result"), l = t.getChildByName("lab_resultCnt"),
        r = t.getChildByName("lab_consumeCnt"), s = t.getChildByName("img_icon"), c = gLanguage.UpLuck[e];
    o.text = c[0], n.text = c[1], i.text = c[2], a.label = c[3], r.text = global.$Api.Formula.OnGetLuckUpConsume(e + 1, global.$Api.QueryDataSource("DataSearch")._sd218e32facebdd5b8d92babdbb19aa()), l.text = gLanguage.UpLuckResult + global.$Api.Formula._s899ec0a0d142a6baefce533957db16(e + 1), 2 == e && global.$Api.GetDataSearchProxy()._sc12317c51bc8f4c96f1a1a9ac1336b() && (r.text = "0"), a.offAll(Laya.Event.CLICK), a.on(Laya.Event.CLICK, this, this.OnBtnLuckUpClick, [e + 1]);
    var u = this.list_luckUp.array[e], h = GetDataTransfer().GetTableRecord("consume", u).Consume[0],
        m = GameCommon._s66eb52e60b9feb53711943e638c9c3(h[0], h[1]);
    this._s92a26e04090def6b8e27a0033ebac9(s), s.addChild(m), s.ItemIcon = m
}, _proto_._s92a26e04090def6b8e27a0033ebac9 = function (t) {
    t.ItemIcon && (t.ItemIcon.removeSelf(), t.ItemIcon.destroy(), t.ItemIcon = null)
}, _proto_.OnCreateLuckIcon = function (t, e) {
    var a = t.getChildByName("img_icon");
    a.visible = this.list_luck.array[e]
}, _proto_.OnBtnLuckUpClick = function (t) {
    var e = {
        Type: t, Callback: function () {
            GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: [gLanguage.LuckUpInfo[t - 1]],
                Colors: ["#ffffff"]
            }), this._s4fb507d6d0f40b2d2a72f6007a938d()
        }.bind(this)
    };
    if (3 != t || global.$Api.GetDataSearchProxy()._sc12317c51bc8f4c96f1a1a9ac1336b()) GetDataSearchInterface().DoLuckUp(e); else {
        var a = global.$Api.Formula.OnGetLuckUpConsume(3, global.$Api.QueryDataSource("DataSearch")._sd218e32facebdd5b8d92babdbb19aa());
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeInfo: [1, 1e3, a],
            Purpose: gLanguage.UpLuck[2][3],
            OnConfirmUse: function () {
                GetDataSearchInterface().DoLuckUp(e)
            }
        })
    }
}, LuckUpDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LuckUpDialog.uiView, t)
};
var LuckWives;
!function () {
    LuckWives = function () {
        LuckWives.super(this);
        var e = laya.events.Event;
        this.btn_Close.on(e.CLICK, this, this.OnCloseBtn), this.btn_Help.on(e.CLICK, this, this.OnHelpBtn), this.TalkBtn.on(e.CLICK, this, this.OnTalkBtn), this.LuckBtn.on(e.CLICK, this, this.OnLuckBtn), this.RewardBtn.on(e.CLICK, this, this.OnRewardBtn), this.SkillBtn.on(e.CLICK, this, this.OnSkillBtn), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.RewardBtn,
            NodeName: "BeautyPresent",
            OnCheckState: TargetCheck.OnCheckBeautyPresent,
            cover: !0
        });
        var t = new Leo.ImageActionManager({Image: this.BeautyImg});
        t._sc95f42251335b3aa0013090797aec9("Breather", {
            BreatherTime: 4e3,
            ScaleX: 1.01,
            ScaleY: 1.01
        }), this._2141739096 = t
    }, Laya.class(LuckWives, "LuckWives", LuckWivesViewUI), LuckWives.GetPreLoadResList = function (e, t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(LuckWivesViewUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyDoSexUI.uiView, e);
        var i = t.HeroId, a = global.$Sys.GetTableService().GetTableRecord("beauty", i);
        e.push(a.Body1Path), e.push(a.Body2Path), e.push(a.NamePath)
    };
    var e = LuckWives.prototype;
    e.OnShow = function (e) {
        if (this._2029868072 && (this._2029868072.destroy(), this._2029868072 = null), this._637678316 && (this._637678316.destroy(), this._637678316 = null), e.HeroId) {
            this._3078968613 = e.HeroId;
            var t = global.$Sys.GetTableService().GetTableRecord("beauty", this._3078968613), i = t.BeautyVoice;
            i && (this._3622136963 = i, GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(i)), this._sc9209ae0dd3fdb06533b36ec4474b1(), this._2407471436 = .1, this.img_LzRight.scaleX = .1, this.img_LzLeft.scaleX = .1, Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
                Node: this.SkillBtn,
                NodeName: "BeautySkill",
                OnCheckState: TargetCheck.OnCheckBeautyAllSkills.bind(this, e.HeroId),
                cover: !0
            })
        }
    }, e._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        this.LoveValue.text = this._sb7bc9b2ecf41aa7be8725a2816cc6c(this._3078968613), this.ChildsValue.text = this._s1cfb0644dcecea404da34deed5909a(this._3078968613), this.CharmValue.text = this._s4ac8a09c401fdbf35805b5cc2913ea(this._3078968613), this.BeautyExp.text = this._s6aabe38e259ab6ece0071872d3073e(this._3078968613), this.BeautyDescribe.text = this._s2fe1f3b9dc212dd451b23edc28a7a8(this._3078968613);
        var e = GetBeautyInterface()._saa111dd0622703d1401ac6be9d1f2d(this._3078968613);
        this.TalkLabel.text = e;
        var t = global.$Sys.GetTableService().GetTableRecord("beauty", this._3078968613);
        this.BeautyImg.destroyChildren();
        GameCommon._s2d5a2f578e0d4afe089454eb2d923d(this.BeautyImg, this._3078968613), this._2141739096._s2e4033b88e999ce7271844dbf3b2dc(), this.ui_Name.skin = t.NamePath
    }, e.OnTalkBtn = function () {
        var e = this._s10610192b3c32de7dc1dd0507a5bc3(this._3078968613);
        this.TalkLabel.text = e
    }, e.OnLuckBtn = function () {
        var e = [];
        e.push(function (e) {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
                ConsumeId: global.$Cfg.Common.Beauty.DoLoveCostConsume,
                UserData: {BeautyId: this._3078968613},
                Purpose: gLanguage.DoSexFont,
                OnConfirmUse: function (t) {
                    e()
                }.bind(this)
            })
        }.bind(this)), e.push(function (e) {
            this._2141739096._s54107fed721f2f5f6636c3b2747bef();
            var t = global.$Cfg.Common.Beauty.DoLoveCostConsume,
                i = GetAssetManager()._s3fe93204207ebad2b8c617add33b0a(t, {BeautyId: this._3078968613});
            return i.Result ? void GetBeautyInterface().DoSex(this._3078968613, function (e) {
                e.Result && this._s63c836220fc5e6d40bede2cfdf2b85(this._3078968613, e, function () {
                    e.ChildId && GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChildBirthView", {ChildId: e.ChildId}), this._sc9209ae0dd3fdb06533b36ec4474b1()
                }.bind(this))
            }.bind(this)) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(i)
        }.bind(this)), async.waterfall(e, function (e, t) {
        })
    }, e._s63c836220fc5e6d40bede2cfdf2b85 = function (e, t, i) {
        this.mouseEnabled = !1;
        var a = this.img_LzLeft, n = this.img_LzRight, o = 400, s = 400, u = 300;
        Laya.Tween.to(n, {scaleX: 1}, o, null, Laya.Handler.create(this, function () {
            this.timerOnce(u, this, function () {
                Laya.Tween.to(n, {scaleX: this._2407471436}, s)
            })
        })), Laya.Tween.to(a, {scaleX: 1}, o, null, Laya.Handler.create(this, function () {
            this.mouseEnabled = !0, this._637678316 = new BeautyDoSexView(e, t, function () {
                i(), this._637678316.destroy(), this._637678316 = null
            }.bind(this), function () {
                this._2029868072.destroy(), this._2029868072 = null
            }.bind(this)), this.sp_XX.addChild(this._637678316), Laya.loader.load("particle/Yezi.part", Laya.Handler.create(this, function (e) {
                var t = new Laya.Particle2D(e);
                t.emitter.start(), t.play(), t.zOrder = 100, this.sp_Yezi.addChild(t), this._2029868072 = t
            }), null, Laya.Loader.JSON), this.timerOnce(u, this, function () {
                Laya.Tween.to(a, {scaleX: this._2407471436}, s, null, Laya.Handler.create(this, function () {
                    this._637678316 && this._637678316._s2e4033b88e999ce7271844dbf3b2dc()
                }))
            })
        }))
    }, e.OnRewardBtn = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("BeautyUseItemDialog", {
            HeroId: this._3078968613,
            LuckWives: this
        })
    }, e.OnSkillBtn = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("BeautySkill", {HeroId: this._3078968613, LuckWives: this})
    }, e.OnClose = function () {
        this._637678316 && this._637678316._sa5976496a6d2dcc1c9da65c8c2101d(), this._2141739096 && this._2141739096._s54107fed721f2f5f6636c3b2747bef(), this.BeautyImg.skin = "", this._3622136963 && GetAudioHelper()._sbebf31910b4e9f79e270fea2f864b7(this._3622136963), this._3622136963 = null
    }, e.OnCloseBtn = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BeautyView")
    }, e.OnHelpBtn = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Beauty"})
    }, e._s5de1ac61fc2c399ed3f4b95a3159f2 = function (e) {
        return GetDataTransfer().GetTableRecord("beauty", e).Name
    }, e._sb7bc9b2ecf41aa7be8725a2816cc6c = function (e) {
        return global.$Api.QueryDataSource("DataBeauty")._s29dca583b451db00109629e3fc4bcd(e).LoveValue
    }, e._s4ac8a09c401fdbf35805b5cc2913ea = function (e) {
        return global.$Api.QueryDataSource("DataBeauty")._s29dca583b451db00109629e3fc4bcd(e).Charm
    }, e._s1cfb0644dcecea404da34deed5909a = function (e) {
        return global.$Api.QueryDataSource("DataBeauty")._s08ba6a1ba12968cac41a4297977513(e).ChildCount || 0
    }, e._sae4873517c9df26bdecfa1d8dda3ef = function (e) {
        var t = [];
        for (var i in e) t.push(i);
        return t
    }, e._s6aabe38e259ab6ece0071872d3073e = function (e) {
        return global.$Api.QueryDataSource("DataBeauty")._s29dca583b451db00109629e3fc4bcd(e).Exp
    }, e._s10610192b3c32de7dc1dd0507a5bc3 = function (e) {
        var t = GetDataTransfer().GetTableRecord("beauty_dialog", e).Dialog, i = parseInt(t.length * Math.random());
        return t[i]
    }, e._s2fe1f3b9dc212dd451b23edc28a7a8 = function (e) {
        return GetDataTransfer().GetTableRecord("beauty", e).Desc
    }
}();

function MailDialog() {
    MailDialog.super(this), this.OnInitMail()
}

Laya.class(MailDialog, "MailDialog", Laya.Dialog);
var _proto_ = MailDialog.prototype;
_proto_.OnShow = function (t) {
    this._sd0f85cb651dc0a59c9004a19307780()
}, _proto_._sd0f85cb651dc0a59c9004a19307780 = function () {
    this.List = [];
    var t = this;
    async.waterfall([function (i) {
        GetCmdProxy().DoCmd("GetMails", {MailType: "Gm"}, function (a) {
            jasmin._s3c96e1f3bee730222501b208d50190(t.List, t._s0b83ff453c998689adb242c402f1c6(a.MailsList, "Gm")), i()
        })
    }, function (i) {
        GetCmdProxy().DoCmd("GetMails", {MailType: "GmEx"}, function (a) {
            jasmin._s3c96e1f3bee730222501b208d50190(t.List, t._s0b83ff453c998689adb242c402f1c6(a.MailsList, "GmEx")), i()
        })
    }, function (i) {
        GetCmdProxy().DoCmd("GetMails", {MailType: "Sys"}, function (a) {
            jasmin._s3c96e1f3bee730222501b208d50190(t.List, t._s0b83ff453c998689adb242c402f1c6(a.MailsList, "Sys")), i()
        })
    }, function (i) {
        GetCmdProxy().DoCmd("GetMails", {MailType: "User"}, function (a) {
            jasmin._s3c96e1f3bee730222501b208d50190(t.List, t._s0b83ff453c998689adb242c402f1c6(a.MailsList, "User")), i()
        })
    }], function (i, a) {
        t.List = _.sortBy(t.List, function (t) {
            return -t.Time
        }), t._1671626501._s4c0b65570515e784236b4134a988a7(t.List), t._1671626501.imgMailBg.visible = jasmin._s2dedbd0e220887101c856bf900fc57(t.List)
    })
}, _proto_.OnInitMail = function () {
    this._1671626501 || (this._1671626501 = new MailList_J), this._1671626501.listMail.array = [], this._1671626501.ui_btnClose.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._1671626501._s220cf0da3a62ff1a28fc54cf8fa057({
        OnClickItem: function (t) {
            var i = {
                ShowTitle: !0, MailData: t, UseListLimit: 4, OnCreateRewardIcons: function (t) {
                    var i = [];
                    return _.each(t, function (t) {
                        if (t[0] != global.$Cfg.CommonEnum.Asset.DataBase || t[1] != global.$Cfg.CommonEnum.DataBase.VipScore) {
                            var a;
                            a = t[0] == global.$Cfg.CommonEnum.Asset.DataHero ? GetItemIconFactory()._sb28617dc58b536a74dd40075815048(t[2]) : t[0] == global.$Cfg.CommonEnum.Asset.DataBeauty ? GetItemIconFactory()._scfdefbc3baca8253b4795d35148e52(t[2]) : GameCommon._s66eb52e60b9feb53711943e638c9c3(t[0], t[1], !1, !0, t[2]), i.push(a)
                        }
                    }), i
                }, OnCallbackGet: function (t) {
                    GetCmdProxy().DoCmd("GetMailsRewards", {MailType: t.Type, guid: t.Guid}, function (t) {
                        this._sd0f85cb651dc0a59c9004a19307780(), GetDataBaseInterface().event("RefreshFortune"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MailContentDiv_J");
                        var i = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
                        if (GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, i), t.Rewards.DataBeauty) {
                            var a = [];
                            for (var e in t.Rewards.DataBeauty) {
                                var n = t.Rewards.DataBeauty[e][2];
                                a.push(function (t, i) {
                                    t ? GetGuiManager()._s2e22e694b9852084df200bc86f9340("RewardBeautyView", {
                                        BeautyId: t,
                                        OnClose: i
                                    }) : i()
                                }.bind(null, n))
                            }
                            async.waterfall(a)
                        }
                    }.bind(this))
                }.bind(this)
            };
            i.ShowButton = !!t.AttachMents, GetGuiManager()._s2e22e694b9852084df200bc86f9340("MailContentDiv_J", i)
        }.bind(this)
    }), this.addChild(this._1671626501)
}, _proto_._s0b83ff453c998689adb242c402f1c6 = function (t, i) {
    for (var a = [], e = 0; e < t.length; e++) {
        var n = {};
        n.Type = i, n.Title = t[e].Title, n.Time = t[e].Timestamp / 1e3, n.Content = t[e].Content, n.SenderName = t[e].Writer || gLanguage.Gm, n.Guid = t[e].Eid, n.Report = t[e].Report, t[e].Rewards ? (n.AttachMents = {}, n.AttachMents.Reward = t[e].Rewards) : n.AttachMents = null, a.push(n)
    }
    return a
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MailDialog")
}, MailDialog.OnPreLoadRes = function (t) {
    var i = GetGuiManager()._scb7af5c43b4d5de44be6273375bc19("MailContentDiv_J"),
        a = GetGuiManager()._scb7af5c43b4d5de44be6273375bc19("MailList_J");
    jasmin._s3c96e1f3bee730222501b208d50190(t, i), jasmin._s3c96e1f3bee730222501b208d50190(t, a)
};
var MainCity = function () {
    function t() {
        t.super(this), this._Init()
    }

    return Laya.class(t, "MainCity", MainCityUI), t.OnPreLoadRes = function (t) {
        for (var e = 0; e < global.$Cfg.Common.CloudPath.length; e++) t.push(global.$Cfg.Common.CloudPath[e]);
        _.each(GetDataBaseInterface()._s890c56d6eca7b89fa2db74b563f432(), function (e) {
            t.push(e)
        }), t.push("res/ui/common/z_image_13.png"), jasmin._s3c96e1f3bee730222501b208d50190(t, GameCommon._s44605232c95cb24f373304cee8baf4()), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BottomMenuUI.uiView, t), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TitleUI.uiView, t), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TopInfoUI.uiView, t), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainCityUI.uiView, t)
    }, t.prototype._Init = function () {
        this._609883226 = BottomMenuController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_BottomMenu, {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
            }
        });
        var t = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
            },
            ShowType: ["Money", "Food", "Troops", "Gold", "TotalProp", "Office", "HeadIcon", "Recharge", "Name"],
            Custom: {}
        };
        this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_TopInfo, t), this._3399175475._s368acb2686a0a07ac871d80150549a("OfficeUpInCity"), this.btn_FuDi.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["FuDi", this.btn_FuDi]), this.btn_Level.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["Level", this.btn_Level]), GetInspection() ? (_.each(this.btn_XunFang._childs, function (t) {
            t.visible = !1
        }), _.each(this.btn_LaoFang._childs, function (t) {
            t.visible = !1
        })) : (this.btn_XunFang.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["SiFang", this.btn_XunFang]), this.btn_LaoFang.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["LaoFang", this.btn_LaoFang])), this.btn_JiuGuan.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["YanHui", this.btn_JiuGuan]), this.btn_Yamen.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["YaMen", this.btn_Yamen]), this.btn_HanLin.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["HanLin", this.btn_HanLin]), this.btn_Fuben.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["FuBen", this.btn_Fuben]), this.btn_HuangGong.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["HuangGong", this.btn_HuangGong]), this.btn_TaoFa.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["TaoFa", this.btn_TaoFa]), this.btn_TongShang.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["TongShang", this.btn_TongShang]), this.btn_LianMeng.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["LianMeng", this.btn_LianMeng]), this.btn_PaiHang.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["PaiHang", this.btn_PaiHang]), this.btn_Cabinet.on(Laya.Event.CLICK, this, this.OnClickMainCityBtn, ["Cabinet", this.btn_Cabinet]), this._3517793858 = new Leo.ImageActionManager({Image: this.img_ReturnFudiFont}), this._3517793858._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: .9,
            ScaleY: .9,
            BreatherTime: 2e3
        }), this.btn_ReturnFudi.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.btn_Mail.on(Laya.Event.CLICK, this, function () {
            return IsOffLine() && !IsDebug() ? void this._s8c41798655529460830ad9c2a1335d() : void GetGuiManager()._s2e22e694b9852084df200bc86f9340("MailDialog")
        }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.btn_Mail,
            NodeName: "Mail",
            OnCheckState: TargetCheck.OnCheckMail,
            cover: !0
        }), this.btn_Setting.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("SetView")
        }), Laya.timer.callLater(this, function () {
            this.panel.scrollTo(233, 0)
        }), this.panel._hScrollBar.on("change", this, function () {
            var t = this.panel._hScrollBar.value;
            this.img_LeftArrow.visible = t > 0, this.img_RightArrow.visible = t < 1600
        }), this._s1f0019efdf9b2f53bcf3f009660ace()
    }, t.prototype._s1f0019efdf9b2f53bcf3f009660ace = function () {
        var t = global.$Cfg.Common.ModuleOpen;
        this.btn_XunFang._ModuleOpenId = t.SiFang, this.btn_LaoFang._ModuleOpenId = t.Prision, this.btn_JiuGuan._ModuleOpenId = t.YanHui, this.btn_Yamen._ModuleOpenId = t.YaMen, this.btn_HanLin._ModuleOpenId = t.HanLin, this.btn_TaoFa._ModuleOpenId = t.ZhengTao, this.btn_TongShang._ModuleOpenId = t.SiChou, this.btn_LianMeng._ModuleOpenId = t.Guild, this.btn_Cabinet._ModuleOpenId = t.Cabinet
    }, t.prototype._s8c41798655529460830ad9c2a1335d = function () {
        GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: ["功能待开启"]})
    }, t.prototype._s3c9ef65dbc56bc2471759d21cc8e2c = function () {
        GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: ["即将开放, 敬请期待"]})
    }, t.prototype.UpdateCloud2 = function (t) {
        var e = .6, n = this.panel.getChildByName("img_Bg2|" + e), i = n.getChildByName("Cloud2");
        i && (i.removeSelf(), i.destroy());
        var a = jasmin._s449f055209cd01229b1846559026f5(global.$Cfg.Common.CloudPath), o = new Laya.Image(a);
        o.name = "Cloud2", o.x = t ? _.random(200, 600) : -o.width, o.y = _.random(120, 150);
        var s = 640 + n.width * e, h = 1e3 * _.random(120, 150);
        n.addChild(o), Laya.Tween.to(o, {x: s}, h, null, Laya.Handler.create(this, this.UpdateCloud2))
    }, t.prototype.UpdateCloud3 = function (t) {
        var e = .15, n = this.panel.getChildByName("img_Bg3|" + e), i = n.getChildByName("Cloud3");
        i && (i.removeSelf(), i.destroy());
        var a = jasmin._s449f055209cd01229b1846559026f5(global.$Cfg.Common.CloudPath), o = new Laya.Image(a);
        o.name = "Cloud3";
        var s = n.width * e;
        o.x = t ? _.random(s - 300, s - 100) : -o.width, o.y = 130;
        var h = 640 + n.width * e, r = 1e3 * _.random(180, 210);
        n.addChild(o), Laya.Tween.to(o, {x: h}, r, null, Laya.Handler.create(this, this.UpdateCloud3))
    }, t.prototype.OnClose = function () {
        this._3517793858._s54107fed721f2f5f6636c3b2747bef(), GetDataBaseInterface().off("RefreshFortune", this, this.OnRefreshFortune), this._2029868072 && (this._2029868072.destroy(), this._2029868072 = null), this._sf361aaed541711b6df50a5f31c570e(), this._2325891651 && this._2325891651._sb21e9331a1c6425ce2218185c68d93(), this._526051148 && this._526051148.removeSelf(), this._3399175475._s54107fed721f2f5f6636c3b2747bef(), Laya.timer.clear(this, this.OnTimeHandle)
    }, t.prototype.OnRefreshFortune = function () {
        this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t.prototype.OnShow = function () {
        ReleaseMem(), this._3517793858._s2e4033b88e999ce7271844dbf3b2dc(), GetDataTaskInterface()._s82dd437e0d798ae5596d8ec68ec545(function () {
            GameCommon._s8309ef797f42a26c507d05ee4868de()
        }), GameCommon._s751fe3068f6886bddb070f080cb5ee("main"), this._609883226._s8c5be7d6d51a594d27451cfb623f26(), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d(), GetDataBaseInterface().on("RefreshFortune", this, this.OnRefreshFortune), this.UpdateCloud2(1), this.UpdateCloud3(1), IsOffLine() || (this._2325891651 = Leo.GetChatSystem_P(), this._526051148 = this._2325891651._saeb2814548eac60bb4139b67d6fbb9(), this._526051148.left = 0, this._526051148.bottom = 110, this.addChild(this._526051148));
        var t = ["Area"];
        jasmin._seb2d63e263badd8a69c54d151f6cc7(GetGuildProxy()._s29a41a18394428f794cfc156c4edd1()) && t.push("Guild"), this._2325891651 && (this._2325891651._s6f061e4f6f62e63e4188bd53fa50e3(t), this._2325891651.OnSetDefIndex("Area"), this._2325891651._s89054e77b7a538cfcf6055d9d64058()), Laya.loader.load("particle/Yezi.part", Laya.Handler.create(this, function (t) {
            var e = new Laya.Particle2D(t);
            e.emitter.start(), e.play(), e.zOrder = 100, this.sp_LZ.addChild(e), this._2029868072 = e
        }), null, Laya.Loader.JSON), this._sdfe9903b355e9f56bb9858ada2868b(), this.OnTimeHandle(), Laya.timer.loop(1e3, this, this.OnTimeHandle)
    }, t.prototype.OnTimeHandle = function () {
        var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), e = new Date(t),
            n = e.getYear() + 1900, i = e.getMonth() + 1, a = e.getDate(),
            o = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance1StartTime),
            s = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, i, a, o.Hour, o.Minute, o.Second);
        o = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance1EndTime);
        var h = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, i, a, o.Hour, o.Minute, o.Second);
        o = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance2StartTime);
        var r = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, i, a, o.Hour, o.Minute, o.Second);
        o = this._se7db998f1acd3c087065e525e08a6f(global.$Cfg.Common.Instance2EndTime);
        var l = jasmin._sa8ce9b799dca49cfed044a7bb95483(n, i, a, o.Hour, o.Minute, o.Second);
        t > s && t < h || t > r && t < l ? this._s417d6c7469c9a046cd4838e8b4bc37() : this._s74c5916364eeeaf38b1ab83f2a1958()
    }, t.prototype._se7db998f1acd3c087065e525e08a6f = function (t) {
        t = t.trim();
        var e = t.split(":"), n = {};
        return n.Hour = e[0] ? parseInt(e[0]) : 0, n.Minute = e[1] ? parseInt(e[1]) : 0, n.Second = e[2] ? parseInt(e[2]) : 0, n
    }, t.prototype._sdc7d62989f61d7602e87894b40b5ba = function (t) {
        var e = [[140, 100], [230, 160], [28, 55]], n = [[190, 256], [190, 256], [91, 105]], i = [1.4, 1.4, 1.7];
        Laya.loader.load(global.$Cfg.Common.InstanceOpenPath[t], Laya.Handler.create(this, function () {
            var a = new Effect, o = {
                Res: global.$Cfg.Common.InstanceOpenEffect[t],
                IsAutoRemove: !1,
                IsAutoHide: !1,
                Scale: i[t],
                Size: n[t]
            };
            if (a.Init(o), a._s2e4033b88e999ce7271844dbf3b2dc(e[t]), 2 == t) {
                var s = this.btn_Fuben.getChildByName("img_Font");
                s.addChild(a)
            } else this.btn_Fuben.addChild(a);
            this.btn_Fuben["eff" + t] = a, this.btn_Fuben["eff" + t].visible = !0
        }))
    }, t.prototype._s417d6c7469c9a046cd4838e8b4bc37 = function () {
        for (var t = 0; t < 3; t++) this.btn_Fuben["eff" + t] ? this.btn_Fuben["eff" + t].visible = !0 : this._sdc7d62989f61d7602e87894b40b5ba(t)
    }, t.prototype._s74c5916364eeeaf38b1ab83f2a1958 = function () {
        for (var t = 0; t < 3; t++) this.btn_Fuben["eff" + t] && (this.btn_Fuben["eff" + t].visible = !1)
    }, t.prototype._CheckModuleOpen = function (t) {
        var e = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("module_open", t);
        if (!e) return !1;
        var n = e.Condition, i = global.$Api.GetAssetManager()._sf591a4a71c68d6c62f9d5c59258ec3(n[0], n[1], n[2]);
        return i.Result
    }, t.prototype._FloatTip = function (t) {
        var e = t._childs[0], n = t._ModuleOpenId;
        if (n) {
            if (!this._CheckModuleOpen(n)) return void(e.gray = !0);
            e.gray = !1
        }
        var i = new Leo.ImageActionManager({Image: e});
        i._sc95f42251335b3aa0013090797aec9("Distance", {Time: 2500, DistanceY: -5}), this._2476441895.push(i)
    }, t.prototype._sdfe9903b355e9f56bb9858ada2868b = function () {
        this._2476441895 = [], this._FloatTip(this.btn_FuDi), this._FloatTip(this.btn_Level), this._FloatTip(this.btn_XunFang), this._FloatTip(this.btn_LaoFang), this._FloatTip(this.btn_JiuGuan), this._FloatTip(this.btn_Yamen), this._FloatTip(this.btn_HanLin), this._FloatTip(this.btn_Fuben), this._FloatTip(this.btn_HuangGong), this._FloatTip(this.btn_TaoFa), this._FloatTip(this.btn_TongShang), this._FloatTip(this.btn_PaiHang), this._FloatTip(this.btn_LianMeng), this._FloatTip(this.btn_Cabinet), _.each(this._2476441895, function (t) {
            t._s2e4033b88e999ce7271844dbf3b2dc()
        })
    }, t.prototype._sf361aaed541711b6df50a5f31c570e = function () {
        _.each(this._2476441895, function (t) {
            t._s54107fed721f2f5f6636c3b2747bef()
        })
    }, t.prototype.OnClickMainCityBtn = function (t, e) {
        var n = e._ModuleOpenId;
        if (!IsDebug() && e._ModuleOpenId && !this._CheckModuleOpen(e._ModuleOpenId)) {
            var i = global.$Sys.GetTableService().GetTableRecord("module_open", n), a = i.ConditionDetail,
                o = global.$Cfg.Language.BeautyUnlockWay;
            return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [jasmin._se91cf955e91eaa1aa510d4335edd4a(o, a)]})
        }
        switch (t) {
            case"FuDi":
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi");
                break;
            case"Level":
                GetDataLevelInterface()._s12a7ca6175a8b405eabec3ccd65b55();
                break;
            case"SiFang":
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SearchPage");
                break;
            case"LaoFang":
                if (0 == _.size(global.$Api.QueryDataSource("DataPrison")._s2801a9c50d15d3db2b0c4444c7c489())) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.PrisionNoPrisioner]});
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PrisonPage");
                break;
            case"YanHui":
                if (IsOffLine()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BanquetMap");
                break;
            case"YaMen":
                if (IsOffLine()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("YamenPage");
                break;
            case"HanLin":
                if (IsOffLine()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetDataInstituteInterface()._s2ae4f6fc306e49e99425fd62e762eb();
                break;
            case"FuBen":
                if (IsOffLine() && !IsDebug()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Instance");
                break;
            case"HuangGong":
                if (IsOffLine() && !IsDebug()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Palace");
                break;
            case"TaoFa":
                GetDataTaofaInterface()._s64f7f34ebce64071cf00db34786e3c();
                break;
            case"TongShang":
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("TradeMap", {CityId: GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d()});
                break;
            case"LianMeng":
                if (IsOffLine() && !IsDebug()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuildInterface()._s19807ae6c4ef3c3187372d1afc3a1a();
                break;
            case"PaiHang":
                if (IsOffLine()) return void this._s3c9ef65dbc56bc2471759d21cc8e2c();
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Rank");
                break;
            case"Cabinet":
                return void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CabinetPage")
        }
    }, t
}();
var MainTaskController;
!function () {
    MainTaskController = function (a, i) {
        this._3257292081 = a, this._4122736007 = i, this._3257292081.btn_task.on(Laya.Event.CLICK, this, this.OnBtnClick), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, MainTaskController._s0daf7356f401bde6dc31ec8d9f8bc8 = function (a, i) {
        return new MainTaskController(a, i)
    };
    var a = MainTaskController.prototype;
    a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = "Main", i = global.$Api.QueryDataSource("DataTask")._se7a80ba4516d999f7a52608a9ce323(a);
        if (0 == i.TaskList.length) return void(this._3257292081.visible = !1);
        var n = i.TaskList[0].ChainId, s = i.TaskList[0].TaskId, t = GetDataTransfer().GetTableRecord("task", a).Table,
            e = GetDataTransfer().GetTableRecord(t, n, s);
        this._3257292081.lab_name.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d.%s", s, e.TaskName);
        var r = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(a, n, s),
            o = ["res/ui/bg/z_bg_41.png", "res/ui/bg/z_bg_42.png"],
            m = ["res/ui/common/z_image_14.png", "res/ui/common/z_image_15.png"];
        this._3257292081.img_icon.skin = m[Number(r)], this._3257292081.img_bg.skin = o[Number(r)], this._3257292081.lab_name.color = r ? "#00ff00" : "#ff0000"
    }, a.OnBtnClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("MainTaskDialog", {OnClose: this._4122736007.OnClose})
    }, MainTaskController._s6ea328e154c15cc2fb730cc9ed1dd4 = function () {
        var a = [];
        return jasmin._s3c96e1f3bee730222501b208d50190(a, ["res/ui/bg/z_bg_41.png", "res/ui/bg/z_bg_42.png"]), jasmin._s3c96e1f3bee730222501b208d50190(a, ["res/ui/common/z_image_14.png", "res/ui/common/z_image_15.png"]), a
    }
}();

function MainTaskDialog() {
    MainTaskDialog.super(this), this.btn_close.on(click, this, this.OnBtnCloseClick), this.btn_get.on(click, this, this.OnBtnGetClick), this._593327032 = []
}

var click = Laya.Event.CLICK;
Laya.class(MainTaskDialog, "MainTaskDialog", MainTaskDialogUI);
var _proto_ = MainTaskDialog.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e || {}, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = "Main", a = global.$Api.QueryDataSource("DataTask")._se7a80ba4516d999f7a52608a9ce323(e);
    if (0 == a.TaskList.length) return void this.OnBtnCloseClick();
    var t = a.TaskList[0].ChainId, i = a.TaskList[0].TaskId, n = GetDataTransfer().GetTableRecord("task", e).Table,
        s = GetDataTransfer().GetTableRecord(n, t, i);
    this.lab_name.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.TaskTitle, i, s.TaskName), this.lab_dec.text = s.TaskDec;
    var o = s.Target[0], r = o[2], c = {};
    s.UserData && (c = jasmin._sdf8385ff3a74421ea218e043d47fdc(s.UserData)), c.TaskType = "Main";
    var l = GameCommon._sc2670617ff77eb1396f5b63c0edc88(o[0], o[1], c);
    this.lab_target.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("(%d/%d)", l, r), this.lab_target.color = l < r ? "#ff0000" : "#5d3921";
    var h = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(e, t, i);
    this.btn_get.label = h ? gLanguage.TaskGet : gLanguage.TaskGoto;
    var u = s.Reward, g = GetDataTransfer().GetTableRecord("reward", u).Award;
    this._s685013bcd44a57497549b890f19acd(), _.each(g, function (e, a) {
        var t;
        t = e[0] == global.$Cfg.CommonEnum.Asset.DataHero && e[1] == global.$Cfg.CommonEnum.DataHero.Hero ? GetItemIconFactory()._sb28617dc58b536a74dd40075815048(e[2]) : GameCommon._s66eb52e60b9feb53711943e638c9c3(e[0], e[1], !1, !0, e[2]), this._593327032.push(t), this.hbox_reward.addChild(t)
    }.bind(this)), this.hbox_reward.refresh()
}, _proto_.OnBtnGetClick = function () {
    var e = "Main", a = global.$Api.QueryDataSource("DataTask")._se7a80ba4516d999f7a52608a9ce323(e),
        t = a.TaskList[0].ChainId, i = a.TaskList[0].TaskId,
        n = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(e, t, i);
    if (n) {
        var s = {
            Group: e, ChainId: t, TaskId: i, Callback: function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d(), GameCommon._s8309ef797f42a26c507d05ee4868de()
            }.bind(this)
        };
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), GetDataTaskInterface().DoTask(s)
    } else {
        var o = GetDataTransfer().GetTableRecord("task", e).Table, r = GetDataTransfer().GetTableRecord(o, t, i),
            c = r.SwitchScene;
        c && "-" != c ? this._s2ae4f6fc306e49e99425fd62e762eb(c) : jasmin.Info("No Scene!!"), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MainTaskDialog")
    }
}, _proto_._s685013bcd44a57497549b890f19acd = function () {
    _.each(this._593327032, function (e) {
        e && (e.removeSelf(), e.destroy(), e = null)
    }), this._593327032 = []
}, _proto_.OnClose = function () {
    this._s685013bcd44a57497549b890f19acd(), this._4122736007.OnClose && this._4122736007.OnClose()
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MainTaskDialog")
}, MainTaskDialog.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MainTaskDialog.uiView, e)
}, _proto_._sa5a6d226ce4253ca4f8110fd3adbd4 = function (e) {
    var a;
    a = "DealAffair" == e ? "DealAffairView" : "BusinessAssets";
    var t = GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765(), i = t.__className;
    if ("FuDi" == i) var n = function () {
        t._3402150980._s4fb507d6d0f40b2d2a72f6007a938d()
    }.bind(this);
    GetGuiManager()._s2e22e694b9852084df200bc86f9340(a, {OnClose: n})
}, _proto_._s2ae4f6fc306e49e99425fd62e762eb = function (e) {
    switch (onClose = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
    }, e) {
        case"SelectHeroPage":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SelectHeroPage", {OnClose: onClose});
            break;
        case"ItemBag":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ItemBag", {OnClose: onClose});
            break;
        case"DailyTask":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DailyTask", {OnClose: onClose});
            break;
        case"Achievement":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Achievement", {OnClose: onClose});
            break;
        case"ShopView":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ShopView", {OnClose: onClose});
            break;
        case Level:
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Level", {LevelId: global.$Api.QueryDataSource("DataLevel").GetValue("LevelId")});
            break;
        case"WelfarePage":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("WelfarePage", {OnClose: onClose});
            break;
        case"PlayerInfo":
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PlayerInfo", {OnClose: onClose});
            break;
        case"PrisonPage":
            if (0 == _.size(global.$Api.QueryDataSource("DataPrison")._s2801a9c50d15d3db2b0c4444c7c489())) {
                GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.PrisionNoPrisioner]});
                break
            }
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PrisonPage");
            break;
        case"DealAffair":
            this._sa5a6d226ce4253ca4f8110fd3adbd4(e);
            break;
        case"FuDi":
            this._sa5a6d226ce4253ca4f8110fd3adbd4(e);
            break;
        case"BusinessGold":
            this._sa5a6d226ce4253ca4f8110fd3adbd4(e);
            break;
        case"BusinessFood":
            this._sa5a6d226ce4253ca4f8110fd3adbd4(e);
            break;
        case"BusinessSoldier":
            this._sa5a6d226ce4253ca4f8110fd3adbd4(e);
            break;
        case"GuildMain":
            GetGuildInterface()._s19807ae6c4ef3c3187372d1afc3a1a();
            break;
        default:
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb(e)
    }
};

function MainUI() {
    var e = laya.events.Event;
    MainUI.super(this), this.btnContinue.on(e.CLICK, this, this.OnBtnContinueGame), this.ui_ChangeServerBtn.on(e.CLICK, this, this.OnChangeServer), this.ui_ChangAccountBtn.on(e.CLICK, this, this.OnChangeAccount), this.ui_ContactUsBtn.on(e.CLICK, this, this.OnContactUsBtn), this._s96ed7e172fe81c0edb69a4e8c98452(), IsOffLine() || Leo.SelectServerDialog_Fox._sc06ccd5cf584c2094ca37a43d8fa15() && (this._3657912215 = Leo.SelectServerDialog_Fox._sc06ccd5cf584c2094ca37a43d8fa15().mark)
}

Laya.class(MainUI, "MainUI", MainPageUI), MainUI.prototype.OnChangeAccount = function () {
    jasmin.Info("切换账号！")
}, MainUI.prototype.OnContactUsBtn = function () {
    jasmin.Info("联系客服!")
}, MainUI.prototype._s96ed7e172fe81c0edb69a4e8c98452 = function () {
    this._s914ed7368bbee4b75929f87d992e22(1)
}, MainUI.prototype._s914ed7368bbee4b75929f87d992e22 = function (e) {
    Laya.timer.frameLoop(e, this, function () {
        this._s9808d3c9ac92b974f6c6da6d299570(this.ui_CloudImg1, 1), this._s9808d3c9ac92b974f6c6da6d299570(this.ui_CloudImg2, .5), this._s9808d3c9ac92b974f6c6da6d299570(this.ui_CloudImg3, .8)
    })
}, MainUI.prototype._s9808d3c9ac92b974f6c6da6d299570 = function (e, a) {
    e.x >= 640 + e.width / 2 + 20 && (e.x = -(e.width / 2) - 40), e.x = e.x + a
}, MainUI.GetPreLoadResList = function (e) {
    var a = GetSkinRes();
    e.push("res/ui/common/z_image_13.png"), e.push(a.Login1Bg), e.push(a.Login2Bg), e.push([{
        url: a.LogoEff,
        type: Laya.Loader.ATLAS
    }])
}, MainUI.prototype.OnClose = function () {
    this._3793876746 && (this._3793876746.offAll("complete"), this._3793876746.destroy(), this._3793876746 = null)
}, MainUI.prototype.OnBtnContinueGame = function () {
    if (this.mouseEnabled = !1, GetVersionCfgManager().GetValue("UseSDK") && !this._2272287617) return Laya.timer.once(2e3, this, function () {
        this.mouseEnabled = !0
    }), void DeepSDK.GetUserSysterm().Login({}, function (e) {
        if (this.mouseEnabled = !0, e.Code != DeepSDK.UserSysterm.ErrorCode.LOGIN_OK) return GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.LoginFailed]}), void this.OnShow({ReLogin: !0});
        e.Data;
        this._2272287617 = e;
        var a = [];
        this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? a.push(this.OnShowNotice.bind(this)) : a.push(function (e) {
            Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
        }), a.push(this.OnShowLoginView.bind(this)), async.waterfall(a, function () {
        }.bind(this))
    }.bind(this));
    var e = [];
    if ("0" != GetVType()) {
        e.push(function (e) {
            this._Login(e)
        }.bind(this))
    }
    e.push(function (e) {
        var a = window.location || {};
        GetCmdProxy().DoCmd("LoadData", {
            ChannelInfo: {
                host: a.host,
                hostname: a.hostname,
                href: a.href
            }
        }, function (a) {
            if ((IsGm() || a.Gm) && Leo.GetLevitatedSphere()._sabbe27d79486b625a06ed3d6ebdec5({
                Image: "res/ui/button/z_but_2.png",
                Click: function () {
                    GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebugWin", GetDebugCfg())
                },
                DefaultX: 0,
                DefaultY: 0
            }), GetActivityManager()._s2f69580587d432038038a6c20c72a0(), GetActivityManager()._sd1c5e401f87b81c27cab574c3ae223(a.Activity), a.Result ? (Leo.GetGuideSystem()._seaac11a9f61697baafbf87d3b7cfdb(), global.$Api.QueryDataSource("PlayerStatData")._s5886de13aababb7fe386a7e917b8b8(function () {
                return global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285()
            })) : this.mouseEnabled = !0, a.ServerId && GetServerInfoInterface()._sdbb730f79fe415639ea2aec361dfd2("ServerId", a.ServerId), a.PayType && GetServerInfoInterface()._sdbb730f79fe415639ea2aec361dfd2("PayType", a.PayType), a.NoReturnReward && GetServerInfoInterface()._sdbb730f79fe415639ea2aec361dfd2("NoReturnReward", a.NoReturnReward), this._s97a783abdb266d5d4753d54be16534(), isLogin = !0, global.$Api.QueryDataSource("DataBase").GetValue("PlayerName")) {
                GetCmdProxy().DoCmd("RecordLoginCount", {}, function (e) {
                }, {NoBlock: !0}), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi", {
                    LoadMode: "LoadingScene",
                    OnEnter: function () {
                        var e = GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765(),
                            a = Leo.GetGuideSystem()._s8c9071ff93fa963fae3afade02491c(e);
                        a || GetServerInfoInterface()._s5c4fd5b482d0f3cb64d5141cadd11f()
                    }
                }, {release: !0});
                var t = "";
                global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex") && (t = "" + global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"));
                var n = "" + global.$Api.QueryDataSource("DataBase").GetValue("CreateTime");
                DeepSDK.GetStatisticsSystem()._sc31c7a9879d41c7bcb2e14eba4b29d("Login", {
                    RoleId: global.$Api.GetOrderGameUserId(),
                    RoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                    RoleLevel: "" + global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                    ZoneId: "" + a.ServerId,
                    ZoneName: gServerName,
                    RoleBalance: "" + global.$Api.QueryDataSource("DataBase").GetValue("Gold"),
                    VipLevel: "" + GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(),
                    RoleCreateTime: n.substr(0, 10),
                    PartyId: global.$Api.QueryDataSource("DataGuild").GetValue("GuildId") || "",
                    PartyName: "无帮派",
                    RoleGender: t,
                    RolePower: GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() ? "" + GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() : "",
                    PartyRoleId: global.$Api.GetOrderGameUserId(),
                    PartyRoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                    ProfessionId: "",
                    Profession: ""
                }), GetServerInfoInterface()._s95a8b1f36825b7b47c4e542efd1229()
            } else GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CreateRoleView", {
                LoadMode: "LoadingScene",
                OnClose: function () {
                    GetCmdProxy().DoCmd("RecordLoginCount", {}, function (e) {
                    }, {NoBlock: !0});
                    var e = "";
                    global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex") && (e = "" + global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"));
                    var t = "" + global.$Api.QueryDataSource("DataBase").GetValue("CreateTime");
                    DeepSDK.GetStatisticsSystem()._sc31c7a9879d41c7bcb2e14eba4b29d("CreateRole", {
                        RoleId: global.$Api.GetOrderGameUserId(),
                        RoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                        RoleLevel: "" + global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                        ZoneId: "" + a.ServerId,
                        ZoneName: gServerName,
                        RoleBalance: "" + global.$Api.QueryDataSource("DataBase").GetValue("Gold"),
                        VipLevel: "" + GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(),
                        RoleCreateTime: t.substr(0, 10),
                        PartyId: global.$Api.QueryDataSource("DataGuild").GetValue("GuildId") || "",
                        PartyName: "无帮派",
                        RoleGender: e,
                        RolePower: GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() ? "" + GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() : "",
                        PartyRoleId: global.$Api.GetOrderGameUserId(),
                        PartyRoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                        ProfessionId: "",
                        Profession: ""
                    }), DeepSDK.GetStatisticsSystem()._sc31c7a9879d41c7bcb2e14eba4b29d("Login", {
                        RoleId: global.$Api.GetOrderGameUserId(),
                        RoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                        RoleLevel: "" + global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                        ZoneId: "" + a.ServerId,
                        ZoneName: gServerName,
                        RoleBalance: "" + global.$Api.QueryDataSource("DataBase").GetValue("Gold"),
                        VipLevel: "" + GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(),
                        RoleCreateTime: t.substr(0, 10),
                        PartyId: global.$Api.QueryDataSource("DataGuild").GetValue("GuildId") || "",
                        PartyName: "无帮派",
                        RoleGender: e,
                        RolePower: GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() ? "" + GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee() : "",
                        PartyRoleId: global.$Api.GetOrderGameUserId(),
                        PartyRoleName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                        ProfessionId: "",
                        Profession: ""
                    })
                }
            }, {release: !0});
            if (a.Orders) for (var o in a.Orders) GetOrderManager()._s157e7a060930389acf5585a5cf665d(o, a.Orders[o], !0);
            GetTimingTask().Start(), e()
        }.bind(this))
    }.bind(this)), e.push(function (e) {
        GetPalaceInterface().DoGetKings(e)
    }), async.waterfall(e, function (e, a) {
    })
}, MainUI.prototype._s97a783abdb266d5d4753d54be16534 = function () {
    var e = {
        Cannel: ["Area", "Guild"],
        PlayerNameColor: ["#ac581a", "#ac581a"],
        CannelIcon: [""],
        CannelMaxCount: 100,
        UpdateTime: 3e4,
        PlayNextChatTime: 5e3,
        DefIndex: 0,
        SenderName: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
        SenderVIP: global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv,
        SenderUid: global.$Api.QueryDataSource("DataBase").GetValue("Uid"),
        OnPushChat: function (e) {
            var a = global.$Api._s203e39483260d999efd78cfd0eea1a(e.Content);
            a ? GetCmdProxy().DoCmd("PushChat", e, function (e) {
                if (!e.Result) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(e)
            }.bind(this)) : GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                Texts: [gLanguage.ChatHasDirtyWords],
                Colors: ["#ffffff"]
            })
        },
        OnGetChatInfo: function (e) {
            GetCmdProxy().DoCmd("PullChat", e, function (e) {
                var a = e.BanList, t = e.ChatList, n = this._OnCheckBanPlayerChatInfo(t, a);
                e.ChatList = n, Leo.GetChatSystem_P()._s599a7e98f9fd146b4790b07828405d(e)
            }.bind(this))
        }.bind(this),
        OnCheckCanSpeak: function (e) {
            var a = global.$Cfg.Common.ChatNeed, t = global.$Api._sa2b7f16c71ccbd23b128ed96d18ed7();
            return t || GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [a.ErrorInfo]}), t
        },
        OnCustomChatBox: function (e, a) {
            var t = e.getChildByName("Hbox"), n = t.getChildByName("img_vip");
            if (a.Userdata && a.Userdata.King) {
                var o = a.Userdata.King.KingId, i = global.$Sys.GetTableService().GetTableRecord("throne", o);
                Laya.loader.load(i.NameFontPath, Laya.Handler.create(this, function () {
                    n.skin = i.NameFontPath
                })), t.space = 15
            } else GameCommon._s30785039c095384a99d4a2b44edd17(n, !0, !0, a.Userdata.VIP), t.space = 5;
            t.changeItems();
            var r = e.getChildByName("ui_labDate"), l = e.getChildByName("ui_labTime"),
                s = GameCommon._s35a1b0c6766e811873de21d05b47cc(a.Timestamp);
            r.visible = !1, s.Type > 1 && (l.text = s.Text), e.offAll(Laya.Event.CLICK), e.on(Laya.Event.CLICK, this, function () {
                GetPalaceInterface().DoGetPlayerInfo(a.Userdata.Uid, function (e) {
                    e.Id = a.Userdata.Uid, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", e)
                })
            })
        },
        OnCustomMiniChat: function (e, a) {
            var t = e.getChildByName("Hbox"), n = t.getChildByName("ui_LabName"), o = t.getChildByName("ui_LabInfo");
            Laya.Tween.clearAll(t), t.centerY = 0;
            var i = 500;
            Laya.Tween.to(t, {centerY: -40}, i, null, Laya.Handler.create(this, function () {
                n.color = global.$Cfg.Common.MiniNameColor, o.color = global.$Cfg.Common.MiniDataColor, n.text = a.Userdata.Name + ":", o.text = a.Content, t.changeItems(), t.centerY = 40, Laya.Tween.to(t, {centerY: 0}, i)
            }))
        },
        OnCheckChatInfo: function (e, a) {
            var t = this._OnCheckBanPlayerChatInfo(e, a);
            return t
        }.bind(this)
    };
    Leo.GetChatSystem_P()._sc06f1773cb2c7a76adbfa55ce54db1(e), Leo.GetChatSystem_P().OnGetChatInfo()
}, MainUI.prototype._OnCheckBanPlayerChatInfo = function (e, a) {
    var t = global.$Api.QueryDataSource("DataBase").GetValue("Uid").substr(0, 15), n = {};
    for (var o in e) {
        n[o] = [];
        for (var i = this._OnCheckSameChatInfo(e[o]), r = 0; r < i.length; r++) {
            var l = jasmin._sa96e5dbe16d978e8310b94a495c86f(a, i[r].Sender);
            l && i[r].Sender != t || n[o].push(i[r])
        }
    }
    return n
}, MainUI.prototype._OnCheckSameChatInfo = function (e) {
    for (var a = global.$Cfg.Common.CheckInfoStart, t = global.$Cfg.Common.CheckInfoCount, n = jasmin._sdf8385ff3a74421ea218e043d47fdc(e), o = 0; o < n.length; o++) {
        var i = n[o], r = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
        if (i.Sender != r) for (var l = o + 1; l < n.length; l++) {
            var s = n[l];
            if (!(s.Timestamp - i.Timestamp >= global.$Cfg.Common.SpeakSameTime)) {
                var u = i.Content.substring(a, a + t), g = s.Content.substring(a, a + t);
                u == g && i.Sender == s.Sender && delete n[o]
            }
        }
    }
    return n = _.filter(n, function (e) {
        return !!e
    })
}, MainUI.prototype.OnChangeServer = function () {
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("Leo.SelectServerDialog_Fox", {
        Callback: function (e) {
            var a = _.find(Leo.SelectServerDialog_Fox._sfe9b857e9eaa06114418ea739d2575(), function (a) {
                return e.mark === a.mark
            });
            return a ? (this.ui_ServerLabel.text = e.name, SetServerName(e.name), this._3657912215 = e.mark, this.ui_ServerTipImg.skin = gCfg.ServerStatePath[a.state], void GetCmdProxy()._s994f4be3a65644490c53172ba39ae4({
                Url: a.url,
                OnGlobalCallBack: GameCommon.OnCmdGlobalCallback,
                DefaultProtocolNo: 256,
                ResponseType: "arraybuffer",
                Headers: {}
            })) : void GetDataTransfer()._se80d4d9de68409f2fb71e3d22f3824({Labels: [gLanguage.InvalidServer]})
        }.bind(this), UseGroup: !0
    })
}, MainUI._xhr_holder = MainUI._xhr_holder || [], MainUI._xhr_holder_delete = function (e) {
    var a = MainUI._xhr_holder, t = a.indexOf(e);
    t >= 0 && (a[t] = a[a.length - 1], a.pop())
}, MainUI._xhr_holder_push = function (e) {
    MainUI._xhr_holder;
    MainUI._xhr_holder.push(e)
}, MainUI.prototype.OnShowNotice = function (e, a) {
    var t = {OnProgress: null, Target: null}, n = {
        Skin: {
            LoadingImg: {centerX: 5, skin: "res/ui/loading/loading_up.png"},
            Progress: {centerX: 0},
            Listenr: t
        }, StrFormat: global.$Cfg.Language.LinkServer
    };
    a && a.NoShowLoadingDialog || GetGuiManager()._s2e22e694b9852084df200bc86f9340("LoadingDialog", n, "ServerDialog", {isModal: !0});
    var o = new Laya.HttpRequest;
    o.once(Laya.Event.PROGRESS, this, function () {
        jasmin.Info(arguments)
    }), o.once(Laya.Event.COMPLETE, this, function (a) {
        jasmin.Info(a);
        var t = JSON.parse(a), n = t.server_notice, i = t.server_list, r = t.server_setting;
        GetServerInfoInterface()._sdbb730f79fe415639ea2aec361dfd2("ServerSetting", r), i.sort(function (e, a) {
            return parseInt(a.mark.slice(4)) - parseInt(e.mark.slice(4))
        }), Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(i), n && GetGuiManager()._s2e22e694b9852084df200bc86f9340("NoticeBoard_X", {
            HtmlInfo: n,
            DefaultColor: "#ffffff",
            DefaultFontSize: 20,
            OnClose: e
        }), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LoadingDialog", "ServerDialog", {release: !0}), InitLayaStat(), InitLayaExtendStat(), n || e(), MainUI._xhr_holder_delete(o)
    }), o.once(Laya.Event.ERROR, this, function (a, t) {
        MainUI._xhr_holder_delete(o), AksoSDK._s2c794bdeaefdf39a654cb7ef7bd466("GetServerListError!!! " + a), this.OnShowNotice(e, {NoShowLoadingDialog: !0})
    });
    var i = "http://45.250.41.85:4000/supportapi/serverinfo/index.php?project=%s&channel=%s&version=%s", r = "1.0.0";
    window.conch && (r = window.conch.config.getAppVersion());
    var l = jasmin._se91cf955e91eaa1aa510d4335edd4a(i, "p12", GetVersionCfgManager().GetValue("Channel"), r);
    MainUI._xhr_holder_push(o), o.send(l, null, "get", "text")
}, MainUI.prototype._s6f572fac0378426bf9f34fea19c9d5 = function () {
    GetOrderManager()._s623ac700b592510ec55a9daa2c854d(), GetDataChildInterface()._s6f572fac0378426bf9f34fea19c9d5(), GetTimingTask()._s54107fed721f2f5f6636c3b2747bef(), GetTimingTask()._se8071f5eaa13f61ddd2fe9bd7a47c4()
}, MainUI.prototype._s232539cfe70acb7fce177357529d3f = function () {
    var e = GetSkinRes(), a = e.LogoEff;
    this._3793876746 = new Laya.Animation, this._3793876746.on("complete", this, function () {
        this.timerOnce(3e3, this, function () {
            this._3793876746 && this._3793876746.play(1, !1)
        })
    }), this._3793876746.loadAtlas(a, Laya.Handler.create(this, function () {
        var e = this._3793876746.getBounds().width;
        this._3793876746.x = (Laya.stage.width - e) / 2, this._3793876746.y = 150, this.addChild(this._3793876746), this._3793876746.play(null, !1)
    }))
}, MainUI.prototype._s30e29d713882a07de07edcd85978c4 = function () {
    return Laya.Browser.onAndriod ? void(this.ui_VersionCode.visible = !0) : void(this.ui_VersionCode.visible = !1)
}, MainUI.prototype.OnShow = function (e) {
    Laya.stage.bgColor = "#000000", this._s30e29d713882a07de07edcd85978c4();
    var a = GetSkinRes();
    this.img_Login1.skin = a.Login1Bg, this.img_Login2.skin = a.Login2Bg, this._2029868072 && (this._2029868072.destroy(), this._2029868072 = null), this._s6f572fac0378426bf9f34fea19c9d5();
    var t = GetVersionCfgManager().GetValue("Channel"), n = GetVersionCfgManager().GetValue("Version");
    if (t && !this.IsInitSDK) {
        AksoSDK.Init({
            AppId: 2, Mark: n, OnHook: function (e) {
                var a, t = {
                    Version: n,
                    Uid: global.$Api.QueryDataSource("DataBase").GetValue("Uid"),
                    ServerName: gServerName,
                    ServerId: GetServerInfoInterface().GetValue("ServerId"),
                    UserAgent: window.navigator.userAgent,
                    LastLog: GetReportInfoManage()._sddb91542ee01ac98d760c9cb774d2b(10)
                }, o = "";
                for (var i in t) a = {}, a[i] = t[i], o += "LastLog" == i ? t.LastLog : JSON.stringify(a) + "\n";
                return e.Data = e.Data + "\n" + o, e
            }.bind(this)
        });
        var o = DeepSDK.GetTalkingDataAdapter();
        DeepSDK.GetStatisticsSystem()._s7963b9eb01091d869972d0542af810(o), this.IsInitSDK = !0
    }
    GetActivityManager()._s54107fed721f2f5f6636c3b2747bef(), "vigor" != t && this._s232539cfe70acb7fce177357529d3f(), this.lab_Version.text = n, GameCommon._s751fe3068f6886bddb070f080cb5ee("login");
    var i = [];
    this.ui_ChangeServerBtn.visible = !1, this.ui_ChangeServerBtn.mouseEnabled = !0, e && e.ReLogin ? DeepSDK.GetUserSysterm().Login({}, function (e) {
        if (this.mouseEnabled = !0, e.Code != DeepSDK.UserSysterm.ErrorCode.LOGIN_OK) return GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.LoginFailed]}), void this.OnShow({ReLogin: !0});
        e.Data;
        this._2272287617 = e, this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? i.push(this.OnShowNotice.bind(this)) : i.push(function (e) {
            Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
        }), i.push(this.OnShowLoginView.bind(this)), async.waterfall(i, function () {
        }.bind(this))
    }.bind(this)) : GetVersionCfgManager().GetValue("UseSDK") && !this.IsInitDeepSDK ? (this.mouseEnabled = !1, this.IsInitDeepSDK = !0, Laya.timer.once(2e3, this, function () {
        this.mouseEnabled = !0
    }), window.conch && window.conch.setOnBackPressedFunction && window.conch.setOnBackPressedFunction(function () {
        DeepSDK.GetUserSysterm().ExitGame()
    }), DeepSDK.GetUserSysterm().SetListener(function (e) {
        if (e.fun == Leo.NativeMarket.Event.LOGIN) e.code == Leo.NativeMarket.CODE_LOGINFAILED; else if (e.fun == Leo.NativeMarket.Event.LOGOUT) {
            if (GetGuiManager()._s352787ebad4fef28746b3676c9c57a(), "MainUI" == GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765().__className) {
                GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765().mouseEnabled = !0;
                var a = [];
                return void DeepSDK.GetUserSysterm().Login({}, function (e) {
                    if (this.mouseEnabled = !0, e.Code != DeepSDK.UserSysterm.ErrorCode.LOGIN_OK) return GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.LoginFailed]}), void this.OnShow({ReLogin: !0});
                    e.Data;
                    this._2272287617 = e, this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? a.push(this.OnShowNotice.bind(this)) : a.push(function (e) {
                        Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
                    }), a.push(this.OnShowLoginView.bind(this)), async.waterfall(a, function () {
                    }.bind(this))
                }.bind(this))
            }
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainUI", {ReLogin: !0})
        }
    }.bind(this)), DeepSDK.GetUserSysterm().Login({}, function (e) {
        if (this.mouseEnabled = !0, e.Code != DeepSDK.UserSysterm.ErrorCode.LOGIN_OK) return GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.LoginFailed]}), void this.OnShow({ReLogin: !0});
        e.Data;
        this._2272287617 = e, this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? i.push(this.OnShowNotice.bind(this)) : i.push(function (e) {
            Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
        }), i.push(this.OnShowLoginView.bind(this)), async.waterfall(i, function () {
        }.bind(this))
    }.bind(this))) : (this.mouseEnabled = !0, this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? i.push(this.OnShowNotice.bind(this)) : i.push(function (e) {
        Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
    }), i.push(this.OnShowLoginView.bind(this)), async.waterfall(i, function () {
    }.bind(this))), Laya.loader.load("particle/Yezi.part", Laya.Handler.create(this, function (e) {
        sp = new Laya.Particle2D(e), sp.emitter.start(), sp.play(), sp.zOrder = 100, this.addChild(sp), this._2029868072 = sp
    }), null, Laya.Loader.JSON)
}, MainUI.prototype.OnShowLoginView = function (e) {
    var a = GetCmdProxy()._s435407f6b94770e1efff627b1ab712();
    if ("0" === GetVType()) {
        if (!a) {
            var t = new LocalCmdDo(null);
            GetCmdProxy()._s18750fcda64f96e221e488f68b3ae7(t), GetCmdProxy()._s994f4be3a65644490c53172ba39ae4({
                OnGlobalCallback: GameCommon.OnCmdGlobalCallback,
                AutoLoadData: {PlayerCmdStat: {DataKey: "Uid", ParamKey: "U", ParamKeyNum: 1}}
            })
        }
        this.ui_ChangeServerBtn.visible = !1, e()
    } else {
        this.ui_ChangeServerBtn.visible = !0;
        var n = Leo.SelectServerDialog_Fox._sc06ccd5cf584c2094ca37a43d8fa15(), o = n.url, i = n.name;
        if (a) GetCmdProxy()._s994f4be3a65644490c53172ba39ae4({
            Url: o,
            OnGlobalCallback: GameCommon.OnCmdGlobalCallback,
            DefaultProtocolNo: 256,
            ResponseType: "arraybuffer",
            Headers: {}
        }); else {
            var t = new NetCmdDo;
            GetCmdProxy()._s18750fcda64f96e221e488f68b3ae7(t), GetCmdProxy()._s994f4be3a65644490c53172ba39ae4({
                Url: o,
                OnGlobalCallback: GameCommon.OnCmdGlobalCallback,
                DefaultProtocolNo: 256,
                ResponseType: "arraybuffer",
                Headers: {}
            })
        }
        if (this.ui_ServerLabel.text = i, this.ui_ServerTipImg.skin = gCfg.ServerStatePath[n.state], SetServerName(i), 1 == GetVType()) return void GetGuiManager()._s2e22e694b9852084df200bc86f9340("InputDialog", {
            titleText: "请输入Uid",
            descriptText: "请输入Uid",
            DefaultInputText: GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("account") || jasmin._s4f88ea73a5cae522e21a8dfa2fd639(),
            clickOkCallBack: function (a) {
                GetStorage()._s54216acbc0200500c827232db13a75("account", a), e()
            }
        });
        if (GetInspection()) return void VigorLoginView._sabbe27d79486b625a06ed3d6ebdec5({
            Skin: VigorLogin_XUI,
            CheckIdentityCard: !1,
            CheckName: !1,
            OnShowErrorInfo: function (e) {
                var a = gLanguage.VigorServerErrorCode[e] || e;
                GetDataTransfer()._se80d4d9de68409f2fb71e3d22f3824({Labels: [a]})
            },
            OnLoginSuccess: function (a) {
                GetStorage()._s54216acbc0200500c827232db13a75("account", a.Guid), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("VigorLoginView", null, {release: !0}), e()
            }.bind(this),
            OnRequest: function () {
                var e = {OnProgress: null, Target: null}, a = {
                    Skin: {
                        LoadingImg: {skin: "res/ui/loading/loading_up.png", centerX: 0, centerY: 0},
                        Progress: {centerX: 0, centerY: 0},
                        Listenr: e
                    }, StrFormat: gLanguage.LinkServer
                };
                GetGuiManager()._s2e22e694b9852084df200bc86f9340("LoadingDialog", a, "ServerDialog", {
                    isModal: !0,
                    useMgrEffect: !1
                })
            },
            OnFinishRequest: function () {
                GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LoadingDialog", "ServerDialog")
            }
        });
        var r = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("account") || jasmin._s4f88ea73a5cae522e21a8dfa2fd639();
        GetStorage()._s54216acbc0200500c827232db13a75("account", r)
    }
}, MainUI.prototype._CallSDKLogin = function () {
    GetGuiManager()._s07a6b0a313d379ce4f1f1cd7370765().mouseEnabled = !0;
    var e = [];
    DeepSDK.GetUserSysterm().Login({}, function (a) {
        if (this.mouseEnabled = !0, a.Code != DeepSDK.UserSysterm.ErrorCode.LOGIN_OK) return GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.LoginFailed]}), void this.OnShow({ReLogin: !0});
        a.Data;
        this._2272287617 = a, this._InitTimingTask(), GetVersionCfgManager().GetValue("Channel") ? e.push(this.OnShowNotice.bind(this)) : e.push(function (e) {
            Leo.SelectServerDialog_Fox._sf0353d5183f5cd33ec3742fc84e0a1(GetVersionCfgManager().GetValue("ServerList")), e()
        }), e.push(this.OnShowLoginView.bind(this)), async.waterfall(e, function () {
        }.bind(this))
    }.bind(this))
}, MainUI.prototype._Login = function (e) {
    var a = this, t = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("account"),
        n = GetVersionCfgManager().GetValue("Channel");
    GetCmdProxy().DoCmd("!Login", {Account: t, Channel: n, Data: a._2272287617}, function (t) {
        if (!t.Result) {
            if (a.mouseEnabled = !0, t.Error == global.$Cfg.ErrorCode.ACCOUNT_BAN) return;
            if (t.Error == global.$Cfg.ErrorCode.CHANNEL_BAN) return;
            if (t.Error == global.$Cfg.ErrorCode.LOGIN_AUTH_FAILED) {
                var n = GameCommon._sfda1f63c5facab3c938382c5591e8c(t.Error, t.Detail), o = JSON.stringify(t.Detail);
                n || (n = t.Error), IsDebug() && (n = "Error:" + n + " Detail:" + o);
                var i = {
                    Title: "错误", Info: n, Buttons: [{
                        Text: gLanguage.BtnOk, OnCallback: function () {
                            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ErrorDialog"), a._CallSDKLogin()
                        }
                    }]
                };
                return GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(global.$Cfg.Common.Audios.ui_open_error_win), void GetGuiManager()._s2e22e694b9852084df200bc86f9340("MessageBoxView", i, "ErrorDialog")
            }
            if (t == -1) {
                var i = {
                    Title: gLanguage.Info,
                    Info: "" + gLanguage.ServerNotOpen,
                    Buttons: [{
                        Text: gLanguage.BtnOk, OnCallback: function () {
                        }
                    }]
                };
                GetGuiManager()._s2e22e694b9852084df200bc86f9340("MessageBoxView", i), jasmin.Error("Can not Get Sid And Gid")
            }
            return void(t.Auth || a._Login(e))
        }
        GetStorage()._s54216acbc0200500c827232db13a75("login_time", t.Timestamp), GetStorage()._s54216acbc0200500c827232db13a75("sid", t.Sid), GetStorage()._s54216acbc0200500c827232db13a75("uid", t.Uid), GetServerTimeManager().Init(t.Timestamp), Leo.SelectServerDialog_Fox._s856b24ec600fdc59d206cacba8dd7a(a._3657912215), e()
    }, {NotShowErrors: [global.$Cfg.ErrorCode.LOGIN_AUTH_FAILED]})
}, MainUI.prototype._InitTimingTask = function () {
    GetTimingTask()._s54107fed721f2f5f6636c3b2747bef(), "0" !== GetVType() && (GetTimingTask()._sec5a590bbe5beb4e916a7c4e001256({
        Name: "OnUploadTotalAttribute",
        Interval: 6e4,
        OnTask: function () {
            var e = UploadTotalAttribute._s6a4dba9453762113ae0d1467dd81b3();
            return e.Result ? void GetServerInfoInterface()._sc174bde6d00eae01fe45b52880bfb2() : e
        }
    }), GetTimingTask()._sec5a590bbe5beb4e916a7c4e001256({
        Name: "OnGetServerInfo", OnTask: function () {
            GetServerInfoInterface()._s5e4cd2532b1628cc274ecc989a5aff()
        }, Interval: 6e4
    }))
};
var MessageBoxView;
!function () {
    MessageBoxView = function () {
        MessageBoxView.super(this), this._3052671391X = this.btn1.x, this.btn1.on(Laya.Event.CLICK, this, this.OnBtn1), this.btn2.on(Laya.Event.CLICK, this, this.OnBtn2), this.btn3.on(Laya.Event.CLICK, this, this.OnBtn3)
    }, Laya.class(MessageBoxView, "MessageBoxView", MessageBoxUI), MessageBoxView.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MessageBoxUI.uiView, t)
    };
    var t = MessageBoxView.prototype;
    t.OnDoClose = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MessageBoxView")
    }, t.OnBtn1 = function () {
        this.OnDoClose(), this._10486187781 && this._10486187781()
    }, t.OnBtn3 = function () {
        this.OnDoClose(), this._10486187783 && this._10486187783()
    }, t.OnBtn2 = function () {
        this.OnDoClose(), this._10486187782 && this._10486187782()
    }, t.OnClose = function () {
        this.htmlBg.destroyChildren()
    }, t.OnShow = function (t) {
        var n = t.Info, e = t.Buttons;
        this.htmlBg.destroyChildren();
        var i = new laya.html.dom.HTMLDivElement;
        this.htmlBg.addChild(i), i.style.fontSize = 30, i.style.align = "center", i.style.color = "#613c34", i.style.width = this.htmlBg.width, i.innerHTML = n, i.y = this.htmlBg.height / 2 - 20;
        var s = this.btn1, l = this.btn2, h = this.btn3;
        1 == e.length ? (s.visible = !1, l.visible = !1, h.visible = !0, h.label = e[0].Text, this._10486187783 = e[0].OnCallback || e[0].Callback) : 2 == e.length && (s.visible = !0, l.visible = !0, h.visible = !1, s.label = e[0].Text, l.label = e[1].Text, this._10486187781 = e[0].OnCallback || e[0].Callback, this._10486187782 = e[1].OnCallback || e[1].Callback)
    }
}();

function MiracleLayer() {
    MiracleLayer.super(this), this.list_miracle.renderHandler = Laya.Handler.create(this, this.OnCreateMiracle, null, !1)
}

Laya.class(MiracleLayer, "MiracleLayer", MiracleLayerUI);
var _proto_ = MiracleLayer.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetDataTransfer().GetTable("miracle");
    this.list_miracle.array = _.toArray(e)
}, _proto_.OnCreateMiracle = function (e, a) {
    var r = e.getChildByName("img_top"), t = e.getChildByName("img_title"), i = e.getChildByName("lab_count"),
        l = e.getChildByName("lab_dec"), c = this.list_miracle.array[a],
        n = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(),
        o = GetDataTransfer().GetTableRecord("vip", n, "MaxMiracle");
    t.skin = c.NameIcon, i.text = o, l.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(c.Desc, o), r.visible = a < 2
}, _proto_.OnClose = function () {
}, _proto_._s90746ef77ff05d47cb37e68d587694 = function () {
}, MiracleLayer.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MiracleLayer.uiView, e), _.each(GetDataTransfer().GetTable("miracle"), function (a) {
        e.push(a.NameIcon)
    })
};
var MiracleTrigger;
!function () {
    MiracleTrigger = function () {
        MiracleTrigger.super(this), this.bg.on(Laya.Event.CLICK, this, function () {
        })
    }, Laya.class(MiracleTrigger, "MiracleTrigger", MiracleTriggerUI), MiracleTrigger.GetPreLoadResList = function (i) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MiracleTriggerUI.uiView, i)
    }, MiracleTrigger._sabbe27d79486b625a06ed3d6ebdec5 = function (i) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("MiracleTrigger", i, null, {useMgrEffect: !1, isModal: !1})
    };
    var i = MiracleTrigger.prototype;
    i._sa1b52eedc94aadc5ddb422009368b9 = function () {
        this.img_TitleBg.x = -300, this.img_FontBg.y = 149, this.img_FontBg.visible = !1, this.img_1.visible = !1, this.img_2.visible = !1
    }, i.OnClose = function () {
        this._sa1b52eedc94aadc5ddb422009368b9()
    }, i.OnShow = function (i) {
        this._855224519 = i.MiracleId, this._197690947 = i.MiracleCnt || 1, this._UpdateView()
    }, i._UpdateView = function () {
        this._197690947--, this._sa1b52eedc94aadc5ddb422009368b9();
        var i = global.$Sys.GetTableService().GetTableRecord("miracle", this._855224519);
        this.img_2.skin = i.NameIcon2, Laya.Tween.to(this.img_TitleBg, {x: 85}, 500, Laya.Ease.backOut, Laya.Handler.create(this, this.OnStage2))
    }, i.OnStage2 = function () {
        this.img_1.visible = !0, Laya.Tween.from(this.img_1, {
            scaleX: 2,
            scaleY: 2
        }, 200, Laya.Ease.backOut, Laya.Handler.create(this, function () {
            this.img_2.visible = !0, Laya.Tween.from(this.img_2, {
                scaleX: 2,
                scaleY: 2
            }, 200, Laya.Ease.backOut, Laya.Handler.create(this, this.OnStage3))
        }))
    }, i.OnStage3 = function () {
        var i = global.$Sys.GetTableService().GetTableRecord("miracle", this._855224519);
        this.lab_Font.text = i.Text, this.img_FontBg.visible = !0, Laya.Tween.from(this.img_FontBg, {
            alpha: .4,
            y: 250
        }, 300, Laya.Ease.backOut, Laya.Handler.create(this, function () {
            this._197690947 > 0 ? this._UpdateView() : Laya.timer.once(300, this, function () {
                GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("MiracleTrigger")
            })
        }.bind(this)))
    }
}();
var ModuleOpenDialog;
!function () {
    ModuleOpenDialog = function () {
        ModuleOpenDialog.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._260265367 = new ModuleOpenLayer, this._260265367.width = 550, this._260265367.height = 760, this.spr_view.addChild(this._260265367)
    }, Laya.class(ModuleOpenDialog, "ModuleOpenDialog", ModuleOpenDialogUI);
    var e = ModuleOpenDialog.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._260265367._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ModuleOpenDialog")
    }, e.OnClose = function () {
    }, ModuleOpenDialog.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ModuleOpenDialog.uiView, e)
    }
}();

function ModuleOpenLayer() {
    ModuleOpenLayer.super(this), this.list_lock.renderHandler = Laya.Handler.create(this, this.OnCreateLockModule, null, !1), this.list_open.renderHandler = Laya.Handler.create(this, this.OnCreateOpenModule, null, !1), this.panel_module.vScrollBarSkin = null
}

Laya.class(ModuleOpenLayer, "ModuleOpenLayer", ModuleOpenLayerUI);
var _proto_ = ModuleOpenLayer.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = GetDataTransfer().GetTable("module_open"), t = [], a = [];
    _.each(e, function (e) {
        var o = e.Condition;
        if (o) {
            var l = GetAssetManager()._sf591a4a71c68d6c62f9d5c59258ec3(o[0], o[1], o[2]);
            l.Result ? a.push(e) : t.push(e)
        }
    }), this.list_lock.array = t, this.list_open.array = a, this.list_lock.repeatY = t.length, this.list_open.repeatY = a.length, this.box_lock.height = this.list_lock.height + 50, this.box_open.height = this.list_open.height + 50, this.vBox_module.refresh(), this.panel_module.refresh()
}, _proto_.OnCreateLockModule = function (e, t) {
    var a = e.getChildByName("lab_moduleName"), o = e.getChildByName("lab_condition"),
        l = e.getChildByName("lab_detail"), i = this.list_lock.array[t];
    a.text = i.ModuleName, o.text = i.ConditionDetail, l.text = i.ModuleDetail
}, _proto_.OnCreateOpenModule = function (e, t) {
    var a = e.getChildByName("lab_moduleName"), o = e.getChildByName("lab_detail"), l = this.list_open.array[t];
    a.text = l.ModuleName, o.text = l.ModuleDetail
}, _proto_.OnClose = function () {
}, _proto_._s90746ef77ff05d47cb37e68d587694 = function () {
}, ModuleOpenLayer.GetPreLoadResList = function (e) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ModuleOpenLayer.uiView, e)
};

function OfficeUpInfo() {
    OfficeUpInfo.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_limit.renderHandler = Laya.Handler.create(this, this.OnCreateLimitLab, null, !1), this._1923706969 = this.img_bg.x, this._839347768 = this.img_bg.y
}

Laya.class(OfficeUpInfo, "OfficeUpInfo", OfficeUpInfoUI);
var _proto_ = OfficeUpInfo.prototype;
_proto_.OnShow = function (e) {
    this._4122736007 = e, this._2430007783 = !1, this._s4fb507d6d0f40b2d2a72f6007a938d()
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    var e = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        a = GetDataTransfer().GetTableRecord("office", e),
        i = ["UnLockHero", "MaxMoneyCount", "MaxFoodCount", "MaxSoldierCount", "MaxAffairsCount", "Salary"], t = [],
        l = 1;
    for (var o in i) if (a[i[o]] && "-" != a[i[o]]) {
        var n = a[i[o]];
        "UnLockHero" == i[o] && (n = GetDataTransfer().GetTableRecord("hero", n).HeroName);
        var r = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.OfficeUpInfo[i[o]], l + ":", n);
        l++, t.push(r)
    }
    this.list_limit.array = t, this.img_office.skin = a.OfficeIcon, this.img_hero.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, a.Clothing);
    var s = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
        m = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
        c = global.$Cfg.Common.HeadIconName[s][m];
    this.img_head.skin = c, this.img_title.skin = a.LvUpIcon, this.img_hand.skin = 1 == s ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand;
    var f = new Leo.ImageActionManager({Image: this.img_lignt1});
    f._sc95f42251335b3aa0013090797aec9("Rotate", {Inversion: !1, Time: 2e4});
    var _ = new Leo.ImageActionManager({Image: this.img_lignt2});
    _._sc95f42251335b3aa0013090797aec9("Rotate", {
        Inversion: !0,
        Time: 2e4
    }), f._s2e4033b88e999ce7271844dbf3b2dc(), _._s2e4033b88e999ce7271844dbf3b2dc(), this._33211662182 = _, this._33211662181 = f, this.OnPlayOpenEffect()
}, _proto_.OnPlayOpenEffect = function () {
    var e = this;
    e.img_artFont1.visible = !1, e.img_artFont2.visible = !1, e.img_artFont3.visible = !1, e.img_artFont4.visible = !1, e.img_seal.visible = !1, e.img_title.visible = !1, e.list_limit.visible = !1, e.img_office.visible = !1, e.img_limit.visible = !1, e.mouseEnabled = !1, async.waterfall([function (a) {
        e.OnTweenToShow(e.img_artFont1), Laya.timer.once(200, this, function () {
            !e._2430007783 && e.OnTweenToShow(e.img_artFont2)
        }), Laya.timer.once(400, this, function () {
            !e._2430007783 && e.OnTweenToShow(e.img_artFont3)
        }), Laya.timer.once(600, this, function () {
            !e._2430007783 && e.OnTweenToShow(e.img_artFont4)
        }), Laya.timer.once(800, this, a, [e._2430007783])
    }, function (a) {
        e.img_title.visible = !0, e.list_limit.visible = !0, e.img_limit.visible = !0, e.img_title.centerX = 0;
        var i = (e.img_title.width + Laya.stage.width) / 2;
        Laya.Tween.from(e.img_title, {centerX: i}, 400, null), i = -(e.list_limit.width + Laya.stage.width) / 2;
        var t = [e.img_limit];
        jasmin._s3c96e1f3bee730222501b208d50190(t, e.list_limit.cells), _.each(t, function (t, l) {
            0 == l ? t.centerX = -155 : t.centerX = 0, Laya.Tween.from(t, {centerX: i}, 400 + 100 * parseInt(l), null, Laya.Handler.create(e, function (i) {
                i == e.list_limit.cells.length - 1 && a(e._2430007783)
            }, [l]))
        })
    }, function (a) {
        e._2430007783 || (e.img_seal.alpha = 1, e.OnTweenToShow(e.img_seal, function () {
            GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_yinzhang), e.img_office.visible = !0;
            var i = [{x: e._1923706969 + 10, y: e._839347768 + 10}, {
                x: e._1923706969 - 10,
                y: e._839347768 - 10
            }, {x: e._1923706969, y: e._839347768}];
            e._3662974371 || (e._3662974371 = new Laya.TimeLine, e._3662974371.addLabel("1", 0).to(e.img_bg, i[0], 100, null, 0).addLabel("2", 0).to(e.img_bg, i[1], 100, null, 0).addLabel("3", 0).to(e.img_bg, i[2], 100, null, 0)), e._3662974371.play(0, !1), Laya.Tween.to(e.img_seal, {alpha: 0}, 800, Laya.Ease.backIn, Laya.Handler.create(e, a, [e._2430007783]))
        }, Laya.Ease.expoIn, 500))
    }], function () {
        Laya.Tween.clearAll(e.img_artFont1), Laya.Tween.clearAll(e.img_artFont2), Laya.Tween.clearAll(e.img_artFont3), Laya.Tween.clearAll(e.img_artFont4), Laya.Tween.clearAll(e.img_title), Laya.Tween.clearAll(e.img_office), Laya.Tween.clearAll(e.list_limit), Laya.Tween.clearAll(e.img_bg), Laya.Tween.clearAll(e.img_seal);
        var a = [e.img_limit];
        jasmin._s3c96e1f3bee730222501b208d50190(a, e.list_limit.cells), _.each(a, function (e) {
            Laya.Tween.clearAll(e)
        }), e.mouseEnabled = !0
    })
}, _proto_.OnTweenToShow = function (e, a, i, t) {
    if (!this._2430007783) {
        var l = t || 1e3, o = i || Laya.Ease.elasticOut;
        e.visible = !0, e.scaleX = 1, e.scaleY = 1, Laya.Tween.from(e, {
            scaleX: 3,
            scaleY: 3
        }, l, o, Laya.Handler.create(this, function () {
            a && a(this._2430007783)
        }))
    }
}, _proto_.OnCreateLimitLab = function (e, a) {
    var i = e.getChildByName("ui_labLimit");
    i.text = e.dataSource
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("OfficeUpInfo")
}, _proto_.OnClose = function () {
    var e = this._33211662181;
    e._s54107fed721f2f5f6636c3b2747bef();
    var a = this._33211662182;
    a._s54107fed721f2f5f6636c3b2747bef(), this._2430007783 = !0
}, OfficeUpInfo.GetPreLoadResList = function (e) {
    var a = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        i = GetDataTransfer().GetTableRecord("office", a);
    e.push(i.LvUpIcon), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(OfficeUpInfo.uiView, e);
    var a = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        i = GetDataTransfer().GetTableRecord("office", a);
    e.push(jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing));
    var t = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
        l = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
        o = global.$Cfg.Common.HeadIconName[t][l];
    e.push(o)
};
var OfficialRankUp;
!function () {
    OfficialRankUp = function () {
        OfficialRankUp.super(this), this.ui_btnClose.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.ui_btnOfficialUp.on(Laya.Event.CLICK, this, this.OnBtnOfficialUpClick), this.ui_listCurLimit.renderHandler = Laya.Handler.create(this, this.OnCreateLimitLab, null, !1), this.ui_listUpLimit.renderHandler = Laya.Handler.create(this, this.OnCreateLimitLab, null, !1)
    }, Laya.class(OfficialRankUp, "OfficialRankUp", OfficialRankUpUI), OfficialRankUp.PLAYTIME = 1e3;
    var a = OfficialRankUp.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a || {}, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a, e = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            i = GetDataTransfer().GetTableRecord("office", e);
        a = e < global.$Cfg.Common.MaxOffice ? GetDataTransfer().GetTableRecord("office", e + 1) : i;
        var t = ["UnLockHero", "MaxMoneyCount", "MaxFoodCount", "MaxSoldierCount", "MaxAffairsCount", "Salary"], n = [],
            o = [], l = 1, r = 1;
        for (var f in t) {
            if (i[t[f]]) {
                var s = i[t[f]];
                "UnLockHero" == t[f] && (s = GetDataTransfer().GetTableRecord("hero", s).HeroName);
                var u = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.OfficeUpInfo[t[f]], l + ":", s);
                l++, n.push(u)
            }
            if ("-" != a[t[f]] && 0 != a[t[f]]) {
                var s = a[t[f]];
                "UnLockHero" == t[f] && (s = GetDataTransfer().GetTableRecord("hero", s).HeroName);
                var u = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.OfficeUpInfo[t[f]], r + ":", s);
                r++, o.push(u)
            }
        }
        this.ui_listCurLimit.array = n, this.ui_listUpLimit.array = o, this.img_curOffice.skin = i.OfficeIcon, this.img_upOffice.skin = a.OfficeIcon, this.ui_imgCurClothes.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing), this.ui_imgUpClothes.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, a.Clothing);
        var c = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
            h = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
            C = global.$Cfg.Common.HeadIconName[c][h];
        this.ui_imgCurHeadIcon.skin = C, this.ui_imgUpHeadIcon.skin = C, this.img_hand1.skin = 1 == c ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, this.img_hand2.skin = 1 == c ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, this._sc3adbecf8e393df3c46a024200461c()
    }, a._sc3adbecf8e393df3c46a024200461c = function (a, e) {
        var i = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            t = GetDataTransfer().GetTableRecord("office", i);
        if (i < global.$Cfg.Common.MaxOffice) {
            this.ui_hboxExp.visible = !0, this.ui_btnOfficialUp.disabled = !1;
            var n = global.$Api.QueryDataSource("DataBase").GetValue("Exp"), o = t.NeedExp;
            this.ui_labCurExp.text = n, this.ui_labNeedExp.text = o, this.ui_hboxExp.refresh();
            a ? Laya.Tween.to(this.ui_barExp, {value: n / o}, OfficialRankUp.PLAYTIME * (1 - n / o), null, Laya.Handler.create(this, function () {
                e && e()
            })) : this.ui_barExp.value = n / o
        } else this.ui_btnOfficialUp.disabled = !0, a ? Laya.Tween.to(this.ui_barExp, {value: 0}, OfficialRankUp.PLAYTIME, null, Laya.Handler.create(this, function () {
            e && e(), this.ui_hboxExp.visible = !1
        })) : (this.ui_barExp.value = 0, e && e())
    }, a.OnClose = function () {
    }, a.OnBtnCloseClick = function () {
        this._4122736007.OnClose && jasmin._s712167db7f08127d6dec4aed0f9846(this._4122736007.OnClose) ? GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PlayerInfo", {OnClose: this._4122736007.OnClose}) : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("PlayerInfo")
    }, a.OnBtnOfficialUpClick = function () {
        GetDataBaseInterface().DoOfficeUp({
            Callback: function () {
                this._sc3adbecf8e393df3c46a024200461c(), GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_win), GetGuiManager()._s2e22e694b9852084df200bc86f9340("OfficeUpInfo", {}, null, {}), this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)
        })
    }, a.OnCreateLimitLab = function (a, e) {
        var i = a.getChildByName("ui_labLimit");
        i.text = a.dataSource
    }, OfficialRankUp.GetPreLoadResList = function (a, e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(OfficialRankUp.uiView, a);
        var i = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            t = GetDataTransfer().GetTableRecord("office", i);
        if (a.push(jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, t.Clothing)), i < global.$Cfg.Common.MaxOffice) {
            var n = GetDataTransfer().GetTableRecord("office", i + 1);
            a.push(jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, n.Clothing))
        }
        var o = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
            l = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
            r = global.$Cfg.Common.HeadIconName[o][l];
        a.push(r)
    }
}();

function Palace() {
    Palace.super(this), this.btn_ClosePalace.on(Laya.Event.CLICK, this, this.OnClickClose), this.btn_Worship.on(Laya.Event.CLICK, this, function (e) {
        this._s09da3186077c6f64dbaf776405efb0(e.target)
    }), this.btn_Player.on(Laya.Event.CLICK, this, this.OnClickPlayer), this.btn_Next.on(Laya.Event.CLICK, this, this.OnClickNext), this.btn_Prev.on(Laya.Event.CLICK, this, this.OnClickPrev), this.lab_SayText.on(Laya.Event.CLICK, this, this.OnChangeSayText), this.list_King.hScrollBarSkin = null, this.list_King.renderHandler = new Laya.Handler(this, this.OnCreateBox), this.list_King.mouseHandler = new Laya.Handler(this, this.OnClickBox), this.list_King.selectHandler = new Laya.Handler(this, this.OnSelectChange)
}

var Palace;
Laya.class(Palace, "Palace", PalaceUI), Palace.OnPreLoadRes = function (e, a) {
    var t = global.$Sys.GetTableService().GetTable("throne");
    for (var i in t) {
        Laya.loader.load(t[i].ClothPath);
        break
    }
    for (var i in global.$Cfg.Common.HeadIconName) for (var n in global.$Cfg.Common.HeadIconName[i]) e.push(global.$Cfg.Common.HeadIconName[i][n]);
    e.push(global.$Cfg.Common.Palace_BoxSelectBg), e.push(global.$Cfg.Common.Palace_BoxUnSelectBg), e.push(global.$Cfg.Common.Palace_PlayerManHand), e.push(global.$Cfg.Common.Palace_PlayerWomanHand), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PalaceUI.uiView, e)
};
var _proto_ = Palace.prototype;
_proto_.OnSelectChange = function (e) {
    var a = this.list_King.selection, t = a.getChildByName("img_ArrowHead");
    t.visible = !0;
    var i = a.getChildByName("btn_King");
    i.skin = global.$Cfg.Common.Palace_BoxSelectBg, this.nowSelectIndex = e;
    var n = Math.max(this.nowSelectIndex - 2, 0);
    this.list_King.tweenTo(n, 200)
}, _proto_.OnClickBox = function (e, a) {
    e.type == Laya.Event.CLICK && this._se0897ef678b02e68eee381c13c9174(a)
}, _proto_._se0897ef678b02e68eee381c13c9174 = function (e) {
    var a = this.nowSelectIndex;
    if (a != e) {
        if (this._1726557478 = 1, Math.abs(a - e) <= 5 && void 0 != this.list_King.selection) {
            var t = this.list_King.selection, i = t.getChildByName("img_ArrowHead");
            i.visible = !1;
            var n = t.getChildByName("btn_King");
            n.skin = global.$Cfg.Common.Palace_BoxUnSelectBg
        }
        this.list_King.selectedIndex = e, Laya.Tween.clearAll(this.btn_Player), this.btn_Player.x = this.playerX, e > a ? Laya.Tween.to(this.btn_Player, {x: -(this.btn_Player.width + this.img_PlayerKingBg.width)}, 150, Laya.Ease.expoOut, Laya.Handler.create(this, this.OnPlayerReturn, [2])) : Laya.Tween.to(this.btn_Player, {x: this.width}, 150, Laya.Ease.expoOut, Laya.Handler.create(this, this.OnPlayerReturn, [1]))
    }
}, _proto_.OnPlayerReturn = function (e) {
    var a = this.list_King.selection, t = a.getChildByName("btn_King"), i = t.getChildByName("img_KingName1");
    this.img_KingName2.skin = i.skin, this._sf862f9131ef21bf36a34f88680aa03(), 2 == e ? (this.btn_Player.x = this.width, Laya.Tween.to(this.btn_Player, {x: this.playerX}, 150, Laya.Ease.expoInOut)) : (this.btn_Player.x = -(this.btn_Player.width + this.img_PlayerKingBg.width), Laya.Tween.to(this.btn_Player, {x: this.playerX}, 150, Laya.Ease.expoInOut))
}, _proto_._sf862f9131ef21bf36a34f88680aa03 = function () {
    var e = this._GetKingInfoByIndex();
    if (e && e.PlayerInfo) {
        var a = e.PlayerInfo;
        1 == a.PlayerSex ? this.img_PlayerHand.skin = global.$Cfg.Common.Palace_PlayerManHand : this.img_PlayerHand.skin = global.$Cfg.Common.Palace_PlayerWomanHand;
        var t = e.ClothPath;
        this.img_PlayerClothes.skin = t;
        var i = a.PlayerHeadId, n = global.$Cfg.Common.HeadIconName[a.PlayerSex][i];
        this.img_PlayerHead.skin = n, a.SayText ? (Laya.timer.clearAll(this.img_SayText), Laya.Tween.clearAll(this.img_SayText), this.img_SayText.alpha = 1, this.img_SayText.visible = !0, this.lab_SayText.text = a.SayText, Laya.timer.once(1e4, this.img_SayText, function () {
            Laya.Tween.to(this.img_SayText, {alpha: 0}, 1500)
        }.bind(this))) : (this.img_SayText.visible = !1, this.lab_SayText.text = null), this.img_NoPlayer.visible = !1, this.img_Player.visible = !0, this.img_NoPlayerName.visible = !1, this.lab_PlayerName.visible = !0, this.lab_PlayerName.text = a.PlayerName
    } else this.img_NoPlayer.visible = !0, this.img_Player.visible = !1, this.img_NoPlayerName.visible = !0, this.lab_PlayerName.visible = !1, this.img_NoPlayerName.skin = e.NameFontPath;
    this.img_KingName2.skin = e.FontPath
}, _proto_.OnClickNext = function () {
    this._1726557478++;
    var e = this._s86a71a56772b763c7c99a4fdfb5c65();
    return this._1726557478 > e ? void(this._1726557478 = e) : (Laya.Tween.to(this.btn_Player, {x: -(this.btn_Player.width + this.img_PlayerKingBg.width)}, 150, Laya.Ease.expoOut, Laya.Handler.create(this, this.OnPlayerReturn, [2])), void this._sf862f9131ef21bf36a34f88680aa03())
}, _proto_.OnClickPrev = function () {
    return this._1726557478--, this._1726557478 < 1 ? void(this._1726557478 = 1) : (Laya.Tween.to(this.btn_Player, {x: this.width}, 150, Laya.Ease.expoOut, Laya.Handler.create(this, this.OnPlayerReturn, [1])), void this._sf862f9131ef21bf36a34f88680aa03())
}, _proto_._s86a71a56772b763c7c99a4fdfb5c65 = function () {
    var e = this._3889805921[this.nowSelectIndex].Id, a = [];
    for (var t in this.King) this.King[t].Id == e && a.push(this.King[t]);
    return jasmin._s68574baea387d56114fc6a81d89c67(a)
}, _proto_._GetKingInfoByIndex = function () {
    var e = 1, a = this._3889805921[this.nowSelectIndex];
    for (var t in this.King) if (a.Id == this.King[t].Id) {
        if (e == this._1726557478) {
            var i = this.King[t];
            break
        }
        e++
    }
    return i
}, _proto_._s08e58a986d37164b685a7a69917e0a = function () {
    var e = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv,
        a = global.$Api.QueryDataSource("DataBase").GetValue("Exp"),
        t = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        i = global.$Api.QueryDataSource("DataLevel").GetValue("LevelId"),
        n = global.$Api.QueryDataSource("DataBeauty")._s3c6764f4e488ee747495208eef7d9b(), l = 0;
    for (var o in n) l += n[o].LoveValue;
    var r = {
        Sum: GetDataBaseInterface()._s7842729eb516eeeb510532bd527bee(),
        Force: GetDataBaseInterface()._s0482008760f4879b888db96e2ce282(),
        Brains: GetDataBaseInterface()._sdeda9d19cb6fc0e164b574762d83fc(),
        Politics: GetDataBaseInterface()._s7a4c6e9338499484ca993a94365fea(),
        Prestige: GetDataBaseInterface()._scafd8060fdaba4eb935eca3bd47fd8(),
        OfficeId: t,
        Exp: a,
        VipLv: e,
        Level: i,
        LoveValueSum: l
    };
    return r
}, _proto_.OnClickPlayer = function () {
    var e = this._GetKingInfoByIndex();
    if (null != e.PlayerInfo) {
        var a = e.PlayerInfo.PlayerId, t = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
        if (a == t) {
            var i = this._s08e58a986d37164b685a7a69917e0a();
            this._s9665286320f42f8cfafdc47e7978f9(i)
        } else GetPalaceInterface().DoGetPlayerInfo(a, function (e) {
            this._s9665286320f42f8cfafdc47e7978f9(e)
        }.bind(this))
    }
}, _proto_._s9665286320f42f8cfafdc47e7978f9 = function (e) {
    var a = this._GetKingInfoByIndex();
    e.PlayerSex = a.PlayerInfo.PlayerSex, e.PlayerHeadId = a.PlayerInfo.PlayerHeadId, GetGuiManager()._s2e22e694b9852084df200bc86f9340("PalacePlayer", {
        KingId: a.Id,
        PlayerInfo: e
    })
}, _proto_._s09da3186077c6f64dbaf776405efb0 = function (e) {
    GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), GetPalaceInterface().DoWorship(function (e) {
        e.Result && (this.btn_Worship.visible = !1, this.img_HasWorship.visible = !0, Laya.Tween.from(this.img_HasWorship, {
            scaleX: 2,
            scaleY: 2
        }, 200), GameCommon._sb95bbf091e97e2cc2b2904a7935a66(e.MiracleId), e.Rewards && GameCommon._s5d340979c9fcfd9445217570f410e4(this.img_HasWorship, GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards)), GameCommon._sd701ab0ea7b927938ca76f91a4368c({
            Texts: [gLanguage.WorshipSuccess],
            Colors: ["#ffffff"],
            FontSize: 40
        }))
    }.bind(this))
}, _proto_.OnClickClose = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
}, _proto_.OnShow = function () {
    this.img_NoPlayer.visible = !1, this.img_Player.visible = !0, this.btn_Player.centerX = 0, this.playerX = this.btn_Player.x, this._1726557478 = 1, this.King = [], this._3889805921 = [], this.waitInput = [], this._s8253daee5c9ba8e7895aafa21e8168()
}, _proto_.OnChangeSayText = function (e) {
    e.stopPropagation();
    var a = this._GetKingInfoByIndex(), t = a.Id, i = a.PlayerInfo.PlayerId;
    i == global.$Api.QueryDataSource("DataBase").GetValue("Uid") && (this.waitInput.push({
        KingId: t,
        PlayerId: i,
        Inputed: !1
    }), this.OnInputSayText())
}, _proto_.OnInputSayText = function () {
    if (!(this.waitInput.length <= 0)) {
        var e = null;
        for (var a in this.waitInput) if (!this.waitInput[a].Inputed) {
            e = this.waitInput[a];
            break
        }
        if (e) {
            var t = global.$Api.QueryDataSource("DataRecord").GetValue(["ForbidOperation", "KingSay"]);
            t || (GetGuiManager()._s2e22e694b9852084df200bc86f9340("PalaceInputSayText", {
                KingId: e.KingId,
                Callback: function (a, t) {
                    return a && "" != a && t ? void GetPalaceInterface().DoAddSayText(e.KingId, e.PlayerId, a, function (e) {
                        e.Result ? GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.PalaceInputSuccess]}) : GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(e), this.waitInput.splice(0, 1), this.OnInputSayText()
                    }.bind(this)) : (this.waitInput.splice(0, 1), void this.OnInputSayText())
                }.bind(this)
            }), e.Inputed = !0)
        }
    }
}, _proto_._s8253daee5c9ba8e7895aafa21e8168 = function () {
    GetPalaceInterface().DoGetKings(function (e) {
        this._s748e512601a290763b0d5141314307(e)
    }.bind(this))
}, _proto_._s748e512601a290763b0d5141314307 = function (e) {
    var a = global.$Api.QueryDataSource("DataBase").GetValue("Uid");
    for (var t in e) {
        var i = e[t].PlayerInfo[a], n = global.$Sys.GetTableService().GetTableRecord("throne", e[t].KingId);
        !this._1063406714 && i && n && n.ThroneLv >= global.$Cfg.Common.KingSalaryNeedLv && (this._1063406714 = !0), i && !i.SayText && n.ThroneLv >= global.$Cfg.Common.KingSayTextNeedLv && this.waitInput.push({
            KingId: e[t].KingId,
            PlayerId: i.PlayerId,
            Inputed: !1
        })
    }
    this.OnInputSayText();
    for (var l = global.$Sys.GetTableService().GetTable("throne"), o = 1; o <= _.size(l) && o <= global.$Cfg.Common.ThroneCount; o++) {
        Laya.loader.load(l[o].ClothPath), Laya.loader.load(l[o].FontPath), Laya.loader.load(l[o].NameFontPath), this._3889805921.push(l[o]);
        var i = null;
        for (var t in e) {
            var r = e[t];
            if (r.KingId == o) {
                for (var s in r.PlayerInfo) i = r.PlayerInfo[s], this.King.push({
                    ClothPath: l[o].ClothPath,
                    FontPath: l[o].FontPath,
                    Name: l[o].Name,
                    NameFontPath: l[o].NameFontPath,
                    Id: l[o].Id,
                    PlayerInfo: i
                });
                break
            }
        }
        var h = this.King.length;
        (0 == h || this.King[h - 1] && this.King[h - 1].Id < o) && this.King.push({
            ClothPath: l[o].ClothPath,
            FontPath: l[o].FontPath,
            Name: l[o].Name,
            NameFontPath: l[o].NameFontPath,
            Id: l[o].Id,
            PlayerInfo: null
        })
    }
    this._sc9209ae0dd3fdb06533b36ec4474b1()
}, _proto_._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
    this.lab_textFun.text = gLanguage.FunText, this.lab_textOffice.text = gLanguage.OfficeText, this.lab_textSalary.text = gLanguage.SalaryText, this.btn_Worship.text = gLanguage.WorshipText;
    var e = this._sbd9c50d56b1fbc498d09ea5ab602b8();
    if (this.lab_OfficeName.text = e.OfficeName, this._1063406714) {
        var a = global.$Sys.GetTableService().GetTableRecord("reward", gCfg.PalaceKingSalary);
        this.lab_Salary.text = a.Award[0][2] + gLanguage.UnitText
    } else this.lab_Salary.text = e.Salary + gLanguage.UnitText;
    this.list_King.array = this._3889805921, void 0 == this.nowSelectIndex && (this.nowSelectIndex = 0), 0 != global.$Api.QueryDataSource("DataDailyRecord")._scc5bc48a87f577d371d77cfc293711("PalaceWorship") ? (this.btn_Worship.visible = !1, this.img_HasWorship.visible = !0) : (this.btn_Worship.visible = !0, this.img_HasWorship.visible = !1), this._sf862f9131ef21bf36a34f88680aa03()
}, _proto_.OnCreateBox = function (e, a) {
    var t = this.list_King.array[a], i = e.getChildByName("img_ArrowHead"), n = e.getChildByName("btn_King");
    this.nowSelectIndex == a ? (n.skin = global.$Cfg.Common.Palace_BoxSelectBg, i.visible = !0) : (n.skin = global.$Cfg.Common.Palace_BoxUnSelectBg, i.visible = !1);
    var l = n.getChildByName("img_KingName1");
    l.skin = t.FontPath
}, _proto_._sbd9c50d56b1fbc498d09ea5ab602b8 = function () {
    var e = global.$Api.QueryDataSource("DataBase")._2552118236.Office,
        a = global.$Sys.GetTableService().GetTableRecord("office", e);
    return a
};

function PalaceInputSayText() {
    PalaceInputSayText.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
        this.Callback && this.Callback(this.textArea_SayText.text, 0), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PalaceInputSayText")
    }), this.btn_OK.on(Laya.Event.CLICK, this, this.OnClickOK)
}

var PalaceInputSayText;
Laya.class(PalaceInputSayText, "PalaceInputSayText", PalaceInputSayTextUI);
var _proto_ = PalaceInputSayText.prototype;
PalaceInputSayText.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PalaceInputSayText.uiView, t)
}, _proto_.OnShow = function (t) {
    this.Callback = t.Callback, this.textArea_SayText.text = "";
    var a = global.$Sys.GetTableService().GetTableRecord("throne", t.KingId);
    this.lab_InputKingName.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.PalaceInput, a.Name)
}, _proto_.OnClickOK = function () {
    var t = Leo.GetDirtyWordsFilter()._s95d3edab3bfd008f58b6e1b086ebca(this.textArea_SayText.text);
    return t ? (this.Callback && this.Callback(this.textArea_SayText.text, 1), void GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PalaceInputSayText")) : void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.TextError]})
};

function PalacePlayer() {
    PalacePlayer.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnClickClose)
}

var PalacePlayer;
Laya.class(PalacePlayer, "PalacePlayer", PalacePlayerUI);
var _proto_ = PalacePlayer.prototype;
PalacePlayer.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PalacePlayer.uiView, a)
}, _proto_.OnShow = function (a) {
    this._4122736007 = a;
    var e = global.$Sys.GetTableService().GetTableRecord("throne", this._4122736007.KingId);
    Laya.loader.load(e.ClothPath, Laya.Handler.create(this, function () {
        this.img_Cloth.skin = e.ClothPath
    })), Laya.loader.load(e.FontPath, Laya.Handler.create(this, function () {
        this.img_KingName.skin = e.FontPath
    }));
    var l = this._4122736007.PlayerInfo;
    1 == l.PlayerSex ? Laya.loader.load(global.$Cfg.Common.Palace_PlayerManHand, Laya.Handler.create(this, function () {
        this.img_Hand.skin = global.$Cfg.Common.Palace_PlayerManHand
    })) : Laya.loader.load(global.$Cfg.Common.Palace_PlayerWomanHand, Laya.Handler.create(this, function () {
        this.img_Hand.skin = global.$Cfg.Common.Palace_PlayerWomanHand
    }));
    var t = l.PlayerHeadId, i = global.$Cfg.Common.HeadIconName[l.PlayerSex][t];
    Laya.loader.load(i, Laya.Handler.create(this, function () {
        this.img_Head.skin = i
    })), this._s55b947627a9c6a8e673afeca2d9df4(this._4122736007.PlayerInfo)
}, _proto_._s55b947627a9c6a8e673afeca2d9df4 = function (a) {
    this.lab_WuLi.text = gLanguage.Force + ":", this.lab_ZhiLi.text = gLanguage.Brains + ":", this.lab_ZhengZhi.text = gLanguage.Politics + ":", this.lab_WeiWang.text = gLanguage.Prestige + ":", this.lab_ZhengJi.text = gLanguage.Exp + ":", this.lab_GuanKa = gLanguage.PalacePlayerCoStom + ":", this.lab_QinMi = gLanguage.PalacePlayerLove + ":", this.lab_GuanPin = gLanguage.PalacePlayerOffice + ":";
    var e = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, a.VipLv);
    Laya.loader.load(e, Laya.Handler.create(this, function () {
        this.img_Vip.skin = e
    })), this.lab_ShiLiValue.text = a.Sum, this.lab_WuLiValue.text = a.Force, this.lab_ZhiLiValue.text = a.Brains, this.lab_ZhengZhiValue.text = a.Politics, this.lab_WeiWangValue.text = a.Prestige, this.lab_ZhengJiValue.text = a.Exp, this.lab_QinMiValue.text = a.LoveValueSum;
    var l = global.$Sys.GetTableService().GetTableRecord("office", a.OfficeId).OfficeName;
    this.lab_GuanPinValue.text = l;
    var t = global.$Sys.GetTableService().GetTableRecord("level", a.Level).Name;
    this.lab_GuanKaValue.text = a.Level + "." + t
}, _proto_.OnClickClose = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PalacePlayer")
};

function PlayerBanquetInfo() {
    PlayerBanquetInfo.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_find.on(Laya.Event.CLICK, this, this.OnBtnFindClick)
}

Laya.class(PlayerBanquetInfo, "PlayerBanquetInfo", PlayerBanquetInfoUI);
var _proto_ = PlayerBanquetInfo.prototype;
_proto_.OnShow = function (t) {
    this._4122736007 = t, this.box_info.visible = !1, Laya.timer.loop(1e3, this, this.OnRefreshTime), this.OnRefreshTime()
}, _proto_.OnClose = function () {
    Laya.timer.clearAll(this)
}, _proto_.OnBtnCloseClick = function () {
    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PlayerBanquetInfo")
}, _proto_.OnBtnJoinClick = function (t, e) {
    e ? (GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("BanquetScene", t), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PlayerBanquetInfo")) : GameCommon._sd701ab0ea7b927938ca76f91a4368c({
        Texts: ["宴会已结束"],
        Colors: ["#ffffff"]
    })
}, _proto_.OnBtnFindClick = function () {
    var t = this.input_id.text;
    console.log;
    var e = {USER: t, U: [global.$Api.QueryDataSource("DataBase").GetValue("Uid"), t]};
    GetDataBanquetInterface().DoFindBanqeut(e, this.OnFindFinish.bind(this))
}, _proto_.OnFindFinish = function (t) {
    if (this.box_info.visible = t.Result, t.Result) {
        var e = t.BanquetData;
        this._832264954 = e;
        var a = GetDataTransfer().GetTableRecord("banquet_type", e.Type), n = _.size(e.Guest);
        this.lab_seat.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", n, a.SeatCount), this.lab_name.text = e.UserData.Name, this.lab_type.text = a.Name, this.btn_join.offAll(Laya.Event.CLICK), this.btn_join.on(Laya.Event.CLICK, this, this.OnBtnJoinClick, [e, t.IsValid])
    }
    this._832264954 = t.BanquetData
}, _proto_.OnRefreshTime = function () {
    var t = this._832264954;
    if (t) {
        var e = GetDataTransfer().GetTableRecord("banquet_type", t.Type),
            a = t.STime + e.ExpiredTime - global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
        this.lab_time.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(a)
    }
};

function PlayerInfo() {
    PlayerInfo.super(this), this.ui_btnClose.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.ui_listInfluence.renderHandler = Laya.Handler.create(this, this.OnUpdateInfluence, null, !1), this.ui_listAssets.renderHandler = Laya.Handler.create(this, this.OnUpdateAssets, null, !1), this.ui_btnOfficialRankUp.on(Laya.Event.CLICK, this, this.OnBtnRankUpClick), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
        Node: this.ui_btnOfficialRankUp,
        NodeName: "OfficeUpBtn",
        OnCheckState: TargetCheck.OnCheckOfficeUp,
        cover: !0,
        Group: "OfficeUp",
        OnExecute: GameCommon.OnAddHeadEffect
    })
}

Laya.class(PlayerInfo, "PlayerInfo", PlayerInfoUI);
var _proto_ = PlayerInfo.prototype;
_proto_.OnShow = function (a) {
    this._4122736007 = a || {}, GetPalaceInterface().DoCheckIsKing(function (a) {
        this._s4fb507d6d0f40b2d2a72f6007a938d(a)
    }.bind(this))
}, _proto_._s4fb507d6d0f40b2d2a72f6007a938d = function (a) {
    for (var e = ["Force", "Brains", "Politics", "Prestige"], t = ["Exp", "Money", "Food", "Troops"], i = [], n = 0, o = 0; o < e.length; o++) {
        var l = {};
        l.Title = gLanguage[e[o]], l.Value = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(o + 1), n += l.Value, i.push(l)
    }
    var r = [];
    for (var s in t) {
        var l = {};
        if (l.Title = gLanguage[t[s]], l.Value = global.$Api.QueryDataSource("DataBase").GetValue(t[s]), l.Skin = gCfg.fortuneIcon[t[s]], "Exp" == t[s] && global.$Api.QueryDataSource("DataBase").GetValue("Office") < global.$Cfg.Common.MaxOffice) {
            var u = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                f = GetDataTransfer().GetTableRecord("office", u).NeedExp;
            "-" != f && (l.Value = l.Value + "/" + f)
        }
        r.push(l)
    }
    this.ui_listInfluence.array = i, this.ui_listAssets.array = r;
    var u = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        c = GetDataTransfer().GetTableRecord("office", u);
    this.ui_imgOfficialRank.skin = c.OfficeIcon, this.ui_labInfluence.text = n, u >= global.$Cfg.Common.MaxOffice ? this.ui_btnOfficialRankUp.disabled = !0 : this.ui_btnOfficialRankUp.disabled = !1, this.ui_labPlayerName.text = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName");
    var h = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex");
    if (a && a.KingId) {
        var g = global.$Sys.GetTableService().GetTableRecord("throne", a.KingId), m = g.ClothPath;
        this.ui_imgCurClothes.skin = m, this.img_hand.visible = !1, this.img_hand2.visible = !1
    } else this.img_hand2.visible = !0, this.img_hand.visible = !0, this.img_hand.skin = 1 == h ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, this.ui_imgCurClothes.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, c.Clothing);
    var C = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId");
    this.ui_imgCurHeadIcon.skin = global.$Cfg.Common.HeadIconName[h][C], this.ui_labUid.text = gLanguage.IdName + "：" + global.$Api.QueryDataSource("DataBase").GetValue("Uid").substr(0, 15);
    var d = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1();
    this.ui_VipLv.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, d)
}, _proto_.OnClose = function () {
}, _proto_.OnBtnCloseClick = function () {
    this._4122736007.OnClose && jasmin._s712167db7f08127d6dec4aed0f9846(this._4122736007.OnClose) ? this._4122736007.OnClose() : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
}, _proto_.OnUpdateInfluence = function (a, e) {
    var t = a.getChildByName("ui_labTitle"), i = a.getChildByName("ui_labValue");
    t.text = a.dataSource.Title, i.text = a.dataSource.Value
}, _proto_.OnUpdateAssets = function (a, e) {
    var t = a.getChildByName("ui_labTitle"), i = a.getChildByName("ui_labValue"), n = a.getChildByName("ui_imgIcon");
    t.text = a.dataSource.Title, i.text = a.dataSource.Value, n.skin = a.dataSource.Skin
}, _proto_.OnBtnRankUpClick = function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("OfficialRankUp", {OnClose: this._4122736007.OnClose})
}, PlayerInfo.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PlayerInfoUI.uiView, a);
    for (var e in global.$Cfg.Common.fortuneIcon) a.push(global.$Cfg.Common.fortuneIcon[e]);
    var t = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
        i = GetDataTransfer().GetTableRecord("office", t);
    a.push(jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing));
    var n = global.$Api.QueryDataSource("DataBase").GetValue("PlayerSex"),
        o = global.$Api.QueryDataSource("DataBase").GetValue("PlayerHeroHeadId"),
        l = global.$Cfg.Common.HeadIconName[n][o];
    a.push(l)
};
var PrisonerInfo;
!function () {
    PrisonerInfo = function () {
        PrisonerInfo.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
    }, Laya.class(PrisonerInfo, "PrisonerInfo", PrisonerInfoUI);
    var e = PrisonerInfo.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = this._4122736007.PrisonerId, r = GetDataTransfer().GetTableRecord("prisoner", e);
        this.lab_prisoner.text = r.PrisonerName, GameCommon._sf6fcc5a5f43833128a7bdc3720f01f(this.img_prisoner, e);
        var n = GetDataTransfer().GetTableRecord("consume", r.Consume).Consume[0];
        this.lab_consume.text = n[2], this.lab_max.text = r.MaxFightCount;
        var o = GetDataTransfer().GetTableRecord("reward", r.Reward).Award;
        o = GetDataTransfer()._s31a203589c4395257a9214becf0195({Reward: o});
        var a = "";
        _.each(o, function (e) {
            a += GameCommon._sf0a0854e48d4ebc005e689b65b3673(e[0], e[1]), a += "、"
        }), this.lab_reward.text = a
    }, e.OnClose = function () {
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("PrisonerInfo")
    }, PrisonerInfo.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PrisonerInfo.uiView, e)
    }
}();
var PrisonPage;
!function () {
    PrisonPage = function () {
        PrisonPage.super(this), this._2091536629 = 0, this.list_prisoner.renderHandler = Laya.Handler.create(this, this.OnCreatePrisoner, null, !1), this.list_prisoner.hScrollBarSkin = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.img_prisoner.on(Laya.Event.CLICK, this, this.OnBtnPrisonerClick), this.btn_quickPunish.on(Laya.Event.CLICK, this, this.OnBtnQuickPunishClick), this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Prison"})
        });
        var e = new Leo.ImageActionManager({Image: this.img_click});
        e._sc95f42251335b3aa0013090797aec9("Breather", {
            ScaleX: 1.2,
            ScaleY: 1.2,
            BreatherTime: 2e3
        }), this._1923706969 = this.img_bg.x, this._839347768 = this.img_bg.y, this._1221692952 = e, this._686431888 = []
    }, Laya.class(PrisonPage, "PrisonPage", PrisonPageUI);
    var e = PrisonPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d(), this._1221692952._s2e4033b88e999ce7271844dbf3b2dc()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            i = global.$Api.QueryDataSource("DataPrison")._sba6e2ae2243d38379cdfd08249a28a(e),
            a = global.$Api.QueryDataSource("DataPrison")._sf49f1b34b52d018fa63fe5de748f96();
        this.lab_renown.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", i, 2 * a), this.lab_dailyRenown.text = a;
        var n = this._sbe0a821db65d2fb9a71a6eeb4842b8();
        this.img_prisoner.visible = !!n, this.img_click.visible = !!n, this.progress_hp.visible = !!n, this.img_NameBg.visible = !!n, this.box_NoPrison.visible = !n;
        for (var t = global.$Api.QueryDataSource("DataPrison")._s2801a9c50d15d3db2b0c4444c7c489(), r = jasmin._sdf8385ff3a74421ea218e043d47fdc(t), o = t.length; o < this.list_prisoner.repeatX; o++) r.push(0);
        if (this.list_prisoner.array = r, !n) return void jasmin.Debug("No Prisoner!!!");
        var s = this._sf483ab4306673633027b22362565de(n);
        this._2091536629 = n, 0 == s && this._sb31bcd636fb4b053e6cb5f9f80af1c(n);
        var l = global.$Sys.GetTableService().GetTableRecord("prisoner", this._2091536629), h = l.PrisonerPath;
        this.img_prisoner.skin = h[0], this.img_name.skin = l.NamePath;
        var c = t.indexOf(n);
        this.progress_hp.value = 1 - s, this.lab_hp.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.BossHp, jasmin._s055f1fab493a7ba1f1a5a9014b1fa0(100 * (1 - s))), this.lab_prisonerIdx.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", c + 1, t.length);
        var u = global.$Api.QueryDataSource("DataPrison")._s44cc03443d0fed2546b962e59ed896();
        this.btn_quickPunish.visible = u, this.lab_quickPunish.visible = !u
    }, e.OnCreatePrisoner = function (e, i) {
        var a = e.getChildByName("img_frame"), n = a.getChildByName("img_headIcon"),
            t = e.getChildByName("img_unknown"), r = e.getChildByName("img_finish"), o = this.list_prisoner.array[i];
        if (o ? GameCommon._s1ab45747cb8dc3a591caf39a095e08(n, o) : n.skin = "", t.visible = !o, r.visible = o && 1 == this._sf483ab4306673633027b22362565de(o), !a.ImgAction) {
            var s = new Leo.ImageActionManager({Image: a});
            s._sc95f42251335b3aa0013090797aec9("Breather", {
                ScaleX: 1.1,
                ScaleY: 1.1,
                BreatherTime: 1e3
            }), a.ImgAction = s, this._686431888.push(s)
        }
        0 != o && (this._2091536629 == o ? a.ImgAction._s2e4033b88e999ce7271844dbf3b2dc() : (a.ImgAction._s54107fed721f2f5f6636c3b2747bef(), a.ScaleX = 1, a.ScaleY = 1)), e.offAll(Laya.Event.CLICK), e.on(Laya.Event.CLICK, this, this.OnShowPrisonerInfo, [o])
    }, e.OnShowPrisonerInfo = function (e) {
        e && GetGuiManager()._s2e22e694b9852084df200bc86f9340("PrisonerInfo", {PrisonerId: e})
    }, e._sb31bcd636fb4b053e6cb5f9f80af1c = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("DetainDialog", {PrisonerId: e}, null, {
            popupEffect: function (e, i) {
                var a = Laya.Tween.from(e, {
                    y: e.y - 100,
                    alpha: 0
                }, 1e3, Laya.Ease.backOut, Laya.Handler.create(null, i));
                return e.alpha = 0, a
            }
        })
    }, e._sbe0a821db65d2fb9a71a6eeb4842b8 = function () {
        var e = GetDataTransfer().GetTable("prisoner"),
            i = global.$Api.QueryDataSource("DataPrison")._s2801a9c50d15d3db2b0c4444c7c489(),
            a = _.find(i, function (i) {
                var a = global.$Api.QueryDataSource("DataPrison")._s4f543b550e8066c42abf48e5a53bc1(i);
                return a < e[i].MaxFightCount
            });
        return a
    }, e._sf483ab4306673633027b22362565de = function (e) {
        var i = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            a = GetDataTransfer().GetTableRecord("prisoner", e).MaxFightCount,
            n = global.$Api.QueryDataSource("DataPrison")._s4f543b550e8066c42abf48e5a53bc1(e, i);
        return n / a
    }, e.OnBtnQuickPunishClick = function () {
        var e = {};
        e.Callback = function (e) {
            this.OnShowReward(e, "Quick")
        }.bind(this), GetDataPrisonInterface().DoQuickPunish(e)
    }, e.OnBtnPrisonerClick = function () {
        var e = {};
        e.Callback = this.OnShowReward.bind(this), GetDataPrisonInterface().DoPunish(e)
    }, e.OnShowReward = function (e, i) {
        if (e.Result) {
            this.img_dialog.alpha = 0, this.mouseEnabled = !1;
            var a = this;
            async.waterfall([function (e) {
                a.img_click.alpha = 1, Laya.Tween.to(a.img_click, {alpha: 0}, 100, null, Laya.Handler.create(this, e))
            }, function (e) {
                var n = global.$Sys.GetTableService().GetTableRecord("prisoner", a._2091536629), t = n.PrisonerPath;
                Laya.timer.once(150, a, function () {
                    a.img_prisoner.skin = t[i ? 2 : 1], Laya.timer.once(i ? 500 : 300, a, function () {
                        a.img_prisoner.skin = t[0], GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_hit), i ? a.OnScreenWobble(e) : e()
                    })
                })
            }, function (i) {
                var n = a._sf483ab4306673633027b22362565de(a._2091536629);
                Laya.Tween.to(a.progress_hp, {value: 1 - n}, 200, null), a.lab_hp.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.BossHp, jasmin._s055f1fab493a7ba1f1a5a9014b1fa0(100 * (1 - n)));
                var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards), r = [];
                _.each(t, function (e) {
                    var i = 1;
                    e[0] == global.$Cfg.CommonEnum.Asset.DataBase && (i = jasmin._sc5ff58245a4160fc0cb89f0345daf9(3, 5)), r.push({
                        Data: e,
                        Count: i
                    })
                });
                var o = {
                    EleDatas: r, OnCreateFunc: function (e) {
                        return GameCommon._s66eb52e60b9feb53711943e638c9c3(e[0], e[1], "NoBcg")
                    }
                }, s = leo.CommFunc._sb590bb9fa37b4471dd0f4e714d987a(o);
                a.img_dialog.alpha = 1;
                var l = jasmin._s449f055209cd01229b1846559026f5(gLanguage.PrisionNpcDialog);
                a.lab_dialog.text = "", GameCommon._scd195118e2b7ac8cde3e75629fcfef(a.lab_dialog, l, 100, function () {
                    a.img_dialog.alpha = 0
                }), _.each(s, function (e, n) {
                    a.addChild(e);
                    var t = {
                        x: jasmin._sc5ff58245a4160fc0cb89f0345daf9(80, 500),
                        y: jasmin._sc5ff58245a4160fc0cb89f0345daf9(800, 950)
                    }, r = {x: 220, y: 870}, o = 200, l = {};
                    l.Src = r, l.Dest = t, l.Target = e, l.AutoDestroy = !1, l.Interval = 350, l.RandX = [(r.x + t.x) / 2, (r.x + t.x) / 2], l.RandY = [r.y - o - 200, r.y - 100], n == s.length - 1 && (l.Callback = i.bind(this, null, s)), Leo.TweenFactory._s2fca5de6c7365b7763ed62546c5236(l)
                });
                var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
                GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, t)
            }, function (e, i) {
                _.each(e, function (n, t) {
                    n.alpha = 1, Laya.Tween.to(n, {alpha: 0}, 200, Laya.Ease.backIn, Laya.Handler.create(a, function () {
                        n.removeSelf(), n.destroy(), t == e.length - 1 && i()
                    }))
                })
            }, function (e) {
                Laya.Tween.to(a.img_click, {alpha: 1}, 200, null, Laya.Handler.create(a, e))
            }], function (e) {
                this.mouseEnabled = !0;
                var i = this._sf483ab4306673633027b22362565de(this._2091536629);
                1 == i && GameCommon._sd701ab0ea7b927938ca76f91a4368c({
                    Texts: [gLanguage.PrisionFinsih],
                    Colors: ["#ffffff"]
                }), this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this))
        }
    }, e.OnPlayEffect = function (e, i) {
        var a, n = i ? "res/effect/langya.sk" : "res/effect/daban.sk", t = this.spr_plank, r = new Laya.Templet;
        r.on(Laya.Event.COMPLETE, this, function () {
            a = r.buildArmature(0), t.addChild(a), a.on(Laya.Event.STOPPED, this, function () {
                r.destroy(), e()
            }), a.play(0, !1)
        }), r.loadAni(n)
    }, e.OnScreenWobble = function (e) {
        var i = [{x: this._1923706969 + 5, y: this._839347768 + 5}, {
            x: this._1923706969 - 5,
            y: this._839347768 - 5
        }, {x: this._1923706969, y: this._839347768}];
        this._3662974371 || (this._3662974371 = new Laya.TimeLine, this._3662974371.addLabel("1", 0).to(this.img_bg, i[0], 50, null, 0).addLabel("2", 0).to(this.img_bg, i[1], 50, null, 0).addLabel("3", 0).to(this.img_bg, i[2], 50, null, 0)), this._3662974371.play(0, !1), Laya.timer.once(150, this, e)
    }, e.OnBtnCloseClick = function (e) {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }, PrisonPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(PrisonPage.uiView, e)
    }, e.OnClose = function () {
        _.each(this._686431888, function (e) {
            e._s54107fed721f2f5f6636c3b2747bef()
        }), this._686431888 = [], this._1221692952._s54107fed721f2f5f6636c3b2747bef()
    }
}();
var Rank;
!function () {
    Rank = function () {
        Rank.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.btn_Worship.on(Laya.Event.CLICK, this, this.OnWorship), this.radio_ListType.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = {}, this.list_rank.vScrollBarSkin = null, this._3646161293 = 0
    }, Laya.class(Rank, "Rank", RankUI);
    var e = Rank.prototype;
    Rank.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(Rank.uiView, e)
    }, e._s57549bd6a03784ed4b3bad03859135 = function (e) {
        this._1092471860Data ? this._s4fb507d6d0f40b2d2a72f6007a938d(e) : this.OnGetRank(), this._sa62401623cc0d5fe321f25c9a193e8(e)
    }, e._sa62401623cc0d5fe321f25c9a193e8 = function (e) {
        var a = {RankIdx: this.radio_ListType.selectedIndex}, t = RankWorship._s6a4dba9453762113ae0d1467dd81b3(a);
        t.Result ? (this.btn_Worship.visible = !0, this.img_HasWorship.visible = !1) : (this.btn_Worship.visible = !1, this.img_HasWorship.visible = !0)
    }, e.OnWorship = function () {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item);
        var e = global.$Api.QueryDataSource("DataBase").GetValue("Uid"),
            a = jasmin._s449f055209cd01229b1846559026f5(this._1092471860Data[this.radio_ListType.selectedIndex].RankList),
            t = {RankIdx: this.radio_ListType.selectedIndex, PlayerId: a, U: [e, a]},
            i = RankWorship._s6a4dba9453762113ae0d1467dd81b3(t);
        return i.Result ? void GetCmdProxy().DoCmd("RankWorship", t, function (e) {
            if (e.Result) {
                this.btn_Worship.visible = !1, this.img_HasWorship.visible = !0, GameCommon._sb95bbf091e97e2cc2b2904a7935a66(e.MiracleId), Laya.Tween.from(this.img_HasWorship, {
                    scaleX: 2,
                    scaleY: 2
                }, 200);
                var a = {};
                if (e.Rewards && (a.Rewards = e.Rewards), e.PlayerInfo) a.PlayerInfo = e.PlayerInfo, GetGuiManager()._s2e22e694b9852084df200bc86f9340("RankPlayer", a); else if (e.Rewards) {
                    var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
                    GameCommon._s5d340979c9fcfd9445217570f410e4(this, t)
                }
            }
            this._sa62401623cc0d5fe321f25c9a193e8(this.radio_ListType.selectedIndex)
        }.bind(this)) : (GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.RANK_HAS_WORSHIP}), i)
    }, e.OnGetRank = function () {
        var e = global.$Cfg.Common.RankName;
        this.radio_ListType.labels = null;
        for (var a in e) {
            a <= 1 ? this.radio_ListType.labels = "," : this.radio_ListType.labels += ",";
            var t = {};
            t.TableName = global.$Cfg.Common.RankName[a], this._s8a8ba2ea25ada6c7fa71d0c0695565(t, a)
        }
    }, e._s8a8ba2ea25ada6c7fa71d0c0695565 = function (e, a) {
        e.TableName && GetCmdProxy().DoCmd("GetRank", e, function (t) {
            if (!t.Result) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.GET_RANK_ERROR});
            this._1092471860Data[a] = t;
            var i = null;
            i = "LevelRank" == e.TableName ? function (a, t, i) {
                for (var n = global.$Sys.GetTableService().GetTable("stage"), s = 0, r = 1, o = 1, l = 0; r <= _.size(n); r++) {
                    for (o = 1; o <= _.size(n[r]); o++) if (s += n[r][o].Progress, s >= t.Score) {
                        l = n[r][o].Progress - (s - t.Score);
                        break
                    }
                    if (s >= t.Score) break
                }
                r > _.size(n) && (jasmin.Error("Level Rank Data Error"), r = _.size(n));
                var h = global.$Sys.GetTableService().GetTableRecord("level", r);
                a.text = r + "." + h.Name + "(" + o + "-" + l + ")", a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(t.Rank), "TotalAttributeRank" == e.TableName ? a.x = 510 : a.x = 448
            }.bind(this) : function (a, t, i) {
                a.text = t.Score || "-", a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(t.Rank), "TotalAttributeRank" == e.TableName ? a.x = 510 : a.x = 448
            }.bind(this);
            var n = null;
            "TotalAttributeRank" != e.TableName && (n = function (e, a, t) {
                if ("" != e.name) e.visible = !1; else {
                    e.destroyChildren(), e.visible = !0;
                    var i = null;
                    if (a.UserData && a.UserData.KingId) {
                        var n = global.$Sys.GetTableService().GetTableRecord("throne", a.UserData.KingId);
                        i = new Laya.Image(n.NameFontPath)
                    } else {
                        var s = a.UserData ? a.UserData.Office : global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                            r = global.$Sys.GetTableService().GetTableRecord("office", s).OfficeName;
                        i = new Laya.Label(r), i.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(a.Rank), i.fontSize = 23
                    }
                    i.centerX = 0, i.centerY = 0, e.addChild(i)
                }
            }.bind(this));
            var s = function (e, t, i) {
                e.text = t.UserData ? t.UserData.Name : global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), e.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(t.Rank), e.name && "" != e.name && (e.underline = !0, e.offAll(Laya.Event.CLICK), e.on(Laya.Event.CLICK, this, function () {
                    var e = this._1092471860Data[a].RankList[i];
                    GetPalaceInterface().DoGetPlayerInfo(e, function (a) {
                        a.Id = e, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", a)
                    })
                }))
            }.bind(this);
            this._1092471860Data[a].ShowTag = {
                Rank: null,
                Name: s,
                Score: i,
                Office: n
            }, 2 == a && this.radio_ListType.selectedIndex == -1 && (this.radio_ListType.selectedIndex = 0)
        }.bind(this))
    }, e._sb3df77da8dd199cc8f2c9b1b4bff73 = function (e) {
        return e && e <= 3 ? global.$Cfg.Common.RankColor[e - 1] : "#755848"
    }, e.OnShow = function () {
        var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), a = e - this._3646161293;
        (this.radio_ListType.selectedIndex == -1 || a > global.$Cfg.Common.RankUpdateTime) && (this.OnGetRank(), this._3646161293 = e), this.radio_ListType.selectedIndex != -1 && (this.radio_ListType.selectedIndex = 0, this._s4fb507d6d0f40b2d2a72f6007a938d(this.radio_ListType.selectedIndex), this._sa62401623cc0d5fe321f25c9a193e8(this.radio_ListType.selectedIndex)), GetInspection() && (this.lab_qmb.visible = !1, this.radio_ListType._childs[2].visible = !1)
    }, e.OnClose = function () {
    }, e.OnSelectType = function (e) {
        switch (e) {
            case 1:
                this.lab_RankText.text = "关卡", this.lab_ScoreText.text = "关卡：", this.lab_RankOffice.visible = !1, this.lab_RankText.x = 451;
                break;
            case 2:
                this.lab_RankText.text = "亲密度", this.lab_ScoreText.text = "亲密度：", this.lab_RankOffice.visible = !1, this.lab_RankText.x = 451;
                break;
            case 0:
                this.lab_RankText.text = "势力", this.lab_ScoreText.text = "势力：", this.lab_RankOffice.visible = !0, this.lab_RankText.x = 512;
                break;
            default:
                jasmin.Error("No Select Radio")
        }
        this._s57549bd6a03784ed4b3bad03859135(e), this.hBox.changeItems()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function (e) {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data[e])
    }
}();
var RankPlayer;
!function () {
    RankPlayer = function () {
        RankPlayer.super(this), this.on(Laya.Event.CLICK, this, function () {
            if (this.mouseEnabled = !1, this._713989164.Rewards) {
                var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._713989164.Rewards);
                GameCommon._s5d340979c9fcfd9445217570f410e4(this.lab_Reward, a), this._713989164.Rewards = null, Laya.timer.once(1e3, this, function () {
                    this.mouseEnabled = !0
                })
            } else GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RankPlayer"), this.mouseEnabled = !0
        })
    }, Laya.class(RankPlayer, "RankPlayer", RankPlayerUI);
    var a = RankPlayer.prototype;
    RankPlayer.GetPreLoadResList = function (a, e) {
        var i = e.PlayerInfo;
        if (i.KingInfo) {
            var n = global.$Sys.GetTableService().GetTableRecord("throne", i.KingInfo.KingId);
            a.push(n.FontPath), a.push(n.ClothPath)
        }
        1 == i.Sex ? a.push(global.$Cfg.Common.Palace_PlayerManHand) : a.push(global.$Cfg.Common.Palace_PlayerWomanHand);
        var t = i.HeadId, l = global.$Cfg.Common.HeadIconName[i.Sex][t];
        a.push(l), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(RankPlayer.uiView, a)
    }, a.OnShow = function (a) {
        this._713989164 = a, this.mouseEnabled = !1, this.alpha = 0, this.lab_SayText.text = "", this._sc9209ae0dd3fdb06533b36ec4474b1()
    }, a._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        var a = this._713989164.PlayerInfo;
        if (this.lab_PlayerName.text = a.Name, a.KingInfo) {
            var e = global.$Sys.GetTableService().GetTableRecord("throne", a.KingInfo.KingId);
            this.img_KingName.skin = e.FontPath, this.img_Cloth.skin = e.ClothPath, this.img_Hand.visible = !1
        } else {
            var i = global.$Sys.GetTableService().GetTableRecord("office", a.OfficeId);
            this.lab_OfficeName.text = i.OfficeName, clothPath = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing), this.img_Cloth.skin = clothPath, this.img_Hand.visible = !0
        }
        this.lab_OfficeName.visible = !a.KingInfo, this.img_KingName.visible = !this.lab_OfficeName.visible;
        var n = null;
        n = 1 == a.Sex ? global.$Cfg.Common.Palace_PlayerManHand : global.$Cfg.Common.Palace_PlayerWomanHand, this.img_Hand.skin = n;
        var t = a.HeadId, l = global.$Cfg.Common.HeadIconName[a.Sex][t];
        this.img_Head.skin = l, Laya.Tween.to(this, {alpha: 1}, 1e3, null, Laya.Handler.create(this, function () {
            var a = jasmin._s449f055209cd01229b1846559026f5(gLanguage.RankWorshipSayText);
            GameCommon._scd195118e2b7ac8cde3e75629fcfef(this.lab_SayText, a, 50), this.mouseEnabled = !0
        }))
    }
}();
var RechargeDailyItem;
!function () {
    RechargeDailyItem = function (e, a) {
        RechargeDailyItem.super(this), this._275936707 = 180, this._1904698560 = e, this._1783591077 = a, this._3928031220 = 1, this.Init()
    }, Laya.class(RechargeDailyItem, "RechargeDailyItem", RechargeDailyItemUI);
    var e = RechargeDailyItem.prototype;
    e.Init = function () {
        var e = global.$Cfg.Common.ActivityCfg.Recharge,
            a = global.$Sys.GetTableService().GetTableRecord(e.TaskTable, this._1904698560, "TableName"),
            t = global.$Sys.GetTableService().GetTableRecord(a, this._1783591077, this._3928031220);
        this.btn_GetReward.visible = !1, this.btn_ToRecharge.visible = !1, this.img_HasGetReward.visible = !1;
        var i = global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(this._1904698560, this._1783591077, this._3928031220),
            s = global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(this._1904698560, this._1783591077, this._3928031220);
        i ? this.img_HasGetReward.visible = !0 : s ? this.btn_GetReward.visible = !0 : this.btn_ToRecharge.visible = !0, this.btn_GetReward.on(Laya.Event.CLICK, this, this.OnGetReward), this.btn_ToRecharge.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeView", {
                OnClose: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeReward")
                }
            })
        });
        var r = t.TaskName;
        for (var h in t.Target) {
            var n = t.Target[h], o = n[2],
                l = GameCommon._sc2670617ff77eb1396f5b63c0edc88(n[0], n[1], {TaskType: this._1904698560});
            r += jasmin._se91cf955e91eaa1aa510d4335edd4a(" (%d/%d)", l, o);
            var c = new Laya.ProgressBar("res/ui/progress/progress_4.png");
            c.left = 0, c.right = 0, c.height = 24, c.value = l / o;
            var d = new Laya.Label(l + "/" + o);
            c.addChild(d), d.width = 200, d.centerX = 0, d.centerY = 0, d.strokeColor = "#4f3217", d.stroke = 2, d.fontSize = 22, d.color = "#ffffff", d.align = "center", this.vBox_progress.addChild(c)
        }
        this.vBox_progress.refresh(), this.lab_Title.text = r;
        for (var g = global.$Sys.GetTableService().GetTableRecord("reward", t.Reward), m = g.Award, _ = 5, b = Math.ceil(m.length / _), h = 0, v = 0; v < b && !(h >= m.length); v++) {
            for (var G = new Laya.HBox, I = 0; I < _ && m[h]; I++) {
                var u = GameCommon._se35db439c4ad2364b987453544666d(m[h], null, !0, m[h][2], {UseEff: !0});
                u.scaleX = .95, u.scaleY = .95, G.addChild(u), h++, G.changeItems()
            }
            G.space = 4, this.vBox_Icon.addChild(G)
        }
        this.vBox_Icon.changeItems(), this.height = this.vBox_Icon.height + this._275936707, this.left = 0, this.right = 0
    }, e.OnGetReward = function () {
        var e = this, a = {
            Group: this._1904698560, ChainId: this._1783591077, TaskId: this._3928031220, Callback: function (a) {
                a.Result && (e.mouseEnabled = !1, e.btn_GetReward.visible = !1, e.btn_ToRecharge.visible = !1, e.img_HasGetReward.visible = !0, Laya.Tween.from(e.img_HasGetReward, {
                    scaleX: 1.6,
                    scaleY: 1.6
                }, 200, null, Laya.Handler.create(this, function () {
                    e.mouseEnabled = !0, e.event("Update")
                })))
            }
        };
        GetDataTaskInterface().DoTask(a)
    }
}();
var RechargeReward;
!function () {
    RechargeReward = function () {
        RechargeReward.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            return this._4122736007 && this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.panel_DailyTotalRecharge.vScrollBarSkin = null, this.list_TotalRecharge.vScrollBarSkin = null, this.panel_DailyCount.vScrollBarSkin = null, this.list_TotalRecharge.renderHandler = Laya.Handler.create(this, this.OnCreateTotalBox, null, !1), this.radioGroup.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1), this._610444602 = 1, this._2731122167 = 2, this._2085941657 = 3, this.radioGroup.selectedIndex = 0
    }, Laya.class(RechargeReward, "RechargeReward", RechargeRewardUI), RechargeReward.GetPreLoadResList = function (e) {
        for (var a in global.$Cfg.Common.RechargeRewardTitle) e.push(global.$Cfg.Common.RechargeRewardTitle[a]);
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(RechargeRewardUI.uiView, e)
    };
    var e = RechargeReward.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e;
        var a = GetActivityManager()._sf6027486c9ce1855a4057ea0b9a5f8("Recharge", ActivityBase.STATUS.Start);
        if (jasmin._s2dedbd0e220887101c856bf900fc57(a)) return void jasmin.Error("No Recharge Activity Open");
        this._3222237592 = {};
        var t = "";
        for (var i in a) {
            var r = a[i], l = GetActivityManager()._sde9f114875db61d769f11ca1b7d1fa(r);
            for (var o in l) {
                var s = l[o], n = s.RewardTable;
                if (!n) {
                    var h = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("activity", "Recharge", s.SType);
                    n = h.GroupName
                }
                var c = global.$Sys.GetTableService().GetTableRecord("activity_recharge", n, "Type");
                switch (c) {
                    case"days":
                        this._3222237592.RecDays = {GroupName: n};
                        break;
                    case"return":
                        this._3222237592.RecTotal = {GroupName: n};
                        break;
                    case"daily":
                        this._3222237592.RecDaily = {GroupName: n}
                }
            }
            t += jasmin._se91cf955e91eaa1aa510d4335edd4a("T: %s GUID: %s  \n", c, r)
        }
        if (IsDebug()) {
            this._DebugLabel && (this._DebugLabel.destroy(), this._DebugLabel = null);
            var d = new Laya.Label;
            d.text = t, d.color = "#1BC06C", d.strokeColor = "#000000", d.stroke = 2, d.fontSize = 20, d.x = 200, d.y = 50, this._DebugLabel = d, this.addChild(d)
        }
        this._s3f0016c7ff54aa26b749558371ef76(), this._sfaec9ed6ff02ff45d88eaac8bc977d(), this._s9b0be66c7fff0401bb98b96d249a8a(), this._s2a45b81dbd2c13e809cd9e3a0940eb(), this.OnTimeHandle(), Laya.timer.loop(1e3, this, this.OnTimeHandle), this._sf02e4a50ec2b1e5e3e150ecd5fb439()
    }, e.OnClose = function () {
        Laya.timer.clear(this, this.OnTimeHandle), this.vBox_Item.destroyChildren(), this.vBox_DailyCount.destroyChildren();
        for (var e = 0; e < this.list_TotalRecharge.array.length; e++) {
            var a = this.list_TotalRecharge.getCell(e);
            if (a) {
                var t = a.getChildByName("lab_RewardText"), i = t.getChildByName("hBox_Reward"),
                    r = i.getChildByName("img_Icon");
                r.destroyChildren()
            }
        }
    }, e._sf02e4a50ec2b1e5e3e150ecd5fb439 = function () {
        Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.radio_Daily,
            NodeName: "RechargeRewardDailyTotal",
            OnCheckState: TargetCheck._CheckCanFinishTask.bind(null, this._3222237592.RecDaily.GroupName),
            cover: !0,
            Group: "RechargeReward"
        }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.radio_Total,
            NodeName: "RechargeRewardTotal",
            OnCheckState: TargetCheck._CheckCanFinishTask.bind(null, this._3222237592.RecTotal.GroupName),
            cover: !0,
            Group: "RechargeReward"
        }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.radio_DailyCount,
            NodeName: "RechargeRewardDaily",
            OnCheckState: TargetCheck._CheckCanFinishTask.bind(null, this._3222237592.RecDays.GroupName),
            cover: !0,
            Group: "RechargeReward"
        })
    }, e._s3f0016c7ff54aa26b749558371ef76 = function () {
        this.vBox_Item.destroyChildren();
        var e = this._3222237592.RecDaily, a = global.$Cfg.Common.ActivityCfg.Recharge, t = a.TaskTable,
            i = global.$Sys.GetTableService().GetTableRecord(t, e.GroupName).TableName,
            r = global.$Sys.GetTableService().GetTable(i),
            l = GameCommon._sc2670617ff77eb1396f5b63c0edc88(CommonEnum.Asset.DataTask, CommonEnum.DataTask.DailyTotalRecharge, {TaskType: e.GroupName});
        this.lab_DailyRechargeCount.text = l + gLanguage.RechargeUnit;
        var o = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(e.GroupName);
        o.sort(function (e, a) {
            return e - a
        });
        for (var s in o) {
            var n = o[s], h = (r[n][1], new DailyTotalItem(e.GroupName, n));
            this.vBox_Item.addChild(h), h.on("Update", this, function () {
                this._s3f0016c7ff54aa26b749558371ef76()
            })
        }
        this.vBox_Item.changeItems()
    }, e._sfaec9ed6ff02ff45d88eaac8bc977d = function () {
        var e = this._3222237592.RecTotal, a = global.$Cfg.Common.ActivityCfg.Recharge, t = a.TaskTable,
            i = global.$Sys.GetTableService().GetTableRecord(t, e.GroupName).TableName,
            r = global.$Sys.GetTableService().GetTable(i), l = [],
            o = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(e.GroupName);
        o.sort(function (e, a) {
            return e - a
        });
        for (var s in o) {
            var n = o[s], h = r[n][1];
            l.push({ChainId: n, TableData: h})
        }
        this.list_TotalRecharge.array = l
    }, e.OnCreateTotalBox = function (e, a) {
        var t = this._3222237592.RecTotal.GroupName, i = this.list_TotalRecharge.array[a].ChainId,
            r = this.list_TotalRecharge.array[a].TableData, l = r.Target[0], o = e.getChildByName("hBox_Title"),
            s = o.getChildByName("lab_TitleCount");
        s.text = l[2], o.changeItems();
        var n = GameCommon._sc2670617ff77eb1396f5b63c0edc88(l[0], l[1], {TaskType: t}),
            h = e.getChildByName("lab_NowCount");
        h.text = "￥" + n;
        var c = global.$Sys.GetTableService().GetTableRecord("reward", r.Reward), d = c.Award[0],
            m = GameCommon._s66eb52e60b9feb53711943e638c9c3(d[0], d[1], !0), g = e.getChildByName("lab_RewardText"),
            T = g.getChildByName("hBox_Reward"), y = T.getChildByName("img_Icon");
        y.destroyChildren(), y.addChild(m), y.width = m.width, y.height = m.height;
        var u = T.getChildByName("lab_RewardCount");
        u.text = "x" + d[2], T.changeItems(), T.centerY = 0;
        var R = e.getChildByName("btn_GetReward"), b = e.getChildByName("btn_ToRecharge"),
            C = e.getChildByName("img_HasGetReward");
        R.visible = !1, b.visible = !1, C.visible = !1, global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(t, i, 1) ? C.visible = !0 : global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(t, i, 1) ? R.visible = !0 : b.visible = !0, R.on(Laya.Event.CLICK, this, this.OnGetTotalReward, [i]), b.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeView", {
                OnClose: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeReward")
                }
            })
        })
    }, e.OnGetTotalReward = function (e) {
        var a = {
            Group: this._3222237592.RecTotal.GroupName, ChainId: e, TaskId: 1, Callback: function (a) {
                if (a.Result) {
                    var t = this.list_TotalRecharge.getCell(e - 1), i = t.getChildByName("btn_GetReward"),
                        r = t.getChildByName("btn_ToRecharge"), l = t.getChildByName("img_HasGetReward");
                    this.mouseEnabled = !1, i.visible = !1, r.visible = !1, l.visible = !0, Laya.Tween.from(l, {
                        scaleX: 1.6,
                        scaleY: 1.6
                    }, 200, null, Laya.Handler.create(this, function () {
                        this.mouseEnabled = !0, this._sfaec9ed6ff02ff45d88eaac8bc977d()
                    }))
                }
            }.bind(this)
        };
        GetDataTaskInterface().DoTask(a)
    }, e._s9b0be66c7fff0401bb98b96d249a8a = function () {
        this.vBox_DailyCount.destroyChildren();
        var e = this._3222237592.RecDays, a = global.$Cfg.Common.ActivityCfg.Recharge, t = a.TaskTable,
            i = global.$Sys.GetTableService().GetTableRecord(t, e.GroupName).TableName,
            r = global.$Sys.GetTableService().GetTable(i),
            l = global.$Api.QueryDataSource("DataTask")._s53ab8782df73bd8f8226efb367cab6(e.GroupName);
        l.sort(function (e, a) {
            return e - a
        });
        for (var o in l) {
            var s = l[o], n = (r[s][1], new RechargeDailyItem(e.GroupName, s));
            this.vBox_DailyCount.addChild(n), n.on("Update", this, function () {
                this._s9b0be66c7fff0401bb98b96d249a8a()
            })
        }
        this.vBox_DailyCount.changeItems()
    }, e._s2a45b81dbd2c13e809cd9e3a0940eb = function () {
        var e = GetActivityManager()._s59445864d00fe89be54e72799eb0e1(3);
        for (var a in e) {
            var t = e[a].Object._1842891454;
            "Recharge" == t.Type && (this._4194977090 = t.Timelst.StartTimelst, this._3942875316 = t.Timelst.StopTimelst)
        }
        var i = this._4194977090, r = this._3942875316,
            l = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeActivityTime, i[1], i[2], i[3], i[4], r[1], r[2], r[3], r[4]);
        this.lab_ActTime1.text = l, this.lab_ActTime2.text = l
    }, e.OnTimeHandle = function () {
        var e = this._3942875316, a = jasmin._sa8ce9b799dca49cfed044a7bb95483(e[0], e[1], e[2], e[3], e[4], e[5]),
            t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), i = a - t,
            r = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(i);
        this.lab_TimeDown1.text = r, this.lab_TimeDown2.text = r
    }, e.OnSelectType = function (e) {
        switch (this.panel_DailyTotalRecharge.visible = !1, this.list_TotalRecharge.visible = !1, this.panel_DailyCount.visible = !1, this.box_DailyRecharge.visible = !1, e) {
            case 0:
                this.panel_DailyTotalRecharge.visible = !0, this.box_Recharge.visible = !1, this.box_DailyRecharge.visible = !0;
                break;
            case 1:
                this.list_TotalRecharge.visible = !0, this.img_TitleFont.skin = global.$Cfg.Common.RechargeRewardTitle[e], this.box_Recharge.visible = !0;
                break;
            case 2:
                this.panel_DailyCount.visible = !0, this.img_TitleFont.skin = global.$Cfg.Common.RechargeRewardTitle[e], this.box_Recharge.visible = !0;
                break;
            default:
                jasmin.Error("RechargeReward SelectType Error!")
        }
    }
}();
var RechargeView;
!function () {
    RechargeView = function () {
        RechargeView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnClickClose), this.list_Recharge.renderHandler = new Laya.Handler(this, this.OnCreateProduct), this.list_Tq.renderHandler = new Laya.Handler(this, this.OnCreateTq), this.list_Recharge.vScrollBarSkin = null, this.list_Tq.vScrollBarSkin = null, this.redioGroup_type.selectHandler = new Laya.Handler(this, this.OnSelectType), this.redioGroup_type.selectedIndex = 0;
        var e = {ShowType: ["Gold"], Custom: {}};
        this._2141111536 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8({ui_labGold: this.ui_labGold}, e)
    }, Laya.class(RechargeView, "RechargeView", RechargeUI), RechargeView.GetPreLoadResList = function (e) {
        var a = GetDataTransfer().GetTable("recharge_product");
        a = _.filter(a, function (e) {
            return IsDebug() ? "Gold" == e.Type : "Gold" == e.Type && 0 == e.Debug
        }), _.each(a, function (a) {
            e.push(a.IconPath), e.push(a.MoneyPath)
        }), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(RechargeUI.uiView, e)
    };
    var e = RechargeView.prototype;
    e.OnRechargeSuccess = function (e) {
        this._s7117882621c92b5f29b6e0f25b229d(), this._s598985d4d759a616761610b468fcf8(), this._sc42ca3988b62aa64e544fe8044e04c(), this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d();
        var a = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv;
        a > e && GetRechargeInterface()._saba13be9989f261cd5498022105295(e, a), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.RechargeSuccess]})
    }, e.OnCreateTq = function (e, a) {
        var t = e.dataSource, i = e.getChildByName("ui_TqBg"), n = i.getChildByName("ui_Title"),
            r = n.getChildByName("ui_VipLv");
        r.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath, t.VipLv);
        var s = e.getChildByName("view_Info");
        s.removeChildren();
        for (var h = t.Infos, o = 0; o < h.length; o++) {
            var g = h[o], c = new Laya.Label(g);
            c.color = "#86604d", c.fontSize = 23, c.y = 34 * o, s.addChild(c)
        }
        var l = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1();
        n.gray = l < t.VipLv
    }, e._sc42ca3988b62aa64e544fe8044e04c = function () {
        var e = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(), a = GetDataTransfer().GetTable("vip"),
            t = _.size(a) - 1, i = global.$Api.QueryDataSource("DataBase").GetValue("VipScore");
        if (this.ui_VipLv.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, e), e >= t) return this.progress_Recharge.value = 1, this.lab_Progress.text = i, void(this.box_RechargeTag.visible = !1);
        this.box_RechargeTag.visible = !0;
        var n = e + 1, r = GetDataTransfer().GetTableRecord("vip", n), s = r.MinRecharge,
            h = jasmin._s640706b813de311f0dd4fcc7fd6a17(s - i, 2), o = i / s;
        this.lab_Progress.text = i + "/" + s, this.progress_Recharge.value = o, this.lab_Recharge1.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeInfo1, h), this.lab_Recharge2.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeInfo2, n), this.box_RechargeTag.changeItems()
    }, e.OnRecharge = function (e) {
        var a = global.$Api._s2a2adefdb34c30568ffef0f601162e().VipLv;
        GetRechargeInterface().DoRecharge(e, function (e, a) {
            a.Result && this.OnRechargeSuccess(e)
        }.bind(this, a))
    }, e.OnCreateProduct = function (e, a) {
        var t = e.dataSource, i = e.getChildByName("btn_Recharge");
        i.on(Laya.Event.CLICK, this, this.OnRecharge, [t.ProductId]);
        var n = i.getChildByName("ui_Double");
        t.MaidenGive ? GetRechargeInterface()._s58063720a8031ca88bafd9e37d8667(t.ProductId) > 0 ? n.visible = !1 : n.visible = !0 : n.visible = !1;
        var r = i.getChildByName("lab_Price");
        r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeGoldFont, t.Gold);
        var s = i.getChildByName("ui_Icon");
        s.skin = t.IconPath;
        var h = i.getChildByName("ui_Price");
        h.skin = t.MoneyPath
    }, e._s7117882621c92b5f29b6e0f25b229d = function () {
        var e = GetDataTransfer().GetTable("recharge_product");
        e = _.filter(e, function (e) {
            return IsDebug() || IsGm() ? "Gold" == e.Type : window.GAME_CHANNEL ? e.Channel == window.GAME_CHANNEL && "Gold" == e.Type && 0 == e.Debug : 1 == e.Default && "Gold" == e.Type && 0 == e.Debug
        }), this.list_Recharge.array = e
    }, e._s598985d4d759a616761610b468fcf8 = function () {
        var e = GetDataTransfer().GetTable("vip"), a = _.keys(e);
        a = _.map(a, function (e) {
            return parseInt(e)
        }), a.sort(function (e, a) {
            return e - a
        });
        for (var t = [], i = 0; i < a.length; i++) {
            var n = a[i];
            if (0 != n) {
                var r, s = e["" + n], h = GetDataTransfer().GetTable("miracle");
                r = GetInspection() ? [jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo1, s.MinRecharge)] : [jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo1, s.MinRecharge), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo2, s.ChildRate), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo3, s.MaxPhysical), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo4, s.MaxBeautyEnergy), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo5, s.FreeChangeLuck), jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo6, s.MaxChildEnergy)];
                var o = !!s.FastUpgrade;
                o && r.push(gLanguage.RechargeTQInfo8);
                var g = !!s.InstitutePassword;
                g && r.push(gLanguage.RechargeTQInfo9), _.each(h, function (e) {
                    r.push(jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo7, e.MiracleName, s.MaxMiracle))
                }), t.push({Infos: r, VipLv: n})
            }
        }
        this.list_Tq.array = t
    }, e.OnSelectType = function (e) {
        this.list_Recharge.visible = 0 == e, this.list_Tq.visible = 1 == e
    }, e.OnShow = function (e) {
        e = e || {}, this.m_OnClose = e.OnClose, this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d(), this._s7117882621c92b5f29b6e0f25b229d(), this._s598985d4d759a616761610b468fcf8(), this._sc42ca3988b62aa64e544fe8044e04c()
    }, e.OnClickClose = function () {
        this.m_OnClose && this.m_OnClose()
    }
}();
var RewardBeautyView;
!function () {
    RewardBeautyView = function () {
        RewardBeautyView.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RewardBeautyView")
        })
    }, Laya.class(RewardBeautyView, "RewardBeautyView", RewardBeautyUI), RewardBeautyView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(RewardBeautyUI.uiView, e)
    };
    var e = RewardBeautyView.prototype;
    e.OnClose = function () {
        this._3321166218._s54107fed721f2f5f6636c3b2747bef(), this.m_OnClose && this.m_OnClose()
    }, e.OnShow = function (e) {
        this.m_OnClose = e.OnClose, this.mouseEnabled = !1, Laya.timer.once(1e3, this, function () {
            this.mouseEnabled = !0
        });
        var a = new Leo.ImageActionManager({Image: this.img_Light});
        a._sc95f42251335b3aa0013090797aec9("Rotate", {
            Inversion: !1,
            Time: 2e4
        }), a._s2e4033b88e999ce7271844dbf3b2dc(), this._3321166218 = a;
        var t = e.BeautyId, i = global.$Api.QueryDataSource("DataBeauty")._s08ba6a1ba12968cac41a4297977513(t),
            n = global.$Sys.GetTableService().GetTableRecord("beauty", t), o = n.BeautyVoice;
        o && GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(o), this.img_Body.skin = n.Body1Path;
        var s = new Laya.Image(n.NamePath);
        s.centerY = .5, this.img_Name.destroyChildren(), this.img_Name.addChild(s), this.lab_SF.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.BeautyRewardSF, n.Identify), this.lab_Charm.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.BeautyRewardCharm, i.Charm), this.lab_Info.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.BeautyRewardLZ, n.Desc)
    }
}();
var RewardDialog;
!function () {
    RewardDialog = function () {
        RewardDialog.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RewardDialog")
        }), this._97284774 = {}
    }, Laya.class(RewardDialog, "RewardDialog", Laya.Sprite), RewardDialog.OnPreLoadRes = function (t, e) {
        e && e.Skin && leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.Skin.uiView, t)
    }, RewardDialog.prototype.OnShow = function (t) {
        var e = t.Skin, i = null;
        this._3257292081 && (this._3257292081.removeSelf(), this._3257292081.destroy(), this._3257292081 = null), this._3257292081 || (i = new e, this.addChild(i), i.centerX = .5, i.centerY = .5), this._950549070 = t || {}, _.each(t.Components, function (e, o) {
            this._97284774[o] = e, e.Init(i, t.Data)
        }.bind(this)), this._sef77c3f8654f8353839813a7c44c02(i, t.Data), this._950549070.Data && this._950549070.Data.AutoClose ? (this._3130016237 = 2, this._3257292081.lab_AutoClose.y = this._3257292081.img_Bg.height + 5, this._3257292081.lab_AutoClose.visible = !0, Laya.timer.loop(1e3, this, this.OnAutoCloseCountdown)) : this._3257292081.lab_AutoClose && (this._3257292081.lab_AutoClose.visible = !1)
    }, RewardDialog.prototype.OnAutoCloseCountdown = function () {
        this._3130016237--, this._3257292081.lab_AutoClose.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.FightAutoCloseReward, this._3130016237), 0 == this._3130016237 && GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RewardDialog")
    }, RewardDialog.prototype._sef77c3f8654f8353839813a7c44c02 = function (t, e) {
        this._3257292081 = t, this._3257292081.ui_listRewardIcons.renderHandler = Laya.Handler.create(this, this._UpdateRewardIcon, null, !1), this._3257292081.ui_listRewardIcons.array = [];
        var i = e.Rewards;
        ASSERT(jasmin._seb2d63e263badd8a69c54d151f6cc7(i), "Coder:RewardDialog rewardItems is required");
        var o = [];
        for (var s in i) jasmin._s2dedbd0e220887101c856bf900fc57(i[s]) || o.push(i[s]);
        var a = o.length;
        if (this.columnIconsCount = 0, this.rowIconsCount = 0, a > this._3257292081.ui_listRewardIcons.repeatX) {
            this.columnIconsCount = this._3257292081.ui_listRewardIcons.repeatX;
            for (var r = 1; r <= this._3257292081.ui_listRewardIcons.repeatY; r++) a < this._3257292081.ui_listRewardIcons.repeatX * r && (this.rowIconsCount = r);
            0 === this.rowIconsCount && (this.rowIconsCount = this._3257292081.ui_listRewardIcons.repeatY, this._3257292081.ui_listRewardIcons.hScrollBarSkin = null)
        } else this.columnIconsCount = a, this.rowIconsCount = 1;
        this._3257292081.ui_listRewardIcons.array = o, this._3257292081.ui_listRewardIcons.width = (this._3257292081.ui_listRewardIcons.spaceX || 0) * (this.columnIconsCount - 1) + this._3257292081.ui_listRewardIcons.itemRender.props.width * this.columnIconsCount, this._3257292081.ui_listRewardIcons.height = (this._3257292081.ui_listRewardIcons.spaceY || 0) * (this.rowIconsCount - 1) + this._3257292081.ui_listRewardIcons.itemRender.props.height * this.rowIconsCount
    }, RewardDialog.prototype._UpdateRewardIcon = function (t, e) {
        t.rewardItem && (t.rewardItem.removeSelf(), t.rewardItem.destroy(), t.rewardItem = null);
        var i = this._3257292081.ui_listRewardIcons.array[e], o = this.OnCreateRewardItem(i);
        jasmin._seb2d63e263badd8a69c54d151f6cc7(o) && (t.addChild(o), t.rewardItem = o)
    }, RewardDialog.prototype.OnCreateRewardItem = function (t) {
        var e = (new Laya.Sprite, GameCommon._s66eb52e60b9feb53711943e638c9c3(t[0], t[1], null, !0, t[2]));
        return e.scaleX = .9, e.scaleY = .9, e
    }, RewardDialog.prototype._s54107fed721f2f5f6636c3b2747bef = function () {
        if (this._3257292081.ui_listRewardIcons) for (var t in this._3257292081.ui_listRewardIcons.cells) this._3257292081.ui_listRewardIcons.cells[t].rewardItem && (this._3257292081.ui_listRewardIcons.cells[t].rewardItem.removeSelf(), this._3257292081.ui_listRewardIcons.cells[t].rewardItem.destroy())
    }, RewardDialog.prototype.OnClose = function () {
        Laya.timer.clear(this, this.OnAutoCloseCountdown), _.each(this._97284774, function (t, e) {
            delete this._97284774[e]
        }.bind(this)), this._s54107fed721f2f5f6636c3b2747bef(), this._950549070.OnClose && this._950549070.OnClose(), this._3257292081.removeSelf(), this._3257292081.destroy(), delete this._3257292081
    }
}();
!function () {
    function e() {
        e.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_books.renderHandler = Laya.Handler.create(this, this.OnCreateBooksBox, null, !1), this.list_books.vScrollBarSkin = null;
        var a = new Leo.ImageActionManager({Image: this.img_light});
        a._sc95f42251335b3aa0013090797aec9("Rotate", {Inversion: !1, Time: 2e4}), this._3321166218 = a
    }

    Laya.class(e, "RewardHeroDialog", RewardHeroUI);
    var a = e.prototype;
    a.OnShow = function (e) {
        this._4122736007 = e, this._3321166218._s2e4033b88e999ce7271844dbf3b2dc(), this._s4fb507d6d0f40b2d2a72f6007a938d();
        var a = global.$Sys.GetTableService().GetTableRecord("hero", this._4122736007.HeroId), t = a.HeroVoice;
        t && GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(t)
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("hero", this._4122736007.HeroId),
            a = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId), t = a.Books;
        this.img_heroName.skin = e.NameIcon, this.img_hero.skin = e.BodyPath;
        var o = 0;
        _.each(t, function (e) {
            o += e.Aptitude
        }), this.lab_aptitude.text = o, this.list_books.array = _.toArray(t)
    }, a.OnCreateBooksBox = function (e, a) {
        var t = e.getChildByName("img_book"), o = e.getChildByName("list_star"),
            i = e.getChildByName("lab_aptitudeName"), r = e.getChildByName("lab_aptitude"),
            s = e.getChildByName("lab_bookName"), l = this.list_books.array[a],
            n = GetDataTransfer().GetTableRecord("book", l.Id);
        t.skin = global.$Cfg.Common.BookIconPath[n.Attribute], i.text = gLanguage.Aptitudes[n.Attribute], r.text = global.$Api.Formula._GetBookAttribute(l.Lv, l.Aptitude), s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("《%s》", n.BookName), o.array = new Array(n.Star)
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RewardHeroDialog")
    }, a.OnClose = function () {
        this._3321166218._s54107fed721f2f5f6636c3b2747bef(), this._4122736007 && this._4122736007.OnClickCallback && this._4122736007.OnClickCallback()
    }, e.GetPreLoadResList = function (a, t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, a), jasmin._s3c96e1f3bee730222501b208d50190(a, global.$Cfg.Common.BookIconPath);
        var o = global.$Sys.GetTableService().GetTableRecord("hero", t.HeroId);
        a.push(o.NameIcon, o.BodyPath)
    }
}();
var RuleMessageDialog;
!function () {
    function e() {
        e.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("RuleMessageDialog")
        })
    }

    Laya.class(e, "RuleMessageDialog", RuleMessageDialogUI);
    var a = e.prototype;
    e.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, a)
    }, a.OnShow = function (e) {
        this._4122736007 = e, this._s55b947627a9c6a8e673afeca2d9df4()
    }, a._s55b947627a9c6a8e673afeca2d9df4 = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("rule_desc", this._4122736007.Field);
        this.lab_RuleMessage.text = e.Desc
    }
}();
var SayDialog;
!function () {
    SayDialog = function () {
        SayDialog.super(this), this.img_Bg.on(Laya.Event.CLICK, this, function (t) {
            this.OnClick()
        }), this.btn_Close.on(Laya.Event.CLICK, this, function (t) {
            this.OnCloseDialog(1)
        }), this.ani_BtnMove1.autoPlay = !0, this.ani_BtnMove2.autoPlay = !0
    }, Laya.class(SayDialog, "SayDialog", SayDialogUI);
    var t = SayDialog.prototype;
    t.OnCloseDialog = function (t) {
        return this._3406448646 ? void this._3406448646(this.OnTweenBlack.bind(this, t)) : void this.OnTweenBlack(t)
    }, t.OnTweenBlack = function (t) {
        return this.mouseEnabled = !1, this.lab_Bg.visible = !0, this._713989164.IsGuide || !this.textRecord.BgPath || "" == this.textRecord.BgPath ? void this.OnCloseDownDialog(t) : (Laya.Tween.clearAll(this.lab_Bg), void Laya.Tween.to(this.lab_Bg, {alpha: 1}, 1e3, null, Laya.Handler.create(this, this.OnCloseDownDialog, [t])))
    }, t.OnCloseDownDialog = function (t) {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SayDialog"), this._OnClose && this._OnClose(t), this.img_Bg.skin = "", this.img_PlayerCloth.skin = "", this.img_PlayerHand.skin = "", this.img_PlayerHead.skin = "", this.img_Right.skin = "", this.img_Left.skin = ""
    }, t.OnClick = function () {
        if (this.CanClick) {
            if (this.CanClick = !1, Laya.timer.once(200, this, function () {
                this.CanClick = !0
            }), "" == this._612288715) return void this.OnNextText();
            var t = this.textRecord.NpcType == -1 ? this.lab_PlotText : this.lab_SayText;
            if (t.text == this._612288715 && this._612288715Id >= this.textRecord.DialogInfo.length) if (this._2230332165++, this._2230332165 >= this.guideRecord.length) this.OnCloseDialog(); else {
                var e = null;
                e = 0 == this.textRecord.NpcType ? this.box_Player : "right" == this.textRecord.NpcPosition ? this.img_Right : this.img_Left, Laya.Tween.to(e, {alpha: 0}, 100, null, Laya.Handler.create(this, function () {
                    return this.textRecord = this.guideRecord[this._2230332165], this._2230332165 && this.textRecord.BgPath && this.textRecord.BgPath != this.img_Bg.skin ? (this.mouseEnabled = !1, this.lab_Bg.visible = !0, void Laya.Tween.to(this.lab_Bg, {alpha: 1}, 1e3, null, Laya.Handler.create(this, function () {
                        this.OnNextText()
                    }))) : void this.OnNextText()
                }))
            } else {
                if (t.text == this._612288715) return void this._s31ff4e310c78e3f91bc049791cccf9();
                Laya.timer.clear(this, this.OnLoop), t.text = this._612288715
            }
        }
    }, t._s11aeb2f0fea74e71023959d8faa693 = function (t) {
        if (this.textRecord.Hide) return this.box_Player.visible = !1, this.img_Right.visible = !1, void(this.img_Left.visible = !1);
        if (void 0 == t && (t = ""), 0 == this.textRecord.NpcType) {
            this.img_Left.visible = !1, this.img_Right.visible = !1, this.img_PlayerCloth.skin = t, this.box_Player.scaleX = this.textRecord.ScaleX ? this.textRecord.ScaleX : 1.2, this.box_Player.scaleY = this.textRecord.ScaleY ? this.textRecord.ScaleY : 1.2, this.img_PlayerCloth.mask && (this.img_PlayerCloth.mask.removeSelf(), this.img_PlayerCloth.mask.destroy(), this.img_PlayerCloth.mask = null);
            var e = new Laya.Image(global.$Cfg.Common.InitialPlotClothMask);
            this.img_PlayerCloth.mask = e;
            var i = -e.height - this.img_PlayerCloth.y;
            return this.box_Player.scaleY && (i *= this.box_Player.scaleY), this.box_Player.y = i, this.box_Player.visible = !0, void Laya.Tween.to(this.box_Player, {alpha: 1}, 100)
        }
        this.box_Player.visible = !1;
        var a;
        "right" == this.textRecord.NpcPosition ? (a = this.img_Right, this.img_Left.visible = !1) : (a = this.img_Left, this.img_Right.visible = !1), a.skin = t, a.scaleX = 1, a.scaleY = 1, this.textRecord.FlipModel ? this.textRecord.ScaleX ? (a.scaleX = -1 * this.textRecord.ScaleX, "right" == this.textRecord.NpcPosition ? a.x -= a.width * this.textRecord.ScaleX : a.x += a.width * this.textRecord.ScaleX) : (a.scaleX = -1, "right" == this.textRecord.NpcPosition ? a.x -= a.width : a.x += a.width) : this.textRecord.ScaleX && (a.scaleX = this.textRecord.ScaleX), this.textRecord.ScaleY && (a.scaleY = this.textRecord.ScaleY), a.visible = !0, Laya.Tween.to(a, {alpha: 1}, 100)
    }, t._s1da39010b3310ee7f026a12fc5c5f6 = function () {
        this._612288715Id = 0, this._612288715 = "", this.lab_SayText.text = "", this.lab_PlotText.text = "", this.lab_Name.text = "", this.img_PlotTextBg.visible = !1, this.img_SayBg.visible = !1
    }, t.OnNextText = function () {
        switch (this._s1da39010b3310ee7f026a12fc5c5f6(), this.textRecord.NpcType) {
            case 0:
                this.lab_Name.text = "我";
                var t;
                GetPalaceInterface().DoCheckIsKing(function (e) {
                    if (e) {
                        var i = global.$Sys.GetTableService().GetTableRecord("throne", e.KingId);
                        t = i.ClothPath, this.img_PlayerHand.visible = !1
                    } else {
                        var a = global.$Api.QueryDataSource("DataBase")._2552118236.Office,
                            i = global.$Sys.GetTableService().GetTableRecord("office", a);
                        t = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing), this.img_PlayerHand.visible = !0
                    }
                    this.textRecord.ShowHand && (this.img_PlayerHand.visible = !0), this._713989164.PlayerClothPath && (t = this._713989164.PlayerClothPath, this.img_PlayerHand.visible = !!this.textRecord.ShowHand), this._s11aeb2f0fea74e71023959d8faa693(t)
                }.bind(this));
                break;
            case 1:
                var e = global.$Sys.GetTableService().GetTableRecord("hero", this.textRecord.NpcId);
                this.lab_Name.text = e.HeroName, this._s11aeb2f0fea74e71023959d8faa693(e.BodyPath);
                break;
            case 2:
                var i = global.$Sys.GetTableService().GetTableRecord("npc", this.textRecord.NpcId);
                this.lab_Name.text = i.NpcName, this._s11aeb2f0fea74e71023959d8faa693(i.BodyPath);
                break;
            case 3:
                var a = global.$Sys.GetTableService().GetTableRecord("beauty", this.textRecord.NpcId);
                this.lab_Name.text = a.Name, this._s11aeb2f0fea74e71023959d8faa693(a.Body1Path)
        }
        return this.textRecord.BgPath && this.textRecord.BgPath != this.img_Bg.skin && (this.img_Bg.skin = this.textRecord.BgPath), 1 == this.lab_Bg.alpha ? (this.mouseEnabled = !1, void Laya.Tween.to(this.lab_Bg, {alpha: 0}, 1e3, null, Laya.Handler.create(this, function () {
            this.lab_Bg.visible = !1, this.mouseEnabled = !0, this._s31ff4e310c78e3f91bc049791cccf9()
        }))) : (this.lab_Bg.visible = !1, this.mouseEnabled = !0, void this._s31ff4e310c78e3f91bc049791cccf9())
    }, t._s31ff4e310c78e3f91bc049791cccf9 = function () {
        this.lab_SayText.text = "", this.lab_PlotText.text = "";
        var t = this.textRecord.NpcType <= -1;
        t = !!t, this.img_PlotTextBg.visible = t, this.img_SayBg.visible = !t, Laya.timer.loop(this._1356664668, this, this.OnLoop, [t]), this._612288715 = this.textRecord.DialogInfo[this._612288715Id], this._612288715Id++
    }, t.OnLoop = function (t) {
        if ("" != this._612288715 && void 0 != this._612288715) {
            var e = t ? this.lab_PlotText : this.lab_SayText, i = e.text.length;
            e.text != this._612288715 && (e.text += this._612288715[i])
        }
    }, t.OnShow = function (t) {
        return this._713989164 = t, t.OnBeforeStart ? void t.OnBeforeStart(function () {
            this.OnStart(t)
        }.bind(this)) : void this.OnStart(t)
    }, t.OnStart = function (t) {
        this.btn_Close.visible = !!t.CanSkip, this.CanClick = !0, this.guideRecord = [];
        for (var e in t.Record) this.guideRecord.push(t.Record[e]);
        this._2230332165 = 0, this.textRecord = this.guideRecord[this._2230332165], this._OnClose = t.onClose, this._3406448646 = t.OnBeforeClose, this._612288715 = "", this._1356664668 = 50, this._612288715Id = 0, this.img_PlotTextBg.visible = !1, this.img_SayBg.visible = !1;
        var i = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerSex;
        1 == i ? this.img_PlayerHand.skin = global.$Cfg.Common.Palace_PlayerManHand : this.img_PlayerHand.skin = global.$Cfg.Common.Palace_PlayerWomanHand;
        var a = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerHeroHeadId,
            s = global.$Cfg.Common.HeadIconName[i][a];
        this.img_PlayerHead.skin = s;
        var o = this.textRecord.BgPath && "" != this.textRecord.BgPath;
        this._713989164.IsGuide && !o || !o ? (this.lab_Bg.visible = !1, this.lab_Bg.alpha = 0) : (this.lab_Bg.visible = !0, this.lab_Bg.alpha = 1), this.OnClick()
    }, t.OnClose = function () {
        this._3406448646 = null, Laya.timer.clear(this, this.OnLoop), this.img_PlayerCloth.mask && (this.img_PlayerCloth.mask.removeSelf(), this.img_PlayerCloth.mask.destroy(), this.img_PlayerCloth.mask = null), this.guideRecord = []
    }, SayDialog.GetPreLoadResList = function (t, e) {
        var i = [];
        for (var a in e.Record) i.push(e.Record[a]);
        for (var s in i) {
            var o = i[s];
            if (o) switch (o.BgPath && t.push(o.BgPath), o.NpcType) {
                case 0:
                    GetPalaceInterface().DoCheckIsKing(function (e) {
                        if (e) {
                            var i = global.$Sys.GetTableService().GetTableRecord("throne", e.KingId);
                            t.push(i.ClothPath)
                        } else {
                            var a = global.$Api.QueryDataSource("DataBase")._2552118236.Office,
                                i = global.$Sys.GetTableService().GetTableRecord("office", a),
                                s = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, i.Clothing);
                            t.push(s)
                        }
                    }.bind(this));
                    break;
                case 1:
                    var l = global.$Sys.GetTableService().GetTableRecord("hero", o.NpcId);
                    t.push(l.BodyPath);
                    break;
                case 2:
                    var h = global.$Sys.GetTableService().GetTableRecord("npc", o.NpcId);
                    t.push(h.BodyPath);
                    break;
                case 3:
                    var r = global.$Sys.GetTableService().GetTableRecord("beauty", o.NpcId);
                    t.push(r.Body1Path)
            }
        }
        var n = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerSex;
        1 == n ? t.push(global.$Cfg.Common.Palace_PlayerManHand) : t.push(global.$Cfg.Common.Palace_PlayerWomanHand);
        var c = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerHeroHeadId,
            g = global.$Cfg.Common.HeadIconName[n][c];
        t.push(g), e.PlayerClothPath && t.push(e.PlayerClothPath), t.push(global.$Cfg.Common.InitialPlotClothMask), t.push(global.$Cfg.Common.InitialPlotBtn), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SayDialog.uiView, t)
    }
}();
var SearchInfoDialog;
!function () {
    SearchInfoDialog = function () {
        SearchInfoDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnClick)
    }, Laya.class(SearchInfoDialog, "SearchInfoDialog", SearchInfoDialogUI), SearchInfoDialog.FRAME_ICON = ["res/ui/bg/z_bg_63.png", "res/ui/bg/z_bg_63_1.png"];
    var a = SearchInfoDialog.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = GetDataTransfer().GetTableRecord("search", this._4122736007.SearchType, this._4122736007.SearchId),
            e = a.BuildId, t = GetDataTransfer().GetTableRecord("search_build", e);
        this.img_build.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ArtTitlePath, t.ArtFont), this.img_bg.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.SearchBgPath, t.Image), this.img_name.visible = 4 != this._4122736007.SearchType, this.img_reward.alpha = 0, this.img_dialog.alpha = 0, this.mouseEnabled = !1;
        var i = gCfg.Sound.UI.z_ui_sifang1;
        if (1 == this._4122736007.SearchType) {
            i = gCfg.Sound.UI.z_ui_sifang2, this.lab_reward.color = "#69ff44", this.img_role.scaleX = .65, this.img_role.scaleY = .65;
            var r = a.BeautyId, s = GetDataTransfer().GetTableRecord("beauty", r),
                o = global.$Api.QueryDataSource("DataBeauty")._s29dca583b451db00109629e3fc4bcd(r);
            if (GameCommon._s2d5a2f578e0d4afe089454eb2d923d(this.img_role, r), this.lab_name.text = s.Name, this.img_frame.skin = SearchInfoDialog.FRAME_ICON[1], o) this._4122736007.BeautyId ? this.lab_reward.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GetBeautyInfo, s.Name) : this.lab_reward.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.LoverUpReward, s.Name), this.lab_dialog.text = a.Dialog2; else {
                var n = global.$Api.QueryDataSource("DataSearch")._s946c1f8235f05f2ffcb3edcfd0d78f(r),
                    l = gLanguage.SearchChat[Math.min(n, gLanguage.SearchChat.length - 1)];
                this.lab_reward.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(l, s.Name), this.lab_dialog.text = a.Dialog1
            }
        } else {
            if (this.lab_reward.color = "#fff2d2", this.img_role.scaleX = 1, this.img_role.scaleY = 1, 4 == this._4122736007.SearchType) this.lab_name.text = "", this.img_role.skin = "", i = ""; else {
                var h = GetDataTransfer().GetTableRecord("search_role", a.RoleId);
                this.lab_name.text = h.RoleName, GameCommon._sf3d67151fb331699ac4729238a3345(this.img_role, a.RoleId)
            }
            if (this.lab_dialog.text = a.Dialog1, this.img_frame.skin = SearchInfoDialog.FRAME_ICON[0], this.lab_reward.text = "", 2 == this._4122736007.SearchType) {
                var m = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards)[0];
                this.lab_reward.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(m[0], m[1]) + "+" + m[2], i = gCfg.Sound.UI.z_ui_sifang1
            }
            if (3 == this._4122736007.SearchType) {
                i = gCfg.Sound.UI.z_ui_sifang3;
                var g = this._4122736007.Consume[0];
                this.lab_reward.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(g[0], g[1]) + " - " + g[2]
            }
        }
        Laya.Tween.to(this.img_reward, {alpha: 1}, 500), Laya.Tween.to(this.img_dialog, {alpha: 1}, 500, null, Laya.Handler.create(this, function () {
            this.mouseEnabled = !0, this._s6fe429f6517c91b34377579301404d()
        }.bind(this))), i && GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(i)
    }, a._s6fe429f6517c91b34377579301404d = function () {
        var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards);
        if (3 == this._4122736007.SearchType) {
            var e = [];
            _.each(this._4122736007.Consume, function (a) {
                e.push([a[0], a[1], -a[2]])
            })
        }
        GameCommon._s5d340979c9fcfd9445217570f410e4(this.lab_reward, a)
    }, a.OnClick = function () {
        closeCfg = {}, closeCfg.afterClose = function () {
            async.waterfall([function (a) {
                this._4122736007.BeautyId ? GetGuiManager()._s2e22e694b9852084df200bc86f9340("RewardBeautyView", {
                    BeautyId: this._4122736007.BeautyId,
                    OnClose: a
                }) : a()
            }.bind(this), function (a) {
                this._4122736007.OnCloseCallback && this._4122736007.OnCloseCallback(), a()
            }.bind(this)])
        }.bind(this), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SearchInfoDialog", null, closeCfg)
    }, a.OnClose = function () {
        this.lab_name.text = "", this.img_role.skin = ""
    }, SearchInfoDialog.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SearchInfoDialog.uiView, a)
    }
}();
var SearchPage;
!function () {
    SearchPage = function () {
        SearchPage.super(this), this.ui_panel.hScrollBarSkin = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_recover.on(Laya.Event.CLICK, this, this.OnBtnRecoverClick), this.btn_luck.on(Laya.Event.CLICK, this, this.OnBtnLuckClick), this.btn_search.on(Laya.Event.CLICK, this, this.OnBtnSearchClick), this.btn_quickSearch.on(Laya.Event.CLICK, this, this.OnBtnQuickSearchClick), this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Search"})
        }), this._3321166218 = [];
        for (var e = 1; e <= 12; e++) {
            var a = this["btn_build" + e];
            a.on(Laya.Event.CLICK, this, this.OnBtnBuildClick, [e]);
            var t = a.getChildByName("img_title"), i = new Leo.ImageActionManager({Image: t});
            i._sc95f42251335b3aa0013090797aec9("Distance", {Time: 2e3, DistanceY: -10}), this._3321166218.push(i)
        }
        this.btn_build1.runtime = "Leo.ScaleButton", this.list_luck.renderHandler = Laya.Handler.create(this, this.OnCreateLuckIcon, null, !1);
        var n = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SearchPage")
            }, ShowType: ["Money", "Food", "Troops", "Gold", "TotalProp", "Office", "HeadIcon", "Recharge"]
        };
        this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this.ui_TopInfo, n), this._3399175475._s368acb2686a0a07ac871d80150549a("OfficeUpInSearch")
    }, Laya.class(SearchPage, "SearchPage", SearchPageUI);
    var e = SearchPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, GameCommon._s751fe3068f6886bddb070f080cb5ee("search"), Laya.timer.callLater(this, function () {
            this.ui_panel.scrollTo(this.img_layer1.width / 2 - 320, 0)
        }), this._s6615480ab1ed7f1e2727e7196332ee(this.img_layer2, "Cloud1"), this._s6615480ab1ed7f1e2727e7196332ee(this.img_layer3, "Cloud1"), this._s6615480ab1ed7f1e2727e7196332ee(this.img_layer3, "Cloud2"), this._s4fb507d6d0f40b2d2a72f6007a938d(), _.each(this._3321166218, function (e) {
            e._s2e4033b88e999ce7271844dbf3b2dc()
        })
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d(), this.OnRefreshCnt(), Laya.timer.loop(1e3, this, this.OnRefreshCnt.bind(this));
        for (var e = global.$Api.QueryDataSource("DataSearch")._s76981ce7b348e018daaefe5a92c2f9(), a = parseInt((e + 9) / 10), t = jasmin._sc0e3cc5b6d5d591d0c26bfbd7189c4(a, !0), i = a; i < 10; i++) t.push(!1);
        this.list_luck.array = t;
        var n = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1();
        this.btn_search.centerX = n < 2 ? 0 : -130, this.lab_vip.visible = n < 2
    }, e.OnRefreshCnt = function () {
        var e,
            a = global.$Api.QueryDataSource("DataSearch")._se589da605da2fd8d658becd4c5124a(global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285());
        e = a.Count ? jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", a.Count, GetDataSearchProxy()._s2a4877fa87668558de52652ce2a5fc()) : GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(a.RemainingTime);
        var t = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1();
        this.btn_recover.visible = !a.Count, this.btn_search.visible = !!a.Count, this.btn_quickSearch.visible = !(t < 2 || !a.Count), this.lab_cnt.text = e
    }, e.OnClose = function () {
        Laya.timer.clearAll(this), _.each(this._3321166218, function (e) {
            e._s54107fed721f2f5f6636c3b2747bef()
        }), this._3399175475._s54107fed721f2f5f6636c3b2747bef()
    }, e.OnBtnLuckClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("LuckUpDialog", {
            Callback: function () {
                this._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this)
        })
    }, e.OnBtnRecoverClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeId: "RecoverSearchTimes",
            Purpose: "恢复体力",
            OnConfirmUse: function (e) {
                var a = {
                    Callback: function (e) {
                        e.Result && this._s4fb507d6d0f40b2d2a72f6007a938d()
                    }.bind(this)
                };
                GetDataSearchInterface().DoRecover(a)
            }.bind(this)
        })
    }, e.OnBtnSearchClick = function () {
        var e = {
            Callback: function (e) {
                this._s4fb507d6d0f40b2d2a72f6007a938d(), this._sd218961c6e767ca09aa78fa9ad169f(e)
            }.bind(this)
        };
        GetDataSearchInterface().DoSearch(e)
    }, e.OnBtnQuickSearchClick = function () {
        var e = {
            Callback: function (e) {
                this._s4fb507d6d0f40b2d2a72f6007a938d(), this._s6fe429f6517c91b34377579301404d(e)
            }.bind(this)
        };
        GetDataSearchInterface().DoQuickSearch(e)
    }, e._sd218961c6e767ca09aa78fa9ad169f = function (e) {
        this.mouseEnabled = !1;
        var a = GetDataTransfer().GetTableRecord("search", e.SearchType, e.SearchId), t = a.BuildId,
            i = this[jasmin._se91cf955e91eaa1aa510d4335edd4a("btn_build%d", t)], n = +i.x - this.ui_panel.width / 2;
        Laya.Tween.to(this.ui_panel.hScrollBar, {value: n}, 300, null, Laya.Handler.create(this, this.OnShowRewardDialog, [e]))
    }, e.OnShowRewardDialog = function (e) {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_door), Laya.timer.once(500, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("SearchInfoDialog", e), this.mouseEnabled = !0
        }.bind(this))
    }, e._s6fe429f6517c91b34377579301404d = function (e) {
        this.beautyReward = [];
        var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
        _.each(e.RewardArr, function (e) {
            1 == e.SearchType ? this.beautyReward.push(e) : 3 == e.SearchType && _.each(e.Consume, function (e) {
                a.push([e[0], e[1], -e[2]])
            })
        }.bind(this)), a = _.filter(a, function (e) {
            return e[0] != CommonEnum.Asset.DataBeauty
        }), jasmin._s2dedbd0e220887101c856bf900fc57(a) || (this.mouseEnabled = !1), GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, a, function () {
            this.mouseEnabled = !0, this.OnShowArrReward()
        }.bind(this))
    }, e.OnShowArrReward = function () {
        var e = this.beautyReward.shift();
        jasmin._seb2d63e263badd8a69c54d151f6cc7(e) && (params = jasmin._sdf8385ff3a74421ea218e043d47fdc(e), params.OnCloseCallback = function () {
            this.OnShowArrReward()
        }.bind(this), GetGuiManager()._s2e22e694b9852084df200bc86f9340("SearchInfoDialog", params))
    }, e.OnCreateLuckIcon = function (e, a) {
        var t = e.getChildByName("img_icon");
        t.visible = this.list_luck.array[a]
    }, e.OnBtnBuildClick = function (e) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("BuildInfoDialog", {BuildId: e})
    }, e._s6615480ab1ed7f1e2727e7196332ee = function (e, a, t) {
        var i = e.name.split("|")[1], n = i ? parseFloat(i) : 1, r = e.width * n;
        e.height;
        e[a] && (e[a].removeSelf(), e[a].destroy(), e[a] = null);
        var o = jasmin._s449f055209cd01229b1846559026f5(global.$Cfg.Common.SearchCloudPath), h = new Laya.Image(o);
        e[a] = h, e.addChild(h);
        var s = h.measureWidth, l = h.measureHeight;
        h.x = t ? -s : _.random(0, r - 2 * s), h.centerY = _.random(0, l / 2), h.width = s, h.height = l, h.mouseThrough = !0;
        var c = 1e3 * _.random(20, 40);
        Laya.Tween.to(h, {x: r}, c, null, Laya.Handler.create(this, this.UpdateCloud, [e, a, "loop"]))
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }, SearchPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SearchPage.uiView, e), jasmin._s3c96e1f3bee730222501b208d50190(e, global.$Cfg.Common.SearchCloudPath)
    }
}();
var SelectBanquetType;
!function () {
    SelectBanquetType = function () {
        SelectBanquetType.super(this), this.list_type.renderHandler = Laya.Handler.create(this, this.OnCreateJoinType, null, !1), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, {ShowType: ["Gold"]})
    }, SelectBanquetType.BUTTON_SKIN = ["res/ui/button/z_but_03.png", "res/ui/button/z_but_11.png"], Laya.class(SelectBanquetType, "SelectBanquetType", SelectBanquetTypeUI);
    var e = SelectBanquetType.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = GetDataTransfer().GetTable("banquet_join");
        this.list_type.array = _.toArray(e), this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnCreateJoinType = function (e, t) {
        var n = e.getChildByName("spr_icon"), a = e.getChildByName("lab_type"), o = e.getChildByName("lab_BanquetInt"),
            l = (e.getChildByName("lab_consume"), e.getChildByName("btn_join")), i = e.getChildByName("hBox_consume"),
            r = this.list_type.array[t], s = r.BanquetScore > 0 ? "+" + r.BanquetScore : r.BanquetScore;
        o.text = gLanguage.BanquetIntDesc + s, a.text = r.Name, l.offAll(Laya.Event.CLICK), l.on(Laya.Event.CLICK, this, this._4122736007.OnSelectType, [t + 1]);
        var c = global.$Sys.GetTableService().GetTableRecord("consume", r.Consume).Consume[0];
        if (i.destroyChildren(), c[0] == CommonEnum.Asset.DataBase) {
            var u = GameCommon._s66eb52e60b9feb53711943e638c9c3(c[0], c[1], !0);
            i.addChild(u), u.scaleX = .5, u.scaleY = .5, u.centerY = 0;
            var m = new Laya.Label(c[2]);
            m.color = "#14833e", m.fontSize = 23, m.centerY = 0, i.addChild(m)
        } else {
            var y = GameCommon._sf0a0854e48d4ebc005e689b65b3673(c[0], c[1]), m = new Laya.Label(y + "x" + c[2]);
            m.color = "#14833e", m.fontSize = 23, m.centerY = 0, i.addChild(m)
        }
        n.ItemIcon && (n.ItemIcon.removeSelf(), n.ItemIcon.destroy(), n.ItemIcon = null);
        var h = GameCommon._s66eb52e60b9feb53711943e638c9c3(c[0], c[1]);
        n.addChild(h), n.ItemIcon = h, l.skin = SelectBanquetType.BUTTON_SKIN[Number(r.BanquetScore < 0)], l.label = r.BanquetScore > 0 ? gLanguage.JoinBanquet : gLanguage.MakeTrouble
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SelectBanquetType")
    }, e.OnClose = function () {
        _.each(this.list_type.cells, function (e) {
            var t = e.getChildByName("spr_icon"), n = e.getChildByName("hBox_consume");
            n.destroyChildren(), t.ItemIcon && (t.ItemIcon.removeSelf(), t.ItemIcon.destroy(), t.ItemIcon = null)
        })
    }, SelectBanquetType.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SelectBanquetType.uiView, e), jasmin._s3c96e1f3bee730222501b208d50190(e, SelectBanquetType.BUTTON_SKIN)
    }
}();
var SelectDialog;
!function () {
    SelectDialog = function () {
        SelectDialog.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SelectDialog")
        }), this.btn_Select.on(Laya.Event.CLICK, this, this.OnClickSelect), this.btn_Handle.on(Laya.Event.CLICK, this, this.OnClickHandle), this.panel_Message.vScrollBarSkin = null
    }, Laya.class(SelectDialog, "SelectDialog", SelectDialogUI);
    var e = SelectDialog.prototype;
    SelectDialog.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SelectDialog.uiView, e)
    }, e.OnClickSelect = function () {
        var e = this.textArea_Input.text;
        if (e = e.trim(), null != e && "" != e) {
            var t, i;
            if (i = /\d*/, t = e.match(i), t != e) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({Error: global.$Cfg.ErrorCode.INPUT_ERROR});
            this._2230332165 = parseInt(e), this._713989164.OnSelect && this._713989164.OnSelect(this._2230332165, function (e) {
                this._sab3f378b7f9cbcd0bb7f2a82534eea(e)
            }.bind(this))
        }
    }, e.OnClickHandle = function () {
        this._713989164.OnHandle && this._713989164.OnHandle(this._2230332165)
    }, e.OnShow = function (e) {
        this._713989164 = e || {}, this._713989164.OnInitDialog && this._713989164.OnInitDialog(this)
    }, e.OnClose = function () {
        this.vBox_Message.removeChildren()
    }, e._sab3f378b7f9cbcd0bb7f2a82534eea = function (e) {
        this.vBox_Message.removeChildren(), this.vBox_Message.space = 8;
        for (var t = 0; t < e.length; t++) {
            var i = new Laya.HBox;
            i.left = 0, i.right = 0;
            var a = new Laya.Label(e[t].Key + "：");
            a.color = "#5b3914", a.font = "SimHei", a.fontSize = 23, i.addChild(a);
            var n = new Laya.Label(e[t].Value);
            0 == t ? n.color = "#b8651b" : n.color = "#398d19", n.font = "SimHei", n.fontSize = 23, n.right = 0, n.left = a.width, n.wordWrap = !0, i.addChild(n), i.changeItems(), this.vBox_Message.addChild(i), this.vBox_Message.refresh()
        }
    }
}();
var SelectHeroDialog;
!function () {
    SelectHeroDialog = function () {
        SelectHeroDialog.super(this), this._1277725458 = HeroListController._s0daf7356f401bde6dc31ec8d9f8bc8(this.list_selectHero), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
    }, Laya.class(SelectHeroDialog, "SelectHeroDialog", SelectHeroDialogUI);
    var e = SelectHeroDialog.prototype;
    e.OnShow = function (e) {
        var t = {
            ShowType: e.ShowType, Callback: function (t, a) {
                async.waterfall([function (a) {
                    e.Callback(t, a)
                }, function (e) {
                    var t = a.getChildByName("img_headIcon");
                    Laya.loader.load("res/effect/z_buff_1.png", Laya.Handler.create(this, function () {
                        var a = new Effect, i = {
                            Res: "res/effect/z_buff_1.json",
                            IsAutoRemove: !0,
                            IsAutoHide: !0,
                            Scale: 1,
                            Interval: 120,
                            Size: [100, 176]
                        };
                        a.Init(i), a._s2e4033b88e999ce7271844dbf3b2dc([t.width / 2, t.height / 2], e), t.addChild(a), this.mouseEnabled = !1
                    }))
                }.bind(this), function (e) {
                    this.mouseEnabled = !0, this._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this)])
            }.bind(this), Heros: e.Heros
        };
        this._1277725458.Init(t), this._3537444593 = e.Item, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = GetDataTransfer().GetTableRecord("item", this._3537444593);
        this.lab_title.text = e.ItemName + "x" + global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(this._3537444593), this.lab_desc.text = e.ItemDesc, this._1277725458._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SelectHeroDialog")
    }
}();
var SelectHeroPage;
!function () {
    SelectHeroPage = function () {
        SelectHeroPage.super(this), this.list_hero.renderHandler = Laya.Handler.create(this, this.OnCreateHeroBox, null, !1), this.list_hero.vScrollBarSkin = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.radio_type.selectHandler = Laya.Handler.create(this, this.OnSelectType, null, !1), this.btn_sort.on(Laya.Event.CLICK, this, this.OnBtnSortClick), this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Hero"})
        })
    }, Laya.class(SelectHeroPage, "SelectHeroPage", SelectHeroPageUI);
    var e = SelectHeroPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e || {}, this.radio_type.selectedIndex == -1 && (this.radio_type.selectedIndex = 0), this.OnSelectType(this.radio_type.selectedIndex)
    }, e.OnSelectType = function (e) {
        if (e != -1) {
            var t = global.$Api.QueryDataSource("DataHero")._s6b8b55436407229b07aeec45efb78d();
            if (0 == e) return this._1056589751 = t, void this._s4fb507d6d0f40b2d2a72f6007a938d();
            var o = _.filter(t, function (t) {
                var o = global.$Sys.GetTableService().GetTableRecord("hero", t.HeroId);
                return _.intersection(o.SpecialtyID, [e, 5, 6]).length
            });
            o.sort(function (t, o) {
                var r = ShareFunc._sf5c4c05dceefc9148e471ef985221d(t.HeroId, e).Aptitude,
                    a = ShareFunc._sf5c4c05dceefc9148e471ef985221d(o.HeroId, e).Aptitude;
                return a - r
            }), this._1056589751 = o, this._s4fb507d6d0f40b2d2a72f6007a938d()
        }
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this.list_hero.array = [], this.list_hero.array = this._1056589751, this.lab_heroCount.text = this._1056589751.length
    }, e.OnClose = function () {
        GetNewItemRecord()._s7f161edbcb79499e2cfca9d7f81648("NewHero"), Leo.GetNodeAdditionalManager()._s562cd74417e6a2e4054bde0106eee0("NewHero"), Leo.GetNodeAdditionalManager()._s67db71535265aebbaaebe9a029b9a0("Hero")
    }, e.OnCreateHeroBox = function (e, t) {
        e.name = "box" + t;
        var o = e.getChildByName("lab_heroName"), r = e.getChildByName("img_headIcon"), a = e.getChildByName("hBox_lv"),
            i = a.getChildByName("lab_heroLv"), n = e.getChildByName("img_quality"), s = this.list_hero.array[t],
            l = GetDataTransfer().GetTableRecord("hero", s.HeroId);
        GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(r, s.HeroId), n.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, s.Title), i.text = s.Lv, o.text = l.HeroName, e.offAll(Laya.Event.CLICK), e.on(Laya.Event.CLICK, this, this.OnHeroClick, [t]), this._s8c5be7d6d51a594d27451cfb623f26(e, s.HeroId, t)
    }, e.OnBtnSortClick = function () {
        this._1056589751.sort(function (e, t) {
            return t.Lv - e.Lv
        }), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnHeroClick = function (e) {
        var t = this.list_hero.array[e], o = this._4122736007.OnClose;
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("HeroDetailPage", {
            HeroId: t.HeroId, OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SelectHeroPage", {OnClose: o})
            }
        })
    }, e.OnBtnCloseClick = function () {
        jasmin._s712167db7f08127d6dec4aed0f9846(this._4122736007.OnClose) ? this._4122736007.OnClose() : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
    }, e._s8c5be7d6d51a594d27451cfb623f26 = function (e, t, o) {
        var r = Leo.GetNodeAdditionalManager();
        r._s6e7b7bc57df31cac2c87387a6113ea({
            Node: e,
            NodeName: "NewHero" + o,
            OnCheckState: TargetCheck.OnCheckNewHero.bind(this, t),
            OnExecute: GameCommon.OnAddNewTitle,
            Group: "NewHero",
            cover: !0
        }), r._s6e7b7bc57df31cac2c87387a6113ea({
            Node: e,
            NodeName: "HeroUp" + o,
            OnCheckState: TargetCheck.OnCheckHeroById.bind(this, t),
            Group: "HeroUp",
            cover: !0
        })
    }, SelectHeroPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SelectHeroPageUI.uiView, e);
        var t = global.$Api.QueryDataSource("DataHero")._s6b8b55436407229b07aeec45efb78d();
        _.each(t, function (t) {
            var o = GetDataTransfer().GetTableRecord("hero", t.HeroId);
            e.push(o.HeadPath || "res/role/hongyan/dress/shanzaihongyan.png")
        })
    }
}();
var SelectProgressDialog;
!function () {
    SelectProgressDialog = function () {
        SelectProgressDialog.super(this)
    }, Laya.class(SelectProgressDialog, "SelectProgressDialog", Laya.Dialog), SelectProgressDialog.COEFFICEIENT = 100;
    var i = SelectProgressDialog.prototype;
    i.OnShow = function (i) {
        this._4122736007 = i, this._1317894818 && (this._1317894818.removeSelf(), this._1317894818.destroy(), this._1317894818 = null), this._1317894818 = new i.Ui, this.addChild(this._1317894818), this._1317894818.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this._1317894818.btn_ok.on(Laya.Event.CLICK, this, this.OnBtnUseClick), this._1317894818.scrollBar_cnt.changeHandler = Laya.Handler.create(this, this.OnChangeCnt, null, !1), this._1317894818.scrollBar_cnt._scrollSize = SelectProgressDialog.COEFFICEIENT, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, i._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var i = this._4122736007.Max, t = this._4122736007.Min;
        this._1317894818.lab_maxCnt.text = i, this._1317894818.scrollBar_cnt.max = i * SelectProgressDialog.COEFFICEIENT, this._1317894818.scrollBar_cnt.min = t * SelectProgressDialog.COEFFICEIENT, this._1317894818.scrollBar_cnt.value = t, this.OnChangeCnt(t * SelectProgressDialog.COEFFICEIENT)
    }, i.OnChangeCnt = function (i) {
        if (1 != i) {
            var t = this._1317894818.scrollBar_cnt.max, s = this._1317894818.scrollBar_cnt.min;
            this._1317894818.progress_cnt.value = t == s ? 1 : (i - s) / (t - s), this._1955251297 = Math.floor(i / SelectProgressDialog.COEFFICEIENT);
            var e = GameCommon._s5c693d8122a877499a10f605a128a3(this._4122736007.Data[this._1955251297].Consume);
            this._1317894818.lab_nowCnt.text = this._1955251297, this._1317894818.lab_consume.text = e, this._1317894818.hBox_cnt.refresh()
        }
    }, i.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SelectProgressDialog")
    }, i.OnClose = function () {
        this._1317894818 && (this._1317894818.removeSelf(), this._1317894818.destroy(), this._1317894818 = null)
    }, SelectProgressDialog.GetPreLoadResList = function (i, t) {
        t && t.Ui && leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(t.Ui.uiView, i)
    }, i.OnBtnUseClick = function () {
        var i = this._1955251297;
        this._4122736007.OnClick(i), GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SelectProgressDialog")
    }
}();
var SetView;
!function () {
    SetView = function () {
        SetView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SetView")
        }), this.btn_ContantUs.on(Laya.Event.CLICK, this, this.OnContantUs), this.btn_SwitchServer.on(Laya.Event.CLICK, this, this.OnSwitchServer), this.btn_CdKey.on(Laya.Event.CLICK, this, this.OnCdKey), this.cb_Sound.on("change", this, this.OnChangeVolume)
    }, Laya.class(SetView, "SetView", SetViewUI), SetView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SetViewUI.uiView, e)
    };
    var e = SetView.prototype;
    e._s3820bbc7c472bc593af5cd2605dff2 = function () {
        var e = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("dataCfg") || {};
        return e.volume
    }, e.OnChangeVolume = function () {
        if (this._1708689357) return void(this._1708689357 = !1);
        var e = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("dataCfg") || {};
        this._s3820bbc7c472bc593af5cd2605dff2() ? (e.volume = !1, GetAudioHelper()._sa89c4e70b85bed6a0eabc63a523bb8()) : (e.volume = !0, GetAudioHelper()._s09eb086732200ccddc4f8d1803c807()), GetStorage()._s54216acbc0200500c827232db13a75("dataCfg", e)
    }, e.OnShow = function (e) {
        GetVersionCfgManager().GetValue("CloseCdKey") && (this.btn_CdKey.visible = !1), this.NameValue.text = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), this.IdValue.text = global.$Api.QueryDataSource("DataBase").GetValue("Uid"), this.SeverValue.text = gServerName, this.VersionId.text = GetVersionCfgManager().GetValue("Version");
        var t = GetServerInfoInterface().GetValue("ServerSetting");
        t && t.QQ ? this.btn_ContantUs.visible = !0 : this.btn_ContantUs.visible = !1, this.cb_Sound.selected != this._s3820bbc7c472bc593af5cd2605dff2() && (this._1708689357 = !0, this.cb_Sound.selected = this._s3820bbc7c472bc593af5cd2605dff2())
    }, e.OnContantUs = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("CustomeRservice")
    }, e.OnSwitchServer = function () {
        GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.ModuleNoExist]})
    }, e.OnCdKey = function () {
        var e = {
            Skin: InputDialog_PUI, OnClick: function (e) {
                var t = {cdKey: e}, a = GetCodeReward._s6a4dba9453762113ae0d1467dd81b3(t);
                if (!a.Result) {
                    var n = GameCommon._sfda1f63c5facab3c938382c5591e8c(a.Error);
                    return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [n], Colors: ["#ffffff"]})
                }
                GetCmdProxy().DoCmd("GetCodeReward", t, function (e) {
                    var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
                    GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, t), GameCommon._s8309ef797f42a26c507d05ee4868de()
                })
            }, Title: "请输入兑换码"
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("Leo.InputDialog_P", e)
    }
}();
var ShopGiftPrefab;
!function () {
    ShopGiftPrefab = function (t, i) {
        ShopGiftPrefab.super(this), this._1648718281 = 115, this._275936707 = 150, this._2521598750 = i, this._1201874386 = 16, this._2093942233 = 16, this._2068411423 = t, this.Init()
    }, Laya.class(ShopGiftPrefab, "ShopGiftPrefab", ShopGiftPrefabUI);
    var t = ShopGiftPrefab.prototype;
    t.Init = function () {
        var t = GetDataTransfer().GetTableRecord("shop_gift", this._2068411423), i = t.ProductInfo;
        if (t.VipLimit ? (this.img_Vip.visible = !0, this.img_Vip.skin = "res/ui/artfont/vip/z_vip_word" + (20 + t.VipLimit) + ".png") : this.img_Vip.visible = !1, this.lab_Name.text = t.ProductName, this.lab_Price.text = t.Price, t.BuyLimit != -1) {
            var e = GetDataShop()._sa476f88e35cb230622f8fbfe7d129f(2, this._2068411423);
            this.lab_LimitCount.visible = !0, this.lab_LimitCount.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ShopBuyLimit, t.BuyLimit - e)
        } else this.lab_LimitCount.visible = !1;
        var h = Math.ceil(i.length / 4), s = this._1648718281 * h, a = s + (h + 1) * this._1201874386;
        this.ui_Items.height = a, this.height = this._275936707 + a, this.ui_Node.height = this.height, this._s01056427d8b105975b52e209c9b5f5(i), this.btn_Buy.on(Laya.Event.CLICK, this, this.OnBuyGift, [this._2068411423])
    }, t.OnBuyGift = function (t) {
        GetDataShopInterface().DoBuyProduct(2, t, function (t) {
            if (t.Result) {
                var i = GetDataTransfer().GetTableRecord("shop_gift", this._2068411423);
                if (i.BuyLimit != -1) {
                    var e = GetDataShop()._sa476f88e35cb230622f8fbfe7d129f(2, this._2068411423);
                    this.lab_LimitCount.visible = !0, this.lab_LimitCount.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ShopBuyLimit, i.BuyLimit - e)
                } else this.lab_LimitCount.visible = !1;
                GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), this._2521598750 && this._2521598750(t)
            }
        }.bind(this))
    }, t._s01056427d8b105975b52e209c9b5f5 = function (t) {
        var i = 0;
        _.each(t, function (t) {
            var e = Math.floor(i / 4), h = i % 4, s = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({
                Id: t[1],
                UseEff: !0,
                ShowCnt: !0,
                Count: t[2]
            });
            s.x = this._2093942233 + h * (this._1648718281 + this._2093942233), s.y = this._1201874386 + e * (this._1648718281 + this._1201874386), this.ui_Items.addChild(s), i++
        }.bind(this))
    }
}();
var ShopView;
!function () {
    ShopView = function () {
        ShopView.super(this), this.ui_ProductList.array = [], this.btn_Close.on(Laya.Event.CLICK, this, function () {
            this.m_OnClose && this.m_OnClose()
        }), this.ui_GiftPanel.vScrollBarSkin = null, this.ui_ProductList.vScrollBarSkin = null, this.redioGroup_type.selectHandler = new Laya.Handler(this, this.OnSelectProductType), this.redioGroup_type.selectedIndex = 0, this.ui_ProductList.renderHandler = new Laya.Handler(this, this.OnCreateProduct);
        var t = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ShopView", {OnClose: this.m_OnClose}), this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this), ShowType: ["Gold", "Recharge"], Custom: {}
        };
        this._2141111536 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8({
            ui_labGold: this.ui_labGold,
            ui_btnRecharge: this.ui_btnRecharge
        }, t)
    }, Laya.class(ShopView, "ShopView", ShopUI), ShopView.GetPreLoadResList = function (t) {
        for (var e = 1; e <= 10; e++) t.push("res/ui/artfont/vip/z_vip_word" + (10 + e) + ".png"), t.push("res/ui/artfont/vip/z_vip_word" + (20 + e) + ".png");
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ShopUI.uiView, t), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ShopGiftPrefabUI.uiView, t)
    };
    var t = ShopView.prototype;
    t._s4717b14a0f77431d5ab947502deddb = function () {
        var t = GetDataTransfer().GetTable("shop_gift"), e = _.filter(t, function (t) {
            var e = global.$Api.QueryDataSource("DataShop")._sc07456f990b329009a736a0abd27c3(1, t.ProductId, global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285());
            if (e && t.Type && !jasmin._s2dedbd0e220887101c856bf900fc57(t.Stype)) {
                e = !1;
                for (var i in t.Stype) {
                    var r = GetActivityManager()._s35ef644c345a298b403c35a4eff8dc(t.Type, t.Stype[i]);
                    if (r) {
                        e = !0;
                        break
                    }
                }
            }
            return e
        });
        e.sort(function (t, e) {
            return t.ShowSort - e.ShowSort
        });
        for (var i = 0; i < e.length; i++) {
            var r = e[i];
            this.ui_GiftBox.addChild(new ShopGiftPrefab(r.ProductId, this.OnBuySuccess.bind(this)))
        }
    }, t.OnCreateProduct = function (t, e) {
        var i = t.dataSource, r = i.ProductInfo[0][1], o = GetDataTransfer().GetTableRecord("item", r);
        t.getChildByName("lab_Name").text = o.ItemName, t.getChildByName("lab_Price").text = i.Price, t.getChildByName("lab_Desc").text = o.ItemDesc;
        var a = t.getChildByName("ui_Icon");
        a.skin = "", a.destroyChildren(), a.addChild(GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({
            Id: r,
            UseEff: !0
        }));
        var n = t.getChildByName("lab_Limit"), s = i.BuyLimit;
        if (s != -1) {
            var u = GetDataShop()._sa476f88e35cb230622f8fbfe7d129f(1, i.ProductId);
            n.visible = !0, n.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ShopBuyLimit, s - u)
        } else n.visible = !1;
        if (i.VipLimit) {
            var h = "res/ui/artfont/vip/z_vip_word" + (10 + i.VipLimit) + ".png", c = new Laya.Image(h);
            a.addChild(c)
        }
        var l = t.getChildByName("btn_BuyProduct");
        l.on(Laya.Event.CLICK, this, this.OnBuyProduct, [i.ProductId, t])
    }, t.OnBuySuccess = function (t, e, i) {
        var r = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
        if (GameCommon._s5d340979c9fcfd9445217570f410e4(this, r), this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d(), e) {
            var o = e.getChildByName("lab_Limit"), a = global.$Sys.GetTableService().GetTableRecord("shop_product", i),
                n = a.BuyLimit;
            if (n != -1) {
                var s = GetDataShop()._sa476f88e35cb230622f8fbfe7d129f(1, a.ProductId);
                o.visible = !0, o.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.ShopBuyLimit, n - s)
            } else o.visible = !1
        }
    }, t.OnBuyProduct = function (t, e) {
        GetDataShopInterface().DoBuyProduct(1, t, function (t, e, i) {
            i.Result && (GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), this.OnBuySuccess(i, t, e))
        }.bind(this, e, t))
    }, t._s1b81a5e5e2285fac7d6524e3844f06 = function () {
        var t = GetDataTransfer().GetTable("shop_product"), e = _.filter(t, function (t) {
            var e = global.$Api.QueryDataSource("DataShop")._sc07456f990b329009a736a0abd27c3(1, t.ProductId, global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285());
            if (e && t.Type && !jasmin._s2dedbd0e220887101c856bf900fc57(t.Stype)) {
                e = !1;
                for (var i in t.Stype) {
                    var r = GetActivityManager()._s35ef644c345a298b403c35a4eff8dc(t.Type, t.Stype[i]);
                    if (r) {
                        e = !0;
                        break
                    }
                }
            }
            return e
        });
        e.sort(function (t, e) {
            return t.ShowSort - e.ShowSort
        }), this.ui_ProductList.array = e
    }, t.OnSelectProductType = function (t) {
        this.ui_ProductList.visible = 0 == t, this.ui_GiftPanel.visible = 1 == t
    }, t.OnShow = function (t) {
        t = t || {}, this.m_OnClose = t.OnClose, this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d(), this._s1b81a5e5e2285fac7d6524e3844f06(), this._s4717b14a0f77431d5ab947502deddb()
    }, t.OnClose = function () {
        _.each(this.ui_GiftBox._childs, function (t) {
            t.ui_Items.destroyChildren()
        }), this.ui_GiftBox.destroyChildren(), _.each(this.ui_ProductList._cells, function (t) {
            var e = t.getChildByName("ui_Icon");
            e.destroyChildren()
        })
    }
}();
var SignInLayar;
!function () {
    function a() {
        a.super(this), this.list_signIn.renderHandler = Laya.Handler.create(this, this.OnCreateSignReward, null, !1), this.list_signIn.vScrollBarSkin = null
    }

    a.SHOW_DATE_NUM = 12, a.SHOW_ROW_NUM = 4, a.BG_SKIN = [], Laya.class(a, "SignInLayar", SignInLayarUI);
    var i = a.prototype;
    i._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        for (var i = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), e = global.$Api.QueryDataSource("DataSign").GetValue("SignInCount"), n = global.$Api.QueryDataSource("DataSign")._s1192e3b4f68594065bf98c836769d9(i), t = n ? e + 1 : e, l = Math.floor((t - 1) / a.SHOW_ROW_NUM) * a.SHOW_ROW_NUM + 1, o = [], g = l; g < l + a.SHOW_DATE_NUM; g++) o.push({SignDate: g});
        this.list_signIn.array = o, this.list_signIn.scrollTo(0)
    }, i.OnCreateSignReward = function (a, i) {
        var e = a.getChildByName("vbox_reward"), n = a.getChildByName("img_getReward"), t = a.getChildByName("img_bg"),
            l = a.getChildByName("img_status"), o = a.getChildByName("hBox_date"), g = o.getChildByName("lab_date"),
            r = a.getChildByName("img_flicker"), s = this.list_signIn.array[i];
        g.text = s.SignDate, o.width = 0, o.refresh();
        var m = 0;
        _.each(o._childs, function (a) {
            m += a.measureWidth
        }), o.width = m;
        var S = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            h = global.$Api.QueryDataSource("DataSign").GetValue("SignInCount"),
            C = global.$Api.QueryDataSource("DataSign")._s1192e3b4f68594065bf98c836769d9(S), c = C ? h + 1 : h,
            d = global.$Api.Formula._s00f001ceb0356b75361d11f1e152fd(s.SignDate);
        e.destroyChildren();
        var u = .7, f = s.SignDate > c || s.SignDate == c && C;
        _.each(d, function (a) {
            var i = GameCommon._se35db439c4ad2364b987453544666d(a, !1, !0, a[2], {UseEff: f});
            i.scaleX = u, i.scaleY = u, e.addChild(i)
        }), a.offAll(Laya.Event.CLICK), n.visible = !1, r.visible = !1, r.Action && r.Action._s54107fed721f2f5f6636c3b2747bef(), s.SignDate < c && (n.visible = !0, t.skin = global.$Cfg.Common.SignBgPath[0], l.skin = global.$Cfg.Common.SignInStatusPath[1]), s.SignDate > c && (t.skin = global.$Cfg.Common.SignBgPath[1], l.skin = global.$Cfg.Common.SignInStatusPath[2]), s.SignDate == c && (C ? (r.visible = !0, a.on(Laya.Event.CLICK, this, this.OnSignIn, [a]), t.skin = global.$Cfg.Common.SignBgPath[1], l.skin = global.$Cfg.Common.SignInStatusPath[0], r.Action || (r.Action = new Leo.ImageActionManager({Image: r}), r.Action._sc95f42251335b3aa0013090797aec9("Flicker", {
            Time: 2e3,
            Alpah: .2
        })), r.Action._s2e4033b88e999ce7271844dbf3b2dc()) : (n.visible = !0, t.skin = global.$Cfg.Common.SignBgPath[0], l.skin = global.$Cfg.Common.SignInStatusPath[1]))
    }, i.OnSignIn = function (a) {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), GetDataSignInterface().DoSignIn({
            Callback: function (i) {
                if (i.Result) {
                    var e = a.getChildByName("img_status");
                    e.skin = global.$Cfg.Common.SignInStatusPath[1], this.moustEnabled = !1, Laya.Tween.from(e, {
                        scaleX: 3,
                        scaleY: 3
                    }, 500, null, Laya.Handler.create(this, function () {
                        this.moustEnabled = !0;
                        var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(i.Rewards);
                        GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, a), this._s4fb507d6d0f40b2d2a72f6007a938d()
                    }.bind(this)))
                }
            }.bind(this)
        })
    }, i._s90746ef77ff05d47cb37e68d587694 = function () {
        _.each(this.list_signIn.cells, function (a) {
            var i = a.getChildByName("img_flicker");
            i.Action && i.Action._s54107fed721f2f5f6636c3b2747bef();
            var e = a.getChildByName("vbox_reward");
            e.destroyChildren()
        })
    }, a.GetPreLoadResList = function (i) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(a.uiView, i), jasmin._s3c96e1f3bee730222501b208d50190(i, global.$Cfg.Common.SignBgPath)
    }
}();
var SprintGuildRank;
!function () {
    SprintGuildRank = function () {
        SprintGuildRank.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SprintGuildRank")
        }), this.list_rank.renderHandler = new Laya.Handler(this, this.OnListRankUpdateItem), this.list_rank.vScrollBarSkin = "", this.listGuild.renderHandler = new Laya.Handler(this, this.OnListGuildUpdateItem), this.listGuild.vScrollBarSkin = ""
    }, Laya.class(SprintGuildRank, "SprintGuildRank", SprintGuildRankUI), SprintGuildRank.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SprintGuildRankUI.uiView, a)
    };
    var a = SprintGuildRank.prototype;
    a.OnShow = function (a) {
        this._713989164 = a, this._4161222688 = a.RankData, this._1340348542 = this._713989164.SType % 10, this.OnUpdateView()
    }, a.OnUpdateView = function () {
        this.labMyInfo.text = gLanguage.RankScoreText[this._1340348542] + "：", this.labGuildInfo.text = gLanguage.RankScoreText[this._1340348542], this.labInfo.text = gLanguage.RankScoreText[this._1340348542], this.list_rank.array = this._4161222688.RankList;
        var a = global.$Api.QueryDataSource("DataGuild").GetValue("GuildId"), t = this._4161222688.UserInfos[a];
        if (t) {
            this.labGuildName.text = t.UserData.Name, this.labMyValue.text = t.Score, this.listGuild.visible = !0;
            var i = t.UserData.MembersContribution, n = [];
            for (var e in i) n.push({Uid: e, Contribution: i[e].Contribution, Name: i[e].Name});
            n.sort(function (a, t) {
                return t.Contribution - a.Contribution
            });
            for (var r = 0; r < n.length; r++) n[r].Rank = r + 1;
            this.labMembersInfo.visible = jasmin._s2dedbd0e220887101c856bf900fc57(n), this.listGuild.array = n
        } else this.labGuildName.text = "无", this.labMyValue.text = "0", this.listGuild.visible = !1
    }, a.OnListRankUpdateItem = function (a, t) {
        var i = this.list_rank, n = this._4161222688.UserInfos[i.array[t]], e = a.getChildByName("labScore"),
            r = a.getChildByName("labName"), l = a.getChildByName("sprRank");
        if (r.text = n.UserData.Name, r.on(Laya.Event.CLICK, this, this._OnShowGuild, [this._713989164, i.array[t]]), e.text = n.Score, l.destroyChildren(), n.Rank && n.Rank <= 3) var s = new Laya.Image(global.$Cfg.Common.RankIcon[n.Rank - 1]); else {
            var s = new Laya.Label(n.Rank || gLanguage.NoJoinRank);
            s.color = "#755848", s.fontSize = 23
        }
        s.centerX = 0, s.centerY = 0, l.addChild(s)
    }, a._OnShowGuild = function (a, t) {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("GuildMembersRank", {RankParam: a, GuildId: t})
    }, a.OnListGuildUpdateItem = function (a, t) {
        var i = (this.listGuild, this.listGuild.array[t]), n = a.getChildByName("labScore"),
            e = a.getChildByName("labName"), r = a.getChildByName("sprRank");
        if (e.text = i.Name, e.on(Laya.Event.CLICK, this, this._PlayerInfo, [i.Uid]), n.text = i.Contribution, r.destroyChildren(), i.Rank && i.Rank <= 3) var l = new Laya.Image(global.$Cfg.Common.RankIcon[i.Rank - 1]); else {
            var l = new Laya.Label(i.Rank || gLanguage.NoJoinRank);
            l.color = "#755848", l.fontSize = 23
        }
        l.centerX = 0, l.centerY = 0, r.addChild(l)
    }, a._PlayerInfo = function (a) {
        GetPalaceInterface().DoGetPlayerInfo(a, function (t) {
            t.Id = a, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", t)
        })
    }
}();
var SprintRank;
!function () {
    SprintRank = function () {
        SprintRank.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SprintRank")
        }), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this), this._1092471860Data = {}, this.list_rank.vScrollBarSkin = null
    }, Laya.class(SprintRank, "SprintRank", SprintRankUI);
    var a = SprintRank.prototype;
    SprintRank.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SprintRank.uiView, a)
    }, a._sbe6272b25b096db7243ecce60a346c = function () {
        var a = (this._713989164.SType, null);
        a = function (a, e, t) {
            a.text = e.Score || "0", a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(e.Rank), a.name && "" != a.name && (1 == this._1340348542 ? a.x = 455 : a.x = 390)
        }.bind(this), this._713989164.IsLevelRank && (a = function (a, e, t) {
            for (var i = global.$Sys.GetTableService().GetTable("stage"), n = 0, r = 1, o = 1, s = 0; r <= _.size(i); r++) {
                for (o = 1; o <= _.size(i[r]); o++) if (n += i[r][o].Progress, n >= e.Score) {
                    s = i[r][o].Progress - (n - e.Score);
                    break
                }
                if (n >= e.Score) break
            }
            r > _.size(i) && (jasmin.Error("Level Rank Data Error"), r = _.size(i));
            var l = global.$Sys.GetTableService().GetTableRecord("level", r);
            a.text = r + "." + l.Name + "(" + o + "-" + s + ")", a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(e.Rank), a.name && "" != a.name && (1 == this._1340348542 ? a.x = 455 : a.x = 390)
        }.bind(this));
        var e = null;
        1 != this._1340348542 && (e = function (a, e, t) {
            if ("" != a.name) a.visible = !1; else {
                a.destroyChildren(), a.visible = !0;
                var i = null;
                if (e.KingId) {
                    var n = global.$Sys.GetTableService().GetTableRecord("throne", e.KingId);
                    i = new Laya.Image(n.NameFontPath)
                } else {
                    var r = e.UserData ? e.UserData.Office : global.$Api.QueryDataSource("DataBase").GetValue("Office"),
                        o = global.$Sys.GetTableService().GetTableRecord("office", r).OfficeName;
                    i = new Laya.Label(o), i.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(e.Rank), i.fontSize = 23
                }
                i.centerX = 0, i.centerY = 0, a.addChild(i)
            }
        }.bind(this));
        var t = function (a, e, t) {
            a.text = e.UserData ? e.UserData.Name : global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), a.color = this._sb3df77da8dd199cc8f2c9b1b4bff73(e.Rank), a.name && "" != a.name && (a.underline = !0, a.offAll(Laya.Event.CLICK), a.on(Laya.Event.CLICK, this, function () {
                var a = this._1092471860Data.RankList[t];
                GetPalaceInterface().DoGetPlayerInfo(a, function (e) {
                    e.Id = a, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", e)
                })
            }))
        }.bind(this);
        this._1092471860Data.ShowTag = {
            Rank: null,
            Name: t,
            Score: a,
            Office: e
        }, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._sb3df77da8dd199cc8f2c9b1b4bff73 = function (a) {
        return a && a <= 3 ? global.$Cfg.Common.RankColor[a - 1] : "#755848"
    }, a._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        var a = this._713989164.SType;
        this._1340348542 = a % 10;
        var e = global.$Sys.GetTableService().GetTableRecord("activity_atlist", a)[1].RankScoreText;
        this.lab_RankText.text = e, this.lab_ScoreText.text = e + "：", 1 == this._1340348542 ? (this.lab_RankOffice.visible = !0, this.lab_RankText.x = 457) : (this.lab_RankOffice.visible = !1, this.lab_RankText.x = 393)
    }, a.OnShow = function (a) {
        this._713989164 = a, this._1092471860Data = this._713989164.RankData, this._sc9209ae0dd3fdb06533b36ec4474b1(), this._sbe6272b25b096db7243ecce60a346c()
    }, a.OnClose = function () {
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
    }
}();
var SprintRankActivity;
!function () {
    SprintRankActivity = function () {
        SprintRankActivity.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnCloseView), this.list_Activity.vScrollBarSkin = null, this.list_Activity.renderHandler = Laya.Handler.create(this, this.OnCreateBox, null, !1)
    }, Laya.class(SprintRankActivity, "SprintRankActivity", SprintRankActivityUI), SprintRankActivity.GetPreLoadResList = function (t) {
        var i = global.$Sys.GetTableService().GetTable("activity_atlist");
        for (var e in i) t.push(i[e][1].IconPath);
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SprintRankActivityUI.uiView, t)
    };
    var t = SprintRankActivity.prototype;
    t.OnShow = function (t) {
        this._4122736007 = t, this._3084668842 = [], this._2840321814 = 0, this._4010244796 = 0, this._3733238110 = ActivityBase.STATUS.Start, this._3418094735 = ActivityBase.STATUS.Stop, this.OnUpdateList(), this.OnTimeHanlder(), Laya.timer.loop(1e3, this, this.OnTimeHanlder)
    }, t.OnClose = function () {
        Laya.timer.clear(this, this.OnTimeHanlder)
    }, t.OnCloseView = function () {
        return this._4122736007 && this._4122736007.OnClose ? void this._4122736007.OnClose() : (GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi"), void Laya.timer.clear(this, this.OnTimeHanlder))
    }, t.OnTimeHanlder = function () {
        _.each(this.list_Activity.cells, function (t) {
            t.event("UpdateTime")
        }.bind(this))
    }, t.OnUpdateList = function () {
        var t = this._s8253daee5c9ba8e7895aafa21e8168();
        return t.length <= 0 ? (this.OnCloseView(), void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.NoRankActivity]})) : void(this.list_Activity.array = t)
    }, t._s8253daee5c9ba8e7895aafa21e8168 = function () {
        var t = [], i = this._3418094735;
        return t = this._s94e94387ffbb11b16b5f2af947b37e(t, i), i = this._3733238110, t = this._s94e94387ffbb11b16b5f2af947b37e(t, i)
    }, t._s94e94387ffbb11b16b5f2af947b37e = function (t, i) {
        var e = GetActivityManager()._s59445864d00fe89be54e72799eb0e1(i);
        for (var a in e) {
            var n = e[a].Object._s505a2ac0cde720ef9099aed2ef7fc0();
            if ("AtList" == n.Type) {
                this._3084668842.push(e[a]);
                for (var s in n.SmallTypes) t.push(n.SmallTypes[s])
            }
        }
        return t
    }, t.OnCreateBox = function (t, i) {
        var e = null, a = this._s89808ae86e3b6845d44601807c73d7(i), n = a.Object._s505a2ac0cde720ef9099aed2ef7fc0(),
            e = t.dataSource.SType, s = global.$Sys.GetTableService().GetTableRecord("activity_atlist", e),
            r = s[1].IconPath, l = t.getChildByName("img_ActivityBg");
        l.skin = r;
        var c = t.getChildByName("lab_ActTimeText"), v = c.getChildByName("lab_ActTime"), o = n.Timelst.StartTimelst,
            m = n.Timelst.StopTimelst,
            y = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RankActivityTime, o[1], o[2], o[3], o[4], m[1], m[2], m[3], m[4]);
        v.text = y;
        var h = t.getChildByName("lab_ActStop"), S = t.getChildByName("lab_TimeDownText"), A = !1;
        4 == a.Object._s6ddc50a91ad6d7036fad03810de880() ? A = !0 : this.OnUpdateTime(t, i), h.visible = A, S.visible = !A;
        var T = t.getChildByName("btn_IntoAct");
        T.off(Laya.Event.CLICK, this, this.OnIntoActivity), T.on(Laya.Event.CLICK, this, this.OnIntoActivity, [i]);
        var u = "UpdateTime";
        t.offAll(u), t.on(u, this, this.OnUpdateTime, [t, i])
    }, t.OnUpdateTime = function (t, i) {
        if (t) {
            var e = t.getChildByName("lab_ActStop"), a = t.getChildByName("lab_TimeDownText"),
                n = this._s89808ae86e3b6845d44601807c73d7(i);
            if (n) {
                var s = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
                if (data = n.Object._s505a2ac0cde720ef9099aed2ef7fc0(), 4 == n.Object._s6ddc50a91ad6d7036fad03810de880()) return a.visible = !1, void(e.visible = !0);
                a.visible = !0, e.visible = !1;
                var r = (data.Timelst.StartTimelst, data.Timelst.StopTimelst),
                    l = jasmin._sa8ce9b799dca49cfed044a7bb95483(r), c = l - s,
                    v = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(c), o = a.getChildByName("lab_TimeDown");
                o.text = v
            }
        }
    }, t._s89808ae86e3b6845d44601807c73d7 = function (t) {
        var i = t;
        for (var e in this._3084668842) if (activity = this._3084668842[e], data = activity.Object._s505a2ac0cde720ef9099aed2ef7fc0(), i -= data.SmallTypes.length, i < 0) return activity
    }, t.OnIntoActivity = function (t) {
        var i = this._s89808ae86e3b6845d44601807c73d7(t);
        if (!i) return this.OnShow(), void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.RankActivityEnd]});
        var e = this.list_Activity.array[t], a = {Activity: i, SType: e};
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SprintRankDetail", a)
    }
}();
var SprintRankBecomeKing;
!function () {
    SprintRankBecomeKing = function () {
        SprintRankBecomeKing.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SprintRankBecomeKing")
        })
    }, Laya.class(SprintRankBecomeKing, "SprintRankBecomeKing", SprintRankBecomeKingUI), SprintRankBecomeKing.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SprintRankBecomeKingUI.uiView, e)
    };
    var e = SprintRankBecomeKing.prototype;
    e.OnShow = function (e) {
        this.mouseEnabled = !1, Laya.timer.once(2e3, this, function () {
            this.mouseEnabled = !0
        }), this._713989164 = e;
        var a = e.KingId;
        this.OnTweenBg();
        var n = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerSex,
            i = global.$Api.QueryDataSource("DataBase")._2552118236.PlayerHeroHeadId,
            t = global.$Cfg.Common.HeadIconName[n][i];
        Laya.loader.load(t, Laya.Handler.create(this, function () {
            this.img_PlayerHead.skin = t
        }));
        var o = global.$Sys.GetTableService().GetTableRecord("throne", a), r = o.ClothPath;
        Laya.loader.load(r, Laya.Handler.create(this, function () {
            this.img_PlayerCloth.skin = r
        }));
        var l = o.FontPath;
        Laya.loader.load(l, Laya.Handler.create(this, function () {
            this.img_KingName.skin = l
        }))
    }, e.OnClose = function () {
        Laya.Tween.clearAll(this.img_PlayerBg)
    }, e.OnTweenBg = function () {
        Laya.Tween.clearAll(this.img_PlayerBg), Laya.Tween.to(this.img_PlayerBg, {rotation: this.img_PlayerBg.rotation + 360}, 3e4, null, Laya.Handler.create(this, this.OnTweenBg))
    }
}();
var SprintRankDetail;
!function () {
    SprintRankDetail = function () {
        SprintRankDetail.super(this), this.btn_Close.on(Laya.Event.CLICK, this, this.OnCloseView), this.btn_Rank.on(Laya.Event.CLICK, this, this.OnOpenRank), this.btn_GetReward.on(Laya.Event.CLICK, this, this.OnGetReward), this.panel_ActItem.vScrollBarSkin = null
    }, GameCommon._s06bc1af507ebc0f5390d44bd8481b9(SprintRankDetailUI, ["item", "box_Item"]), Laya.class(SprintRankDetail, "SprintRankDetail", SprintRankDetailUI), SprintRankDetail.GetPreLoadResList = function (t) {
        var e = global.$Sys.GetTableService().GetTable("activity_atlist");
        for (var i in e) t.push(e[i][1].IconName), t.push(e[i][1].InfoPath);
        for (var i in global.$Cfg.Common.GuildSprintRank) t.push(global.$Cfg.Common.GuildSprintRank[i]);
        GameCommon._s06cdfd3fa57289d2a621c2a5c34f27(SprintRankDetailUI, t)
    };
    var t = SprintRankDetail.prototype;
    t.OnShow = function (t) {
        this._4122736007 = t, this._sc9209ae0dd3fdb06533b36ec4474b1(), this._sbe6272b25b096db7243ecce60a346c(), this._sf5022c8b253f370a62098754d303c1(), this.OnTimeHanlder(), Laya.timer.loop(1e3, this, this.OnTimeHanlder)
    }, t.OnClose = function () {
        Laya.timer.clear(this, this.OnTimeHanlder), this.vBox_ActItem.destroyChildren()
    }, t.OnCloseView = function () {
        return this._4122736007 && this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("SprintRankActivity")
    }, t._s646a51d9f7358cdd4aa83bee437051 = function () {
        var t = this._4122736007.Activity;
        if (!t) return !1;
        var e = t.Object._s6ddc50a91ad6d7036fad03810de880();
        return 3 == e || 4 == e
    }, t._s95fe664233ef81a493aa0fd2d990c2 = function () {
        this._4122736007 || (this._4122736007 = {}), this._4122736007.OnClose || (this._4122736007.OnClose = function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
        }), this.OnCloseView(), GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.RankActivityEnd]})
    }, t.OnTimeHanlder = function () {
        if (!this.img_HasGetReward.visible) {
            var t = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), e = this._4122736007.Activity,
                i = e.Object._s505a2ac0cde720ef9099aed2ef7fc0();
            if (this._s646a51d9f7358cdd4aa83bee437051()) {
                if (4 == e.Object._s6ddc50a91ad6d7036fad03810de880()) return this.lab_TimeDownText.visible = !1, this.lab_ActStop.visible = !0, this.lab_NoTime.visible = !1, void(this.btn_GetReward.mouseEnabled = !0);
                var a = (i.Timelst.StartTimelst, i.Timelst.StopTimelst), n = jasmin._sa8ce9b799dca49cfed044a7bb95483(a),
                    r = n - t, s = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(r);
                this.lab_TimeDown.text = s, this.lab_ActStop.visible = !1, this.lab_TimeDownText.visible = !0, this.lab_NoTime.visible = !0, this.btn_GetReward.mouseEnabled = !1
            }
        }
    }, t.OnOpenRank = function () {
        if (!this._643151339) return void this._sbe6272b25b096db7243ecce60a346c(function () {
            if (!this._s646a51d9f7358cdd4aa83bee437051()) return void this._s95fe664233ef81a493aa0fd2d990c2();
            var t = this._4122736007.Activity,
                e = (t.Object._s505a2ac0cde720ef9099aed2ef7fc0(), this._4122736007.SType.SType),
                i = 4 == this._1340348542, a = {SType: e, RankData: this._643151339, IsLevelRank: i}, n = "SprintRank";
            5 == this._1340348542 && (n = "SprintGuildRank"), GetGuiManager()._s2e22e694b9852084df200bc86f9340(n, a)
        }.bind(this));
        if (!this._s646a51d9f7358cdd4aa83bee437051()) return void this._s95fe664233ef81a493aa0fd2d990c2();
        var t = this._4122736007.Activity,
            e = (t.Object._s505a2ac0cde720ef9099aed2ef7fc0(), this._4122736007.SType.SType), i = 4 == this._1340348542,
            a = {SType: e, RankData: this._643151339, IsLevelRank: i}, n = "SprintRank";
        5 == this._1340348542 && (n = "SprintGuildRank"), GetGuiManager()._s2e22e694b9852084df200bc86f9340(n, a)
    }, t.OnGetReward = function () {
        if (!this._s646a51d9f7358cdd4aa83bee437051()) return void this._s95fe664233ef81a493aa0fd2d990c2();
        var t = {}, e = this._4122736007.Activity, i = e.Object._s505a2ac0cde720ef9099aed2ef7fc0();
        t.GUID = i.GUID, t.SType = this._4122736007.SType.SType;
        var a = jasmin._sa8ce9b799dca49cfed044a7bb95483(i.Timelst.BeginTimelst);
        if (this._sb5cf044194d889d52c6436ddc759be(i.GUID, this._4122736007.SType.SType, a)) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({
            Result: !1,
            Error: ERR.SprintRank_HasGetReward
        });
        if (jasmin._sf8362a01e1d177e98ff9b0aa45e654(global.$Cfg.Common.SprintGuildRank, this._4122736007.SType.SType)) {
            var n = global.$Api.QueryDataSource("DataGuild").GetValue("GuildId");
            if (!n) return void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600({
                Result: !1,
                Error: global.$Cfg.ErrorCode.Guild_UserNoGuild
            })
        }
        GetCmdProxy().DoCmd("SprintRankGetReward", t, function (t) {
            if (t.Result) {
                if (t.RewardId && t.RewardRank) {
                    var e = {RewardId: t.RewardId, RewardRank: t.RewardRank, SType: this._4122736007.SType.SType};
                    GetGuiManager()._s2e22e694b9852084df200bc86f9340("SprintRankRewardDialog", e)
                }
                t.KingId && (GetPalaceInterface()._s68fc8a7ed85013c1392e8183b4b3ce(t.KingId), GetGuiManager()._s2e22e694b9852084df200bc86f9340("SprintRankBecomeKing", {KingId: t.KingId})), this.btn_GetReward.visible = !1, Laya.Tween.from(this.img_HasGetReward, {
                    scaleX: 2,
                    scaleY: 2
                }, 200), this.img_HasGetReward.visible = !0
            }
        }.bind(this))
    }, t._sb5cf044194d889d52c6436ddc759be = function (t, e, i) {
        var a = global.$Api.QueryDataSource("DataRecord").GetValue(["SprintRankReward", t, e]);
        return !(!a || !a.HasGetReward || a.BeginTime != i)
    }, t._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        var t = this._4122736007.Activity, e = t.Object._s505a2ac0cde720ef9099aed2ef7fc0(),
            i = this._4122736007.SType.SType, a = jasmin._sa8ce9b799dca49cfed044a7bb95483(e.Timelst.BeginTimelst),
            n = global.$Sys.GetTableService().GetTableRecord("activity_atlist", i, 1);
        this.img_ActTitle.skin = n.IconName, this.img_ActText.skin = n.InfoPath;
        var r = e.Timelst.StartTimelst, s = e.Timelst.StopTimelst,
            m = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RankActivityTime, r[1], r[2], r[3], r[4], s[1], s[2], s[3], s[4]);
        this.lab_ActTime.text = m;
        var l = e.GUID, o = !1;
        this._sb5cf044194d889d52c6436ddc759be(l, i, a) && (o = !0), this.img_HasGetReward.visible = o, this.btn_GetReward.visible = !o, this.lab_NoTime.visible = !o, this.lab_TimeDownText.visible = !o, this.lab_ActStop.visible = o
    }, t._sbe6272b25b096db7243ecce60a346c = function (t) {
        var e = this._4122736007.Activity, i = e.Object._s505a2ac0cde720ef9099aed2ef7fc0(),
            a = this._4122736007.SType.SType;
        this._1340348542 = a % 10;
        var n = global.$Sys.GetTableService().GetTableRecord("activity_rank", i.Type, a), r = {TableName: n.RankName},
            s = "GetRank";
        5 == this._1340348542 && (s = "GuildGetRank"), GetCmdProxy().DoCmd(s, r, function (e) {
            this._643151339 = e, this.lab_MyRank.text = this._643151339.MyRank.Rank || "未上榜", t && t()
        }.bind(this))
    }, t._sf5022c8b253f370a62098754d303c1 = function () {
        var t = this._4122736007.Activity, e = t.Object._1842891454, i = this._4122736007.SType.SType;
        this.vBox_ActItem.destroyChildren(), this.vBox_ActItem.sortItem = function (t) {
        };
        var a = 136;
        if (5 == this._1340348542) return void this._s96df03cb76db72f440771b74dd8a90(i, a);
        var n = global.$Sys.GetTableService().GetTableRecord("activity_atlist", i),
            r = this._4122736007.SType.RewardTable;
        r || (jasmin.Debug("No RewardTable UseRecordRewardTable"), r = n[1].RewardTable);
        for (var s = global.$Sys.GetTableService().GetTable(r), m = 1; m <= _.size(s); m++) {
            var e = s[m], l = SprintRankDetail._prefabs.item, o = Laya.View.createComp(l),
                h = o.getChildByName("img_RankName");
            h.skin = e.RankingPath;
            var d = o.getChildByName("img_IconBg"), c = d.getChildByName("vBox_Icon"),
                p = GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(c, e.RewardId, 4, 10, null, {UseEff: !0});
            o.height = p.height + a, o.x = null, o.y = null, this.vBox_ActItem.addChild(o)
        }
    }, t._s96df03cb76db72f440771b74dd8a90 = function (t, e) {
        var i = SprintRankDetail._prefabs.box_Item,
            a = global.$Sys.GetTableService().GetTableRecord("activity_atlist", t),
            n = this._4122736007.SType.RewardTable;
        n || (jasmin.Debug("No RewardTable UseRecordRewardTable"), n = a[1].RewardTable);
        for (var r = global.$Sys.GetTableService().GetTable(n), s = 1; s <= _.size(r); s++) {
            var m = r[s], l = SprintRankDetail._prefabs.item, o = Laya.View.createComp(l),
                h = o.getChildByName("img_RankName");
            h.skin = m.RankingPath;
            var d = o.getChildByName("img_IconBg"), c = d.getChildByName("vBox_Icon");
            c.sortItem = function (t) {
            };
            var p = Laya.View.createComp(i), v = p.getChildByName("img_GuildOfficeText");
            v.skin = global.$Cfg.Common.GuildSprintRank[0], p.centerX = 0, c.addChild(p);
            var R = new Laya.VBox;
            R.left = 0, R.right = 0;
            GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(R, m.RewardId, 4, 10, c.width, {UseEff: !0});
            c.addChild(R);
            var y = Laya.View.createComp(i), v = y.getChildByName("img_GuildOfficeText");
            v.skin = global.$Cfg.Common.GuildSprintRank[1], y.centerX = 0, c.addChild(y);
            var R = new Laya.VBox;
            R.left = 0, R.right = 0;
            GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(R, m.RewardId2, 4, 10, c.width, {UseEff: !0});
            c.addChild(R), c.space = 20, c.changeItems(), o.height = c.height + e, o.x = null, o.y = null, this.vBox_ActItem.addChild(o)
        }
    }
}();
var SprintRankRewardDialog;
!function () {
    SprintRankRewardDialog = function () {
        SprintRankRewardDialog.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("SprintRankRewardDialog")
        })
    }, Laya.class(SprintRankRewardDialog, "SprintRankRewardDialog", SprintRankRewardDialogUI), SprintRankRewardDialog.GetPreLoadResList = function (i) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SprintRankRewardDialogUI.uiView, i)
    };
    var i = SprintRankRewardDialog.prototype;
    i.OnShow = function (i) {
        GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), this._713989164 = i, this._sc9209ae0dd3fdb06533b36ec4474b1()
    }, i.OnClose = function () {
        this.vBox_Icon.destroyChildren()
    }, i._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        this.vBox_Icon.destroyChildren(), GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(this.vBox_Icon, this._713989164.RewardId, 4, 10, 540);
        var i = 117;
        this.img_Item.height = this.vBox_Icon.height + i
    }
}();
var TaofaRankView;
!function () {
    TaofaRankView = function () {
        TaofaRankView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TaofaRankView")
        }), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this.view_rank), this._1092471860Data = null
    }, Laya.class(TaofaRankView, "TaofaRankView", TaofaRankUI), TaofaRankView.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TaofaRankUI.uiView, a)
    };
    var a = TaofaRankView.prototype;
    a._s32c780894fee77d307fe624a327e30 = function () {
        return !this._926118106 || global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285() - this._926118106 > 6e5
    }, a.OnShow = function (a) {
        this._4122736007 = a, this._s32c780894fee77d307fe624a327e30() ? GetDataTaofaInterface().DoGetRank({}, function (a) {
            jasmin._se7a49036f5cfea7f559beac9db86e9(a.Result, "Get RankData Error!!!!"), this._926118106 = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(), this._1092471860Data = a, this._1092471860Data.ShowTag = {
                Rank: null,
                Name: null,
                Score: null
            }, this._s4fb507d6d0f40b2d2a72f6007a938d()
        }.bind(this)) : this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
    }
}();
var TaofaRewardComponent;
!function () {
    TaofaRewardComponent = function () {
    };
    var e = TaofaRewardComponent.prototype;
    e.Init = function (e, a) {
        e.list_Font.renderHandler = new Laya.Handler(this, this.OnCreateBox);
        var t, n = Math.ceil(a.Rewards.length / 4);
        0 == n ? t = 0 : (e.ui_listRewardIcons.repeatY = Math.min(2, n), t = e.ui_listRewardIcons.height, e.ui_listRewardIcons.centerX = .5);
        var o = a.FontRewards, i = Math.ceil(o.length / 2);
        0 == i ? (e.list_Font.array = [], e.list_Font.height = 0) : (e.list_Font.vScrollBarSkin = null, e.list_Font.array = o, e.list_Font.repeatY = Math.min(6, i));
        var r = (e.img_Bg.height, e.list_Font.height + t);
        e.img_Bg.height = r + 160, e.box.y = 110, e.img_Bg.centerY = .5, a.Level && (e.lab_Info.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaRewardTitle, a.Level)), a.ToLevel && (e.lab_Info.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaOneKeyRewardTitle, a.ToLevel))
    }, e.OnCreateBox = function (e, a) {
        var t = e.dataSource, n = GameCommon._sd829d199a08f4ea0e8f4acd2566c18([t]), o = n[0];
        e.getChildByName("lab_Info").text = o[0] + " + " + o[1]
    }
}();
var TaofaView;
!function () {
    TaofaView = function () {
        TaofaView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
        }), this.btn_OneKeyFight.on(Laya.Event.CLICK, this, this.OnOneKeyFight), this.btn_Help.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Crusade"})
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.lab_Level.font = "font5";
        var e = {ShowType: ["Exp", "Force", "Troops"], Custom: {}};
        this._1658958566 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, e), this.btn_Border.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("TaofaRankView")
        })
    }, Laya.class(TaofaView, "TaofaView", TaofaUI), TaofaView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(TaofaUI.uiView, e)
    };
    var e = TaofaView.prototype;
    e.OnOneKeyFight = function () {
        var e = global.$Api.QueryDataSource("DataTaofa")._s5628fcc030ba13533c176ce5ef4123(), a = (e.LevelInfo, e.Level),
            t = GetDataTaofaInterface()._s2d038acf69ee1812ec129616d8d0b6();
        if (!t) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [global.$Cfg.Language.TaofaCantOneKeyFight]});
        var o = t[1], i = {}, n = 0;
        _.each(o, function (e, a) {
            n += e, i[a] = {Consume: n}
        }.bind(this)), GetGuiManager()._s2e22e694b9852084df200bc86f9340("SelectProgressDialog", {
            Min: a,
            Max: t[0],
            Data: i,
            Ui: TaofaSelectLevelUI,
            OnClick: function (e) {
                GetDataTaofaInterface().DoOneKeyFight(e, function (t) {
                    this.OnOneKeyFightEnd(t, e - a + 1)
                }.bind(this))
            }.bind(this)
        })
    }, e.OnOneKeyFightEnd = function (e, a) {
        var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards), o = [], i = [],
            n = global.$Cfg.CommonEnum, r = global.$Cfg.CommonEnum.Asset;
        _.each(t, function (e) {
            var a = e[0], t = e[1];
            a == r.DataBase && t == n.DataBase.Exp || a == r.DataTaofa && t == n.DataTaofa.Score || a == r.DataBeauty && t == n.DataBeauty.Charm ? o.push(e) : i.push(e)
        });
        var l = {};
        l.Trade = new TaofaRewardComponent, GameCommon._sd38698afd531859b2de84f3549fe92(TaofaRewardUI, l, {
            Rewards: i,
            FontRewards: o,
            ToLevel: a
        }, function () {
            this._s0d336c1dbcbe888485dcc9e2a5be49()
        }.bind(this), !0)
    }, e.OnCreateItem = function (e, a) {
        var t = e.getChildByName("lab_Name"), o = e.getChildByName("lab_Reward"), i = e.getChildByName("btn_Fight"),
            n = e.getChildByName("img_Head"), r = e.getChildByName("lab_Soldier"), l = e.getChildByName("img_RewardBg"),
            s = e.dataSource;
        i.on(Laya.Event.CLICK, this, this.OnFight, [a, s]);
        var f = s.NpcId, u = global.$Sys.GetTableService().GetTableRecord("npc", f);
        r.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaSoldier, s.Soldier), n.skin = u.HeadPath, t.text = u.NpcName;
        var g = s.Reward, h = global.$Cfg.CommonEnum, c = 3;
        l.destroyChildren(), _.each(g, function (e) {
            var a, t = e[0], o = e[1];
            a = t == h.Asset.DataHero ? GetItemIconFactory()._sb28617dc58b536a74dd40075815048(e[3].HeroId) : t == h.Asset.DataBeauty && t == h.DataBeauty.Charm ? GetItemIconFactory()._scfdefbc3baca8253b4795d35148e52(e[3].BeautyId) : GameCommon._s66eb52e60b9feb53711943e638c9c3(t, o, null, !0, e[2]), a && (a.x = c, a.y = 5, l.addChild(a), a.scale(.52, .52), c += 62)
        });
        var d = s.BaseReward, C = global.$Sys.GetTableService().GetTableRecord("reward", d), m = C.Award,
            T = GameCommon._sd829d199a08f4ea0e8f4acd2566c18(m), b = "";
        _.each(T, function (e, a) {
            b += e[0] + "+" + e[1], a != T.length - 1 && (b += "\n")
        }), o.text = b || jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaBaseReward, b)
    }, e._s2e6efe8bf2e1ecbf2b82b708dbf10e = function () {
        this.list.array = GetDataTaofaInterface()._se070871983e76e737f5eabb6a11a62()
    }, e.OnFight = function (e, a) {
        var t = a.NpcId, o = global.$Sys.GetTableService().GetTableRecord("npc", t), i = a.Force, n = a.Soldier,
            r = this._s9e23ddce7afc3ba7c751c41926ef5b(),
            l = {MaxSoldier: n, CurSoldier: n, Force: i, Name: o.NpcName, Office: "", NpcId: t},
            s = {MyData: r, EnemyData: l}, f = {
                Title: jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaLevelTitle, GetDataTaofaInterface()._sd6f76f8ece5b6eb710bf8a6aab7921()),
                Level: GetDataTaofaInterface()._sd6f76f8ece5b6eb710bf8a6aab7921()
            };
        GetDataTaofaInterface().DoFight(e, this.OnPlayFight.bind(this, s, f))
    }, e._s9e23ddce7afc3ba7c751c41926ef5b = function () {
        var e = global.$Api.QueryDataSource("DataBase").GetValue("Troops"),
            a = global.$Api.QueryDataSource("DataBase").GetValue("Office"),
            t = global.$Sys.GetTableService().GetTableRecord("office", a), o = {
                MaxSoldier: e,
                Force: ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(1),
                Name: global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"),
                Office: t.OfficeName,
                CurSoldier: e
            };
        return o
    }, e.OnPlayFight = function (e, a, t) {
        var o = a.Level, i = global.$Sys.GetTableService().GetTableRecord("taofa_info", o), n = t.CurEnemySoldier;
        FightView._sabbe27d79486b625a06ed3d6ebdec5({
            Bg: "res/ui/bg/level/stage/z_zhandou_bg" + i.BgId + ".png",
            Fighters: e,
            OnCreateTitleNode: function () {
                var e = new TaofaFightTitleUI;
                return e.lab_Title.font = "font5", e.lab_Title.text = a.Title, e.lab_Title.centerX = .5, e
            },
            OnPlayFight: function (e) {
                var a = {
                    Success: t.Success,
                    Rewards: t.Rewards,
                    Fighters: {
                        MyData: {CurSoldier: global.$Api.QueryDataSource("DataBase").GetValue("Troops")},
                        EnemyData: {CurSoldier: t.Success ? 0 : n}
                    }
                };
                e(a)
            },
            OnFightEnd: function (e, t) {
                if (!e.Success) return void LevelFailed._sabbe27d79486b625a06ed3d6ebdec5({
                    OnClose: function () {
                        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightView"), this._s0d336c1dbcbe888485dcc9e2a5be49()
                    }.bind(this)
                });
                var o = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards), i = [], n = [],
                    r = global.$Cfg.CommonEnum, l = global.$Cfg.CommonEnum.Asset;
                _.each(o, function (e) {
                    var a = e[0], t = e[1];
                    a == l.DataBase && t == r.DataBase.Exp || a == l.DataTaofa && t == r.DataTaofa.Score || a == l.DataHero && t == r.DataHero.SkillExp || a == l.DataHero && t == r.DataHero.BookExp || a == l.DataBeauty && t == r.DataBeauty.Charm ? i.push(e) : n.push(e)
                });
                var s = {};
                s.Trade = new TaofaRewardComponent, GameCommon._sd38698afd531859b2de84f3549fe92(TaofaRewardUI, s, {
                    Rewards: n,
                    FontRewards: i,
                    Level: a.Level
                }, function () {
                    GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("FightView"), this._s0d336c1dbcbe888485dcc9e2a5be49()
                }.bind(this), !0)
            }.bind(this)
        })
    }, e.OnFightEnd = function (e) {
        this._s0d336c1dbcbe888485dcc9e2a5be49()
    }, e._s0d336c1dbcbe888485dcc9e2a5be49 = function () {
        this.btn_OneKeyFight.visible = global.$Api.QueryDataSource("DataTaofa").GetValue("OneKeyFight"), this.lab_OneKeyFightTip.visible = !global.$Api.QueryDataSource("DataTaofa").GetValue("OneKeyFight");
        var e = GetDataTaofaInterface()._sd6f76f8ece5b6eb710bf8a6aab7921();
        this.list.visible = !0, e > _.size(global.$Sys.GetTableService().GetTable("taofa_info")) ? (this.lab_Level.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaLevelTitle, 200), this.btn_OneKeyFight.visible = !1, this.list.visible = !1) : this.lab_Level.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.TaofaLevelTitle, e), this._s2e6efe8bf2e1ecbf2b82b708dbf10e(), this._1658958566._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnShow = function (e) {
        this._s0d336c1dbcbe888485dcc9e2a5be49()
    }, e.OnClose = function () {
        _.each(this.list.cells, function (e) {
            var a = e.getChildByName("img_RewardBg");
            a.destroyChildren()
        })
    }
}();

function angle(a, e) {
    var t = e.x - a.x, r = e.y - a.y;
    return 360 * Math.atan(r / t) / (2 * Math.PI)
}

var TestBattleScene = function () {
    function a() {
        a.super(this), this.MAX_LINE = 8, this.MAX_COUNT_PER_LINE = 6
    }

    return Laya.class(a, "TestBattleScene", Laya.View), a.GetPreLoadResList = function (a) {
        var e = 1, t = "ani/FightEnemy" + e + ".ani", r = "res/atlas/atlas/fight/enemy" + e + ".atlas";
        a.push([{url: gCfg.Sound.UI.z_ui_hit, type: Laya.Loader.SOUND}, {
            url: "res/atlas/atlas/fight/hero1.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero1.ani", type: Laya.Loader.JSON}, {
            url: "res/atlas/atlas/fight/hero2.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero2.ani", type: Laya.Loader.JSON}, {
            url: "res/atlas/atlas/fight/hero3.atlas",
            type: Laya.Loader.ATLAS
        }, {url: "ani/FightHero3.ani", type: Laya.Loader.JSON}]);
        for (var i = 1; i <= 6; i++) {
            var t = "ani/FightEnemy" + i + ".ani", r = "res/atlas/atlas/fight/enemy" + i + ".atlas";
            a.push([{url: t, type: Laya.Loader.JSON}, {url: r, type: Laya.Loader.ATLAS}])
        }
        a.push([{url: "res/atlas/atlas/fight/hero1.atlas", type: Laya.Loader.ATLAS}, {
            url: "ani/FightHero1.ani",
            type: Laya.Loader.JSON
        }])
    }, a.prototype.OnShow = function () {
        Laya.stage.bgColor = "#000000";
        var a = new Laya.Label("1");
        a.color = "#ffffff", a.centerX = .5, a.centerY = .5, Laya.stage.addChild(a), GetBattleDirector().Init({
            Scene: Laya.stage,
            StartPosX: Laya.stage.width / 2,
            StartPosY: Laya.stage.height / 2 - 60
        }), GetBattleDirector()._s6b62d5f4d13d1dce02135d67face32({
            MySoldier: 3e7,
            EnemySoldier: 3e5,
            EnemyId: 1
        }), GetBattleDirector().Start({MySoldier: 1e4, EnemySoldier: 0})
    }, a
}();
!function () {
    function t(i) {
        t.super(this), this._InitUI()
    }

    Laya.class(t, "TestModeView", Laya.Dialog), t.prototype._InitUI = function () {
        var t = new Laya.Panel;
        t.width = Laya.stage.width, t.height = Laya.stage.height, t.vScrollBarSkin = null, this.addChild(t), this.pagePanel = t, this.buttonWidth = 180, this.buttonHeight = 50, this.tabButtonWidthSpace = 20, this.tabButtonHeightSpace = 10, this.pagePanelWidth = Laya.stage.width
    }, t.prototype._OnGroupChange = function () {
        this.pagePanel.removeChildren();
        for (var t = 1; ;) if (t += this.buttonWidth + this.tabButtonWidthSpace, t > this.pagePanelWidth - this.buttonWidth) break;
        var i = 1, e = i, n = 100 + this.tabButtonHeightSpace, a = this.buttonIdxStartWith,
            o = TestMode._s505a2ac0cde720ef9099aed2ef7fc0();
        for (var h in o) {
            var s = o[h], l = s.Name;
            this.buttonIdxIsShow && (l = a + ". " + l);
            var u = new Laya.Button(null, l);
            u.width = this.buttonWidth, u.height = this.buttonHeight, u.labelColors = "#ffffff", u.labelSize = 30, u.x = e, e += this.buttonWidth + this.tabButtonWidthSpace, u.y = n, e > this.pagePanelWidth - this.buttonWidth && (e = i, n += this.buttonHeight + this.tabButtonHeightSpace), u.on(Laya.Event.CLICK, this, s.OnCallback, [u]), a++, this.pagePanel.addChild(u)
        }
    }, t.prototype._OnCloseBtnClick = function () {
        this.dialogCloseCallBack && this.dialogCloseCallBack(), this.OnClose(), this.close()
    }, t.prototype._OnBtnClick = function (i) {
        if (ASSERT("function" == typeof i._clickCallBack, "C:Function is supposed to be a function,please check."), "function" == typeof i._clickCallBack) {
            var e = i._clickCallBack(i._clickCallBackArg, t.prototype._s217579e04d29b1d8ec3d88ff4aec68.bind(this));
            "undefined" != typeof e && this._s34baaa11e14d108ac2b940cf52766e(e)
        }
    }, t.prototype._s34baaa11e14d108ac2b940cf52766e = function (t) {
        this.textDebugInfo.text = t
    }, t.prototype._s337aab36fa6fead1da67a330880008 = function (t) {
        var i = this.textDebugInfo.text;
        i += t, this._s34baaa11e14d108ac2b940cf52766e(i)
    }, t.prototype.OnShow = function () {
        this._InitUI(), this._OnGroupChange()
    }, t.prototype.OnClose = function () {
    }
}();
var TitleUpDialog;
!function () {
    function e() {
        e.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_titleUp.on(Laya.Event.CLICK, this, this.OnBtnTitleUpClick), this.list_consume.renderHandler = Laya.Handler.create(this, this.OnCreateConsume, null, !1)
    }

    Laya.class(e, "TitleUpDialog", TitleUpDialogUI);
    var t = e.prototype;
    t.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = global.$Api.QueryDataSource("DataHero").GetHeroById(this._4122736007.HeroId),
            t = GetDataTransfer().GetTableRecord("hero", this._4122736007.HeroId),
            a = GetDataTransfer().GetTableRecord("title", e.Title);
        if (GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_hero, this._4122736007.HeroId), this.lab_name.text = t.HeroName, this.lab_curTitleName.text = a.TitleName, this.lab_curMaxLv.text = a.MaxHeroLv, e.Title < global.$Cfg.Common.MaxHeroTitle) {
            var i = GetDataTransfer().GetTableRecord("title", e.Title + 1);
            this.lab_upTitleName.text = i.TitleName, this.lab_upMaxLv.text = i.MaxHeroLv;
            var o = GetDataTransfer()._s2594a8c1d22f7c1b53347530466408(i.Consume);
            this.list_consume.array = _.pairs(o[2])
        } else this.lab_upTitleName.text = "------------", this.lab_upMaxLv = "------------"
    }, t.OnCreateConsume = function (e, t) {
        var a = e.getChildByName("img_item"), i = e.getChildByName("lab_cnt"), o = this.list_consume.array[t], l = o[0],
            r = o[1];
        a.ItemIcon && (a.ItemIcon.removeSelf(), a.ItemIcon.destroy(), a.ItemIcon = null);
        var n = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: l});
        a.ItemIcon = n, a.addChild(n);
        var s = global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(l);
        i.color = r > s ? "#866f59" : "#1a900a", i.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("( %s/%s )", s, r)
    }, t.OnClose = function () {
        this._4122736007.OnClose && this._4122736007.OnClose()
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TitleUpDialog")
    }, t.OnBtnTitleUpClick = function () {
        var e = {
            HeroId: this._4122736007.HeroId, Callback: function () {
                GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TitleUpDialog")
            }.bind(this)
        };
        GetDataHeroInterface().DoHeroTitleUp(e)
    }
}();
var TradeCityInfo;
!function () {
    function e() {
        e.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_fight.on(Laya.Event.CLICK, this, this.OnBtnFightClick), this._3641591423 = this.img_bg.height
    }

    Laya.class(e, "TradeCityInfo", TradeCityInfoUI);
    var t = e.prototype;
    t.OnShow = function (e) {
        this._4122736007 = e || {}, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = this._4122736007.CityId || GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d(),
            t = global.$Sys.GetTableService().GetTableRecord("silk_road", e);
        this.lab_name.text = t.StageName, this.lab_money.text = t.Money, this.lab_brain.text = t.Brain;
        var a = global.$Sys.GetTableService().GetTableRecord("reward", t.RewardId).Award, i = 0;
        _.each(a, function (e) {
            jasmin._s2dedbd0e220887101c856bf900fc57(e) || i++
        });
        var r = Math.ceil(i / this.ui_listRewardIcons.repeatX);
        this.ui_listRewardIcons.repeatY = r, this._2948137457 || (this._2948137457 = new RewardDialog), this._2948137457._sef77c3f8654f8353839813a7c44c02(this, {Rewards: a}), this.btn_fight.visible = e == GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d(), this.img_bg.height = this._3641591423 + r * (115 + this.ui_listRewardIcons.spaceY)
    }, t.OnBtnFightClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TradeCityInfo"), GetDataTradeInterface().DoTrade({}, function (e) {
            GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("TradeScene", e)
        }.bind(this))
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TradeCityInfo")
    }, t.OnClose = function () {
        this._2948137457._s54107fed721f2f5f6636c3b2747bef()
    }, e.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, t)
    }
}();
var TradeCityPrefab;
!function () {
    function i() {
        i.super(this), this.on(Laya.Event.CLICK, this, this.OnClick)
    }

    Laya.class(i, "TradeCityPrefab", TradeCityPrefabUI);
    var t = i.prototype;
    t._s4fb507d6d0f40b2d2a72f6007a938d = function (i) {
        this._449088314 = i.OnClick, this._313232772 = i.Id;
        var t = global.$Sys.GetTableService().GetTableRecord("silk_road", this._313232772);
        this.lab_name.text = this._313232772 + ". " + t.StageName;
        var e = GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d();
        this.img_arrows.visible = this._313232772 == e, this.img_finish.visible = this._313232772 < e, this.visible = this._313232772 <= e
    }, t.OnClick = function () {
        this._449088314 && this._449088314(this._313232772)
    }, t.OnClose = function () {
    }, i.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(i.uiView, t)
    }
}();
var TradeMap;
!function () {
    function e() {
        e.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_oneKey.on(Laya.Event.CLICK, this, this.OnOneKeyFight), this.btn_rank.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("TradeRankDialog")
        }), this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Silkroad"})
        }), this._3769195805 = {}, this._3399175475 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8(this, {ShowType: ["Money", "Brain"]})
    }

    Laya.class(e, "TradeMap", TradeMapUI);
    var t = e.prototype;
    t.OnShow = function (e) {
        this._3769195805Id = e.CityId, jasmin._se7a49036f5cfea7f559beac9db86e9(jasmin._seb2d63e263badd8a69c54d151f6cc7(this._3769195805Id), "Please Input city ID!"), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._3399175475._s4fb507d6d0f40b2d2a72f6007a938d();
        var e = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road", this._3769195805Id);
        e || (this._3769195805Id--, e = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road", this._3769195805Id));
        var t = e.StateId, a = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road_state", t);
        this.img_map.skin = a.MapBg;
        var i = global.$Sys.GetTableService().GetTableRecord("silk_road_pos", a.PosId);
        this._s725aae6088c59ab3b78cdbdb048d4d(), jasmin._se7a49036f5cfea7f559beac9db86e9(_.size(i) == a.CityId.length, "Design:Pos Count != City Count,Please Check");
        for (var s in a.CityId) {
            var o = a.CityId[s], n = this._FormatPos(i[parseInt(s) + 1].Pos), r = new TradeCityPrefab;
            r._s4fb507d6d0f40b2d2a72f6007a938d({
                Id: o,
                OnClick: this.OnCityClick.bind(this)
            }), r.x = n[0], r.y = n[1], this._3769195805[o] = r, this.img_map.addChild(r)
        }
        var l = a.CityId.indexOf(this._3769195805Id);
        if (jasmin._se7a49036f5cfea7f559beac9db86e9(l != -1, "Design:StageId：" + t + " Not Found City,CityId is " + this._3769195805Id), l) {
            var d = l + "_" + (l + 1),
                h = jasmin._sdf8385ff3a74421ea218e043d47fdc(global.$Sys.GetTableService().GetTableRecord("silk_road_path", a.PosId, d, "PathPoints")),
                c = this._FormatPos(h.shift().split("-"));
            this.img_pos.x = c[0], this.img_pos.y = c[1], this.mouseEnabled = !1;
            var y = [], u = this;
            _.each(h, function (e) {
                var t = function (t) {
                    var a = u._FormatPos(e.split("-"));
                    u.img_pos.scaleX = u.img_pos.x - a[0] >= 0 ? -1 : 1, Laya.Tween.to(u.img_pos, {
                        x: a[0],
                        y: a[1]
                    }, global.$Cfg.Common.TradeCfg.MoveSpeed, null, Laya.Handler.create(u, t))
                };
                y.push(t)
            }), async.waterfall(y, function () {
                u.mouseEnabled = !0
            })
        } else {
            var g = this._FormatPos(i[l + 1].Pos);
            this.img_pos.x = g[0], this.img_pos.y = g[1]
        }
        this.btn_oneKey.visible = global.$Api.QueryDataSource("DataTrade").GetValue("OneKey"), this.lab_oneKey.visible = !global.$Api.QueryDataSource("DataTrade").GetValue("OneKey")
    }, t.OnCityClick = function (e) {
        e == this._3769195805Id && GetGuiManager()._s2e22e694b9852084df200bc86f9340("TradeCityInfo", {CityId: e})
    }, t._s725aae6088c59ab3b78cdbdb048d4d = function () {
        _.each(this._3769195805, function (e, t) {
            e && (e.removeSelf(), e.destroy(), delete this._3769195805[t])
        }.bind(this))
    }, t.OnOneKeyFight = function () {
        var e = global.$Api.QueryDataSource("DataTrade")._s68597f8db34321bbee924f93c90614();
        if (jasmin._s2dedbd0e220887101c856bf900fc57(e)) return void GameCommon._sd701ab0ea7b927938ca76f91a4368c({
            Texts: [gLanguage.NO_ENOUGH_WEALTH],
            Colors: ["#ffffff"]
        });
        var t = _.keys(e);
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("SelectProgressDialog", {
            Min: t[0],
            Max: t[t.length - 1],
            Data: e,
            Ui: TradeSelectLevelUI,
            OnClick: function (e) {
                GetDataTradeInterface().DoOneKeyTrade({Progress: e}, function () {
                    this._3769195805Id = GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d(), this._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this))
            }.bind(this)
        })
    }, t._FormatPos = function (e) {
        return [640 * e[0], 1138 * (1 - e[1])]
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }, t.OnClose = function () {
    }, e.GetPreLoadResList = function (t, a) {
        var i = a.CityId, s = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road", i);
        s || (i--, s = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road", i));
        var o = s.StateId, n = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("silk_road_state", o);
        t.push(n.MapBg), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, t)
    }
}();
var TradeRankDialog;
!function () {
    function a() {
        a.super(this), this._1092471860 = CommonRankController._s44377e7cc909eaacd34555256b505d(this.view_rank), this._1092471860Data = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick)
    }

    Laya.class(a, "TradeRankDialog", TradeRankDialogUI);
    var n = a.prototype;
    n.OnShow = function (a) {
        this._4122736007 = a, this._1092471860Data ? this._s4fb507d6d0f40b2d2a72f6007a938d() : GetDataTradeInterface().DoGetRank({}, function (a) {
            jasmin._se7a49036f5cfea7f559beac9db86e9(a.Result, "Get RankData Error!!!!"), this._1092471860Data = a, this._1092471860Data.ShowTag = {
                Rank: null,
                Name: null,
                Score: null
            }, this._s4fb507d6d0f40b2d2a72f6007a938d()
        }.bind(this))
    }, n._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1092471860._s4fb507d6d0f40b2d2a72f6007a938d(this._1092471860Data)
    }, n.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("TradeRankDialog")
    }, n.OnClose = function () {
    }
}();
var TradeRewardComponent;
!function () {
    TradeRewardComponent = function () {
    }, TradeRewardComponent.prototype.Init = function (e, t) {
        this._2145934043 || (this._2145934043 = e.img_CloseBg.height), e.lab_consume.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Trade.MoneyConsume, GameCommon._s5c693d8122a877499a10f605a128a3(t.Consume));
        var a = Math.ceil(t.Rewards.length / 4), n = "";
        t.CityId && (n = global.$Sys.GetTableService().GetTableRecord("silk_road", t.CityId).StageName), e.lab_score.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Trade.Score, t.Score || 1), e.lab_city.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Trade.RewardInfo, n), e.ui_listRewardIcons.repeatY = a, e.img_CloseBg.height = this._2145934043 + 125 * a
    }
}();
var TradeScene;
!function () {
    function e() {
        e.super(this)
    }

    Laya.class(e, "TradeScene", TradeSceneUI);
    var a = e.prototype;
    a.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = global.$Sys.GetTableService().GetTableRecord("silk_road", this._4122736007.CityId),
            a = global.$Api.QueryDataSource("DataBase").GetValue("Money");
        this.lab_playerMoney._sf977f711b73aed12dbe5d83d29b8f6(a + this._4122736007.Consume), this.lab_playerName.text = global.$Api.QueryDataSource("DataBase").GetValue("PlayerName"), this.lab_playerBrain.text = global.$Api.ShareFunc._s6e9d5cbe8cb490b85e72b5e5a3fe56(global.$Cfg.CommonEnum.HeroAttribute.BRAINS), this.lab_enemyMoney._sf977f711b73aed12dbe5d83d29b8f6(e.Money), this.lab_enemyName.text = this._4122736007.CityId + "." + e.StageName, this.lab_enemyBrain.text = e.Brain, this.lab_playerMoney._sf977f711b73aed12dbe5d83d29b8f6(a, 3e3), this.lab_enemyMoney._sf977f711b73aed12dbe5d83d29b8f6(this._4122736007.Money, 3e3), this.progress_player.value = 0, this.progress_enemy.value = 0;
        var t = this._4122736007.Money <= 0 ? this.progress_player : this.progress_enemy,
            r = this._4122736007.Money > 0 ? this.progress_player : this.progress_enemy;
        this.img_progress.x = .5 * this.progress_player.width;
        var s = this;
        async.waterfall([function (e) {
            Laya.Tween.to(t, {value: .5}, 1e3), Laya.Tween.to(r, {value: .5}, 1e3, null, Laya.Handler.create(s, e))
        }, function (e) {
            for (var a = [], i = [], n = 0; n < 5; n++) {
                var o = .5 + jasmin._sc5ff58245a4160fc0cb89f0345daf9(-100, 100) / 1e3,
                    l = jasmin._sc5ff58245a4160fc0cb89f0345daf9(100, 200);
                a.push({Value: o, Time: l}), i.push({Value: 1 - o, Time: l})
            }
            a.push({Value: 1, Time: 100}), i.push({
                Value: 0,
                Time: 100
            }), s.progress_player.on(Laya.Event.CHANGE, s, function () {
                s.img_progress.x = s.progress_player.width * s.progress_player.value
            });
            var m = s._s0c88ff8195ebfa0cf929b324ec5815(t, a), u = s._s0c88ff8195ebfa0cf929b324ec5815(r, i, e);
            m.play(0), u.play(0)
        }], function () {
            s.progress_player.offAll(Laya.Event.CHANGE), s.OnShowReward()
        })
    }, a._s0c88ff8195ebfa0cf929b324ec5815 = function (e, a, t) {
        var r = new Laya.TimeLine;
        for (var s in a) r.addLabel(s, 0).to(e, {value: a[s].Value}, a[s].Time, Laya.Ease.bounceInOut);
        return t && r.once(Laya.Event.COMPLETE, this, t), r
    }, a.OnShowReward = function () {
        if (this._4122736007.Money <= 0) {
            var e = {};
            e.Trade = new TradeRewardComponent, GameCommon._sd38698afd531859b2de84f3549fe92(TradeRewardDialogUI, e, {
                Rewards: GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards),
                Consume: this._4122736007.Consume,
                CityId: this._4122736007.CityId
            }, this.OnBtnCloseClick.bind(this), !0)
        } else GetGuiManager()._s2e22e694b9852084df200bc86f9340("LevelFailed", {
            NoShowTips: !0,
            OnClose: this.OnBtnCloseClick.bind(this)
        })
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("TradeMap", {CityId: GetDataTradeProxy()._sbe9b6c8c21d549c9b2e6639894ee4d()})
    }, a.OnClose = function () {
    }, e.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, a)
    }
}();
var VipChangeView;
!function () {
    VipChangeView = function () {
        VipChangeView.super(this), this.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("VipChangeView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem)
    }, Laya.class(VipChangeView, "VipChangeView", VipChangeUI), VipChangeView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(VipChangeUI.uiView, e)
    };
    var e = VipChangeView.prototype;
    e._s4d38693a39d4d74881ec76b1e50182 = function (e, a) {
        var i = a.FontSize;
        e.lab1.text = a.Key, e.lab2.text = a.Value, i && (e.lab1.fontSize = i, e.lab2.fontSize = i), a.KeyColor && (e.lab1.color = a.KeyColor), a.ValueColor && (e.lab2.color = a.ValueColor), e.box.changeItems()
    }, e.OnCreateItem = function (e, a) {
        var i = e.dataSource, n = e.getChildByName("att"), t = "#ffe8a2", o = "#00ff7e";
        this._s4d38693a39d4d74881ec76b1e50182(n, {Key: i.Key, KeyColor: t, Value: i.Value, ValueColor: o, FontSize: 25})
    }, e.OnShow = function (e) {
        this.mouseEnabled = !1, Laya.timer.once(1e3, this, function () {
            this.mouseEnabled = !0
        });
        var a = e.OldVipLv, i = e.NewVipLv;
        this.lab_Tq.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.VipLvTQFont, i), this.img_OldVip.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, a), this.img_NewVip.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.VipLvFontPath2, i);
        var n, t = global.$Sys.GetTableService().GetTableRecord("vip", i), o = GetDataTransfer().GetTable("miracle");
        n = GetInspection() ? [] : [{
            Key: gLanguage.RechargeTQInfo2_2,
            Value: "+" + t.ChildRate + "%"
        }, {Key: gLanguage.RechargeTQInfo2_3, Value: t.MaxPhysical}, {
            Key: gLanguage.RechargeTQInfo2_4,
            Value: t.MaxBeautyEnergy
        }, {Key: gLanguage.RechargeTQInfo2_5, Value: t.FreeChangeLuck}, {
            Key: gLanguage.RechargeTQInfo2_6,
            Value: t.MaxChildEnergy
        }];
        var g = !!t.FastUpgrade;
        g && n.push({Key: gLanguage.RechargeTQInfo8, Value: ""});
        var l = !!t.InstitutePassword;
        l && n.push({Key: gLanguage.RechargeTQInfo9, Value: ""}), _.each(o, function (e) {
            var a = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RechargeTQInfo2_7, e.MiracleName);
            n.push({Key: a, Value: t.MaxMiracle})
        }), this.list.array = n
    }, e.OnClose = function () {
        this.img_OldVip.skin = "", this.img_NewVip.skin = ""
    }
}();
var VipRewardLayer;
!function () {
    function a() {
        a.super(this), this.btn_get.on(Laya.Event.CLICK, this, this.OnBtnGetClick), this.btn_pay.on(Laya.Event.CLICK, this, this.OnBtnPayClick)
    }

    Laya.class(a, "VipRewardLayer", VipRewardLayerUI);
    var e = a.prototype;
    e._s4fb507d6d0f40b2d2a72f6007a938d = function (a) {
        this._4122736007 = a;
        var e = this._4122736007.VipLv, i = "Vip", t = GetDataTransfer().GetTableRecord("task", i).Table,
            s = GetDataTransfer().GetTableRecord(t, e)[1], r = s.Reward;
        this.img_bg.skin = s.BgPath, this.btn_get.visible = !1, this.btn_pay.visible = !1, this.img_finish.visible = !1, global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3(i, e, 1) ? this.img_finish.visible = !0 : global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329(i, e, 1) ? this.btn_get.visible = !0 : this.btn_pay.visible = !0, this.hBox_reward.destroyChildren();
        var n = GetDataTransfer().GetTableRecord("reward", r).Award, h = 0;
        _.each(n, function (a) {
            if (a[0] == CommonEnum.Asset.DataBag) {
                var e = GameCommon._se35db439c4ad2364b987453544666d(a, !1, !0, a[2], {UseEff: !0});
                this.hBox_reward.addChild(e), h += e.measureWidth + this.hBox_reward.space
            }
        }.bind(this)), this.hBox_reward.width = h - this.hBox_reward.space, this.hBox_reward.refresh(), this.img_reward.visible = e >= 9
    }, e._s90746ef77ff05d47cb37e68d587694 = function () {
        this.hBox_reward.destroyChildren()
    }, e.OnBtnGetClick = function () {
        var a = {
            Group: "Vip", ChainId: this._4122736007.VipLv, TaskId: 1, Callback: function () {
                GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_item), this._s4fb507d6d0f40b2d2a72f6007a938d(this._4122736007)
            }.bind(this)
        };
        GetDataTaskInterface().DoTask(a)
    }, e.OnBtnPayClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("RechargeView", {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
            }
        })
    }, a.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(a.uiView, e)
    }
}();
var WeChatWelfareLayer;
!function () {
    function e() {
        e.super(this)
    }

    Laya.class(e, "WeChatWelfareLayer", WeChatWelfareLayerUI);
    var a = e.prototype;
    a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
    }, a._s90746ef77ff05d47cb37e68d587694 = function () {
    }, e.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, a)
    }
}();
var WelfarePage;
!function () {
    function a() {
        a.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_welfare.renderHandler = Laya.Handler.create(this, this.OnCreateWelfareBtn, null, !1), this._2767905484 = {}, this.list_welfare.hScrollBarSkin = null, this._1216469265 = []
    }

    Laya.class(a, "WelfarePage", WelfarePageUI);
    var e = a.prototype;
    e.OnShow = function (a) {
        this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = [{
            ClassName: "SignInLayar",
            Params: {},
            IconPath: global.$Cfg.Common.WelfareIconPath[0],
            Title: global.$Cfg.Common.WelfareTitlePath[0]
        }, {
            ClassName: "CardControllerLayer",
            Params: {Type: MonthCardUI},
            IconPath: global.$Cfg.Common.WelfareIconPath[2],
            Title: global.$Cfg.Common.WelfareTitlePath[2]
        }, {
            ClassName: "CardControllerLayer",
            Params: {Type: YearCardUI},
            IconPath: global.$Cfg.Common.WelfareIconPath[3],
            Title: global.$Cfg.Common.WelfareTitlePath[3]
        }, {
            ClassName: "CardControllerLayer",
            Params: {Type: TwoCardUI},
            IconPath: global.$Cfg.Common.WelfareIconPath[17],
            Title: global.$Cfg.Common.WelfareTitlePath[9]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 1},
            IconPath: global.$Cfg.Common.WelfareIconPath[4],
            Title: global.$Cfg.Common.WelfareTitlePath[4]
        }, {
            ClassName: "MiracleLayer",
            Params: {},
            IconPath: global.$Cfg.Common.WelfareIconPath[5],
            Title: global.$Cfg.Common.WelfareTitlePath[5]
        }], e = [{
            ClassName: "VipRewardLayer",
            Params: {VipLv: 2},
            IconPath: global.$Cfg.Common.WelfareIconPath[8],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 3},
            IconPath: global.$Cfg.Common.WelfareIconPath[9],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 4},
            IconPath: global.$Cfg.Common.WelfareIconPath[10],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 5},
            IconPath: global.$Cfg.Common.WelfareIconPath[11],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 6},
            IconPath: global.$Cfg.Common.WelfareIconPath[12],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 7},
            IconPath: global.$Cfg.Common.WelfareIconPath[13],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 8},
            IconPath: global.$Cfg.Common.WelfareIconPath[14],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 9},
            IconPath: global.$Cfg.Common.WelfareIconPath[15],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }, {
            ClassName: "VipRewardLayer",
            Params: {VipLv: 10},
            IconPath: global.$Cfg.Common.WelfareIconPath[16],
            Title: global.$Cfg.Common.WelfareTitlePath[8]
        }];
        if (GetInspection()) {
            _.each(e, function (e) {
                global.$Cfg.Common.InspectionCfg.WelfareCfg.indexOf(e.Params.VipLv) != -1 && a.push(e)
            });
            for (var l, t = 0; t < a.length; t++) l = a[t], !l || 1 != l.Params.VipLv && "CardControllerLayer" != l.ClassName || (a.splice(t, 1), t--)
        } else jasmin._s3c96e1f3bee730222501b208d50190(a, e);
        if ("VipReward" == this._4122736007.Type) {
            var i, o = GetDataVipProxy()._sff41e96cc8733a06f82315792303e1(), r = e[o - 2];
            for (var n in e) {
                var o = e[n].Params.VipLv;
                if (global.$Api.QueryDataSource("DataTask")._s1ea78f546bb33248870d72d7cf0329("Vip", o, 1)) {
                    i = e[n];
                    break
                }
            }
            this._4122736007.Index = i ? jasmin._sa96e5dbe16d978e8310b94a495c86f(a, i) : jasmin._sa96e5dbe16d978e8310b94a495c86f(a, r)
        }
        var s = [], m = [];
        _.each(a, function (a, e) {
            var l = "VipRewardLayer" == a.ClassName && global.$Api.QueryDataSource("DataTask")._sde8844de42f5ea3dc0f73bffcd9ec3("Vip", a.Params.VipLv, 1);
            l ? m.push(a) : s.push(a)
        }), jasmin._s3c96e1f3bee730222501b208d50190(s, m);
        var C = s[0], h = 0;
        this._4122736007 && this._4122736007.Index && (C = a[this._4122736007.Index], _.find(s, function (a, e) {
            a == C && (h = e)
        })), this.OnSelectType(C, h), this.list_welfare.array = s, this.list_welfare.scrollTo(h)
    }, e.OnCreateWelfareBtn = function (a, e) {
        var l = a.getChildByName("img_bg"), t = a.getChildByName("btn_type"), i = this.list_welfare.array[e];
        l.skin = i.IconPath, a.offAll(Laya.Event.CLICK), a.on(Laya.Event.CLICK, this, this.OnSelectType, [i, e]), t.selected = e == this._1106609705;
        var o;
        "SignInLayar" == i.ClassName && (o = {
            Node: a,
            NodeName: "SignInLayar",
            OnCheckState: TargetCheck.OnCheckSign,
            cover: !0
        }), "VipRewardLayer" == i.ClassName && (o = {
            Node: a,
            NodeName: i.ClassName + i.Params.VipLv,
            OnCheckState: TargetCheck.OnCheckVipReward.bind(this, i.Params.VipLv),
            Group: "VipRewardLayer",
            cover: !0
        }), o && Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea(o)
    }, e.OnSelectType = function (a, e) {
        this._1106609705 = e;
        var l = a.ClassName;
        this.img_title.skin = a.Title, this._2767905484[l] || (this._2767905484[l] = this._s042b464ff0ebd439e55600cb29bfc3(l), this.box_center.addChild(this._2767905484[l])), this._2767905484[l]._s4fb507d6d0f40b2d2a72f6007a938d(a.Params), _.each(this._2767905484, function (a, e) {
            a.visible = e == l
        }), _.each(this.list_welfare.cells, function (e) {
            var l = e.getChildByName("btn_type");
            l.selected = e.dataSource == a
        })
    }, e._s042b464ff0ebd439e55600cb29bfc3 = function (a) {
        var e = new window[a];
        return e
    }, e.OnClose = function () {
        _.each(this._2767905484, function (a, e) {
            a._s90746ef77ff05d47cb37e68d587694()
        }.bind(this))
    }, e.OnBtnCloseClick = function () {
        return this._4122736007.OnClose ? void this._4122736007.OnClose() : void GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("FuDi")
    }, a.GetPreLoadResList = function (e) {
        _.each(global.$Cfg.Common.WelfareTitlePath, function (a) {
            e.push(a)
        }), _.each(global.$Cfg.Common.WelfareIconPath, function (a) {
            e.push(a)
        });
        var l = global.$Sys.GetTableService().GetTable("task_vip");
        for (var t in l) {
            var i = l[t][1].BgPath;
            i && e.push(i)
        }
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(a.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MiracleLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ModuleOpenLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(SignInLayar.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(VipRewardLayer.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(YearCardUI.uiView, e), leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(MonthCardUI.uiView, e)
    }
}();
var YamenPage;
!function () {
    function e() {
        e.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_record.on(Laya.Event.CLICK, this, this.OnBtnRecordClick), this.btn_rank.on(Laya.Event.CLICK, this, this.OnBtnRankClick), this.btn_use.on(Laya.Event.CLICK, this, this.OnBtnUseClick), this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Debate"})
        }), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: this.btn_record,
            NodeName: "YamenNewReport",
            OnCheckState: TargetCheck.OnCheckYamenNewReport,
            cover: !0
        })
    }

    Laya.class(e, "YamenPage", YamenPageUI);
    var t = e.prototype;
    t.OnShow = function (e) {
        this._4122736007 = e, GameCommon._s751fe3068f6886bddb070f080cb5ee("yamen"), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, t._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        if (this.img_role.visible = !1, this.img_rest.visible = !1, this.img_useItem.visible = !1, global.$Api.QueryDataSource("DataYamen")._s934216218d6dd80d52ec0f9635215f()) this.img_role.visible = !0, this._s0c67f2b7d553a206eb69fd003e4f42(); else {
            var e = GetDataYamenInterface()._sff32ee1049e6a502191c3cd9e54fc3();
            if (e == -1) this.img_rest.visible = !0, Laya.timer.clearAll(this), Laya.timer.loop(1e3, this, this.OnRefreshTime), this.OnRefreshTime(); else if (e == -2) {
                this.img_useItem.visible = !0;
                var t = global.$Cfg.Common.Yamen.DispatchConsumeKey,
                    a = GetDataTransfer().GetTableRecord("consume", t).Consume[0];
                this.spr_item.ItemIcon && (this.spr_item.ItemIcon.removeSelf(), this.spr_item.ItemIcon.destroy(), this.spr_item.ItemIcon = null);
                var n = GameCommon._s66eb52e60b9feb53711943e638c9c3(a[0], a[1]);
                this.spr_item.addChild(n), this.spr_item.ItemIcon = n;
                var i = global.$Api.QueryDataSource("DataYamen")._s567b5a4ff50d268b5cbb353c99e04e()._s7d40d2cea7eab73120a0dd05b16316(),
                    o = global.$Api.QueryDataSource("DataYamen")._s567b5a4ff50d268b5cbb353c99e04e()._s8a016566e5872f6e6a5780795e79b2();
                this.lab_FightCount.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.DispatchCount, o, i)
            } else GetDataYamenInterface().DoDebateInit({DebateType: 1}, function (e) {
                e.Result && (this.img_role.visible = !0, this._s0c67f2b7d553a206eb69fd003e4f42())
            }.bind(this))
        }
        GetDataYamenInterface().DoGetReport({}, this.OnRefreshReport.bind(this))
    }, t.OnRefreshReport = function (e) {
        if (e.Result) {
            var t = e.Report.reverse();
            if (this.btn_more.offAll(Laya.Event.CLICK), this.btn_more.on(Laya.Event.CLICK, this, this.OnBtnMoreClick, [t]), jasmin._s2dedbd0e220887101c856bf900fc57(e.Report)) return this.lab_recordName.text = "", this.lab_recordHero.text = "", this.lab_enemy.text = "", void(this.lab_recordCnt.text = "");
            var a = t[0].Report, n = gLanguage.Yamen, i = GetDataTransfer().GetTableRecord("hero", a.HeroId).HeroName,
                o = n[a.AllDefeat ? "AllDefeat" : "Defeat"];
            this.lab_recordName.text = a.Names[0], this.lab_recordHero.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(n.HeroDefeat, i, o), this.lab_enemy.text = a.Names[1], this.lab_recordCnt.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(n.HeroCount, a.Count), this.hBox_record.refresh()
        }
    }, t.OnRefreshTime = function () {
        var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285(),
            t = global.$Api.QueryDataSource("DataYamen").GetValue("LastDebateTime") + global.$Cfg.Common.Yamen.ExchangeRefreshInterval - e;
        t > 0 ? this.lab_cdTime.text = "冷却：" + GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(t) : (Laya.timer.clearAll(this), this._s4fb507d6d0f40b2d2a72f6007a938d())
    }, t._s0c67f2b7d553a206eb69fd003e4f42 = function () {
        var e = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData"),
            t = GetDataTransfer().GetTableRecord("hero", e.HeroId);
        GameCommon._s8a21ef794823199e0f5d44c20a9476(this.img_role, e.HeroId);
        var a = global.$Api.QueryDataSource("DataYamen")._sa92864dea93fd57220565ea8f50362();
        this.img_role.offAll(Laya.Event.CLICK), a ? (this.lab_debateHero.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.InDebate, t.HeroName), this.img_role.on(Laya.Event.CLICK, this, this.OnSwitchDebate)) : (this.lab_debateHero.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Yamen.ReadyDebate, t.HeroName), this.img_role.on(Laya.Event.CLICK, this, this.OnShowDebateDialog))
    }, t.OnShowDebateDialog = function () {
        var e, t = global.$Api.QueryDataSource("DataYamen").GetValue("DebateData"), a = t.HeroId, n = t.UserName,
            i = GetDataTransfer().GetTableRecord("hero", a).HeroName;
        e = n ? jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.Yamen.QueryFight, i, n) : jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.Yamen.QueryFightOld, i), GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateInfoDialog", {
            Button: [{
                OnClick: function () {
                    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage")
                }, Label: "确认"
            }, {Label: "取消"}], ButtonSpace: 120, HeroId: a, Info: e
        })
    }, t.OnSwitchDebate = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("DebateMainPage")
    }, t.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }, t.OnClose = function () {
        Laya.timer.clearAll(this), this.spr_item.ItemIcon && (this.spr_item.ItemIcon.removeSelf(), this.spr_item.ItemIcon.destroy(), this.spr_item.ItemIcon = null)
    }, t.OnBtnUseClick = function () {
        var e = global.$Cfg.Common.Yamen.DispatchConsumeKey, t = {
            ConsumeId: e, Purpose: "增加次数？", OnConfirmUse: function (e) {
                GetDataYamenInterface().DoUseDispatch({}, function () {
                    this._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this))
            }.bind(this)
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", t)
    }, t.OnBtnMoreClick = function (e) {
        var t = {};
        t.popupEffect = function (e, t) {
            e.bottom = 0;
            var a = Laya.Tween.from(e, {bottom: -e.height}, 100, null, Laya.Handler.create(null, t));
            return a
        }, t.closeEffect = function (e, t) {
            var a = Laya.Tween.to(e, {bottom: -e.height}, 100, null, Laya.Handler.create(null, t));
            return a
        }, GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateReport", {Report: e}, null, t)
    }, t.OnBtnRankClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateRank")
    }, t.OnBtnRecordClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("DebateRecord")
    }, e.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(e.uiView, t)
    }
}();
var HeroOneKeyRewardView;
!function () {
    HeroOneKeyRewardView = function () {
        HeroOneKeyRewardView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("HeroOneKeyRewardView")
        }), this.list.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list.vScrollBarSkin = null
    }, Laya.class(HeroOneKeyRewardView, "HeroOneKeyRewardView", HeroOneKeyRewardUI), HeroOneKeyRewardView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HeroOneKeyRewardUI.uiView, e)
    };
    var e = HeroOneKeyRewardView.prototype;
    e._s4d38693a39d4d74881ec76b1e50182 = function (e, t) {
        e.lab1.text = t.Key, e.lab2.text = t.Value, t.KeyColor && (e.lab1.color = t.KeyColor), t.ValueColor && (e.lab2.color = t.ValueColor), e.box.changeItems()
    }, e.OnCreateItem = function (e, t) {
        var i = e.dataSource, a = e.getChildByName("img_Body");
        a.skin = "";
        var r = e.getChildByName("view_Lab"), o = i[0], n = i[1], l = i[2];
        GameCommon._s8a21ef794823199e0f5d44c20a9476(a, o);
        var s = global.$Cfg.CommonEnum,
            h = global.$Sys.GetTableService().GetTableRecord("reward_icon", s.Asset.DataHero, l);
        this._s4d38693a39d4d74881ec76b1e50182(r, {
            Key: h.Desc,
            KeyColor: "#ddcca8",
            Value: "+" + n,
            ValueColor: "#25df86"
        })
    }, e.OnClose = function () {
        this.list.array = []
    }, e.OnShow = function (e) {
        var t = 140;
        e.Info ? (this.lab_Info.text = e.Info, this.list.y = 110) : (this.list.y = 70, t = 100, this.lab_Info.text = "");
        var i = [], a = e.Rewards, r = {};
        _.each(a, function (e) {
            var t = e[1], i = e[3].HeroId, a = e[2];
            r[i] || (r[i] = {type: t, value: 0}), r[i].value += a
        }.bind(this)), _.each(r, function (e, t) {
            i.push([t, e.value, e.type])
        }), 1 == i.length ? (this.list.repeatX = 1, this.list.height = 245) : (this.list.repeatX = 2, i.length >= 6 ? this.list.repeatY = 3 : this.list.repeatY = Math.ceil(i.length / 2), this.list.height = 245 * this.list.repeatY), this.list.array = i;
        var o = this.list.height, n = o;
        this.img_Bg.height = n + t, this.btn_Close.y = this.img_Bg.height + 50, this.list.centerX = .5, this.img_Bg.centerY = .5
    }
}();
var HanlinBookUpRewardView = function () {
    function t() {
        t.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("HanlinBookUpRewardView")
        }), this.list.vScrollBarSkin = null, this.list.renderHandler = new Laya.Handler(this, this.OnUpdateItem)
    }

    return Laya.class(t, "HanlinBookUpRewardView", HanlinBookUpRewardUI), t.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(HanlinBookUpRewardUI.uiView, t)
    }, t.prototype.OnShow = function (t) {
        var e = t.Ret;
        this._308835052 = global.$Sys.GetTableService().GetTableRecord("book", e.BookId).BookName, this._3548392028 = e.Heros;
        var i = 100;
        this.list.y = 70, this.lab_Info.text = "";
        var s = this._3548392028;
        1 == s.length ? (this.list.repeatX = 1, this.list.height = 245) : (this.list.repeatX = 2, s.length >= 6 ? this.list.repeatY = 3 : this.list.repeatY = Math.ceil(s.length / 2), this.list.height = 245 * this.list.repeatY), this.list.array = s;
        var a = this.list.height, n = a;
        this.img_Bg.height = n + i, this.btn_Close.y = this.img_Bg.height + 50, this.list.centerX = .5, this.img_Bg.centerY = .5
    }, t.prototype.OnUpdateItem = function (t, e) {
        var i = t.getChildByName("html_info");
        i.style.fontSize = 30, i.style.align = "center", i.style.fontSize = 25;
        var s = t.getChildByName("img_Body"), a = t.dataSource;
        GameCommon._s8a21ef794823199e0f5d44c20a9476(s, a);
        var n = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Institute.BooksIRewardHTML, this._308835052);
        i.innerHTML = n
    }, t
}();
var CabinetPage;
!function () {
    CabinetPage = function () {
        CabinetPage.super(this), this._1842891454 = null, this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_event.renderHandler = Laya.Handler.create(this, this.OnCreateEvent, null, !1), this.list_event.vScrollBarSkin = null, this.btn_rule.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._s2e22e694b9852084df200bc86f9340("RuleMessageDialog", {Field: "Cabinet"})
        }), this.list_event.array = []
    }, Laya.class(CabinetPage, "CabinetPage", CabinetPageUI);
    var e = CabinetPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._sa4a95e1ae2426793b0a8777fced7fe(), this._s3757fac25f6e1a2cd4466fc1c33221()
    }, e._sa4a95e1ae2426793b0a8777fced7fe = function () {
        this.timerLoop(1e3, this, this.OnTimerLoop)
    }, e._sba8dccb7f9520b22fcad20277b05d9 = function () {
        this.clearTimer(this, this.OnTimerLoop)
    }, e.OnTimerLoop = function () {
        var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
        return this._1842891454.NextTime - e < 0 ? (jasmin.Info("GetServerData!!"), this._sba8dccb7f9520b22fcad20277b05d9(), void this._s3757fac25f6e1a2cd4466fc1c33221(this._sa4a95e1ae2426793b0a8777fced7fe.bind(this))) : void _.each(this.list_event.cells, function (e) {
            e.event("RefreshTime")
        })
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        return this._1842891454.State == GlobalCabinet.STATE.UNINIT ? (this.lab_noEvent.visible = !0, this.list_event.array = [], void(this.lab_info.text = gLanguage.CabinetFinishInfo)) : (this.lab_noEvent.visible = !1, this.list_event.array = _.toArray(this._1842891454.Data.Events), this.list_event.scrollTo(0), void(this.lab_info.text = gLanguage.CabinetAffairInfo))
    }, e.OnCreateEvent = function (e, t) {
        var a = e.getChildByName("img_bg"), i = e.getChildByName("img_type"), n = e.getChildByName("img_status"),
            o = e.getChildByName("btn_enter"), s = e.getChildByName("img_team"), r = n.getChildByName("lab_name"),
            l = n.getChildByName("lab_state"), h = n.getChildByName("lab_isJoin"), C = n.getChildByName("lab_eventLv"),
            m = n.getChildByName("lab_time"), b = n.getChildByName("lab_att"), g = s.getChildByName("lab_teamCnt"),
            d = this.list_event.array[t], u = parseInt(d.NeedAttr);
        a.skin = global.$Cfg.Common.CabinetEventBg[u], i.skin = global.$Cfg.Common.CabinetEventImg[u];
        var v = this._1842891454.Data.MaxHero, c = d.Team.length;
        g.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("%d/%d", c, v), l.text = gLanguage.CabinetStausInfo[this._1842891454.State] + "：";
        var f = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
        m.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(this._1842891454.NextTime - f), b.text = gLanguage.CabinetAttInfo[u], C.text = gLanguage.CabinetAffairLv[d.AffairLv];
        var _ = global.$Sys.GetTableService().GetTableRecord("cabinet", d.Id);
        r.text = _.Name;
        var S = !1;
        for (var G in d.Team) if (d.Team[G].Uid == global.$Api.QueryDataSource("DataCabinet").GetValue("Uid")) {
            S = !0;
            break
        }
        h.text = gLanguage.CabinetJoin[Number(S)], h.color = S ? "#28b244" : "#ee5626", o.off(Laya.Event.CLICK), o.on(Laya.Event.CLICK, this, this.OnEnterEvent, [d]), e.off("RefreshTime"), e.on("RefreshTime", this, function () {
            var e = global.$Sys.GetTimeService()._s84b6810b77033dfce863ff4c455285();
            m.text = GameCommon._s840685c6dfa5f3e0d7ba02ebaa063a(this._1842891454.NextTime - e)
        }.bind(this)), Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: o,
            NodeName: "CabinetReward" + t,
            Group: "CabinetReward",
            OnCheckState: TargetCheck.OnCheckCabinet.bind(this, this._1842891454.State, d.Team, d.AffairLv),
            OnExecute: GameCommon._s96729fd95eeee178e1c7f3b48ddb40({scaleX: .8, scaleY: .8, right: -5, top: -5}),
            cover: !0
        })
    }, e.OnEnterEvent = function (e) {
        switch (this._1842891454.State) {
            case GlobalCabinet.STATE.UNINIT:
                break;
            case GlobalCabinet.STATE.REWARD:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CabinetRewardPage", e);
                break;
            default:
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CabinetDetailPage", {
                    Event: e,
                    State: this._1842891454.State
                })
        }
    }, e._s3757fac25f6e1a2cd4466fc1c33221 = function (e) {
        GetDataCabinetInterface().DoGetInfo(function (t) {
            this._1842891454 = t, this._s4fb507d6d0f40b2d2a72f6007a938d(), e && e()
        }.bind(this))
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainCity")
    }, e.OnClose = function () {
        this._sba8dccb7f9520b22fcad20277b05d9(), this.list_event.array = []
    }, CabinetPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetPage.uiView, e)
    }
}();
var CabinetDetailPage;
!function () {
    CabinetDetailPage = function () {
        CabinetDetailPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_team.renderHandler = Laya.Handler.create(this, this.OnCreateTeam, null, !1), this.list_bg.renderHandler = Laya.Handler.create(this, this.OnCreateBg, null, !1), this.list_team.vScrollBarSkin = null, this.list_team._scrollBar.on("change", this, this.OnScrollChange.bind(this)), this.list_bg.vScrollBarSkin = null, this._1193197536 = 0, this.btn_rewardInfo.on(Laya.Event.CLICK, this, this.OnRewardInfoClick)
    }, Laya.class(CabinetDetailPage, "CabinetDetailPage", CabinetDetailPageUI), CabinetDetailPage.BG_SKIN = ["res/ui/bg/z_bg_229.png", "res/ui/bg/z_bg_229_1.png"];
    var e = CabinetDetailPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnClose = function () {
        this.list_team.array = [], this.list_bg.array = []
    }, e.OnScrollChange = function () {
        var e = this.list_team._scrollBar.value;
        this._1193197536 != e && (this._1193197536 = e, this.list_bg._scrollBar.value = e)
    }, e.OnCreateBg = function (e, a) {
        var i = e.getChildByName("img_bg"), t = e.getChildByName("spr_role"), n = t.getChildByName("img_dialog"),
            l = n.getChildByName("lab_info"), s = t.getChildByName("img_role"), r = t.getChildByName("img_head"),
            o = t.getChildByName("img_name"), m = t.getChildByName("img_office"), b = o.getChildByName("lab_name"),
            h = m.getChildByName("lab_office"), g = t.getChildByName("img_defaultRole");
        if (i.skin = CabinetDetailPage.BG_SKIN[Number(0 != a)], 0 != a || this._4122736007.State != GlobalCabinet.STATE.OPEN) return void(t.visible = !1);
        t.visible = !0, g.visible = !1, o.visible = !1, s.visible = !1, r.visible = !1;
        var C = this._4122736007.Event.NeedAttr, c = global.$Cfg.Common.CabinetEventKing[C],
            f = global.$Sys.GetTableService().GetTableRecord("throne", c, "Name");
        h.text = f;
        var v = GetPalaceInterface()._se684e29d5f78289e3e5272975d813e(c);
        if (v) {
            o.visible = !0, s.visible = !0, r.visible = !0, s.skin = global.$Sys.GetTableService().GetTableRecord("throne", c, "ClothPath");
            var _ = jasmin._s449f055209cd01229b1846559026f5(v.PlayerInfo);
            r.skin = global.$Cfg.Common.HeadIconName[_.PlayerSex][_.PlayerHeadId], b.text = _.PlayerName
        } else g.visible = !0;
        l.text = global.$Sys.GetTableService().GetTableRecord("cabinet", this._4122736007.Event.Id, "Intro")
    }, e.OnCreateTeam = function (e, a) {
        var i = this.list_team.array[a];
        if ("UNVALID_SEAT" == i) return void(e.visible = !1);
        e.visible = !0;
        var t = e.getChildByName("img_arrows"), n = e.getChildByName("img_bottom"), l = e.getChildByName("img_role"),
            s = e.getChildByName("img_info"), r = s.getChildByName("lab_office"), o = s.getChildByName("lab_name");
        l.visible = !1, s.visible = !1, t.visible = !1, n.off(Laya.Event.CLICK), t.off(Laya.Event.CLICK);
        var m = this._4122736007.State == GlobalCabinet.STATE.OPEN;
        return i && m ? (l.visible = !0, s.visible = !0, r.text = global.$Sys.GetTableService().GetTableRecord("office", i.Data.OfficeId, "OfficeName"), void(o.text = i.Data.Name)) : (m && (t.visible = !0), n.on(Laya.Event.CLICK, this, this.OnJoin, [a - 1]), void t.on(Laya.Event.CLICK, this, this.OnJoin, [a - 1]))
    }, e.OnJoin = function (e) {
        var a = this._4122736007.State;
        switch (a) {
            case GlobalCabinet.STATE.READY:
                GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CabinetReadyInfo]});
                break;
            case GlobalCabinet.STATE.OPEN:
                var i = _.find(this._4122736007.Event.Team, function (e) {
                    if (e.Uid == global.$Api.QueryDataSource("DataCabinet").GetValue("Uid")) return !0
                });
                i ? GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CabinetPlayerIsJoin]}) : GetGuiManager()._s2e22e694b9852084df200bc86f9340("CabinetSelectTeam", {
                    Attribute: this._4122736007.Event.NeedAttr,
                    Callback: function (a) {
                        this.OnJoinCallback(a, e)
                    }.bind(this)
                });
                break;
            case GlobalCabinet.STATE.CLEAR:
                GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: [gLanguage.CabinetFinishInfo]});
                break;
            default:
                jasmin._se7a49036f5cfea7f559beac9db86e9(!1, "CODER : STATE_ERROR state is " + a)
        }
    }, e.OnJoinCallback = function (e, a) {
        var i = this._4122736007.Event.Consume;
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ItemUseDialog", {
            ConsumeId: i,
            Purpose: gLanguage.CabinetJoinTitle,
            OnConfirmUse: function (i) {
                GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CabinetSelectTeam"), GetDataCabinetInterface().DoJoin(this._4122736007.Event.Id, a, e.Queue, function (e) {
                    var a = e.Data;
                    this._4122736007 = {
                        Event: a.Events[this._4122736007.Event.Id],
                        State: this._4122736007.State
                    }, jasmin.Info("Cb Params"), jasmin.Info(this._4122736007), this._s4fb507d6d0f40b2d2a72f6007a938d()
                }.bind(this))
            }.bind(this)
        })
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = this.list_team.array = new Array(30), a = this._4122736007.Event.Team;
        for (var i in a) {
            var t = a[i];
            e[t.Seat - 1] = t
        }
        e.unshift("UNVALID_SEAT", "UNVALID_SEAT"), this.list_team.array = e, this.list_bg.array = new Array(30)
    }, e.OnRewardInfoClick = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("CabinetRankReward", {AffairLv: this._4122736007.Event.AffairLv})
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CabinetPage")
    }, CabinetDetailPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetDetailPage.uiView, e)
    }
}();
!function () {
    var e, a, t = "AcademyOneKeyStudy";
    "function" == typeof require && "object" == typeof module ? (e = module, a = "exports", e[a] = {CmdName: t}) : (e = function () {
        return this || (0, eval)("(this)")
    }(), a = t, e[a] = {});
    var r = e[a];
    if ("function" == typeof require && "object" == typeof module) var u = (require("lib_js/jasmin/jasmin"), require("lib_js/underscore/underscore")._); else var u = (window.jasmin, window._);
    r._sb7e01e46e284124f4c60b3d14a2456 = function () {
        return {
            DataAcademy: {DataKey: "Uid", ParamKey: "U"},
            DataTask: {DataKey: "Uid", ParamKey: "U"},
            DataBase: {DataKey: "Uid", ParamKey: "U"},
            DataBag: {DataKey: "Uid", ParamKey: "U"},
            DataHero: {DataKey: "Uid", ParamKey: "U"},
            DataBeauty: {DataKey: "Uid", ParamKey: "U"},
            DataChild: {DataKey: "Uid", ParamKey: "U"}
        }
    }, r._s6a4dba9453762113ae0d1467dd81b3 = function (e, a) {
        var t = global.$Api.QueryDataSource("DataAcademy")._s8d49d912c025979ba690afb2b68668();
        if (t < global.$Cfg.Common.OpenQueueNeedCnt) return {Result: !1, Error: ERR.AcademyMaxSeatNotEnough};
        var r = global.$Api.QueryDataSource("DataAcademy").GetValue("Seat"), o = 0;
        if (u.each(r, function (e) {
            e.HeroId && o++
        }), o >= t) return {Result: !1, Error: ERR.AcademyNoEmptySeat};
        var y = global.$Api.QueryDataSource("DataAcademy")._s67fa031f58c0ff9fc6b44a539ee411();
        if (y.length <= 0) return {Result: !1, Error: ERR.AcademyNoQueue};
        var i = 0;
        for (var n in y) if (y[n]) {
            var d = global.$Api.QueryDataSource("DataAcademy")._s67d9dc4e5642dbe7adf83beb6ffeb0(y[n]);
            d && i++
        }
        return i >= y.length ? {Result: !1, Error: ERR.AcademyQueueIsStudy} : {Result: !0}
    }, r.Do = function (e, a) {
        return global.$Api.QueryDataSource("DataAcademy").OnKeyStudy(), {Result: !0}
    }
}();
!function () {
    var e, a, t = "AcademySetQueue";
    "function" == typeof require && "object" == typeof module ? (e = module, a = "exports", e[a] = {CmdName: t}) : (e = function () {
        return this || (0, eval)("(this)")
    }(), a = t, e[a] = {});
    var r = e[a];
    if ("function" == typeof require && "object" == typeof module) {
        require("lib_js/jasmin/jasmin"), require("lib_js/underscore/underscore")._
    } else {
        window.jasmin, window._
    }
    r._sb7e01e46e284124f4c60b3d14a2456 = function () {
        return {
            DataAcademy: {DataKey: "Uid", ParamKey: "U"},
            DataTask: {DataKey: "Uid", ParamKey: "U"},
            DataBase: {DataKey: "Uid", ParamKey: "U"},
            DataBag: {DataKey: "Uid", ParamKey: "U"},
            DataHero: {DataKey: "Uid", ParamKey: "U"},
            DataBeauty: {DataKey: "Uid", ParamKey: "U"},
            DataChild: {DataKey: "Uid", ParamKey: "U"}
        }
    }, r._s6a4dba9453762113ae0d1467dd81b3 = function (e, a) {
        var t = global.$Api.QueryDataSource("DataAcademy")._s8d49d912c025979ba690afb2b68668();
        return t < global.$Cfg.Common.OpenQueueNeedCnt ? {Result: !1, Error: ERR.AcademyMaxSeatNotEnough} : {Result: !0}
    }, r.Do = function (e, a) {
        var t = e.Queue;
        return global.$Api.QueryDataSource("DataAcademy")._s54c7a6cf1866af7bb13985818beae9(t), {Result: !0}
    }
}();

function HeroPelletLayer() {
    HeroPelletLayer.super(this), this.list_Pellet.renderHandler = Laya.Handler.create(this, this.OnCreatePellet, null, !1), this.list_Pellet.vScrollBarSkin = null, this.list_Pellet.scrollBar.elasticDistance = 500
}

Laya.class(HeroPelletLayer, "HeroPelletLayer", HeroPelletLayerUI);
var _proto_ = HeroPelletLayer.prototype;
_proto_.OnRefresh = function (e) {
    this._4122736007 = e || this._4122736007 || {}, this.OnUpdateList()
}, _proto_.OnClose = function () {
    _.each(this.list_Pellet.cells, function (e) {
        var t = e.getChildByName("img_Item");
        t.destroyChildren()
    })
}, _proto_._sa68e2f61ab7d8e64cb1c71e491dc5f = function () {
    for (var e = global.$Api.QueryDataSource("DataBag")._s233bcecc9537a12cc7f6c574185461(), t = 0; t < e.length; t++) {
        var a = e[t].ItemId, l = global.$Sys.GetTableService().GetTableRecord("item", a);
        l.UseType == global.$Cfg.CommonEnum.UseType.ELIXIR ? (e[t].ItemEffect = l.ItemDesc, e[t].ItemName = l.ItemName) : (e.splice(t, 1), t--)
    }
    return e
}, _proto_.OnUpdateList = function () {
    this.list_Pellet.array = [];
    var e = this._sa68e2f61ab7d8e64cb1c71e491dc5f();
    this.list_Pellet.array = e
}, _proto_.OnCreatePellet = function (e, t) {
    var a = e.getChildByName("img_Item"), l = e.getChildByName("lab_ItemEffect"), r = e.getChildByName("hbox_ItemName"),
        o = r.getChildByName("lab_ItemName"), i = r.getChildByName("lab_ItemCount"),
        s = e.getChildByName("btn_UseItem"), n = e.dataSource, m = n.ItemId,
        h = GameCommon._s66eb52e60b9feb53711943e638c9c3(global.$Cfg.CommonEnum.Asset.DataBag, m);
    h.scaleX = .9, h.scaleY = .9, a.addChild(h), o.text = n.ItemName, i.text = n.Count, r.changeItems(), l.text = n.ItemEffect, e.offAll("UpdateCount"), e.on("UpdateCount", this, function (e, t, a) {
        var l = global.$Api.QueryDataSource("DataBag")._sb81069be5bd736d4cbdb5d6ef74a08(t);
        if (l <= 0) return this.list_Pellet.deleteItem(a), void this.list_Pellet.refresh();
        var r = e.getChildByName("hbox_ItemName"), o = r.getChildByName("lab_ItemCount");
        o.text = l
    }, [e, m, t]), s.off(Laya.Event.CLICK, this, this.OnClickUseItem), s.on(Laya.Event.CLICK, this, this.OnClickUseItem, [e, m])
}, _proto_.OnClickUseItem = function (e, t) {
    var a = {UserData: {HeroId: this._4122736007.HeroId}, ItemId: t};
    GetDataBagInterface()._SelectCount(a, function (t) {
        e.event("UpdateCount"), this.event("UsePelletSuccess");
        var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
        GameCommon._s5d340979c9fcfd9445217570f410e4(Laya.stage, a)
    }.bind(this))
};
var BeautyWeifen;
!function () {
    BeautyWeifen = function (e) {
        BeautyWeifen.super(this), this.listBeaty.renderHandler = new Laya.Handler(this, this.OnUpdateItem), this.listBeaty.vScrollBarSkin = "", this.OnUpdateView(e)
    }, Laya.class(BeautyWeifen, "BeautyWeifen", BeautyWeifenUI), BeautyWeifen.LESS_HEIGHT = 100, BeautyWeifen.Y_HEIGHT = 200, BeautyWeifen.X_COUNT = 3, BeautyWeifen.NULL_SKIN = "res/ui/bg/z_bg_minnv.png";
    var e = BeautyWeifen.prototype;
    e.OnUpdateView = function (e) {
        var t = global.$Api.QueryDataSource("DataBeauty")._sd29ac33cbd396ebabb3dcea2591d7c(e.Lv);
        this._3289394066 = e;
        var a = jasmin._s68574baea387d56114fc6a81d89c67(t);
        if (e.IsShowPicture) for (var i = a; i < e.BeautyCntLimit; i++) t.push({});
        var n = jasmin._s68574baea387d56114fc6a81d89c67(t);
        this.height = BeautyWeifen.LESS_HEIGHT + Math.ceil(n / BeautyWeifen.X_COUNT) * BeautyWeifen.Y_HEIGHT, this.imgTitle.skin = e.ArtWord, this.labCount.text = "(" + a + "/" + e.BeautyCntLimit + ")", 1 == e.Lv && (this.labCount.text = "(" + a + ")"), this.labCondition.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.JarligCondition, e.TitleRequireIntimacy, e.TitleRequireCharm), this.labEffect.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.JarligEffect, e.TitleEffect), this.OnListInformation(t)
    }, e.OnListInformation = function (e) {
        this.listBeaty.array = e
    }, e.OnUpdateItem = function (e, t) {
        for (var a = this.listBeaty, i = a.array[t], n = 0; n < 3; n++) if (n == this._3289394066.PictureType) {
            var l = e.getChildByName("box" + n);
            l.visible = !0
        } else {
            var r = e.getChildByName("box" + n);
            r.visible = !1
        }
        var s = l.getChildByName("imgBeauty"), o = l.getChildByName("imgName"), u = l.getChildByName("imgNameBg");
        if (i.Id) {
            GameCommon._s92f0c530de187bbb9bb21d3079ebaa(s, i.Id), s.on(Laya.Event.CLICK, this, this._SelectItem, [i]);
            var y = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty", i.Id);
            o.skin = y.NamePath, o.visible = !0, u.visible = !0
        } else s.skin = BeautyWeifen.NULL_SKIN, o.visible = !1, u.visible = !1;
        var f = {};
        f[i.Id] = i, Leo.GetNodeAdditionalManager()._s6e7b7bc57df31cac2c87387a6113ea({
            Node: e,
            NodeName: "Beauty_item",
            OnCheckState: TargetCheck.OnCheckWeifen.bind(this, f),
            cover: !0
        })
    }, e._SelectItem = function (e) {
        var t = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty_title", this._3289394066.Lv + 1);
        t || (t = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty_title", this._3289394066.Lv));
        var a = {
            BeautyData: e,
            TitleEffect: this._3289394066.TitleEffect,
            NextLvTitleData: t,
            Callback: this._3289394066.Callback
        };
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("BeautyJarligDialog", a)
    }, BeautyWeifen.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyWeifen.uiView, e)
    }
}();

function BeautyJarligDialog() {
    BeautyJarligDialog.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btnJarlig.on(Laya.Event.CLICK, this, this.OnBtnJarligClick)
}

Laya.class(BeautyJarligDialog, "BeautyJarligDialog", BeautyJarligDialogUI);
var _proto_ = BeautyJarligDialog.prototype;
_proto_.OnShow = function (a) {
    this._4122736007 = a, this._696458372 = a.BeautyData.JarligLv || 1, this.OnUpdateView(a)
}, _proto_.OnUpdateView = function (a) {
    this.proIntimacy.value = a.BeautyData.LoveValue / a.NextLvTitleData.TitleRequireIntimacy, this.labIntimacy.text = a.BeautyData.LoveValue + "/" + a.NextLvTitleData.TitleRequireIntimacy, a.BeautyData.LoveValue / a.NextLvTitleData.TitleRequireIntimacy >= 1 ? this.labIntimacy.color = "#32ff00" : this.labIntimacy.color = "#ff0400", this.proCharm.value = a.BeautyData.Charm / a.NextLvTitleData.TitleRequireCharm, this.labCharm.text = a.BeautyData.Charm + "/" + a.NextLvTitleData.TitleRequireCharm, a.BeautyData.Charm / a.NextLvTitleData.TitleRequireCharm >= 1 ? this.labCharm.color = "#32ff00" : this.labCharm.color = "#ff0400", this.labAddition.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Language.ChildAddition, a.TitleEffect), GameCommon._s92f0c530de187bbb9bb21d3079ebaa(this.imgBeauty, a.BeautyData.Id);
    var t = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty", a.BeautyData.Id);
    this.imgName.skin = t.NamePath;
    var i = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty_title", this._696458372);
    this.imgTitle.skin = i.ArtWord
}, _proto_.OnBtnJarligClick = function () {
    var a = {
        JarligLv: this._696458372, OnClickCallback: function (a) {
            var t = {BeautyId: this._4122736007.BeautyData.Id, JarligLv: a},
                i = BeautyJarlig._s6a4dba9453762113ae0d1467dd81b3(t);
            return i.Result ? void GetCmdProxy().DoCmd("BeautyJarlig", t, function (t) {
                if (t.Result) {
                    if (this.close(), this._4122736007.Callback(), this._696458372 > a) var i = "BeautyJarligDownDialog"; else if (this._696458372 < a) var i = "BeautyJarligUpDialog";
                    GetGuiManager()._s2e22e694b9852084df200bc86f9340(i, {
                        OldLv: this._696458372,
                        NewLv: a,
                        BeautyId: this._4122736007.BeautyData.Id
                    })
                }
            }.bind(this)) : void GameCommon._s30cc50bf7aa0ccc0d03c26418e1600(i)
        }.bind(this)
    };
    GetGuiManager()._s2e22e694b9852084df200bc86f9340("BeautyJarligLvDialog", a)
}, _proto_.OnBtnCloseClick = function () {
    this.close()
}, _proto_.OnClose = function () {
}, BeautyJarligDialog.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyJarligDialog.uiView, a)
};

function BeautyJarligLvDialog() {
    BeautyJarligLvDialog.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.listLv.renderHandler = new Laya.Handler(this, this.OnUpdateItem)
}

Laya.class(BeautyJarligLvDialog, "BeautyJarligLvDialog", BeautyJarligLvDialogUI);
var _proto_ = BeautyJarligLvDialog.prototype;
_proto_.OnShow = function (a) {
    this._3289394066 = a;
    var t = _.values(global.$Sys.GetTableService().GetTable("beauty_title"));
    this.listLv.array = t.reverse()
}, _proto_.OnUpdateItem = function (a, t) {
    var e = this.listLv, i = e.array[t], l = a.getChildByName("labInfo"), o = a.getChildByName("labNow"),
        r = a.getChildByName("imgMask"), s = a.getChildByName("imgName"),
        n = global.$Api.QueryDataSource("DataBeauty")._s2ad8b8a62604af4ecb79a5a47956e6(i.Lv),
        v = global.$Sys.GetTableService()._s8f1240e4405a1fdea7c0adbf78e9a7("beauty_title", i.Lv);
    1 == i.Lv ? l.text = " (" + n + ")" : l.text = " (" + n + "/" + i.BeautyCntLimit + ")", o.visible = this._3289394066.JarligLv == i.Lv, r.visible = this._3289394066.JarligLv == i.Lv, s.skin = v.ArtWord, a.on(Laya.Event.CLICK, this, this._OnSelect, [i.Lv])
}, _proto_._OnSelect = function (a) {
    this._3289394066 && this._3289394066.OnClickCallback && this._3289394066.OnClickCallback(a), this.close()
}, _proto_.OnBtnCloseClick = function () {
    this.close()
}, BeautyJarligLvDialog.GetPreLoadResList = function (a) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyJarligLvDialog.uiView, a)
};

function BeautyJarligDownDialog() {
    BeautyJarligDownDialog.super(this), this.on(Laya.Event.CLICK, this, this._ClickEvent)
}

Laya.class(BeautyJarligDownDialog, "BeautyJarligDownDialog", BeautyJarligDownDialogUI);
var _proto_ = BeautyJarligDownDialog.prototype;
_proto_.OnShow = function (t) {
    var e = global.$Sys.GetTableService().GetTableRecord("beauty_title", t.OldLv),
        i = global.$Sys.GetTableService().GetTableRecord("beauty_title", t.NewLv);
    this.labOldEffect.text = e.TitleEffect + "%", this.labNewEffect.text = i.TitleEffect + "%", this.imgOld.skin = e.ArtWord, this.imgNew.skin = i.ArtWord
}, _proto_._ClickEvent = function () {
    this.close()
}, BeautyJarligDownDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyJarligDownDialog.uiView, t)
};

function BeautyJarligUpDialog() {
    BeautyJarligUpDialog.super(this), this.on(Laya.Event.CLICK, this, this._ClickEvent)
}

Laya.class(BeautyJarligUpDialog, "BeautyJarligUpDialog", BeautyJarligUpDialogUI);
var _proto_ = BeautyJarligUpDialog.prototype;
_proto_.OnShow = function (t) {
    var e = global.$Sys.GetTableService().GetTableRecord("beauty_title", t.OldLv),
        i = global.$Sys.GetTableService().GetTableRecord("beauty_title", t.NewLv);
    this.labOldEffect.text = e.TitleEffect + "%", this.labNewEffect.text = i.TitleEffect + "%", this.imgOld.skin = e.ArtWord, this.imgNew.skin = i.ArtWord, GameCommon._s2d5a2f578e0d4afe089454eb2d923d(this.imgBeauty, t.BeautyId)
}, _proto_._ClickEvent = function () {
    this.close()
}, BeautyJarligUpDialog.GetPreLoadResList = function (t) {
    leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(BeautyJarligUpDialog.uiView, t)
};
var CabinetRewardPage;
!function () {
    CabinetRewardPage = function () {
        CabinetRewardPage.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_rank.renderHandler = Laya.Handler.create(this, this.OnCreateRank, null, !1), this.list_rank.vScrollBarSkin = null
    }, Laya.class(CabinetRewardPage, "CabinetRewardPage", CabinetRewardPageUI);
    var e = CabinetRewardPage.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e, this._3098463714 = e.NeedAttr, this._1849905653 = e.Id, this.lab_info.text = gLanguage.CabinetAwardInfo;
        var a = this._3098463714, i = global.$Cfg.Common.CabinetEventKing[a],
            t = global.$Sys.GetTableService().GetTableRecord("throne", i, "Name");
        this.lab_office.text = t, this.img_name.visible = !1, this.img_role.visible = !1, this.img_head.visible = !1, this.img_defaultRole.visible = !1;
        var r = GetPalaceInterface()._se684e29d5f78289e3e5272975d813e(i);
        if (r) {
            this.img_name.visible = !0, this.img_role.visible = !0, this.img_head.visible = !0, this.img_role.skin = global.$Sys.GetTableService().GetTableRecord("throne", i, "ClothPath");
            var n = jasmin._s449f055209cd01229b1846559026f5(r.PlayerInfo);
            this.img_head.skin = global.$Cfg.Common.HeadIconName[n.PlayerSex][n.PlayerHeadId], this.lab_name.text = n.PlayerName
        } else this.img_defaultRole.visible = !0;
        this._2546668206 = global.$Sys.GetTableService().GetTableRecord("cabinet_reward", this._4122736007.AffairLv), this._2847735493 = _.sortBy(_.keys(this._2546668206), function (e) {
            return Math.min(e)
        }), this._1265530182 = this._2847735493[this._2847735493.length - 1], this._s1b1a35158dbd156c0e8f80931e5e0d(), this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, e.OnClose = function () {
        this.list_rank.array = []
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var e = this._4122736007.Team;
        this.list_rank.array = e.slice(0, this._1265530182), this.list_rank.scrollTo(0)
    }, e._s1b1a35158dbd156c0e8f80931e5e0d = function () {
        var e = this._4122736007.Team.slice(0, this._1265530182);
        for (var a in e) {
            var i = e[a];
            if (i.Uid == global.$Api.QueryDataSource("DataCabinet").GetValue("Uid")) {
                i.Reward || (GetDataCabinetInterface().DoGetReward(this._1849905653, function (e) {
                    GetGuiManager()._s2e22e694b9852084df200bc86f9340("CabinetRewardDialog", {
                        Rewards: e.Rewards,
                        Rank: parseInt(a) + 1
                    }, null, {useMgrEffect: !1})
                }), jasmin.Info("领奖1111111"));
                break
            }
        }
    }, e.OnCreateRank = function (e, a) {
        var i = e.getChildByName("box_role"), t = i.getChildByName("img_office"), r = i.getChildByName("img_head"),
            n = e.getChildByName("lab_name"), s = e.getChildByName("lab_reward"), l = e.getChildByName("lab_info"),
            o = e.getChildByName("hBox_heros"), m = e.getChildByName("img_rankBg"), d = m.getChildByName("img_rank"),
            h = this.list_rank.array[a], g = h.Data;
        o.destroyChildren();
        var b = global.$Sys.GetTableService().GetTableRecord("office", g.OfficeId);
        t.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.ClothesPath, b.Clothing), r.skin = global.$Cfg.Common.HeadIconName[g.Sex][g.HeadId];
        for (var _ in g.HeroData) {
            var C = g.HeroData[_], c = new HeroHeadFabUI;
            GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(c.img_headIcon, C.Id), c.img_quality.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, C.Quality), c.scaleX = .35, c.scaleY = .35, o.addChild(c)
        }
        o.refresh(), n.text = g.Name, l.text = gLanguage.CabinetAttInfo[this._3098463714] + "：" + h.Score;
        var f = a + 1;
        d.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a("res/ui/artfont/paiming/z_word_%d.png", f);
        for (var v = null, w = 0; w < this._2847735493.length; w++) {
            var R = parseInt(this._2847735493[w]);
            if (f <= R) {
                v = R;
                break
            }
        }
        jasmin._se7a49036f5cfea7f559beac9db86e9(v, "Design: Please Check Table ,Table Name is cabinet_reward  Current Rank is " + f);
        var k = this._2546668206[v].RewardId;
        jasmin.Debug(k);
        var u = global.$Sys.GetTableService().GetTableRecord("reward", k, "Award"),
            y = GameCommon._sd829d199a08f4ea0e8f4acd2566c18(u), G = "";
        for (var _ in y) G = G + y[_][0] + "+" + y[_][1] + "  ";
        s.text = G
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("CabinetPage")
    }, CabinetRewardPage.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetRewardPage.uiView, e)
    }
}();
var CabinetSelectTeam;
!function () {
    CabinetSelectTeam = function () {
        CabinetSelectTeam.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.btn_save.on(Laya.Event.CLICK, this, this.OnBtnSevaClick), this.list_selected.renderHandler = Laya.Handler.create(this, this.OnCreateSeleactHeros, null, !1), this.list_hero.renderHandler = Laya.Handler.create(this, this.OnCreateHeros, null, !1), this.list_hero.vScorllBarSkin = null, this._1277725458 = HeroListController._s0daf7356f401bde6dc31ec8d9f8bc8(this.list_hero), this.list_selected.mouseHandler = Laya.Handler.create(this, this.OnClickBox, null, !1), this.list_selected.selectHandler = Laya.Handler.create(this, this.OnSelectChange, null, !1), this._1779202952 = 0, this.list_selected.selectedIndex = 0
    }, Laya.class(CabinetSelectTeam, "CabinetSelectTeam", CabinetSelectTeamUI), CabinetDetailPage.SHOW_TYPE = {
        1: "Force",
        2: "Brains",
        3: "Politics",
        4: "Prestige",
        5: "TotalAptitude"
    };
    var e = CabinetSelectTeam.prototype;
    e.OnShow = function (e) {
        this._4122736007 = e;
        var t = parseInt(this._4122736007.Attribute);
        this._1779202952edHeros = [], this._1056589751 = jasmin._sdf8385ff3a74421ea218e043d47fdc(global.$Api.QueryDataSource("DataHero")._s6b8b55436407229b07aeec45efb78d());
        var i = global.$Api.QueryDataSource("DataCabinet")._s4e524d2569d3a2cd7f17a8ba57cccb();
        this._1056589751 = _.filter(this._1056589751, function (e) {
            return i.indexOf(e.HeroId) == -1
        }), this._1056589751.sort(function (e, i) {
            if (5 == t) {
                for (var s = l = 0, a = 1; a <= 4; a++) s += global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, a).AptitudeAdd, l += global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(i.HeroId, a).AptitudeAdd;
                return l - s
            }
            var s = global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(e.HeroId, t).AptitudeAdd,
                l = global.$Api.ShareFunc._sf5c4c05dceefc9148e471ef985221d(i.HeroId, t).AptitudeAdd;
            return l - s
        });
        var s = {
            ShowType: ["Lv", CabinetDetailPage.SHOW_TYPE[t]], Callback: function (e, t) {
                if (this._1779202952edHeros.indexOf(e) != -1) this.OnUnSelect(e); else {
                    if (this._1779202952edHeros.length >= gCfg.CabinetAffair_TeamMaxCnt) return;
                    this.OnSelect(e)
                }
            }.bind(this), Heros: this._1056589751, OnCustom: function (e, t) {
                var i = e.getChildByName("btn_btn");
                i.selected = this._1779202952edHeros.indexOf(t.HeroId) != -1
            }.bind(this)
        };
        this._1277725458.Init(s), this._s4fb507d6d0f40b2d2a72f6007a938d(), this.OnClickBox(Laya.Event.CLICK, 0)
    }, e._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        this._1277725458._s4fb507d6d0f40b2d2a72f6007a938d();
        for (var e = gCfg.CabinetAffair_TeamMaxCnt, t = jasmin._sdf8385ff3a74421ea218e043d47fdc(this._1779202952edHeros); t.length < e;) t.push(null);
        this.list_selected.array = t
    }, e.OnCreateSeleactHeros = function (e, t) {
        var i = e.getChildByName("img_headIcon"), s = e.getChildByName("img_quality"), a = this.list_selected.array[t];
        if (!a) return i.skin = "", void(s.skin = "");
        var l = global.$Api.QueryDataSource("DataHero").GetHeroById(a);
        GameCommon._s08d3ae254b0f7db6c9601a55ff3f9c(i, a), s.skin = jasmin._se91cf955e91eaa1aa510d4335edd4a(global.$Cfg.Common.HeroQualityBcgPath, l.Title)
    }, e.OnUnSelect = function (e) {
        var t = jasmin._sa96e5dbe16d978e8310b94a495c86f(this._1779202952edHeros, e);
        jasmin._seb2d63e263badd8a69c54d151f6cc7(t) && t != -1 && (this._1779202952edHeros.splice(parseInt(t), 1), this.OnUpdateListData(e), this._1277725458._s4fb507d6d0f40b2d2a72f6007a938d())
    }, e.OnSelect = function (e) {
        this._1779202952edHeros.push(e), this.OnUpdateListData(e, 1)
    }, e.OnUpdateListData = function (e, t) {
        for (var i = jasmin._sdf8385ff3a74421ea218e043d47fdc(this._1779202952edHeros); i.length < gCfg.CabinetAffair_TeamMaxCnt;) i.push(null);
        this.list_selected.array = i
    }, e.OnClickBox = function (e, t) {
        if (e.type == Laya.Event.CLICK) {
            if (this._1779202952 == t) return void this.OnUnSelect(this._1779202952edHeros[t]);
            this.list_selected.selectedIndex = t
        }
    }, e.OnSelectChange = function (e) {
        var t = this.list_selected.getCell(this._1779202952), i = t.getChildByName("img_SelectBg");
        i.visible = !1;
        var s = this.list_selected.selection, a = s.getChildByName("img_SelectBg");
        a.visible = !0, this._1779202952 = e
    }, e.OnBtnSevaClick = function () {
        var e = (_.compact(this._1779202952edHeros), {Queue: this._1779202952edHeros});
        this._4122736007.Callback && this._4122736007.Callback(e)
    }, e.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CabinetSelectTeam")
    }, e.OnClose = function () {
        this.list_selected.array = []
    }, CabinetSelectTeam.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetSelectTeam.uiView, e)
    }
}();
var CabinetRewardDialog;
!function () {
    CabinetRewardDialog = function () {
        CabinetRewardDialog.super(this), this.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_reward.renderHandler = Laya.Handler.create(this, this.OnCreateReward, null, !1)
    }, Laya.class(CabinetRewardDialog, "CabinetRewardDialog", CabinetRewardDialogUI);
    var a = CabinetRewardDialog.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(this._4122736007.Rewards);
        a = GameCommon._sd829d199a08f4ea0e8f4acd2566c18(a), this.list_reward.array = a;
        var e = this._4122736007.Rank;
        this.lab_info.text = jasmin._se91cf955e91eaa1aa510d4335edd4a("恭喜大人在本次内阁中获取第%d名", e)
    }, a.OnCreateReward = function (a, e) {
        var t = a.getChildByName("lab_reward"), i = this.list_reward.array[e];
        t.text = i[0] + "+" + i[1]
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CabinetRewardDialog")
    }, a.OnClose = function () {
    }, CabinetRewardDialog.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetRewardDialog.uiView, a)
    }
}();
var CabinetRankReward;
!function () {
    CabinetRankReward = function () {
        CabinetRankReward.super(this), this.btn_close.on(Laya.Event.CLICK, this, this.OnBtnCloseClick), this.list_reward.renderHandler = Laya.Handler.create(this, this.OnCreateRewardBox, null, !1), this.list_reward.vScrollBarSkin = null
    }, Laya.class(CabinetRankReward, "CabinetRankReward", CabinetRankRewardUI);
    var a = CabinetRankReward.prototype;
    a.OnShow = function (a) {
        this._4122736007 = a, this._s4fb507d6d0f40b2d2a72f6007a938d()
    }, a._s4fb507d6d0f40b2d2a72f6007a938d = function () {
        var a = this._4122736007.AffairLv, e = global.$Sys.GetTableService().GetTableRecord("cabinet_reward", a), n = 1,
            r = [];
        for (var t in e) for (; n <= t; n++) r.push({Rank: n, RankInfo: e[t].RewardId});
        this.list_reward.array = [], this.list_reward.array = r
    }, a.OnBtnCloseClick = function () {
        GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("CabinetRankReward")
    }, a.OnClose = function () {
    }, a.OnCreateRewardBox = function (a, e) {
        var n = a.getChildByName("node_Rank"), r = a.getChildByName("node_PReward"),
            t = a.getChildByName("node_HReward"), i = this.list_reward.array[e].RankInfo,
            o = this.list_reward.array[e].Rank;
        if (n.destroyChildren(), o <= 3) var s = new Laya.Image(global.$Cfg.Common.RankIcon[o - 1]); else {
            var s = new Laya.Label(o);
            s.color = "#755848", s.fontSize = 23
        }
        s.centerX = 0, s.centerY = 0, n.addChild(s);
        var l = global.$Sys.GetTableService().GetTableRecord("reward", i, "Award");
        for (var d in l) switch (l[d][0]) {
            case global.$Cfg.CommonEnum.Asset.DataBase:
                r.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(l[d][0], l[d][1]) + "+" + l[d][2];
            case global.$Cfg.CommonEnum.Asset.DataHero:
                t.text = GameCommon._sf0a0854e48d4ebc005e689b65b3673(l[d][0], l[d][1]) + "+" + l[d][2]
        }
    }, CabinetRankReward.GetPreLoadResList = function (a) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(CabinetRankReward.uiView, a)
    }
}();
var ActivityHarvestType;
!function () {
    ActivityHarvestType = function () {
        ActivityHarvestType.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtn), this.btnEntrance.on(Laya.Event.CLICK, this, this.OnEntranceBtn), this.btnShop.on(Laya.Event.CLICK, this, this.OnShopBtn), this.btnReward.on(Laya.Event.CLICK, this, this.OnClickBtnReward), this.btnExChange.on(Laya.Event.CLICK, this, this.OnClickBtnExChange), this._1528714484 = []
    }, Laya.class(ActivityHarvestType, "ActivityHarvestType", ActivityHarvestUI), ActivityHarvestType.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ActivityHarvestUI.uiView, t);
        var i = global.$Sys.GetTableService().GetTable("harvest_relative_activity");
        for (var a in i) t.push(i[a].ShopIcon)
    };
    var t = ActivityHarvestType.prototype;
    t.OnShow = function (t) {
        this._713989164 = t, this._248024307 = t.Data, this._1473968907 = t.Data.AtlistData, this._1528714484 = [], this._OnBreatheTween(this.btnShop, 1.1, 1e3), this._OnBreatheTween(this.btnEntrance, 1.2, 700), this._sc9209ae0dd3fdb06533b36ec4474b1()
    }, t.OnClose = function () {
        for (var t in this._1528714484) this._1528714484[t].destroy();
        this.btnShop.scaleX = 1, this.btnShop.scaleY = 1, this.btnEntrance.scaleX = 1, this.btnEntrance.scaleY = 1
    }, t._OnBreatheTween = function (t, i, a) {
        var e = new Laya.TimeLine;
        e.to(t, {scaleX: i, scaleY: i}, a, null, 0).to(t, {
            scaleX: 1,
            scaleY: 1
        }, a, null, 0), e.play(0, !0), this._1528714484.push(e)
    }, t.OnCloseBtn = function () {
        this._713989164.OnClose()
    }, t._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        if (this.imgBg.skin = this._248024307.BgImageForward, this.imgTitle.skin = this._248024307.ImageTitle, this.btnShop.skin = this._248024307.ShopIcon, this.labInfo.text = this._248024307.ActivityInfo, this.labTitle.text = this._248024307.Name, this._1473968907) {
            var t = this._1473968907.Object._s505a2ac0cde720ef9099aed2ef7fc0(), i = t.Timelst.StartTimelst,
                a = t.Timelst.StopTimelst;
            this.labDate.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RankActivityTime, i[1], i[2], i[3], i[4], a[1], a[2], a[3], a[4])
        }
    }, t.OnShopBtn = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ActivityHarvestShop", this._713989164)
    }, t.OnClickBtnExChange = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ActivityHarvestExchangeView", this._713989164)
    }, t.OnEntranceBtn = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ActivityHarvestMain", this._713989164)
    }, t.OnClickBtnReward = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ActivityHarvestReward", this._713989164)
    }
}();
var ActivityHarvestShop;
!function () {
    ActivityHarvestShop = function () {
        ActivityHarvestShop.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            this.close()
        }.bind(this)), this.listShop.renderHandler = new Laya.Handler(this, this._OnUpdateShopItem), this.listShop.vScrollBarSkin = null, this.listBag.renderHandler = new Laya.Handler(this, this._OnUpdateBagItem), this.listBag.vScrollBarSkin = null, this.tabType.selectHandler = new laya.utils.Handler(this, this._OnBagTabChange);
        var t = {
            OnClose: function () {
                GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ActivityHarvestShop", {OnClose: this.m_OnClose}), this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d()
            }.bind(this), ShowType: ["Gold", "Money"], Custom: {}
        };
        this._2141111536 = FortuneController._s0daf7356f401bde6dc31ec8d9f8bc8({
            ui_labGold: this.ui_labGold,
            ui_labMoney: this.ui_labMoney
        }, t)
    }, Laya.class(ActivityHarvestShop, "ActivityHarvestShop", ActivityHarvestShopUI), ActivityHarvestShop.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ActivityHarvestShopUI.uiView, t)
    };
    var t = ActivityHarvestShop.prototype;
    t.OnClose = function () {
    }, t.OnShow = function (t) {
        this._713989164 = t, this._776227573 = t.Data.Id, t && t.Index && this.tabType.selectedIndex == t.Index && this._OnBagTabChange(), this.tabType.selectedIndex = t.Index || 0
    }, t._OnBagTabChange = function () {
        this.listShop.visible = !1, this.listBag.visible = !1, this.box_gold.visible = !1, this.box_Money.visible = !1, 0 == this.tabType.selectedIndex ? (this.listShop.visible = !0, this._UpdateShop(), this.box_gold.visible = !0, this.box_Money.visible = !0, this._2141111536._s4fb507d6d0f40b2d2a72f6007a938d()) : 1 == this.tabType.selectedIndex && (this.listBag.visible = !0, this._UpdateBag())
    }, t._UpdateShop = function () {
        var t = global.$Sys.GetTableService().GetTableRecord("harvest_relative_activity_shop", this._776227573);
        this.listShop.array = jasmin._sb9f32267a085eac6ed6dcd044081e2(t)
    }, t._UpdateBag = function () {
        var t = global.$Api.QueryDataSource("DataActivityParams")._s0a9ee0146d0fa226cf5f522861f6da([this._776227573, "Bags"]) || {};
        this.listBag.array = jasmin._sb9f32267a085eac6ed6dcd044081e2(t)
    }, t._OnUpdateShopItem = function (t, e) {
        var i = this.listShop, a = i.array[e], s = t.getChildByName("lab_name"), n = t.getChildByName("img_icon"),
            o = t.getChildByName("lab_limit"), h = t.getChildByName("lab_info"),
            l = (t.getChildByName("lab_score"), t.getChildByName("sp_Consume")), r = t.getChildByName("btn_buy"),
            d = GetDataTransfer().GetTableRecord("reward", a.Reward).Award[0],
            c = GameCommon._s3c28725f2d273f38327479132c6eba(d[0], d[1]),
            m = GetDataTransfer().GetTableRecord("item", c.ItemId);
        n.destroyChildren();
        var y = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({
            Id: c.ItemId,
            Attribute: d[1],
            Width: n.width,
            height: n.height
        });
        if (n.addChild(y), s.text = m.ItemName, h.text = m.ItemDesc, a.BuyCnt) {
            var v = global.$Api.QueryDataSource("DataActivityParams")._s0a9ee0146d0fa226cf5f522861f6da([this._776227573, "BuyRecord", a.Index]) || 0;
            o.visible = !0, o.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.BuyCnt, a.BuyCnt - v), r.disabled = v >= a.BuyCnt
        } else o.visible = !1;
        if (a.Consume) {
            l.destroyChildren(), l.visible = !0, r.visible = !0;
            var b = GameCommon._s99e465082e74d6b9006bd301fbaed7(a.Consume, 40, !0);
            b.width = 30, b.height = 30, l.addChild(b)
        } else l.visible = !1, r.visible = !1;
        r.on(Laya.Event.CLICK, this, this.OnClickBuy, [a])
    }, t.OnClickBuy = function (t) {
        GetDataActivityParamsInterface().DoBuy({ProductInfo: t, ActivityType: this._776227573}, function (t) {
            var e = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
            GameCommon._s5d340979c9fcfd9445217570f410e4(this, e), this._OnBagTabChange()
        }.bind(this))
    }, t._OnUpdateBagItem = function (t, e) {
        var i = this.listBag, a = i.array[e], s = t.getChildByName("lab_name"), n = t.getChildByName("img_icon"),
            o = t.getChildByName("btn_select"), h = t.getChildByName("lab_info"), l = t.getChildByName("lab_count");
        n.destroyChildren();
        var r = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: a.ItemId, Width: n.width, height: n.height});
        n.addChild(r);
        var d = GetDataTransfer().GetTableRecord("item", a.ItemId);
        s.text = d.ItemName, h.text = d.ItemDesc, l.text = a.Count, o.on(Laya.Event.CLICK, this, this.OnSelectProp, [a]), o.visible = this._713989164.OnCallback
    }, t.OnSelectProp = function (t) {
        this._713989164.OnCallback && (this._713989164.OnCallback(t), this.close())
    }
}();
var ActivityHarvestExchangeViewView;
!function () {
    ActivityHarvestExchangeView = function () {
        ActivityHarvestExchangeView.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("ActivityHarvestExchangeView")
        }), this.list_Item.renderHandler = new Laya.Handler(this, this.OnCreateItem), this.list_Item.vScrollBarSkin = null
    }, Laya.class(ActivityHarvestExchangeView, "ActivityHarvestExchangeView", ActivityHarvestExchangeUI), ActivityHarvestExchangeView.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ActivityHarvestExchangeUI.uiView, e)
    };
    var e = ActivityHarvestExchangeView.prototype;
    e.OnClose = function () {
    }, e.OnShow = function (e) {
        this._713989164 = e, this._776227573 = e.Data.Id, this.OnUpdateView()
    }, e.OnUpdateView = function () {
        this.labIntegration.text = global.$Api.QueryDataSource("DataActivityParams")._s0a9ee0146d0fa226cf5f522861f6da([this._776227573, "Integration", global.$Cfg.CommonEnum.DataActivityScore[this._776227573 + "Integration"]]) || 0;
        var e = global.$Sys.GetTableService().GetTableRecord("harvest_relative_activity_exchange", this._776227573);
        this.list_Item.array = jasmin._sb9f32267a085eac6ed6dcd044081e2(e)
    }, e.OnCreateItem = function (e, t) {
        var a = this.list_Item, i = a.array[t], n = e.getChildByName("lab_Name"), r = e.getChildByName("sp_Icon"),
            o = e.getChildByName("sp_Count"), c = o.getChildByName("lab_Count"), s = e.getChildByName("lab_Contribute"),
            l = e.getChildByName("btn_Exchange"), h = i.Reward, y = i.Consume,
            g = global.$Sys.GetTableService().GetTableRecord("reward", h), m = g.Award[0][1],
            v = global.$Sys.GetTableService().GetTableRecord("consume", y), u = v.Consume[0][2],
            d = global.$Sys.GetTableService().GetTableRecord("item", m);
        n.text = d.ItemName, r.destroyChildren();
        var C = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({Id: m, Width: 115, Height: 115});
        r.addChild(C), r._Icon = C, s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.Integration, u);
        var b = global.$Api.QueryDataSource("DataActivityParams")._s0a9ee0146d0fa226cf5f522861f6da([this._776227573, "ExchangeRecord", i.Index]) || 0;
        c.text = i.BuyCnt - b, l.disabled = b >= i.BuyCnt, l.on(Laya.Event.CLICK, this, this.OnClickExchange, [i])
    }, e.OnClickExchange = function (e) {
        GetDataActivityParamsInterface().DoExchange({
            ExchangeInfo: e,
            ActivityType: this._776227573
        }, this.OnExchangeFinish.bind(this))
    }, e.OnExchangeFinish = function (e) {
        var t = GetDataTransfer()._s31a203589c4395257a9214becf0195(e.Rewards);
        GameCommon._s5d340979c9fcfd9445217570f410e4(this, t), this.OnUpdateView()
    }, e._se209e5d483fcc32f5f1d845d0c91b5 = function () {
        var e = global.$Api.QueryDataSource("DataGuild").GetValue("Contribution"),
            t = GetGuildInterface()._s95fcf4eec1203efb0214290ba46406(),
            a = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.GuildGXInfo, e, t);
        this.lab_MyContribute.text = a
    }
}();
var ActivityHarvestMain;
!function () {
    ActivityHarvestMain = function () {
        ActivityHarvestMain.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtn), this.btnFight.on(Laya.Event.CLICK, this, this.OnBtnFight), this.imgIcon.on(Laya.Event.CLICK, this, this.OnChangeProp), this.tabType.selectHandler = new laya.utils.Handler(this, this._OnBagTabChange), this.listRank.renderHandler = new Laya.Handler(this, this._OnUpdate), this.listRank.vScrollBarSkin = null
    }, Laya.class(ActivityHarvestMain, "ActivityHarvestMain", ActivityHarvestMainUI), ActivityHarvestMain.GetPreLoadResList = function (t) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ActivityHarvestMainUI.uiView, t)
    };
    var t = ActivityHarvestMain.prototype;
    t.OnShow = function (t) {
        this._713989164 = t, this._776227573 = t.Data.Id, this._248024307 = t.Data, this.tabType.selectedIndex = 0, this._sc9209ae0dd3fdb06533b36ec4474b1()
    }, t._sc9209ae0dd3fdb06533b36ec4474b1 = function () {
        if (this.imgBg.skin = this._248024307.BgImageBackward, this.imgTitle.skin = this._248024307.ImageTitle, this.imgMoveable.skin = this._248024307.ImageMovable, this.imgMoveable.y = this._248024307.ImageMovableAxisYOffset, this._OnBagTabChange(this.tabType.selectedIndex), this._2552118236) {
            var t = global.$Api.QueryDataSource("DataActivityParams")._s0a9ee0146d0fa226cf5f522861f6da([this._776227573, "Bags", this._2552118236.ItemId]);
            (!t || t.Count <= 0) && (this.imgIcon.destroyChildren(), this._2552118236 = null)
        }
    }, t._OnBagTabChange = function () {
        var t = this.tabType.selectedIndex, a = {}, i = global.$Sys.GetTableService().GetTable("activity_rank"),
            e = i.AtList[this._713989164.Data.AtlistStype].RankName;
        return global.$Cfg.Common.ActivityRankNameRelevance[e] ? (0 == t ? a.TableName = global.$Cfg.Common.ActivityRankNameRelevance[e].RankName[0] : 1 == t && (a.TableName = global.$Cfg.Common.ActivityRankNameRelevance[e].RankName[1]), void GetCmdProxy().DoCmd("GetRank", a, function (t) {
            var a = [];
            for (var i in t.RankList) {
                var e = t.RankList[i];
                a.push({Uid: e, UserInfo: t.UserInfos[e]})
            }
            this.listRank.array = a
        }.bind(this))) : void(this.listRank.array = [])
    }, t._OnUpdate = function (t, a) {
        var i = this.listRank, e = i.array[a], n = e.UserInfo, s = t.getChildByName("labInfo");
        s.text = jasmin._se91cf955e91eaa1aa510d4335edd4a(gLanguage.RankInfo, n.Rank, n.UserData.Name, n.Score)
    }, t.OnBtnFight = function () {
        return this._2552118236 ? void this._OnUseTween(function () {
            GetDataActivityParamsInterface().DoUse({
                ItemId: this._2552118236.ItemId,
                ActivityType: this._776227573
            }, function (t) {
                var a = GetDataTransfer()._s31a203589c4395257a9214becf0195(t.Rewards);
                GameCommon._s5d340979c9fcfd9445217570f410e4(this, a), this._sc9209ae0dd3fdb06533b36ec4474b1()
            }.bind(this))
        }.bind(this)) : void GameCommon._sd701ab0ea7b927938ca76f91a4368c({Texts: ["未选择道具"], Colors: ["#ffffff"]})
    }, t._OnUseTween = function (t) {
        this.btnFight.disabled = !0;
        var a = new Laya.TimeLine, i = 645 - this._248024307.ImageMovableAxisYOffset;
        a.to(this.imgIcon, {
            x: this.imgMoveable.x,
            y: this.imgMoveable.y
        }, i, null, 0).to(this.imgIcon, {alpha: 0}, 1, null, 0).to(this.imgMoveable, {
            scaleX: 1.1,
            scaleY: 1.1
        }, 300, null, 0).to(this.imgMoveable, {scaleX: 1, scaleY: 1}, 300, null, 0).to(this.imgIcon, {
            x: 320,
            y: 674,
            alpha: 1
        }, 1, null, 0), a.play(), Laya.timer.once(i + 605, this, function () {
            this.btnFight.disabled = !1, t()
        })
    }, t.OnChangeProp = function () {
        GetGuiManager()._s2e22e694b9852084df200bc86f9340("ActivityHarvestShop", {
            Data: this._713989164.Data,
            Index: 1,
            OnCallback: this._OnSelectProp.bind(this)
        })
    }, t._OnSelectProp = function (t) {
        this._2552118236 = t, this.imgIcon.destroyChildren();
        var a = GetItemIconFactory()._sa41389620ae6bec260fd42ef4289e0({
            Id: t.ItemId,
            Width: this.imgIcon.width,
            height: this.imgIcon.height,
            NoShowDet: !0,
            NoBcg: !0
        });
        this.imgIcon.addChild(a)
    }, t.OnCloseBtn = function () {
        GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("ActivityHarvestType", this._713989164)
    }
}();
var ActivityHarvestReward;
!function () {
    ActivityHarvestReward = function () {
        ActivityHarvestReward.super(this), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtn), this.tabType.selectHandler = new laya.utils.Handler(this, this._OnBagTabChange), this.panel_ActItem.vScrollBarSkin = null
    }, GameCommon._s06bc1af507ebc0f5390d44bd8481b9(ActivityHarvestRewardUI, ["item", "box_Item"]), Laya.class(ActivityHarvestReward, "ActivityHarvestReward", ActivityHarvestRewardUI), ActivityHarvestReward.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(ActivityHarvestRewardUI.uiView, e)
    };
    var e = ActivityHarvestReward.prototype;
    e.OnShow = function (e) {
        this._713989164 = e, this._776227573 = "harvest", this.tabType.selectedIndex = 0, this._OnBagTabChange()
    }, e._OnBagTabChange = function () {
        var e = 136;
        if (this.vBox_ActItem.destroyChildren(), 0 == this.tabType.selectedIndex) {
            var t = global.$Sys.GetTableService().GetTableRecord("harvest_relative_activity_rankreward", this._776227573);
            this._ShowPersonalReward(t, e)
        } else if (1 == this.tabType.selectedIndex) {
            var t = global.$Sys.GetTableService().GetTableRecord("harvest_relative_activity_guild_rankreward", this._776227573);
            this._ShowGuildReward(t, e)
        }
    }, e._ShowPersonalReward = function (e, t) {
        for (var a in e) {
            var i = e[a], r = ActivityHarvestReward._prefabs.item, n = Laya.View.createComp(r),
                d = n.getChildByName("img_RankName");
            d.skin = i.RankingPath;
            var s = n.getChildByName("img_IconBg"), l = s.getChildByName("vBox_Icon"),
                o = GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(l, i.Reward, 4, 10, null, {UseEff: !0});
            n.height = o.height + t, n.x = null, n.y = null, this.vBox_ActItem.addChild(n)
        }
    }, e._ShowGuildReward = function (e, t) {
        var a = ActivityHarvestReward._prefabs.box_Item;
        for (var i in e) {
            var r = e[i], n = ActivityHarvestReward._prefabs.item, d = Laya.View.createComp(n),
                s = d.getChildByName("img_RankName");
            s.skin = r.RankingPath;
            var l = d.getChildByName("img_IconBg"), o = l.getChildByName("vBox_Icon");
            o.sortItem = function (e) {
            };
            var h = Laya.View.createComp(a), v = h.getChildByName("img_GuildOfficeText");
            v.skin = global.$Cfg.Common.GuildSprintRank[0], h.centerX = 0, o.addChild(h);
            var c = new Laya.VBox;
            c.left = 0, c.right = 0;
            GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(c, r.Reward, 4, 10, o.width, {UseEff: !0});
            o.addChild(c);
            var m = Laya.View.createComp(a), v = m.getChildByName("img_GuildOfficeText");
            v.skin = global.$Cfg.Common.GuildSprintRank[1], m.centerX = 0, o.addChild(m);
            var c = new Laya.VBox;
            c.left = 0, c.right = 0;
            GameCommon._s9f2c2dd0ad695729bd3d4fdb2a23ae(c, r.Reward2, 4, 10, o.width, {UseEff: !0});
            o.addChild(c), o.space = 20, o.changeItems(), d.height = o.height + t, d.x = null, d.y = null, this.vBox_ActItem.addChild(d)
        }
    }, e.OnCloseBtn = function () {
        this.close()
    }
}();
var GuildMembersRank;
!function () {
    GuildMembersRank = function () {
        GuildMembersRank.super(this), this.btn_Close.on(Laya.Event.CLICK, this, function () {
            GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("GuildMembersRank")
        }), this.listGuild.renderHandler = new Laya.Handler(this, this.OnListGuildUpdateItem), this.listGuild.vScrollBarSkin = ""
    }, Laya.class(GuildMembersRank, "GuildMembersRank", GuildMembersRankUI), GuildMembersRank.GetPreLoadResList = function (e) {
        leo.CommFunc._scb7af5c43b4d5de44be6273375bc19(GuildMembersRankUI.uiView, e)
    };
    var e = GuildMembersRank.prototype;
    e.OnShow = function (e) {
        this._4161222688 = e.RankParam.RankData, this._1340348542 = e.RankParam.SType % 10, this._1614568200 = e.GuildId, this.OnUpdateView()
    }, e.OnUpdateView = function () {
        this.labMyInfo.text = gLanguage.RankScoreText[this._1340348542] + "：", this.labGuildInfo.text = gLanguage.RankScoreText[this._1340348542];
        var e = this._4161222688.UserInfos[this._1614568200];
        if (e) {
            this.labGuildName.text = e.UserData.Name, this.labMyValue.text = e.Score, this.listGuild.visible = !0;
            var a = e.UserData.MembersContribution, t = [];
            for (var i in a) t.push({Uid: i, Contribution: a[i].Contribution, Name: a[i].Name});
            t.sort(function (e, a) {
                return a.Contribution - e.Contribution
            });
            for (var n = 0; n < t.length; n++) t[n].Rank = n + 1;
            this.listGuild.array = t
        } else this.labGuildName.text = "无", this.labMyValue.text = "0", this.listGuild.visible = !1
    }, e.OnListGuildUpdateItem = function (e, a) {
        var t = (this.listGuild, this.listGuild.array[a]), i = e.getChildByName("labScore"),
            n = e.getChildByName("labName"), l = e.getChildByName("sprRank"), i = e.getChildByName("labScore"),
            n = e.getChildByName("labName"), l = e.getChildByName("sprRank");
        if (n.text = t.Name, n.on(Laya.Event.CLICK, this, this._PlayerInfo, [t.Uid]), i.text = t.Contribution, l.destroyChildren(), t.Rank && t.Rank <= 3) var s = new Laya.Image(global.$Cfg.Common.RankIcon[t.Rank - 1]); else {
            var s = new Laya.Label(t.Rank || gLanguage.NoJoinRank);
            s.color = "#755848", s.fontSize = 23
        }
        s.centerX = 0, s.centerY = 0, l.addChild(s)
    }, e._PlayerInfo = function (e) {
        GetPalaceInterface().DoGetPlayerInfo(e, function (a) {
            a.Id = e, GetGuiManager()._s2e22e694b9852084df200bc86f9340("ChatPlayerInfo", a)
        })
    }
}();

function AppPreloadAsset(e) {
    var a = function () {
        gPreLoadEnd && (e(), Laya.timer.clear(null, a))
    };
    Laya.timer.loop(100, null, a)
}

function IsDebug() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "debug"),
        n = GetServerInfoInterface().GetValue("ServerSetting"), t = !!n && n.Debug;
    return 1 == a || t
}

function IsGm() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "gm"),
        n = global.$Api.QueryDataSource("DataBase").GetValue("UserType");
    return 1 == a || 90 == n
}

function GetVType() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "vtype");
    return a
}

function IsTestMode() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "testmode");
    return 1 == a
}

function GetGuideOn() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "guide");
    return !a || 1 == a
}

function IsOffLine() {
    return "0" == GetVType()
}

function GetLogin() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "Login");
    return 1 == a
}

function GetInspection() {
    var e = GetVersionCfgManager().GetValue("Inspection");
    if (jasmin._s2005e5016e164fe57540f2ee806320(e)) return e;
    var a = window.location.search, n = jasmin._s5e7fe484a029675983b47f040fc285(a, "inspection");
    return 1 === n || "1" === n
}

function IsStrict() {
    if (GetInspection()) return !0;
    var e = GetVersionCfgManager().GetValue("Strict");
    return !!e
}

function GetGameParam(e) {
    var a = window.location.search;
    return jasmin._s5e7fe484a029675983b47f040fc285(a, e)
}

function GetSIp() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "sip");
    return a
}

function GetFrameType() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "ftype");
    return !!a
}

function GetGuideSystem() {
    var e = window.location.search, a = jasmin._s5e7fe484a029675983b47f040fc285(e, "guide");
    if (jasmin._s2005e5016e164fe57540f2ee806320(a)) return "0" !== a;
    var n = GetVersionCfgManager().GetValue("Guide");
    return !jasmin._s2005e5016e164fe57540f2ee806320(n) || n
}

function InitLaya() {
    Laya.init(640, 1138, Laya.WebGL), Laya.MouseManager.multiTouchEnabled = !1, Laya.stage.alignV = Laya.Stage.ALIGN_MIDDLE, Laya.stage.alignH = Laya.Stage.ALIGN_CENTER, "undefined" != typeof JsBridgeNative || window.conch ? Laya.stage.scaleMode = "exactfit" : Laya.Browser.onMobile ? Laya.stage.scaleMode = laya.display.Stage.SCALE_SHOWALL : Laya.stage.scaleMode = laya.display.Stage.SCALE_SHOWALL, Laya.stage.bgColor = "#ffffff", Laya.stage.frameRate = Laya.Stage.FRAME_MOUSE, Laya.alertGlobalError = !0
}

function InitLoadManager() {
    function e(e, a, n, t) {
        var o = t && t.LoadMode, r = t && t.PushScene;
        GetLoadManager()._s525e39e94cf6c7657c803ecd79c28f(e, a, n, o, r)
    }

    GetLoadManager()._s98b218d2a431f07858d013c5ce5b61("LoadingFrame", function (e, a, n) {
        if (0 == _.size(e)) return void(a && a());
        var t = {OnProgress: null}, o = {
            Skin: {
                LoadingImg: {skin: "res/ui/loading/loading_up.png", centerX: 0, centerY: 0},
                Progress: {centerX: 0, centerY: 0}
            }, Listner: t
        };
        o.Delay = 300, "PopInfo" !== n && GetGuiManager()._s2e22e694b9852084df200bc86f9340("LoadingDialog", o, null, {
            isModal: !1,
            useMgrEffect: !1
        }), Laya.stage.updateZOrder();
        var r = [], i = [];
        for (var l in e) {
            var g = e[l];
            jasmin._sff1822038f0e0ac263347ab39aae4d(g) && g.handler ? i.push(g) : r.push(g)
        }
        var u = _.size(r) + _.size(i), s = function () {
            "PopInfo" !== n && GetGuiManager()._sdfe99ac092cf7083e4732bdb919ef8("LoadingDialog"), a && a()
        };
        if (0 == u) return void s();
        var c = 0, d = function () {
            c++, t.OnProgress && t.OnProgress(c / u), c >= u && Laya.timer.frameOnce(3, null, s)
        };
        _.each(r, function (e) {
            Laya.loader.load(e, Laya.Handler.create(this, function () {
                c >= u || d()
            }))
        }), _.each(i, function (e) {
            c >= u || e.handler(function () {
                d()
            })
        })
    }), GetLoadManager()._s98b218d2a431f07858d013c5ce5b61("LoadingScene", function (e, a, n, t) {
        t ? GetGuiManager()._s768408cac808778482f4ce68b7fb6b("LoadResView", {
            Res: e,
            OnLoadComplete: a
        }) : GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("LoadResView", {Res: e, OnLoadComplete: a})
    }), GetLoadManager()._s46ee852b9093c1bfdad7c5dbfa8387("LoadingFrame"), GetLoadManager()._s45e2e170b0ec99126fa80d6c1b0264("FightUI", "LoadingScene"), GetGuiManager()._s0f007901515d5f6422609d20ad7292(e)
}

function InitLayaStat() {
    IsDebug() && (Laya.Stat.fullScreenEnabled = !0, Laya.Stat.mouseThrough = !0, Laya.Stat.show(0, 0), gLayaStatShow = !0)
}

function InitElse() {
    window.GetStorage = jasmin._s1a533d19f32767fb032c0d5565ac3b(Leo.Storage), window.GetReporter = jasmin._s1a533d19f32767fb032c0d5565ac3b(Leo.Reporter), window.AssetManager = game.AssetManager, window.GetItemIconFactory = game.GetItemIconFactory, window.Browser = Laya.Browser, window.NetCmdDo = game.NetCmdDo, window.CmdProxy = game.CmdProxy, window.LocalCmdDo = game.LocalCmdDo, window.GetCmdProxy = jasmin._s1a533d19f32767fb032c0d5565ac3b(CmdProxy), Leo.GetDialogManager()._se2a2666a0dff50e36bf19e57c96f93({
        isModal: !0,
        closeOnSide: !1,
        useMgrEffect: !1,
        popupCenter: !0,
        closeEffect: function (e, a) {
            if ("LoadingDialog" == e.__className) return void a();
            var n = Laya.Tween.to(e, {
                x: Laya.stage.width / 2,
                y: Laya.stage.height / 2,
                scaleX: 0,
                scaleY: 0,
                alpha: 0
            }, 150, Laya.Ease.strongOut, Laya.Handler.create(null, a));
            return n
        },
        popupEffect: function (e, a) {
            var n = Laya.Tween.from(e, {
                x: Laya.stage.width / 2,
                y: Laya.stage.height / 2,
                scaleX: 0,
                scaleY: 0,
                alpha: 0
            }, 150, Laya.Ease.backOut, Laya.Handler.create(null, a));
            return e.alpha = 0, n
        }
    });
    for (var e = ["System", "World", "Team", "Private"], a = 0; a < e.length; a++) {
        var n = {};
        n.Name = e[a], n.Is_private = "Private" == e[a], n.Cache_count = 50
    }
    GetFlowLog().Init(function () {
    } || jasmin.Info), LayaPatch.Enable_LoadErrorHint(IsDebug())
}

function InitDirtyWord(e) {
    var a = g_table.dirty_word_array;
    a = a.concat(gLanguage.ShieldWord), Leo.GetDirtyWordsFilter()._sa3c8a04b9b659550c86b19ec630f97(a), logger.info("InitDirtyWord Complete!"), e()
}

function LoadTableRes(e) {
    e()
}

function InitLoadBitmapFont(e) {
    function a(e, a, n) {
        var t = new Laya.BitmapFont;
        t.loadFont(e, new Laya.Handler(this, function (e) {
            e.setSpaceWidth(10), Laya.Text.registerBitmapFont(a, e), n()
        }, [t]))
    }

    var n = [];
    for (var t in global.$Cfg.Common.BitmapFontInfo) n.push(function (e, n, t) {
        a(e, n, t)
    }.bind(null, global.$Cfg.Common.BitmapFontInfo[t], t));
    async.waterfall(n, function (a, n) {
        a || (logger.info("LoadBitmapFont Complete!"), e())
    })
}

function InitGuideManager(e) {
    return GetGuideOn() ? (Leo.GetGuideSystem()._sdd29c22693c8cf90f80da4fde85242(function (e) {
        global.$Api.QueryDataSource("DataClient")._s505a2ac0cde720ef9099aed2ef7fc0("GuideStep");
        _.each(e, function (e, a) {
            global.$Api.QueryDataSource("DataClient")._s97bf4f9ee6daf249ae439a830d526b(["GuideStep", a], e)
        })
    }), Leo.GetGuideSystem()._s9809e2bb7254e7cc9a235536ba8c17(function (e) {
        GetCmdProxy().DoCmd("RecordClientData", {Data: {GuideStep: global.$Api.QueryDataSource("DataClient")._s505a2ac0cde720ef9099aed2ef7fc0("GuideStep")}}, function (e) {
        }, {NoBlock: !0})
    }), Leo.GetGuideSystem()._sf3aea9b674e955e333147a839237ce(function () {
        return global.$Api.QueryDataSource("DataClient")._s505a2ac0cde720ef9099aed2ef7fc0("GuideStep")
    }), Leo.GetGuideSystem()._s4592767b9ca81fd13bdc16c16f5dd5(function () {
        var e = "" != GetDataBase().GetValue("PlayerName") && isLogin;
        return e
    }), GetGuideSystem() && GetGuideManager().Start(), logger.info("InitGuideManager Complete!"), void e()) : void e()
}

function InitGuiManager(e) {
    LayaPatch.Disable_WebGLImageMerageInAtlas(), LayaPatch.Disable_AutoBitmapReleaseSource(), GetGuiManager()._sec4252b7354fc97e3fc491b8502880("SwitchScene", {AutoReleaseSelf: !0}), GetGuiManager()._sec4252b7354fc97e3fc491b8502880("OpenDialog", {AutoReleaseSelf: !0}), GetGuiManager()._sa7e5997e33cdfbafa6a6c352e63072("LoadingDialog", {AutoReleaseSelf: !1}), GetGuiManager()._sa7e5997e33cdfbafa6a6c352e63072("ServerDialog", {AutoReleaseSelf: !1}), GetGuiManager()._sfdc12bf9252b41a84d49853b99d1b5("ResFilter", function (e) {
        var a = ["res/ui/map/z_denglong_2.png", "res/ui/map/z_denglong_1.png", "res/ui/common/z_image_13.png", "res/ui/common/z_image_36.png", "res/ui/common/z_knife_image.png", "res/ui/common/z_knife_image_1.png", "res/ui/bg/z_bg2.png", "res/ui/button/z_but_03.png", "res/role/createroles/z_guanzhi_1.png", "res/role/createroles/z_guanzhi_2.png", "res/role/createroles/z_guanzhi_3.png", "res/role/createroles/z_guanzhi_4.png", "res/role/createroles/z_guanzhi_5.png", "res/role/createroles/z_guanzhi_6.png", "res/role/createroles/z_guanzhi_7.png", "res/role/createroles/z_guanzhi_8.png", "res/role/createroles/z_guanzhi_9.png", "res/role/createroles/z_guanzhi_10.png", "res/role/createroles/z_guanzhi_11.png", "res/role/createroles/z_guanzhi_12.png", "res/role/createroles/z_guanzhi_13.png", "res/role/createroles/z_guanzhi_14.png", "res/role/createroles/z_guanzhi_15.png", "res/role/createroles/z_guanzhi_16.png", "res/role/createroles/z_guanzhi_17.png", "res/role/createroles/z_guanzhi_18.png", "res/role/createroles/z_guanzhi_19.png", "res/role/createroles/z_guanzhi_20.png", "res/role/createroles/z_guanzhi_21.png", "res/role/createroles/z_guanzhi_22.png", "res/role/createroles/z_guanzhi_23.png", "res/role/createroles/z_guanzhi_24.png", "res/role/createroles/z_guanzhi_25.png", "res/role/createroles/z_guanzhi_26.png", "res/role/createroles/z_guanzhi_27.png", "res/role/createroles/z_guanzhi_28.png", "res/role/createroles/z_guanzhi_29.png", "res/role/createroles/z_guanzhi_30.png", "res/role/createroles/z_guanzhi_31.png", "res/role/createroles/z_guanzhi_32.png", "res/role/createroles/z_nan_1.png", "res/role/createroles/z_nan_2.png", "res/role/createroles/z_nan_3.png", "res/role/createroles/z_nan_4.png", "res/role/createroles/z_nan_5.png", "res/role/createroles/z_nan_6.png", "res/role/createroles/z_nv_1.png", "res/role/createroles/z_nv_2.png", "res/role/createroles/z_nv_3.png", "res/role/createroles/z_nv_4.png", "res/role/createroles/z_nv_5.png", "res/role/createroles/z_nv_6.png", "res/role/createroles/z_shou.png", "res/role/createroles/z_shou_nan.png"];
        return _.each(a, function (a) {
            var n = e.indexOf(a);
            n != -1 && e.splice(n, 1)
        }), e
    }), GetGuiManager()._sfdc12bf9252b41a84d49853b99d1b5("ResAddUrl", function (e) {
        var a = [];
        _.each(e, function (e) {
            jasmin._sfa34d45503f490fd6e159ceeb03c36(e) && a.push(e)
        }), GetResCleaner()._s61689a8b14b149344e673893823dd2(a)
    }), GetGuiManager()._sfdc12bf9252b41a84d49853b99d1b5("ResDelUrl", function (e) {
        var a = [];
        _.each(e, function (e) {
            jasmin._sfa34d45503f490fd6e159ceeb03c36(e) && a.push(e)
        }), GetResCleaner()._s307b5e7d16216fe9f62003d295aa9d(a)
    }), logger.info("InitGuiManager Complete!"), e()
}

function InitLoad(e) {
    async.waterfall([LoadTableRes, LoadVersionCfg, function (e) {
        InitArtCfg(), Leo.ScaleButton._scaleTime = 50, Leo.ScaleButton._clickCd = 200, Leo.ScaleButton._sa66cfbf90d950b86cf1ccf805e993c(), Leo.ScaleButton._s001cbba761a9669dcdd1679b066359(global.$Cfg.Common.Audios.button_click), e()
    }, InitGuiManager, InitGuideManager, InitLoadBitmapFont, InitDirtyWord, InitVolume, InitClientTempData, InitOrderManager, InitSdk, SetKeyDownListener], function (a, n) {
        return a ? void jasmin.Error("Init Error!!!!!!!!!!!!!!!!!!!!") : (Laya.Text.langPacks = gLanguage, e(), void(gPreLoadEnd = !0))
    })
}

function InitIDataStorage(e) {
    IsOffLine() ? IData._sc7d6308c57a2ec6a092e8caab37a8b(new RheaLocalStorage) : IData._sc7d6308c57a2ec6a092e8caab37a8b(new RheaNetWorkStorage), jasmin.Info("InitIDataStorage Success!"), e()
}

function InitVolume(e) {
    var a, n = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("dataCfg");
    jasmin._s2005e5016e164fe57540f2ee806320(n) ? a = !jasmin._s2005e5016e164fe57540f2ee806320(n.volume) || n.volume : (GetStorage()._s54216acbc0200500c827232db13a75("dataCfg", {volume: !0}), a = !0), GetAudioHelper()._sf2bad9d1526e6378ff8d2a7f1660a1(!0), GetAudioHelper()._secde0f73f8b79188060e617b573ecc(1 == GetGameParam("OffSound") ? 0 : 1), a ? GetAudioHelper()._s09eb086732200ccddc4f8d1803c807() : GetAudioHelper()._sa89c4e70b85bed6a0eabc63a523bb8(), logger.info("Init Volume Complete!"), e()
}

function InitClientTempData(e) {
    var a = GetStorage()._s505a2ac0cde720ef9099aed2ef7fc0("TempData");
    a || GetStorage()._s54216acbc0200500c827232db13a75("TempData", {}), e()
}

function OnLogoScene() {
    InitIDataStorage(function () {
    }), InitLoad(function () {
        window.PreLoadJSView && (window.PreLoadJSView.OnClose && window.PreLoadJSView.OnClose(), window.PreLoadJSView.destroy(), window.PreLoadJSView = null), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("MainUI", null, {AutoReleaseSelf: !0})
    })
}

function onAssetLoaded() {
    var e = {OnLoadingCallback: null, OnPlayOverCallback: OnLogoScene};
    IsDebug() && (e.PlayTime = 500), GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("Leo.LoadingScene_Cat", e)
}

function InitGame(e) {
    InitLaya(), InitLoadManager(), InitLayaStat(), InitLeoDialogManager(), InitLayaExtendStat(), InitProtocolService(), InitElse(), e()
}

function StartGame() {
    Leo.GetFrameRateManager()._sc92df1c58315c1d144e03350f182fd(!0), GetGuiManager()._s9a54271706817c160cafccdbfddc85("Leo.LoadingScene_Cat", function () {
        window.loadingView && window.loadingView.loading(100), OnLogoScene()
    })
}

function LoadVersionCfg(e) {
    GetVersionCfgManager()._se5551f1d861b9b084a671b59e0b885("versioncfg.json", function () {
        logger.info("LoadVersionCfg Complete!"), window.GAME_CHANNEL && GetVersionCfgManager()._sdbb730f79fe415639ea2aec361dfd2("Channel", window.GAME_CHANNEL), e()
    })
}

function IsFilterDialog(e, a) {
    return _.indexOf(a, e.__className) !== -1
}

function SetServerName(e) {
    gServerName = e
}

function GetServerName() {
    return gServerName
}

function InitProtocolService() {
    GetProtocolRegister().Init({
        Protocols: [{ProtocolNo: 8224}, {
            ProtocolNo: 256,
            Params: "{0B4E8D13-1EC2-4fa9-B5B3-0FADA8EFF471}"
        }]
    })
}

function InitLeoDialogManager() {
    Leo.GetDialogManager().on("readyOpen", null, function (e) {
        IsFilterDialog(e, ["LoadingDialog", "HightLightNodeDialog", "GuideDialog", "LoadResView", "HightLightNodeDialogEx", "Leo.StarUpgradeDialog_SID", "StarUpgradeDialog_SID", "FloatPower_J", "PopInfo", "SayDialog"]) || GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_open)
    }), Leo.GetDialogManager().on("readyClose", null, function (e) {
        IsFilterDialog(e, ["LoadingDialog", "HightLightNodeDialog", "GuideDialog", "LoadResView", "HightLightNodeDialogEx", "HightLightNodeDialogXY", "FloatPower_J", "PopInfo"]) || (Leo.GetGuideSystem()._sd900aa372084b8f59701ad66c750cc(), e.mouseEnabled = !1, IsFilterDialog(e, ["SayDialog"]) || GetAudioHelper()._s49e05ea2a346f7219e10e07b6367d5(gCfg.Sound.UI.z_ui_open))
    }), Leo.GetDialogManager().on("open", null, function (e) {
        IsFilterDialog(e, ["LoadingDialog", "HightLightNodeDialog", "GuideDialog", "HightLightNodeDialogXY", "HightLightNodeDialogEx"]) || Leo.GetGuideSystem()._s4f0c1f41c3f51e35579dd1b601c82e()
    }), Leo.GetDialogManager().on("close", null, function (e) {
        "HightLightNodeDialog" != e.__className && "HightLightNodeDialogEx" != e.__className && "SayDialog" != e.__className && "HightLightNodeDialogXY" != e.__className && "GuideDialog" != e.__className && (e.mouseEnabled = !0, Leo.GetGuideSystem()._sd900aa372084b8f59701ad66c750cc())
    }), Leo.GetDialogManager().on("sceneopen", null, function (e) {
        Leo.GetGuideSystem()._s4f0c1f41c3f51e35579dd1b601c82e()
    })
}

function InitLayaExtendStat() {
    IsDebug() && Laya.Stat._canvas && Laya.Stat._s5518a1c87aa328d207803bdba5b274([{
        Title: "Effect:",
        OnGetValue: function () {
            return GetObjCounter("Effect")._s9398e58386eb524e3091345e42e4c7() + "/" + GetObjCounter("Effect")._s84bf534974021135e0c1a23c1245d2()
        },
        Color: "yellow"
    }, {
        Title: "Model:", OnGetValue: function () {
            return GetObjCounter("Model")._s9398e58386eb524e3091345e42e4c7() + "/" + GetObjCounter("Model")._s84bf534974021135e0c1a23c1245d2()
        }, Color: "yellow"
    }, {
        Title: "Bullet:", OnGetValue: function () {
            return GetObjCounter("Bullet")._s9398e58386eb524e3091345e42e4c7() + "/" + GetObjCounter("Bullet")._s84bf534974021135e0c1a23c1245d2()
        }, Color: "yellow"
    }, {
        Title: "ImageIcon:", OnGetValue: function () {
            return GetObjCounter("ImageIcon")._s9398e58386eb524e3091345e42e4c7() + "/" + GetObjCounter("ImageIcon")._s84bf534974021135e0c1a23c1245d2()
        }, Color: "yellow"
    }])
}

function InitSdk(e) {
    DeepSDK.VigorSdkAdapter.SetShowErrorInfoCallback(function (e) {
        var a = gLanguage.VigorServerErrorCode[e] || e;
        GetDataTransfer()._se80d4d9de68409f2fb71e3d22f3824({Labels: [a]})
    });
    var a = {};
    a = GetVersionCfgManager().GetValue("Channel") ? GetVersionCfgManager().GetValue("DeepCfg") : {
        SDKMap: {TestSdkAdapter: {}},
        FunctionCfg: {UserSysterm: "TestSdkAdapter", PaySystem: "TestSdkAdapter"}
    }, DeepSDK.SDKLoader._se5551f1d861b9b084a671b59e0b885(a, function () {
        e()
    })
}

function SetKeyDownListener(e) {
    if (!JsBridge || !Laya.Browser.onAndriod) return void e();
    var a = {KEY_BACK: 4}, n = JsBridge.Require("NativeUtil");
    n.SetKeyDownListener({}, function (e) {
        e.KeyCode == a.KEY_BACK && DeepSDK.GetUserSysterm().ExitGame()
    }), e()
}

function GetSkinRes() {
    var e = "res/effect/z_effect_logo.json", a = "res/ui/login/z_map_01.png", n = "res/ui/login/z_map_02.png",
        t = "res/ui/login/z_map_01.png", o = window.SKIN_NAME;
    return o && (e = "res_" + o + "/effect/z_effect_logo.json", a = "res_" + o + "/ui/login/z_map_01.png", n = "res_" + o + "/ui/login/z_map_02.png", t = "res_" + o + "/ui/loadview/bg.png"), {
        LoadViewBg: t,
        LogoEff: e,
        Login1Bg: a,
        Login2Bg: n
    }
}

function ReleaseMem() {
    "undefined" != typeof conch && conch.config && conch.config.getUsedMem() > conch.config.getAvalidMem() && leo.CommFunc._s089abe218170b4f3889474149412b4()
}

function InitOrderManager(e) {
    GetOrderManager()._sf7213675dc2f3807855c106f7107c7(GetOrderInterface().OnCreateOrder), GetOrderManager()._sd795110140ccdbf44396bb8a57c8cb(GetOrderInterface().OnPayOrder), GetOrderManager()._s44bc323a2b9cd635337cf2df62be65(GetOrderInterface().OnCheckOrder), GetOrderManager()._s2da05dc18496991e497d7a491e28e0(GetOrderInterface().OnGetOrderReward), e()
}

GuiManager.DEBUG = !1;
var GetResCleaner = jasmin._s9c6539554ec0a0ad3d80ff512e40b6(ResCleaner);
LayaPatch.Enable_LayaStat(), LayaPatch.Enable_ResEncode();
var RES_CRC_MAP;
LayaPatch.Enable_LoadWithCRC(RES_CRC_MAP);
var gPreLoadEnd = !1;
IsDebug() ? ASSERT = jasmin.Verify : ASSERT = jasmin.Assert, ASSERT || (ASSERT = function (e, a) {
    e || jasmin.Error(a)
});
var gLayaStatShow = !1, isLogin = !1, gServerName;
InitGame(1 == GetGameParam("TestBattle") ? function () {
    GetGuiManager()._s2ae4f6fc306e49e99425fd62e762eb("TestBattleScene")
} : 1 == GetGameParam("TestMode") ? function () {
    InitLoad(function () {
        jasmin.Info("进入测试模式"), TestMode._s64f7f34ebce64071cf00db34786e3c()
    })
} : StartGame), GetReportInfoManage()._s7f3f35a27c6b396f641081b8e39c28();